@echo off
setlocal EnableDelayedExpansion
title Clear Shatterlands cache
rem Put this .bat in the same folder as ShatterEngine2_reactive.py (or run it from there).
rem Your saved settings (shatter_prefs.json, shatter_settings_*.json) are NOT touched.

set "GAME=%~dp0"
echo.
echo  Clearing Shatterlands / ShatterEngine cache in: %GAME%
echo.

rem --- 1. close any running copy so nothing is held in memory or locked ---
for /f "tokens=2 delims=," %%P in ('wmic process where "name='python.exe' or name='pythonw.exe'" get ProcessId^,CommandLine /format:csv 2^>nul ^| findstr /i "ShatterEngine"') do (
    echo  Closing running game ^(PID %%P^)
    taskkill /F /PID %%P >nul 2>&1
)
for %%E in (ShatterEngine2_reactive.exe ShatterEngine2.exe ShatterEngine.exe) do taskkill /F /IM %%E >nul 2>&1

rem --- 2. terrain / mesh disk cache folder next to the game ---
for %%D in ("cache" ".cache" "shatter_cache" "shatterlands_cache" "mesh_cache" "terrain_cache") do (
    if exist "%GAME%%%~D" (
        echo  Removing %%~D
        rmdir /s /q "%GAME%%%~D"
    )
)

rem --- 3. custom cache folder, if SHATTERLANDS_CACHE_DIR is set ---
if defined SHATTERLANDS_CACHE_DIR if exist "%SHATTERLANDS_CACHE_DIR%" (
    echo  Removing %SHATTERLANDS_CACHE_DIR%
    rmdir /s /q "%SHATTERLANDS_CACHE_DIR%"
)

rem --- 4. compiled Python cache (this folder and below) ---
for /d /r "%GAME%" %%C in (__pycache__) do if exist "%%C" (
    echo  Removing %%C
    rmdir /s /q "%%C"
)

rem --- 5. GPU shader caches (rebuilt automatically on next launch; first start may be slower) ---
for %%G in ("%LOCALAPPDATA%\NVIDIA\GLCache" "%LOCALAPPDATA%\NVIDIA\DXCache" "%LOCALAPPDATA%\D3DSCache" "%LOCALAPPDATA%\AMD\GLCache") do (
    if exist "%%~G" (
        echo  Clearing shader cache %%~G
        del /s /f /q "%%~G\*" >nul 2>&1
    )
)

echo.
echo  Done.
pause
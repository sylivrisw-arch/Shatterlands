# ShatterEngine 2.0

An experimental voxel destruction engine and interactive physics test bench developed for **Shatterlands**. Build a shape, choose its material, and inspect how it breaks, burns, falls and settles.

Verified against `ShatterEngine2_reactive.py` on 15 November 2026 by source inspection. The GPU app and physics reproductions were not run for this documentation update.

## Features

- GPU-compute loose debris and instanced rendering; CPU rigid chunks, bonds and structural support checks.
- Flat terrain, cube, pillar and wall; dirt, steel, brick, glass and timber.
- Explode, Gun, Jerry can (throw an oil drum), Drop weight, Ram, Add debris, Torch and Pour oil tools.
- Placeable fireworks and a first-person camera with spectate and playable character modes.
- Reactive timber fire, embers, spilled oil and drum cook-off.
- Compact settings sidebar, live CPU/GPU diagnostics and cube-state inspection.
- Material textures, bloom and optional ray-traced lighting with material shine controls.
- JSON settings export and scene video/PNG recording.

## Run

Requires Python, pygame, PyOpenGL, NumPy, SciPy and hardware **OpenGL 4.3 compatibility**, including at least **9 compute shader storage blocks**. Loose debris has no CPU fallback; software renderers are rejected in normal use.

Run from this folder:

```powershell
python -m pip install pygame PyOpenGL numpy scipy
python .\ShatterEngine2_reactive.py
```

Optional packages:

```powershell
python -m pip install numba opencv-python
```

Numba accelerates CPU kernels. OpenCV enables MP4 recording; if it or the video writer is unavailable, recording falls back to numbered PNGs. NVIDIA GPU utilisation uses `nvidia-smi`; unavailable diagnostics show `N/A`.

`dev_tools/check_req.bat` checks and installs required and optional packages. It does not verify GPU capability. The cache-clearing helper can stop running engine processes and remove caches; inspect it before use. Neither helper is needed for a normal launch.

Launch options include `--size 1360x800`, `--max-debris 200000` (default buffer: 100,000), `--no-gl-checks` (disables per-call GL error reporting), and `--shots <folder>` (scripted screenshots, then exit).

## Controls

| Input | Action |
| --- | --- |
| Left click | Use selected tool; hold for Gun, Torch, Pour oil or Add debris |
| Tab | Open/close menu |
| W A S D / Shift | Move camera / boost speed; walk / run in character mode |
| Space | Pause/resume; jump in character mode |
| R | Reset scene and diagnostics history |
| C | Clear loose debris only when recycling is enabled (Keep debris off) |
| E / Q | Cycle material / shape and rebuild |
| G | Show/hide Live Diagnostics |
| Right-drag / middle-drag | Orbit / pan in normal view |
| Mouse wheel | Zoom, or scroll the hovered menu |
| Ctrl+click / Backspace | Inspect a debris cube / deselect it |
| V | Enter/leave a camera placed through Objects |
| Delete | Remove the placed camera |
| Right-click in camera view | Open camera menu: play, spectate, record or delete |
| Esc | Close the camera context menu, otherwise quit |

In character mode the mouse looks around and tools aim at the crosshair; Tab frees the cursor. The menu's **Clear debris** button clears debris regardless of the C-key restriction.

The nine tabs are **World, Physics, Cube state, Objects, Weapons, Export, Record, Controls, Settings**, arranged in three rows. Physics opens first. Top toolbar buttons also select materials and shapes.

## Settings and recording

**Export** saves `shatter_settings_<timestamp>.json` beside the script, with internal settings, readable values, weapon, hidden cube states and an optional camera pose. There is no general settings import. [PREFS.txt](PREFS.txt) documents defaults and project preferences; it is not loaded by the engine.

VSync is the exception to session-only settings: `shatter_prefs.json` stores it for the next launch. Other settings start from code defaults.

**Record** starts/stops capture into `recordings/` beside the script. Default output is 720p at 30 fps, with width following the window aspect ratio. Capture includes the scene before menus and overlays are drawn.

## Development status

This is an evolving test bench. Self-weight stress checks are disabled above **40,000 live cells** per fixed structure; complete disconnection can still detach material. The total terrain limit of **700,000 cells** can coarsen the requested detail.

G currently shows diagnostics only. Stress colouring and damage crack rendering remain in the source, but the normal scene draw call does not enable stress debug mode. Glass remains opaque, including when reflective lighting is enabled. GPU loose debris and CPU chunks use different solvers; the whole engine is not GPU physics.

The older audit is absent from this folder. Historical findings in [PREFS.txt](PREFS.txt) are a verification backlog, not freshly reproduced results for this script.

## License

The previous README stated MIT licensing for the engine. No `LICENSE` file is present in this folder; include and verify the full license before distribution.

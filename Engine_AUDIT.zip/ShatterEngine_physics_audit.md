# ShatterEngine physics and performance audit

Audited 16 November 2026: `ShatterEngine2_reactive(7).py`, the supplied standalone brick bench with an embedded `_ENGINE_SRC`. All source line numbers below refer to this exact attachment, including the embedded engine. This is an analysis, not an edited engine release.

## Scope and evidence

The application uses two different physics implementations:

- **CPU rigid chunks:** voxel occupancy, sampled contacts, a dense contact-space matrix and projected Gauss–Seidel/sequential impulses. Optional Numba accelerates the iterative solve, point probing and contact reduction.
- **GPU loose cubes:** OpenGL 4.3 compute shaders, resident SSBO state, linked-list spatial hashing, yawed-box SAT, three Jacobi-style contact passes and instanced drawing. This is not the Numba solver and not CuPy debris physics.
- **CPU reactive materials:** nominally 10 Hz NumPy updates over fixed structures. Optional CuPy concerns a connectivity-labeling fallback; SciPy takes precedence when available.

I extracted the relevant Python definitions with AST and exercised them without importing the UI. NumPy 2.3.5 and SciPy were available. Numba, pygame and OpenGL were unavailable. Consequently, the results below include actual CPU function tests and isolated timings, but **no compiled-Numba benchmark, gameplay FPS, GPU timing or visual stack-stability measurement**. GPU findings are source analysis. Timings are from this execution host, not the user's laptop.

## Priority order

| Priority | Finding | Evidence / consequence |
|---|---|---|
| P0 | Large chunks stop impact fracturing at the body cap | Reproduced: 27-cell chunk, 10 bodies, contact force 1,000× reference threshold, zero broken bonds. |
| P0 | Structure detachment bypasses the body cap | Reproduced: 12 detached chunks despite `MAX_LOOSE_BODIES = 10`. |
| P0 | Sustained-contact damage depends on substep count | Reproduced: same force and duration gives damage 0.24 / 0.48 / 0.72 at 1 / 2 / 3 substeps. |
| P1 | Unbounded GPU substeps and historical size extrema | Fine debris or old recycled sizes can permanently increase dispatch cost until reset. |
| P1 | Connectivity and component extraction can spike | SciPy switches from grid labeling to graph construction after bond damage; per-component full-grid masks add further cost. |
| P1 | CPU chunks are stepped at different effective times | Body A completes all its substeps before B starts, while already changing B's velocity. |
| P1 | Visual changes invalidate collision uploads | Burn tint, oil staining, glow and heat-view changes increment `mesh_ver`, used by GPU occupancy caching. |
| P2 | Contact persistence, friction and penetration handling | No warm start; square friction limit; one deepest-contact position correction; contact sampling can miss thin crossings. |
| P2 | Thermal model is bounded but not energy-consistent across materials | Capacity-weighted energy rises in an isolated two-cell conduction test. |

P0 means fix before tuning thresholds or increasing iteration counts. P1 means a likely scaling or consistency problem. P2 means a numerical/physical quality issue or a targeted optimization.

## 1. Constraint solver and stability

### What is implemented correctly

`_nb_solve` (line 80) and the NumPy/Python loop in `RigidBody._solve` (line 11243) use the same accumulated-impulse projection. The normal impulse is clamped nonnegative, and updates use the **change** in accumulated impulse. `fastmath=False` is an appropriate choice for this solver.

The matrix includes both the active body's mass/inertia and a dynamic partner's contribution to that partner's contact rows. Equal-and-opposite impulses are applied to partners. A direct equal-mass, central-contact test preserved total linear momentum exactly in floating-point output and changed velocities from −2/0 to −1/−1.

Executing the extracted `_nb_solve` body as ordinary Python and the actual fallback on one four-contact case produced a maximum state/normal-impulse difference of zero. That establishes algebraic parity for the tested case, not compiled-code parity for every layout or scene.

### 1A. Solve islands together instead of stepping complete bodies sequentially

`StructureManager.update` (line 11835) calls `b.step(...)` for each awake body. Each `step` advances that body's full timestep, and each solve can immediately change another body's velocity. Later bodies then integrate from an earlier pose using already modified velocities. The same pair may also be rediscovered and solved from the opposite side with fresh impulses. Repeated pair processing is not necessarily a literal doubled impulse, because closing speed may already be removed, but it creates order-dependent and inconsistent contact histories.

Recommended integration order, within each fixed physics tick:

1. Choose substeps consistently for each connected contact island.
2. Apply forces and predict/update all island members on the same substep clock.
3. Generate each unordered body pair once and build manifolds.
4. Solve all island constraints, updating both bodies after every impulse.
5. Perform position correction, update all poses and decide island sleep.

The current main loop already has a 1/60 s accumulator (`FIXED`, line 6458). Keep it. The missing consistency is inside the rigid-body update. The current reduction of CPU substeps as awake-body count grows also changes contact accuracy and damage behavior under load. Prefer stable physical steps and explicit limits on fracture/render work.

### 1B. Warm start persistent manifolds

Both solve paths reset `lam` to zero on every call. Resting stacks repeatedly relearn their support impulses, and contact reduction can choose different points on successive steps. Cache contacts using body pair, surviving cell/face identity and local anchors; invalidate contacts when their geometry disappears or the normal changes too much. Store friction as a world-space tangential impulse or transform it into the refreshed tangent basis.

For sustained loads when substep duration changes, start with:

```python
lam = cached_lam * (h / previous_h)
# Before iterations, update the residual to include the seeded impulses.
jv += K @ lam
```

Apply the final total impulse to velocities once, or warm-start velocities and apply only subsequent deltas; do not do both. Do not treat a cached restitution impact as a new bounce every frame.

Erin Catto's [Solver2D discussion](https://box2d.org/posts/2024/02/solver2d/) explains accumulated impulses, warm starting, substeps, block solving and separate position solvers. These techniques are relevant to this solver, although this engine is 3D and cannot copy a 2D manifold implementation unchanged.

### 1C. Square friction over-resists diagonal sliding

The code independently limits both tangent components to `±mu * lambda_n`. Consequently:

\[
\|\lambda_t\|_2 \le \sqrt{2}\,\mu\lambda_n
\]

instead of a circular Coulomb limit `||lambda_t|| <= mu*lambda_n`. An isolated one-contact test with `mu=0.7`, normal impulse 1 and diagonal sliding produced tangential magnitude **0.98995**, against the circular limit **0.7**: 41.4% excess. This is a friction-pyramid approximation rather than an error in normal impulse accumulation, but it creates directional grip.

Use a two-component update followed by disk projection. The following illustrates the replacement tangent block with NumPy arrays; mirror the same 2×2 arithmetic in `_nb_solve` and include its delta in the convergence measure:

```python
rows = np.array([m + i, 2*m + i])
old = lam[rows].copy()                    # lam must be an ndarray
Ktt = K[np.ix_(rows, rows)]
trial = old - np.linalg.solve(Ktt, jv[rows])
limit = mu * lam[i]
trial *= min(1.0, limit / max(np.linalg.norm(trial), 1e-12))
delta = trial - old
lam[rows] = trial
jv += K[:, rows] @ delta
moved += np.abs(delta).sum()
```

This is a practical cone-limited block update, not a claim of an exact full cone-complementarity solution. Keep material-pair friction separate from gameplay looseness. `_S_MU` exists, but CPU collision friction currently comes from global `WOBBLE['friction']`; GPU coefficients are also mostly global/hard-coded.

### 1D. Position correction is too asymmetric

The solver intentionally adds no separating velocity for existing overlap. This avoids artificial launch energy, but `step` (line 11361 onward) corrects only the deepest contact by moving **self**, at most 0.03 world units per substep. It neither rotates the chunk out nor gives a dynamic partner a mass-weighted share. Opposing normals in a dense cluster can alternate which contact wins.

Use a separate iterative position solver, with per-contact inverse mass and inertia on both ends. For penetration `d`, slop `s`, correction fraction `beta` and contact effective inverse mass `k_n`:

\[
\lambda_p = \beta\max(d-s,0)/k_n
\]

Apply positional and angular changes to both bodies, recomputing local-anchor separation. Start with `beta` around 0.1–0.3 and cap correction relative to cell size. This correction must not count as physical impact damage. Keep physical velocities separate from position correction.

The absolute slop `STRUCT_SLOP = 0.03`, fixed 0.12 contact-selection band and 0.12 support-SVD threshold should be checked against cell size and object dimensions. These values behave very differently for centimetre voxels and large blocks.

### 1E. Contact normals, reduction, tunneling and sleep

- **Buried cell seams:** `GridObject.probe` and `_nb_probe` fall back to the nearest cell face if all six faces are buried. That face is not an external surface. Reproduced at the centre of a solid 3×3×3 grid with 0.5-unit cells: reported depth 0.25, actual box exit distance 0.75. Use a surface-distance query, directional boundary traversal or cached distance field for deep overlaps. Never use internal seams as ordinary shallow contacts.
- **Sampled collision misses:** contacts come from corners/face centres inside the other grid, not a continuous swept convex query. A point segment crossing a 5 cm slab can have both endpoints outside. Add swept AABBs and CCD for fast tools/chunks; conservative advancement or swept voxel traversal is appropriate. Include rotational travel `|omega|*radius` in any travel bound. Also test edge–edge crossings where surface sample points are inadequate.
- **Reduction:** ten points are retained globally, not per partner and normal cluster. A deep wall contact can displace useful floor contacts. Keep persistent manifolds per pair, group normals, then reduce to a stable support polygon with a bounded total budget.
- **Restitution:** the default CPU coefficient is zero and bouncing only activates below normal speed −1.5. The threshold suppresses resting micro-bounces. For nonzero restitution, compute its target from pre-impact speed once per impact. Guard speculative contacts against premature bouncing and avoid using position-correction impulses as impacts.
- **AABB cache:** `_sync()` changes orientation/inertia but does not clear `_aabb`. `step` clears it at completion, which limits the normal-loop exposure, but intermediate or external pose queries can be stale. A direct pose/sync test confirmed stale bounds. Invalidate bounds whenever position, orientation or local bounds change.
- **Sleep:** CPU support is inferred from contact-point spread rather than a ground-connected support graph and gravity direction. GPU sleep can persist without support: sleeping cubes skip gravity, and loss of support alone does not wake them. Revalidate contacts/island support when an obstacle moves or disappears. Allow legitimate frictional wedges, but require their contact set to remain valid.

The fixed absolute `moved < 1e-5` stopping test is an impulse-change heuristic. Measure normal complementarity residuals in velocity units, use absolute-plus-relative tolerances, and retain an iteration ceiling. A small impulse change by itself is not a scale-independent convergence guarantee.

## 2. Impact bonds, connectivity and cell fracturing

### 2A. Fix both body-cap bugs first

In `_apply_impacts` (line 11669), section fracture requires `len(self.bodies) < MAX_LOOSE_BODIES`. Later, large chunks are excluded from individual cell shedding. At the cap, neither route operates. My 27-cell test recorded `idmg = 1.2`, all 54 bonds intact and `broke = 0`, despite force 1,000× the reference threshold.

Let the fracture decision depend on load/material, then apply the representation budget to the results:

```python
# Do not include the body-count condition here.
if obj.live_count >= FRACTURE_MIN_CELLS and obj.frac_cd <= 0.0:
    cuts = self._stress_fracture(obj, loads, scale)
    # Split components; keep important chunks and convert excess to debris.
```

Separately, `Structure._detach` appends rigid chunks without a manager-level cap at the end of the structural-detachment batch. Twelve independently detached 8-cell chunks produced twelve bodies. Enforce the cap after all detachment producers and again after later fracture producers, while keeping tools exempt as intended.

Do not silently change a piece's physical size or mass during conversion. `_release` (line 11736) takes no source cell-size argument and spawns with `debris_cell_size()`; its collected `cs_l` values in `_apply_impacts` are unused. Changing debris size/detail can therefore change released volume and mass. Preserve source size or aggregate mass explicitly, and carry the parent's linear plus angular point velocity.

### 2B. Separate shock failure from fatigue

`step` turns normal impulse into force with `F = lambda_n / h`. `_apply_impacts` then adds `0.6 * sum(R)` damage per invocation, without multiplying by elapsed time. The direct sustained-force test at `R = 0.4` produced:

| Substeps over the same interval | Accumulated damage |
|---:|---:|
| 1 | 0.24 |
| 2 | 0.48 |
| 3 | 0.72 |

Keep two distinct failure mechanisms:

```python
# Persistent load damage; fatigue_tau is a tunable time constant.
damage += (h / fatigue_tau) * max(0.0, R - fatigue_start)**fatigue_power

# New impact only: integrate physical contact impulses over the collision.
impact_J += physical_normal_impulse
```

Use force/stress for sustained yield and impulse or dissipated contact energy for impact fracture. An instantaneous collision peak `lambda/h` naturally depends on how the impact is resolved; a smaller integration step is not a physical contact-duration model. If force-based impact thresholds are retained, use a defined contact compliance or measurement window and calibrate it.

`_stress_fracture(..., 1.0 / nsub)` further divides the already estimated contact force. For a steady load, that explicitly lowers section load as substeps increase; for an idealized single impulsive hit it can partly cancel the `1/h` effect. Choose a physical measurement model instead of mixing these two meanings. Also avoid recording the same collision twice through opposite-body visits or geometry-retry solves.

### 2C. Connectivity is a major burst cost

`_label_scipy` (line 10258) has a useful fast path when bonds match all live-cell adjacency. Once even one bond differs, it builds COO/CSR arrays and runs graph connected components. The fallback `_label_cells_xp` repeatedly copies and sweeps the full label grid; a long thin or winding component can require many passes.

Median isolated labeling times, with warm-up and repeated calls:

| Cells | SciPy, intact bonds | SciPy, one broken bond | NumPy propagation, one broken bond |
|---:|---:|---:|---:|
| 4,096 | 0.064 ms | 0.253 ms | 1.004 ms |
| 32,768 | 0.232 ms | 1.347 ms | 11.051 ms |
| 110,592 | 0.719 ms | 4.995 ms | 56.359 ms |

These tests are dense cubes with only one deleted bond. They do not include mesh rebuilding, detachment or contact generation. The >40,000-cell self-weight shortcut does not eliminate labeling required for detachment.

Recommended changes:

- Implement a compiled grid BFS or union-find rebuild over live cells and surviving bonds. Ordinary union-find does not support deletions by itself; rebuild affected components or use chunk-level connectivity with local rebuilds.
- Store stable topology versions and reuse connectivity only when the bond/cell graph really has not changed. Temporary plane cuts need their own labeling result.
- `_split_body` (line 11985) computes `(lab == label).sum()` for every label, then allocates another full-grid mask for each piece. This is O(component_count × grid_volume). Count with `bincount`/`unique(return_counts=True)`, group active indices once and crop each child to its own bounds. `_piece_of` currently also starts with parent-sized arrays.
- When only ground reachability is needed, flood from anchors and find unreachable cells; label the free region only if separate bodies must be created.
- Batch cell removals before geometry rebuilding and batch spawn uploads rather than processing each cell independently.

### 2D. Support budgets and physical discontinuities

`STRUCT_BUDGET_S = 0.0025` is applied per structure. A single `check_plane` call can exceed it, and `_detach` runs outside that debt-controlled loop. Multiple structures multiply the budget. `BOND_PER_STEP` likewise applies to a pass, not the entire game tick, and section cuts can sever many bonds at once.

Use one manager-level deadline and a fair queue for support/fracture jobs. Make large connectivity jobs resumable or perform them against immutable snapshots off-thread; publish completed topology changes coherently and reject results whose topology version is stale. Simply moving shared writable arrays to a worker would introduce races.

Structures above 40,000 live cells skip self-weight cracking. That is a gameplay shortcut: increasing detail can disable collapse even when physical dimensions and material stay the same. Replace the hard cell-count switch with a coarse structural graph or cluster-level load model. The local support window also marks all cut-window boundary faces as anchored, which can overestimate support. Exact `_detach` connectivity helps catch wholly disconnected sections, but does not make the local stress estimate exact.

Fixed-structure stress already uses the weaker endpoint's material strengths and face area. Loose-body section fracture instead uses a body-wide mean bond factor and force norm per section. A strong steel region can inflate the capacity of a weak joint elsewhere. Sum capacities of the bonds actually crossing each section, account for endpoint damage and temperature, and distinguish normal tension/compression from tangential shear. For slender rotating chunks, evaluate bending moments as well as net section force.

## 3. GPU/CPU distribution and performance

### 3A. Keep resident GPU state; acknowledge one-way coupling

The SSBO layout and direct instancing avoid sending every cube position through Python each frame. Keep that architecture.

However, debris sees CPU bodies as moving obstacles, while debris contact impulses are never returned to those bodies. CPU chunk contacts do not include GPU cubes. A rubble pile therefore cannot physically support, brake or push a CPU chunk with a reciprocal reaction.

If that interaction matters, either move load-bearing participants into a shared solver or promote selected debris clusters to CPU rigid aggregates. Another option is GPU contact accumulation into per-body force/torque records with explicit delayed-coupling damping, accepting latency. Do not synchronously read every contact back to the CPU each substep. Purely cosmetic debris can retain the cheaper one-way behavior as an explicit game rule.

### 3B. Bound the dispatch workload without permitting tunneling

`GpuDebris.advance` (line 994) computes:

\[
N_s=\max(N_\text{requested},\lceil\Delta t\,v_\text{bound}/(0.4s_\min)\rceil)
\]

There is no upper work bound. Each substep has `integrate + 3 × (clear/build/count/solve) + sleep` = **14 dispatches**. With a 1/60 s tick, a speed bound of 80 and minimum cube size 0.05, that is 67 substeps or **938 dispatches in one tick**. GPU sleeps do not remove those slots from the collision kernels when any work remains.

`_min_size`, `_max_size`, launch and height extrema are tracked historically until reset, even after recycling/deletion. One obsolete tiny cube can retain a tiny travel bound; one obsolete large cube can retain an oversized hash cell size. Maintain active-slot extrema, preferably per size class, and update them on recycling.

Do not fix this solely by clamping substeps: that sacrifices collision correctness. Use swept/CCD handling for fast cubes, size classes or multilevel grids, and a clear policy for carrying simulation backlog or reducing visual work. Include moving-obstacle linear/angular speed and relative pair speed in conservative collision bounds. The current measured speed ignores values above a guessed ceiling, so it is not a mathematical upper bound in the presence of large collision-induced velocities.

### 3C. Reduce repeated SAT and improve hashing

There are 8,192 buckets and linked lists. At 100,000 slots, a uniform hash has an average roughly 12.2 entries per bucket before spatial clustering; each query visits 27 nearby cell hashes and traverses collisions. A large cube also makes `cellSize = 1.8 * historical_max_size` coarse for all smaller cubes.

Both `count` and `solve` recompute SAT for directed pairs in each of three iterations. An ordinary unordered pair can therefore receive up to twelve full SAT evaluations per substep, before static-grid tests. Each SAT includes up to 15 axes and repeated yaw transforms.

Profile candidate count, exact contacts, chain lengths and SAT tests per cube. Evaluate sorted integer cell keys with contiguous cell ranges, cached per-iteration contact records, yaw precomputation and tiered grids for mixed sizes. Choose grid cell/query range conservatively for each size tier. Rebuilding the grid after positional corrections is valid; reusing an old grid requires fat bounds or an explicit motion limit.

Add conservative per-obstacle world AABBs or a coarse obstacle grid before GPU voxel probing. `staticContacts` currently loops every obstacle, and a large debris cube against fine terrain can cover a large voxel box. Cache/exploit surface occupancy and use coarse-to-fine rejection.

The GPU solver averages corrections according to contact degree and contains settling clamps, extra ground grip and tip-off forces. These are useful gameplay stabilizers, but three Jacobi passes plus those clamps do not constitute a force-accurate heavy-stack solver. The post-solve vertical velocity clamp also changes momentum independently of reciprocal pair impulses. Loose cubes have fixed yaw and no dynamic angular velocity/inertia; their tipping is approximated by sliding forces.

### 3D. Separate collision, visual and pose versions

`_prepare_objects` (line 967) keys occupancy with `(id, mesh_ver, shape)` and repacks **all** object grids if any key changes. Heat glow, heat-map quantization, wood charring and oil staining increment `mesh_ver` without changing occupancy. This causes unnecessary occupancy upload and clears the global sleeping fast path.

Introduce versions with explicit consumers:

```python
# Cell occupancy or exposed collision faces changed:
o.topology_ver += 1

# Colour, tint, damage colour, glow or heat view changed:
o.visual_ver += 1

# Position/orientation changed:
o.pose_ver += 1
o._aabb = None
```

Use stable per-object buffer offsets and upload only dirty voxel ranges, including their face-neighbor halo. Pose updates need only metadata. Audit all writers rather than simply replacing the key with the current `visual_ver`. Material changes that preserve occupancy may still need material-property updates.

### 3E. Readback stalls, barriers and diagnostics

`_poll` (line 1056) dispatches counters and immediately calls `glGetBufferSubData`. Sixteen bytes can still wait for preceding GPU work. Polling occurs per simulated interval or from the UI, not strictly the four wall-time reads claimed in the class comment.

Use a 2–3-slot telemetry ring. After reduction/copy, insert a fence; on later frames consume only a signaled older slot. Keep a conservative speed bound while data is pending. Do not block merely to refresh a UI count, and do not re-use a slot while its writer is active.

The cube-state inspector is a different path: it reads the full 80-byte state per slot about 4 Hz, or 10 Hz with selection, plus selected-cube reads. At 100,000 slots that is 8 MB per snapshot, roughly 32–80 MB/s before CPU copies/classification, with potential synchronization stalls. Implement GPU state histograms and compact requested IDs; read full states only on explicit inspection.

`_run` currently uses shader-storage, vertex-attrib and buffer-update barrier bits after every kernel. The render shader reads cube state as an SSBO; it is not vertex attribute data. Use the barrier appropriate to the **next consumer**, keeping shader-storage visibility between dependent compute passes and buffer-update visibility before relevant API copies/readbacks. Keep essential grid-build/solve ordering. A memory barrier establishes visibility/order, whereas a fence is used to test completion. See [Khronos glMemoryBarrier](https://wikis.khronos.org/opengl/GLAPI/glMemoryBarrier) and [the OpenGL specification](https://registry.khronos.org/OpenGL/specs/gl/glspec46.core.pdf).

### 3F. Numba cache and fallback

The current startup warm-up and `cache=True, fastmath=False` are sensible. Kernels take mutable physical parameters explicitly; keep that design. Numba documents that cached globals act as constants and cache invalidation does not detect all cross-file changes: [Numba caching notes](https://numba.readthedocs.io/en/stable/developer/caching.html).

- Move stable kernels to a small normal module so editing the UI/embedded engine does not invalidate their cache through the giant source file.
- Use a persistent application cache rather than temp if cache survival across temp cleanup matters.
- Warm the exact dtype, contiguity and mutability signatures used by production. Record warmed signatures and backend status in profiles.
- Warm/disable kernels independently. The current single warm-up exception clears all three, even if just one fails.
- A later specialization or runtime failure is not guarded at the call sites. If adding fallback, catch expected backend failures narrowly and restore scratch input before retrying: `_nb_solve` mutates `jv` in place. Do not silently mask invalid geometry or non-finite physics data.
- Avoid `parallel=True` inside this Gauss–Seidel loop. Its rows are dependent. Parallelize independent islands or use a deliberately different solver.

## 4. Heat conduction, fire and oil

### 4A. Current conduction is bounded

`thermal_diffuse` (line 2643) uses simultaneous pair fluxes with a harmonic conductivity and caps each edge coefficient at 0.16. A cell has at most six neighbors, so outgoing coefficient sum is at most 0.96. With finite, nonnegative inputs, the conduction update is a convex combination and does not produce a new temperature extremum. Cooling uses a nonnegative exponential factor.

An extreme conduction-only test with very large `dt`/conductivity kept temperatures within the initial range; relative temperature-sum error was about 7.2e−8. Do not describe this implementation as an unstable unconstrained explicit Laplacian.

The cap does make heat transport depend on timestep when reached: excess intended conductivity is discarded instead of integrated in smaller steps. Normal default rates at roughly 0.1 s are well below the cap, so this is mainly a future tuning/high-dt limitation.

### 4B. Capacity-weighted energy and spatial scale need correction

`hcap` affects `_deposit_t` but not conduction. Pair flux subtracts and adds the same **temperature** increment. That preserves total temperature for conduction, rather than total thermal energy when capacities differ.

Two cells at temperature excess `[100, 0]`, capacities `[0.7, 1.4]`, conductivity 0.5 and `dt=0.1` became `[95, 5]`. Capacity-weighted energy rose from **70 to 73.5**, with cooling disabled.

Use per-cell thermal capacity `C_i` and face conductance `G_ij`:

\[
Q_{ij}=G_{ij}(T_j-T_i)\Delta t,\qquad
\Delta T_i=Q_{ij}/C_i,\quad \Delta T_j=-Q_{ij}/C_j.
\]

For physical coefficients, `C_i = rho_i * cp_i * cell_size**3` and `G_ij = k_harmonic * area / distance`. For a tuned game model, equivalent consistent capacities/rates can be calibrated to a reference cell size. The resulting homogeneous diffusion rate scales as `1/cell_size**2`; current `kc` values are fixed per second with no such scaling, so finer cells spread heat more slowly in world space.

Explicit integration should satisfy:

\[
\Delta t\max_i\left(\sum_jG_{ij}/C_i\right)\le\theta,\qquad \theta<1.
\]

Choose thermal substeps from that bound instead of clipping each face's physical flux. Use a coarse thermal grid, conservative remapping or an implicit method if fine spatial detail makes explicit conduction too expensive. A fixed 10 Hz outer material schedule need not mean one conduction substep.

### 4C. Preserve fire and temperature through fracture

`Reactive.update` uses `STRUCTS.structs`, not moving bodies. `_cut_body` and `_piece_of` do not copy `_T`, `_burn`, hot bounds or glow state. Detached hot steel or burning timber becomes a cold/unburning chunk, and GPU cubes show cold in heat view.

Transfer thermal fields with each extracted cell mask and crop them with the child. Extend source deposition/probing to object-local coordinates:

```python
local = (world_points - obj.frame_pos) @ obj.R - obj.corner
grid = np.floor(local / obj.cs).astype(np.int64)
```

The current source deposition and oil probes assume axis-aligned fixed structures. Simply adding rigid bodies to the iteration would heat the wrong cells. Decide whether tiny GPU debris carries temperature or is represented by aggregate heat/ember sources; conserve the heat removed from the parent according to that chosen approximation.

There is a second initialization gap: burning cells impose `FIRE_C` inside `_heat`, but `_heat` only runs when `_tb` already exists. A timber region burning via the burn system alone can lack `_T`/`_tb`. Ensure any active burn creates or extends its thermal region independently of external temperature deposition.

### 4D. Steel failure is probabilistic deletion, not melting

Hot steel is selected with a temperature-dependent probability and up to 14 cells are removed per object per reactive tick. There is no molten phase, latent heat, load-dependent yield or gradual thermal weakening of bond capacity. For the test bench this can be a useful visual damage rule; label it accordingly.

For mechanical softening, use a temperature-dependent capacity factor before deletion:

\[
s(T)=\operatorname{clamp}(1-a(T-T_0),s_\min,1),\qquad
F_\mathrm{capacity}(T)=s(T)F_\mathrm{capacity,reference}.
\]

Apply it to the actual crossing bonds in support and impact models. Choose the curve from the intended material model; the current game constants are not calibrated engineering material data. Add a phase fraction/latent-heat budget only if molten metal behavior is actually required.

Use `p = 1 - exp(-rate*dt)` for rate-based failures. Glass currently uses `p=0.6` per reactive invocation regardless of `dt`; an equivalent reference rate at 0.1 s is `-log(0.4)/0.1`. Separate persistent failure candidates from the per-frame removal/visual budget so the 14-cell cap does not silently become a detail-dependent material strength.

### 4E. Reactive workload and oil

The active temperature/burn boxes are a good optimization. A few distant sources can nevertheless make their union almost the full grid. Sparse active bricks with halos avoid sweeping a large empty region. Reuse flux, capacity and neighbor-count scratch arrays where topology is stable. Use axis projections for hot bounds instead of materializing every hot index when only min/max is needed.

Thermal deposition builds `sources × stencil` arrays, then sorts/uniques destination indices. The stencil radius is capped at three cells, so increasing source radius beyond that does not heat its full nominal sphere. Group sources by radius and spatial brick, process bounded batches, and cap total deposited energy per cell without losing source coverage. Keep the existing overlapping-source limit if it is an intended flame-temperature rule.

Timber spread samples at most 5,000 burning cells without compensating its spread contribution. Large burning populations therefore have fewer spread attempts per source. That is a material-behavior change under load, not only an effects reduction. Prefer updating active burn-front cells or a deterministic time-sliced queue. Keep smoke/ember render limits independent of authoritative burn propagation.

Oil is a surface-runner/puddle model with material speed/soak factors, not a volume-conserving fluid. The code already limits puddles to 1,200 and stops admitting runners around 160, so it is not wholly unbounded. Remaining opportunities are batching puddle creation/merging once per tick, a local spatial hash for minimum-gap deduplication and reuse of source neighborhood queries.

`_probe` transforms every query against every fixed structure; add object AABB rejection/coarse spatial lookup. `_flow` caps travel substeps at six, so high speed can skip thin supports; use segment traversal or a conservative step. If physical oil volume is important, give each runner/puddle a volume and transfer that volume into trail deposits, absorption and combustion rather than creating independent burn-time puddles along its path.

## 5. Profiling and acceptance plan on the target machine

The script already supports profiling:

```bash
python brick_bench.py --profile physics_profile.json
```

Use the attachment's filename instead if it has not been renamed. Profile with the same camera, resolution, settings, deterministic scene and input sequence. Inspect the existing CPU stages (`cpu_structures`, `reactive_fire_oil`, etc.), GPU debris time and frame-time p95. GPU queries are consumed asynchronously when available, which is appropriate. Nested CPU stage times overlap; do not add them as independent totals.

Add measurements that identify the algorithm causing a spike:

| Area | Counters/timers |
|---|---|
| CPU contacts | candidate body pairs, transformed surface points, probe time, raw/reduced contacts, matrix-build time, solve iterations and residual |
| Connectivity | label calls, cells/edges, fast vs graph path, elapsed time, component count and extraction allocations |
| Fracture | contacts recorded, unique collision events, fracture retries, pending jobs, transferred mass and angular/linear momentum |
| GPU | actual substeps, dispatch count, candidate/SAT counts, hash-chain distribution, active/sleep slots and live size extrema |
| Upload/readback | bytes and calls for occupancy, pose and visuals; blocking readback wall time; pending telemetry age |
| Heat/oil | active bricks/cells/sources, stencil work, thermal substeps, deposited/lost energy, burn/failure budget backlog and runner count |

Test four scenes separately:

1. **Heavy stack:** mass ratios 1:1, 10:1 and 100:1; static and dynamic support. Measure penetration, residual and resting speed; reverse insertion order.
2. **Collapse burst:** many components, several structures, body count crossing ten, with SciPy and the NumPy fallback. Verify fracture still occurs and total work is bounded.
3. **Mixed-size fast debris:** normal and tiny cubes, recycled/deleted tiny slots, fast moving tools and a 5 cm wall. Verify contact correctness and that old extrema do not retain excessive cost.
4. **Thermal fracture:** insulated mixed-capacity slab, heated timber support and steel section, then detach while hot. Verify capacity-weighted energy, detail/timestep consistency and retained temperatures.

Repeat normal scenarios with `--no-numba` and compiled Numba after warm-up, and compare physical outcomes rather than only FPS. The pre-import `--no-numba` check exists, but the argparse help does not declare it; add `ap.add_argument('--no-numba', action='store_true')` so the fallback can actually be selected from the command line without argparse rejecting it. Record cold-start compilation separately from warmed simulation. Acceptance should include a maximum frame-time target, invariant damage under substep changes, no body-cap immunity, no persistent unsupported sleepers after support removal, and no added thermal energy in insulated conduction.

The first implementation pass should fix the cap and damage bugs, separate topology from visual invalidation and instrument connectivity/readback/substep costs. A shared island solver and persistent manifolds are the next architectural step; moving all CPU structure logic to the GPU before these fixes would preserve the same behavioral problems in a harder-to-debug form.

# ShatterEngine 2.0

An experimental voxel destruction engine and interactive physics test bench developed for **Shatterlands**. Build a shape, choose its material, and inspect how it breaks, burns, falls and settles. The engine/test bench and future game are separate projects.

Updated **16 November 2026** against `ShatterEngine2_reactive(8).py` (12,092 lines). This upload is byte-identical to the (7) version covered by `ShatterEngine_physics_audit.md`. Documentation was checked by source inspection; that audit includes isolated CPU checks. The full OpenGL application, compiled Numba kernels and target-GPU performance were not tested.

## Features

- GPU-compute loose debris with shared simulation/render buffers and instanced drawing; CPU rigid chunks, impact bonds, connectivity and structural support checks.
- Flat terrain, cube, pillar and wall; dirt, steel, brick, glass and timber.
- **Explode, Gun, Jerry can, Drop weight, Ram, Add debris, Fireball and Pour oil.** Jerry can throws an oil drum; Fireball retains the internal settings key `torch`.
- Placeable fireworks and a first-person camera with spectate and playable-character modes.
- Reactive timber fire, embers, oil ignition and drum cook-off. Oil runs across surfaces, over edges and down walls, with material-dependent flow and absorption.
- Cell heating, conduction, cooling, hot-material glow and heat-triggered material damage on fixed structures.
- Compact settings sidebar, CPU/GPU/heat diagnostics, temperature heat map and cube-state inspection.
- Material textures, bloom, optional ray-traced lighting and per-material shine controls.
- Five quality presets: **Very low, Low, Medium, High, Ultra**. They change graphics and physics workload together; High is selected at startup.
- JSON settings export, scene recording and opt-in CPU/GPU performance profiling.

## Run

Requires Python, pygame, PyOpenGL, NumPy, SciPy and hardware **OpenGL 4.3 compatibility**, including at least **9 compute shader storage blocks**. Loose debris has no CPU fallback. Software renderers are rejected during normal launch.

Using the attached filename in PowerShell:

```powershell
python -m pip install pygame PyOpenGL numpy scipy
python ".\ShatterEngine2_reactive(8).py"
```

If you rename the script to `brick_bench.py` or `ShatterEngine2_reactive.py`, use that filename instead.

Optional packages:

```powershell
python -m pip install numba opencv-python
```

Numba accelerates CPU contact-solving, cell-probing and contact-reduction kernels. Startup warms the kernels and uses their compiled cache when available. OpenCV enables MP4 recording; an unavailable video writer falls back to numbered PNG frames. NVIDIA utilization readings use `nvidia-smi`; unavailable readings show `N/A`.

Launch options:

| Option | Purpose |
| --- | --- |
| `--size 1360x800` | Initial window size |
| `--max-debris 200000` | Override loose-cube buffer capacity; default 100,000 |
| `--profile physics_profile.json` | Save CPU stage timings, sampled GPU timings and mesh-cache counters on exit |
| `--profile` | Use `dev_notes/performance_profile.json` beside the script |
| `--no-gl-checks` | Disable PyOpenGL per-call error checks |
| `--shots <folder>` | Run the scripted screenshot sequence and exit |

The source checks `--no-numba` before import, but the current argument parser does not accept it. It needs a parser declaration before it is a working launch option.

## Controls

| Input | Action |
| --- | --- |
| Left click | Use selected tool; hold for Gun, Fireball, Pour oil or enabled Add debris hold |
| Tab | Open/close menu |
| W A S D / Shift | Move camera / boost speed; walk / run in character mode |
| Space | Pause/resume; jump in character mode |
| R | Reset scene and performance history |
| C | Clear loose debris when recycling is enabled (Keep debris off) |
| E / Q | Cycle material / shape and rebuild |
| G | Toggle Live Diagnostics and the temperature heat map |
| Right-drag / middle-drag | Orbit / pan in normal view |
| Mouse wheel | Zoom, or scroll the hovered menu |
| Ctrl+click / Backspace | Inspect a debris cube / deselect it |
| V | Enter/leave a camera placed through Objects |
| Delete | Remove the placed camera |
| Right-click in camera view | Open camera menu: play, spectate, record or delete |
| Esc | Close the camera context menu, otherwise quit |

In character mode the mouse looks around and tools aim at the crosshair; Tab frees the cursor. The menu's **Clear debris** button clears debris independently of the C-key restriction.

The nine tabs are **World, Physics, Cube state, Objects, Weapons, Export, Record, Controls, Settings**, arranged in three rows. Physics opens first. Toolbar buttons also select materials and shapes.

## Heat, fire and diagnostics

The **Heat** controls appear under Objects and the Explode, Fireball and Pour oil weapon cards. They control heating, heat power, cooling and heat-triggered material damage. Timber can char, ignite and burn through; glass can crack, and selected hot steel/masonry cells can fail.

**G** shows frame time, awake/sleeping cube counts, simulation speed, 15-second CPU/GPU charts, hottest-cell history and a temperature colour key. Fixed structures are coloured by temperature. Loose GPU cubes carry no temperature and appear cold blue; cube-state colouring can override their heat-view colour.

The retained stress-debug renderer is separate and is not enabled by the normal scene draw call. G does not display structural stress or activate the retained damage-crack renderer.

## Defaults, settings and recording

The initial scene is anchored Dirt terrain, 25 cm requested terrain cells and 15 cm debris cubes at scale 1. Defaults include Keep debris on, gravity 24 world units/s², simulation speed 100%, debris minimum substeps 3, chunk substeps setting 7, FPS cap 120 and ray-traced lighting off. The requested terrain detail can be coarsened by the 700,000-cell scene limit; adaptive debris substeps can exceed the selected minimum.

Fireball defaults: 28 m/s launch speed, 60 cm splash radius and 3 shots/s while held. Oil defaults: pour setting 12, flow 100%, soak 100%, volatility 200%. The pour setting is internally scaled to five newly generated puddles per call at default, before spacing/cap filtering. Heat, heat damage, smoke and ordinary fire spread are enabled.

**Export** saves `shatter_settings_<timestamp>.json` beside the script, including internal settings, readable values, weapon, hidden cube states and optional camera pose. There is no general settings import. [PREFS.txt](PREFS.txt) records project preferences, current code defaults and the development handoff; it is not loaded by the application.

VSync is persisted separately in `shatter_prefs.json` and applies on the next launch. Other settings start from code defaults. Presets change graphics, effects, detail, retention and substeps together; changing terrain detail rebuilds the scene. Ultra enables ray-traced lighting.

**Record** captures into `recordings/` beside the script. Default output is 720p at 30 fps, with width following the window aspect ratio. Capture includes the finished scene before menus and overlays are drawn. MP4 uses OpenCV `mp4v`; the fallback is numbered PNG frames.

## Architecture and current limits

- Loose cubes use OpenGL compute shaders and a GPU spatial hash. CPU rigid chunks use a different sequential impulse solver. Optional CuPy code concerns connectivity fallback, not the loose-debris implementation.
- GPU debris reacts to CPU chunks without returning contact reactions to them. Cubes have fixed spawn yaw rather than full angular contact dynamics.
- Self-weight stress checks are disabled above **40,000 live cells** per fixed structure; complete disconnection can still detach material.
- Glass is opaque. Material strengths and temperatures are game tuning.
- Heat/burning updates apply to fixed structures. Detached chunks lose thermal/burn state; steel heat failure currently removes cells rather than simulating molten metal or gradual thermal yielding.
- Oil uses bounded surface runners and puddles; it is not a volume-conserving fluid simulation.

## Audit and next work

The 16 November audit reproduced substep-dependent sustained-contact damage, large-chunk impact-fracture immunity at the ten-body cap, and detachment exceeding that cap. It also identified direction-dependent friction limits and inconsistent mixed-capacity thermal energy. These findings apply to this identical source and remain unresolved.

Priorities are to fix those fracture/damage rules, separate topology from visual invalidation, instrument connectivity/readbacks/substep costs, then improve shared contact-island stepping and persistent manifolds. The full audit contains reproductions, numerical adjustments and a target-machine profiling plan. Detailed status and remaining historical checks are in [PREFS.txt](PREFS.txt).

## License

The engine is MIT-licensed as specified by the project owner. Distribute the full MIT license text with the engine. Licensing for the future game is separate.

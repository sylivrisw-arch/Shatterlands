@echo off
setlocal EnableDelayedExpansion
title ShatterEngine - check and install requirements
cd /d "%~dp0"

echo.
echo  ShatterEngine requirements check
echo  ================================
echo.

rem ---- find Python (py launcher first, then python) ----
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY (
    where python >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo  [X] Python was not found.
    echo      Install Python 3.9 or newer from https://www.python.org/downloads/
    echo      and tick "Add python.exe to PATH" in the installer, then run this again.
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%v in ('%PY% -c "import sys;print('%%d.%%d.%%d'%%sys.version_info[:3])"') do set "PYVER=%%v"
%PY% -c "import sys;sys.exit(0 if sys.version_info>=(3,9) else 1)"
if errorlevel 1 (
    echo  [X] Python !PYVER! is too old. Please install Python 3.9 or newer.
    echo.
    pause
    exit /b 1
)
echo  [OK] Python !PYVER!  ^(%PY%^)
echo.

rem ---- make sure pip works ----
%PY% -m pip --version >nul 2>nul
if errorlevel 1 (
    echo  pip is missing, installing it...
    %PY% -m ensurepip --upgrade
)

rem ---- package list: import name ^| pip name ^| required or optional ----
set "FAILED="
call :check pygame     pygame          required
call :check numpy      numpy           required
call :check OpenGL     PyOpenGL        required
call :check scipy      scipy           required
call :check cv2        opencv-python   recording
call :check numba      numba           speed

echo.
if defined FAILED (
    echo  Some packages could not be installed:!FAILED!
    echo  Check your internet connection and run this file again.
) else (
    echo  Everything is installed. You can run ShatterEngine2_reactive.py now.
)
echo.
pause
exit /b 0

:check
rem %1 = import name, %2 = pip name, %3 = what it is for
%PY% -c "import %1" >nul 2>nul
if not errorlevel 1 (
    echo  [OK] %2
    exit /b 0
)
echo  [..] %2 is missing ^(%3^) - installing...
%PY% -m pip install --disable-pip-version-check %2
%PY% -c "import %1" >nul 2>nul
if errorlevel 1 (
    echo  [X]  %2 failed to install
    if /i "%3"=="required" set "FAILED=!FAILED! %2"
    if /i "%3"=="recording" echo       ^(video recording will save PNG pictures instead of an mp4 until this is installed^)
    if /i "%3"=="speed" echo       ^(optional: the game still runs, just slower^)
    if /i "%3"=="diagnostics" echo       ^(optional: only used for the live diagnostics panel^)
) else (
    echo  [OK] %2 installed
)
exit /b 0
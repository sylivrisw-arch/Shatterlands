#!/usr/bin/env python3
"""
Brick bench: a test scene for the Shatterlands impact-bond system.

An empty floor with one flat plane of dirt terrain on it,
an explosion tool. Loose cubes use GPU compute + instanced rendering only.
Requires hardware OpenGL 4.3 compatibility (no CPU debris fallback).
It uses the real Shatterlands engine (embedded below as _ENGINE_SRC) (cells, bonds, rigid bodies, support
checks), so what breaks here breaks the same way in the game.

Needs:   pygame  PyOpenGL  numpy  scipy   (the Shatterlands engine is built into this file, at the bottom)
Run:     python brick_bench.py        (add --no-gl-checks to skip PyOpenGL's per-call error checks)

Controls
  Left click      blows up the structure at the point under the mouse
  Right-drag      orbit the camera                 Mouse wheel  zoom       Middle-drag  pan
  W A S D         move the camera (forward / left / back / right; hold Shift for 3x speed)
  Tab             show / hide the menu (tabs: World / Physics / Cube state / Objects / Weapons / Export / Controls: every key and mouse control)
  Objects tab     drag an item into the world, or click it and then click the ground; click a placed oil drum (red) or fireworks box (purple) to set it off; drum settings are under the items
  Weapons tab     Explode (the default click blast) or Gun (tiny bullets, hold the mouse to fire): shoot an oil drum to set it off
                  Drop weight (click: a steel cube falls from rest above the point; mass, size and height are separate sliders)
                  Ram (a motor-driven steel block: speed control or force control, force limit, stroke; stalls at its force limit)
                  Add debris (click / hold: drop thousands of loose cubes to find how many the GPU debris can hold; --max-debris N raises the buffer)
                  Torch (click / hold: set the point alight) and Pour oil (click / hold: spill oil). Fire, embers and oil spread: see FIRE & EMBERS under the Objects tab and the Torch / Pour oil weapons.
                  Timber (E key) burns: it chars, catches, spreads, and burns through; a burnt-through post drops what it held. Blasts and embers light timber and oil.
  Export tab      save every slider and toggle setting (and the weapon) to a .json file next to this script
  E               cycle test material: dirt, steel, brick, glass, timber (rebuilds the scene)
  Q               switch what you blow up: flat terrain, a cube, a pillar or a wall (rebuilds it)
  Space           pause      R rebuild the structure      C  clear loose debris
  Sliders (left panel) drag with the left mouse button. Bond strength, the explosion settings and the substeps apply at once;
                       terrain width and depth rebuild the terrain when you let go.
"""
import sys, os, math, time, types, argparse, json
from collections import deque
import numpy as np
import pygame
from pygame.locals import *
import OpenGL
if '--no-gl-checks' in sys.argv:                   # optional speed-up: PyOpenGL otherwise calls glGetError after every GL call
    OpenGL.ERROR_CHECKING = False                   # (GL mistakes are then not reported); try it and compare the FPS in the panel
    OpenGL.ERROR_LOGGING = False
from OpenGL import GL as gl
import ctypes

HERE = os.path.dirname(os.path.abspath(__file__))
TERRAIN_SIZE = (50, 5, 50)                         # cells: the terrain chunk is 50 wide, 5 high (thick) and 50 deep (at TERRAIN_REF_CUBE)
TERRAIN_REF_CUBE = 0.2                             # metres: the cube size TERRAIN_SIZE is measured in; it fixes the terrain's physical size
SHAPES = (('Flat terrain', None),                          # what Q cycles through: the thing standing on the floor to blow up (metres: width, height, depth)
          ('Cube', (6.0, 6.0, 6.0)),
          ('Pillar', (2.0, 10.0, 2.0)),
          ('Wall', (12.0, 5.0, 1.0)))
PLAYER_EYE, PLAYER_R = 1.7, 0.28                           # the playable character: eye height above the feet, body radius (metres)
PLAYER_SPEED, PLAYER_RUN, PLAYER_JUMP, PLAYER_GRAV = 4.5, 8.0, 7.5, -22.0      # walk and run speed (m/s), jump speed, gravity
PLAYER_STEP = 0.55                                         # the tallest step it walks straight up
BENCH_MATERIALS = (('Dirt','DIRT'), ('Steel','STEEL'), ('Brick','BRICK'), ('Glass','GLASS'), ('Timber','PLANKS'))
TERRAIN_MAX_CELLS = 700000                         # most terrain cells allowed in total (smaller cubes are rounded up to stay under it)


# ------------------------------------------------------------------------------------------------ engine

# ------------------------------------------------------------------------------------------------ optional CPU speed-up (numba)
# Two hot loops of the loose-body physics (the contact solver and the point-in-body probe) have compiled versions. They give
# the same answers as the numpy code they replace. Without numba the numpy code is used. Install:  pip install numba
NUMBA_KERNELS = {}
try:
    if '--no-numba' in sys.argv:
        raise ImportError('disabled by --no-numba')
    from numba import njit as _njit

    @_njit(cache=True, fastmath=False)
    def _nb_solve(KT, jv, dg, cl, m, fric, iters):
        """Sequential impulses (same maths as RigidBody._solve's loop). KT is K transposed so that a column of K is a row."""
        n3 = 3 * m
        lam = np.zeros(n3)
        for _ in range(iters):
            moved = 0.0
            for i in range(m):
                new = max(0.0, lam[i] - (jv[i] - cl[i]) / dg[i])
                dl = new - lam[i]
                if dl != 0.0:
                    lam[i] = new
                    for j in range(n3):
                        jv[j] += KT[i, j] * dl
                    moved += abs(dl)
                lim = fric * lam[i]
                for t in range(2):
                    row = m + i if t == 0 else 2 * m + i
                    new = min(max(lam[row] - jv[row] / dg[row], -lim), lim)
                    dl = new - lam[row]
                    if dl != 0.0:
                        lam[row] = new
                        for j in range(n3):
                            jv[j] += KT[row, j] * dl
                        moved += abs(dl)
            if moved < 1e-5:
                break
        return lam

    @_njit(cache=True, fastmath=False)
    def _nb_probe(Pw, fp, R, corner, cs, alive, expo):
        """World points -> (indices of points inside a live cell, depth to the nearest exposed face, face number 0..5)."""
        n = Pw.shape[0]
        nx, ny, nz = alive.shape
        sel = np.empty(n, np.int64)
        depth = np.empty(n)
        face = np.empty(n, np.int64)
        cnt = 0
        dist = np.empty(6)
        for p in range(n):
            d0 = Pw[p, 0] - fp[0]
            d1 = Pw[p, 1] - fp[1]
            d2 = Pw[p, 2] - fp[2]
            q0 = (d0 * R[0, 0] + d1 * R[1, 0] + d2 * R[2, 0] - corner[0]) / cs
            q1 = (d0 * R[0, 1] + d1 * R[1, 1] + d2 * R[2, 1] - corner[1]) / cs
            q2 = (d0 * R[0, 2] + d1 * R[1, 2] + d2 * R[2, 2] - corner[2]) / cs
            i = int(np.floor(q0))
            j = int(np.floor(q1))
            k = int(np.floor(q2))
            if i < 0 or j < 0 or k < 0 or i >= nx or j >= ny or k >= nz:
                continue
            if not alive[i, j, k]:
                continue
            f0 = q0 - i
            f1 = q1 - j
            f2 = q2 - k
            dist[0] = f0
            dist[1] = 1.0 - f0
            dist[2] = f1
            dist[3] = 1.0 - f1
            dist[4] = f2
            dist[5] = 1.0 - f2
            best = -1
            bestv = np.inf
            for a in range(6):
                if expo[i, j, k, a] and dist[a] < bestv:
                    bestv = dist[a]
                    best = a
            if best < 0:                                           # no exposed face: use the nearest face
                best = 0
                bestv = dist[0]
                for a in range(1, 6):
                    if dist[a] < bestv:
                        bestv = dist[a]
                        best = a
            sel[cnt] = p
            depth[cnt] = bestv * cs
            face[cnt] = best
            cnt += 1
        return sel[:cnt], depth[:cnt], face[:cnt]

    @_njit(cache=True, fastmath=False)
    def _nb_spread(P, dep, count):
        """Farthest-point pick of `count` rows of P, starting from the deepest (same choice as RigidBody._reduce's loop)."""
        n = P.shape[0]
        chosen = np.empty(count, np.int64)
        first = 0
        for i in range(1, n):
            if dep[i] > dep[first]:
                first = i
        chosen[0] = first
        mind = np.empty(n)
        for i in range(n):
            d = 0.0
            for a in range(3):
                t = P[i, a] - P[first, a]
                d += t * t
            mind[i] = np.sqrt(d)
        for c in range(1, count):
            k = 0
            for i in range(1, n):
                if mind[i] > mind[k]:
                    k = i
            chosen[c] = k
            for i in range(n):
                d = 0.0
                for a in range(3):
                    t = P[i, a] - P[k, a]
                    d += t * t
                d = np.sqrt(d)
                if d < mind[i]:
                    mind[i] = d
        return chosen

    NUMBA_KERNELS = {'solve': _nb_solve, 'probe': _nb_probe, 'spread': _nb_spread}
except Exception as _e:                                            # no numba, or it will not compile here: the numpy code runs instead
    NUMBA_KERNELS = {}
    if '--no-numba' not in sys.argv:
        print('numba not available (%s): using the slower numpy physics. pip install numba to speed it up.' % str(_e)[:60])


def load_engine(game_path=None):
    """Import the Shatterlands engine. It is built into the bottom of this file (_ENGINE_SRC), so nothing else is needed."""
    mod = types.ModuleType('shatterlands_engine')
    mod.__file__ = os.path.abspath(__file__)
    sys.modules['shatterlands_engine'] = mod
    mod.NB = NUMBA_KERNELS                             # compiled loops the engine uses when numba is installed
    exec(compile(_ENGINE_SRC, '<shatterlands_engine in brick_bench.py>', 'exec'), mod.__dict__)
    if not hasattr(mod, 'BOND') or not hasattr(mod, 'fire_cannon'):
        raise SystemExit('The built-in engine has no impact bonds.')
    if NUMBA_KERNELS:                                                    # compile (or load the cached build of) the kernels now, not in the middle of a blast
        try:
            _t = time.perf_counter()
            _a = np.ones((2, 2, 2), bool)
            NUMBA_KERNELS['probe'](np.zeros((2, 3)), np.zeros(3), np.eye(3), np.zeros(3), 1.0, _a, np.ones((2, 2, 2, 6), bool))
            NUMBA_KERNELS['solve'](np.eye(3), np.zeros(3), np.ones(3), np.zeros(1), 1, 0.5, 2)
            NUMBA_KERNELS['spread'](np.random.rand(12, 3), np.random.rand(12), 10)
            if time.perf_counter() - _t > 1.0:
                print('numba: compiled the physics kernels in %.1f s (cached for next time)' % (time.perf_counter() - _t))
        except Exception as _e:
            print('numba kernels failed (%s): using the numpy physics' % str(_e)[:80])
            NUMBA_KERNELS.clear()
    return mod


# ------------------------------------------------------------------------------------------------ GPU debris
# GPU-resident state: five vec4s per cube, shared by compute and instanced drawing.
# No CPU simulation, mesh expansion, collision tree, or per-frame position readback.
_GPU_COMMON = r'''
struct Cube { vec4 ps; vec4 vy; vec4 colour; vec4 anchor; vec4 flags; };
struct Obstacle {
    vec4 origin; vec4 corner; ivec4 dims;
    vec4 c0; vec4 c1; vec4 c2; vec4 velocity; vec4 omega;
};
layout(std430, binding=0) readonly buffer Source { Cube src[]; };
layout(std430, binding=1) writeonly buffer Destination { Cube dst[]; };
layout(std430, binding=2) buffer Heads { int head[]; };
layout(std430, binding=3) buffer Links { int links[]; };
layout(std430, binding=4) buffer Cells { ivec4 cells[]; };
layout(std430, binding=5) buffer Counts { uvec4 contacts[]; };
layout(std430, binding=6) readonly buffer Objects { Obstacle objects[]; };
layout(std430, binding=7) readonly buffer Voxels { uint voxels[]; };
layout(std430, binding=8) buffer Stats { uint awakeCount; uint sleepCount; uint spare0; uint spare1; };
uniform int n, objectCount;
uniform float dt, gravity, cellSize, tumble, popStrength;
const uint BUCKETS = 8192u;
uint hashCell(ivec3 p) {
    uvec3 v = uvec3(p);
    return ((v.x*73856093u) ^ (v.y*19349663u) ^ (v.z*83492791u)) & (BUCKETS-1u);
}
mat3 axes(float yaw) {
    float c=cos(yaw), s=sin(yaw);
    return mat3(vec3(c,0,-s), vec3(0,1,0), vec3(s,0,c));
}
// Separating-axis test for actual yawed cubes and arbitrary oriented voxel boxes.
// Normal points from B towards A. Negative depth is a small speculative gap.
bool boxContact(vec3 a, mat3 A, float ah, vec3 b, mat3 B, float bh,
                float margin, out vec3 normal, out float depth) {
    vec3 delta=a-b;
    depth=1e30; normal=vec3(0,1,0);
    for(int k=0;k<15;k++) {
        vec3 axis;
        if(k<3) axis=A[k];
        else if(k<6) axis=B[k-3];
        else axis=cross(A[(k-6)/3],B[(k-6)%3]);
        float ll=dot(axis,axis);
        if(ll<1e-10) continue;
        axis*=inversesqrt(ll);
        float ra=ah*(abs(dot(axis,A[0]))+abs(dot(axis,A[1]))+abs(dot(axis,A[2])));
        float rb=bh*(abs(dot(axis,B[0]))+abs(dot(axis,B[1]))+abs(dot(axis,B[2])));
        float distance=dot(delta,axis);
        float overlap=ra+rb-abs(distance);
        if(overlap < -margin) return false;
        if(overlap<depth) { depth=overlap; normal=distance>=0.0 ? axis : -axis; }
    }
    return true;
}
bool pairContact(uint i, uint j, out vec3 normal, out float depth) {
    Cube a=src[i], b=src[j];
    bool hit=boxContact(a.ps.xyz,axes(a.vy.w),a.ps.w*.5,
                        b.ps.xyz,axes(b.vy.w),b.ps.w*.5,
                        min(a.ps.w,b.ps.w)*.015,normal,depth);
    if(dot(a.ps.xyz-b.ps.xyz,a.ps.xyz-b.ps.xyz)<1e-14 && i>j) normal=-normal;
    return hit;
}
// One cube against the floor and resident structure occupancy grids.
void staticContacts(inout Cube c, out bool supported) {
    supported=false;
    float halfSize=c.ps.w*.5;
    float margin=c.ps.w*.015;
    if(c.ps.y-halfSize<=margin) {
        supported=true;
        c.ps.y=max(c.ps.y,halfSize);
        if(c.vy.y<0.0) c.vy.y=c.vy.y < -1.5 ? -c.vy.y*.03 : 0.0;
    }
    mat3 A=axes(c.vy.w);
    bool tipOver=false, tipOff=false; vec3 tipDir=vec3(0); float tipF=0.0;
    // HARD TERRAIN: two passes, so a push out of one voxel that lands in its neighbour is corrected in the same call.
    for(int pass=0;pass<2;pass++) {
    bool moved=false;
    for(int oi=0;oi<objectCount;oi++) {
        Obstacle o=objects[oi];
        mat3 B=mat3(o.c0.xyz,o.c1.xyz,o.c2.xyz);
        mat3 invB=transpose(B);
        vec3 local=invB*(c.ps.xyz-o.origin.xyz)-o.corner.xyz;
        vec3 extent=abs(invB*A[0])*halfSize+abs(invB*A[1])*halfSize+abs(invB*A[2])*halfSize;
        float cs=o.origin.w;
        ivec3 lo=max(ivec3(floor((local-extent-margin)/cs)),ivec3(0));
        ivec3 hi=min(ivec3(floor((local+extent+margin)/cs)),o.dims.xyz-1);
        for(int x=lo.x;x<=hi.x;x++) for(int y=lo.y;y<=hi.y;y++) for(int z=lo.z;z<=hi.z;z++) {
            uint index=uint(o.dims.w+(x*o.dims.y+y)*o.dims.z+z);
            uint mask=voxels[index];
            if((mask>>1u)==0u) continue; // Buried voxel faces cannot support loose debris.
            vec3 centre=o.origin.xyz+B*(o.corner.xyz+(vec3(x,y,z)+.5)*cs);
            vec3 normal; float depth;
            if(!boxContact(c.ps.xyz,A,halfSize,centre,B,cs*.5,margin,normal,depth)) continue;
            // Resolve against the union's exposed faces, never the invisible seams
            // between adjacent solid voxels (those used to act like tiny shelves).
            float bestDepth=1e30; int bestFace=-1;
            for(int face=0;face<6;face++) {
                if((mask & (1u<<uint(face+1)))==0u) continue;
                int axis=face/2; float sign=(face%2==0) ? -1.0 : 1.0;
                vec3 faceNormal=B[axis]*sign;
                float radius=halfSize*(abs(dot(faceNormal,A[0]))+abs(dot(faceNormal,A[1]))+abs(dot(faceNormal,A[2])));
                float faceDepth=radius+cs*.5-dot(c.ps.xyz-centre,faceNormal);
                if(faceDepth>=-margin && faceDepth<bestDepth) {
                    bestDepth=faceDepth; normal=faceNormal; bestFace=face;
                }
            }
            if(bestFace<0) continue;
            depth=bestDepth;
            vec3 surfaceVelocity=o.velocity.xyz+cross(o.omega.xyz,c.ps.xyz-o.origin.xyz);
            // A ledge supports sleep only when the cube's centre projects onto it.
            // Touching a wall edge or a moving body is not stable support.
            vec3 onFace=transpose(B)*(c.ps.xyz-centre);
            int faceAxis=bestFace/2;
            bool overFace=true;
            for(int k=0;k<3;k++) if(k!=faceAxis && abs(onFace[k])>cs*.5+margin) overFace=false;
            if(normal.y>.75 && overFace && length(surfaceVelocity)<.02) supported=true;
            if(normal.y>.75) {
                if(overFace) tipOver=true;
                else {
                    float excess=max(abs(onFace[(faceAxis+1)%3]),abs(onFace[(faceAxis+2)%3]))-cs*.5;
                    vec3 away=c.ps.xyz-centre; away.y=0.0;
                    if(dot(away,away)>1e-12) {
                        tipOff=true; tipDir=normalize(away);
                        tipF=max(tipF,clamp((excess-.02*c.ps.w)/(.1*c.ps.w),0.0,1.0));
                    }
                }
            }
            float pushOut=max(depth,0.0);                    // the full penetration is removed: no slop
            if(pushOut>0.0) moved=true;
            c.ps.xyz+=normal*pushOut;
            vec3 relative=c.vy.xyz-surfaceVelocity;
            float vn=dot(relative,normal);
            if(vn<0.0) {
                if(-vn>.75) { c.flags.x=0.0; c.anchor.w=0.0; c.flags.w=1.0; }
                c.vy.xyz-=normal*vn*(vn < -1.5 ? 1.02 : 1.0);
                vec3 tangent=relative-normal*vn;
                float speed=length(tangent);
                if(speed>1e-8) c.vy.xyz-=tangent*min(1.0,.65*(-vn)/speed);
            }
        }
    }
    if(!moved) break;
    }
    // Centre past the edge of every ledge it touches (and not over any): slide off. (Called twice per substep.)
    if(tipOff && !tipOver && c.flags.x<.5 && dot(c.vy.xz,tipDir.xz)<1.2) c.vy.xz+=tipDir.xz*gravity*dt*.75*tipF;
}
'''

_GPU_INTEGRATE = r'''
void main() {
    uint i=gl_GlobalInvocationID.x; if(i>=uint(n)) return;
    Cube c=src[i];
    c.flags.w=0.0; // Significant contacts this substep prevent sleep.
    if(c.flags.x<.5) {
        c.vy.y-=gravity*dt;
        c.ps.xyz+=c.vy.xyz*dt;
    }
    bool supported; staticContacts(c,supported);
    c.flags.y=supported ? 1.0 : 0.0;
    c.flags.z=c.flags.y;
    if(supported && c.flags.x<.5) {
        float horizontal=length(c.vy.xz);
        float mu=clamp(.95-.10*tumble,.5,1.0);
        float budget=mu*gravity*dt*3.0;                  // a cube that has landed grips hard: it stops where it lands
        if(horizontal<=max(budget*1.25,.8)) c.vy.xz=vec2(0);
        else if(horizontal>1e-8) c.vy.xz*=max(0.0,1.0-budget/horizontal);
    }
    dst[i]=c;
}
'''
_GPU_CLEAR_GRID = r'''
void main() { uint i=gl_GlobalInvocationID.x; if(i<BUCKETS) head[i]=-1; }
'''
_GPU_BUILD_GRID = r'''
void main() {
    uint i=gl_GlobalInvocationID.x; if(i>=uint(n)) return;
    ivec3 cell=ivec3(floor(src[i].ps.xyz/cellSize)); cells[i]=ivec4(cell,0);
    links[i]=atomicExchange(head[hashCell(cell)],int(i));
}
'''
_GPU_COUNT = r'''
void main() {
    uint i=gl_GlobalInvocationID.x; if(i>=uint(n)) return;
    uvec4 count=uvec4(0); ivec3 base=cells[i].xyz;
    for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++) {
        ivec3 cell=base+ivec3(x,y,z);
        int j=head[hashCell(cell)];
        while(j>=0) {
            if(uint(j)!=i && all(equal(cells[j].xyz,cell))) {
                vec3 normal; float depth;
                if(pairContact(i,uint(j),normal,depth)) {
                    count.x++;
                    vec3 an=abs(normal);
                    int axis=an.y>=an.x && an.y>=an.z ? 1 : (an.x>=an.z ? 0 : 2);
                    count[axis+1]++;
                }
            }
            j=links[j];
        }
    }
    contacts[i]=count;
}
'''
_GPU_SOLVE = r'''
void main() {
    uint i=gl_GlobalInvocationID.x; if(i>=uint(n)) return;
    Cube a=src[i]; vec3 dP=vec3(0), dV=vec3(0);
    bool wake=false, supported=false, settledSupport=false; float settledVy=-1e9;
    bool tipOff=false; vec3 tipDir=vec3(0); float tipF=0.0;     // resting on a cube's edge with the centre already past it
    ivec3 base=cells[i].xyz;
    for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++) {
        ivec3 cell=base+ivec3(x,y,z);
        int jj=head[hashCell(cell)];
        while(jj>=0) {
            uint j=uint(jj);
            if(j!=i && all(equal(cells[j].xyz,cell))) {
                vec3 normal; float depth;
                if(pairContact(i,j,normal,depth)) {
                    Cube b=src[j];
                    vec3 relative=a.vy.xyz-b.vy.xyz;
                    float vn=dot(relative,normal);
                    // Wake from incoming speed before the solver removes it.
                    bool impact=vn < -.75;
                    // HARD COLLISION: two cubes that visibly overlap (more than 4% of a side) are always pushed apart, even when
                    // both are asleep (a sleeping cube is woken for it), so cubes can never stay interpenetrated.
                    bool deep=depth>.04*min(a.ps.w,b.ps.w);
                    float wa=(a.flags.x<.5 || impact || deep) ? 1.0/max(a.colour.w,1e-8) : 0.0;
                    float wb=(b.flags.x<.5 || impact || deep) ? 1.0/max(b.colour.w,1e-8) : 0.0;
                    float sum=wa+wb;
                    vec3 offset=transpose(axes(b.vy.w))*(a.ps.xyz-b.ps.xyz);
                    bool overBottom=abs(offset.x)<=b.ps.w*.5 && abs(offset.z)<=b.ps.w*.5;
                    if(normal.y>.75 && overBottom) {
                        supported=true;
                        if((b.flags.x>.5 || b.flags.z>.5) && length(b.vy.xyz)<.02) settledSupport=true;   // support that is itself settled counts at once: a stack settles together, not one layer per sleep delay
                        if(b.flags.y>.5) settledVy=max(settledVy,b.vy.y);   // b was itself supported last substep: the load path ends at the ground
                    } else if(normal.y>.75 && a.flags.x<.5 && max(abs(offset.x),abs(offset.z))>b.ps.w*.5+.25*a.ps.w) {
                        // Cubes have no rotation, so nothing would ever tip this one off: slide it off the edge instead.
                        float excess=max(abs(offset.x),abs(offset.z))-b.ps.w*.5;
                        vec3 away=a.ps.xyz-b.ps.xyz; away.y=0.0;
                        if(dot(away,away)>1e-12) {
                            tipOff=true; tipDir=normalize(away);
                            tipF=max(tipF,clamp((excess-.02*a.ps.w)/(.1*a.ps.w),0.0,1.0));
                        }
                    } else if(normal.y>.75) {
                        // Resting on an edge but not far enough over it to be slid off: it stays put, so it counts as supported.
                        supported=true;
                        if((b.flags.x>.5 || b.flags.z>.5) && length(b.vy.xyz)<.02) settledSupport=true;
                        if(b.flags.y>.5) settledVy=max(settledVy,b.vy.y);   // b was itself supported last substep: the load path ends at the ground
                    }
                    if(impact || deep) { wake=true; a.flags.w=1.0; }
                    // Two cubes that have already landed (supported last substep, barely moving) and touch side to side keep
                    // the spot they landed in: no push, no friction, so a crowded layer does not jostle for room.
                    bool landedPair=abs(normal.y)<.6 && depth<.15*min(a.ps.w,b.ps.w) && a.flags.y>.5 && b.flags.y>.5 && length(a.vy.xz)<2.0 && length(b.vy.xz)<2.0 && !impact;
                    if(sum>0.0) {
                        // Same normalization on both ends: equal/opposite pair impulses.
                        // Side contacts must not dilute the reaction that supports weight.
                        vec3 an=abs(normal);
                        int axis=an.y>=an.x && an.y>=an.z ? 1 : (an.x>=an.z ? 0 : 2);
                        float norm=float(max(max(contacts[i][axis+1],contacts[j][axis+1]),1u));
                        float share=wa/sum/norm;
                        // Positional correction on every face (top, bottom and the four sides): full overlap removed, tiny slop only.
                        float overlap=max(depth-min(a.ps.w,b.ps.w)*.004,0.0);   // .4% slop: any less and resting stacks 'breathe'
                        dP+=normal*overlap*share;
                        if(!landedPair) {
                        dV+=normal*overlap*popStrength*share;      // POP: the squeezed pile stores its overlap as a spring and gives it back as speed (0 outside a blast)
                        if(vn<0.0) {
                            float speed=-vn*(vn < -1.5 ? 1.02 : 1.0);
                            dV+=normal*speed*share*.9;
                        }
                        // Coulomb/static friction also acts on persistent supporting
                        // contacts, not only on the instant of a new collision.
                        vec3 tangent=relative-normal*vn;
                        float tlen=length(tangent);
                        float supportBudget=abs(normal.y)>.6 ? gravity*dt/3.0 : 0.0;
                        float budget=max(max(-vn,0.0),supportBudget);
                        float mu=clamp(.95-.10*tumble,.5,1.0);
                        float friction=tlen<=1.25*mu*budget ? tlen : min(tlen,mu*budget);
                        if(tlen>1e-8) dV-=tangent*(friction/tlen)*share;
                        // No synthetic sideways kicks: those repeatedly injected
                        // motion into settled contacts and made rubble flow.
                        }   // end if(!landedPair)
                    }
                }
            }
            jj=links[jj];
        }
    }
    if(tipOff && !supported && dot(a.vy.xz,tipDir.xz)<1.2) dV.xz+=tipDir.xz*gravity*dt*1.5*tipF;   // no push once it is already sliding off
    a.ps.xyz+=dP; a.vy.xyz+=dV;
    // Resting on a cube that was itself supported last substep (so the load path ends at the ground): match that cube's velocity so
    // gravity is not stored as a bounce. This is deliberately NOT applied for any other contact below: a lower cube that is
    // falling or being pushed gets no clamp here and is handled only by the paired impulse above (previously the clamp zeroed
    // world velocity for ANY cube below, which erased downward momentum of falling stacks).
    if(settledVy>-1e8 && a.vy.y<settledVy && a.vy.y>settledVy-1.5) a.vy.y=settledVy;
    bool fixedSupport; staticContacts(a,fixedSupport);
    a.flags.y=(supported || fixedSupport) ? 1.0 : 0.0;
    a.flags.z=(settledSupport || fixedSupport) ? 1.0 : 0.0;
    if(wake) { a.flags.x=0.0; a.anchor.w=0.0; }   // (was: || a.flags.z<.5, which kept resetting the sleep timer of wedged cubes)
    dst[i]=a;
}
'''
_GPU_SLEEP = r'''
void main() {
    uint i=gl_GlobalInvocationID.x; if(i>=uint(n)) return;
    Cube c=src[i];
    bool near=distance(c.ps.xyz,c.anchor.xyz)<c.ps.w*.03;
    bool slow=length(c.vy.xyz)<.15 || (c.flags.z>.5 && near);

    // Immobilised cubes (slow and still inside the anchor radius) tick the sleep timer,
    // whether or not they have vertical support. Anything moving resets it.
    if(slow && near) c.anchor.w+=dt;
    else { c.anchor.w=0.0; c.anchor.xyz=c.ps.xyz; }

    if(c.anchor.w>=.5) { c.flags.x=1.0; c.vy.xyz=vec3(0); }
    else if(!slow) c.flags.x=0.0;
    dst[i]=c;
}
'''
_GPU_COMMAND = r'''
uniform int command, startSlot, commandCount, capacity;
uniform vec3 centre;
uniform float radius, columnUp, velocityScale, blastPower;
uniform vec3 blastNormal;
uniform float blastFocus, blastDome, blastJitter;
void applyBlast(inout Cube c, uint i, bool fresh) {
    vec3 delta=c.ps.xyz-centre;
    float distance=length(delta);
    float reach=max(radius*1.75,1e-5);
    if(distance>=reach) return;
    // A loose cube lying behind the struck face is shielded by the wall: it is never driven into it.
    if(!fresh && dot(blastNormal,blastNormal)>.5 && dot(delta,blastNormal)< -0.25*c.ps.w) return;
    // Pressure is an impulse over exposed area, not a wake-only notification.
    float falloff=pow(max(0.0,1.0-distance/reach),1.3);
    float base=min(80.0,8.0*sqrt(max(blastPower,0.0))*max(velocityScale,0.0));
    float areaMass=.38*c.ps.w*c.ps.w/max(c.colour.w,1e-8);
    vec3 direction;
    if(distance>1e-6) direction=delta/distance;
    else {
        float angle=float(i)*2.39996323;
        direction=normalize(vec3(cos(angle),.25,sin(angle)));
    }
    if(dot(blastNormal,blastNormal)>.5) {
        // Wall impacts eject straight out of the struck face along its fixed normal. Only a fraction (blastFocus) of the radial
        // direction is kept as sideways spread: 0 = a dead-straight jet, 1 = a wide spray.
        float focus=clamp(blastFocus,0.0,1.2);
        vec3 tangent=direction-blastNormal*dot(direction,blastNormal);
        // DOME: a cube starting further across the face leans further outward (blastDome), and every cube gets a lean of its own
        // (blastJitter). Without this, cubes cut from one lattice column all leave in the same near-vertical direction at different
        // speeds, catch each other in flight and land as intact towers.
        vec3 lateral=delta-blastNormal*dot(delta,blastNormal);
        float lat=length(lateral);
        vec3 outward=lat>1e-6 ? lateral/lat : vec3(0.0);
        vec3 helper=abs(blastNormal.y)<.9 ? vec3(0,1,0) : vec3(1,0,0);
        vec3 t1=normalize(cross(blastNormal,helper)), t2=cross(blastNormal,t1);
        float ha=fract(sin(float(i)*78.233+centre.x*5.3+centre.z*2.9)*43758.5453)*6.2831853;
        float hm=fract(sin(float(i)*39.346+centre.z*4.1+centre.x*8.7)*24634.6345);
        vec3 wobble=(t1*cos(ha)+t2*sin(ha))*blastJitter*(0.3+hm);
        direction=normalize(tangent*focus+outward*min(lat/max(radius,1e-5),1.0)*blastDome+wobble+blastNormal*(1.0+abs(dot(direction,blastNormal))));
    }
    float pick=fract(sin(float(i)*12.9898+centre.x*3.1+centre.z*7.7)*43758.5453);
    float stretch=(dot(blastNormal,blastNormal)>.5) ? mix(0.5,1.5,pick) : 1.0;   // different speeds along the jet: a plume, not a ball
    vec3 impulseVelocity=direction*(base*areaMass*falloff*stretch);
    c.vy.xyz=fresh ? impulseVelocity : c.vy.xyz+impulseVelocity;
    float speed=length(c.vy.xyz);
    if(speed>80.0) c.vy.xyz*=80.0/speed;
    c.flags.x=0.0; c.flags.z=0.0; c.flags.w=1.0;
    c.anchor.xyz=c.ps.xyz; c.anchor.w=0.0;
}
void main() {
    uint k=gl_GlobalInvocationID.x;
    if(command==4 || command==5) {
        bool fresh=command==5;
        if(k>=uint(fresh ? commandCount : n)) return;
        uint i=fresh ? (uint(startSlot)+k)%uint(capacity) : k;
        Cube c=src[i]; applyBlast(c,i,fresh); dst[i]=c; return;
    }
    if(command==3) {
        if(k>=uint(n)) return;
        if(src[k].flags.x>.5) {
            atomicAdd(sleepCount,1u);
            if(src[k].flags.z<.5 && src[k].ps.y<1.0e5) atomicAdd(spare1,1u);          // asleep with no settled support (not a deleted cube)
        } else atomicAdd(awakeCount,1u);
        float sp=length(src[k].vy.xyz);
        if(sp<=velocityScale) atomicMax(spare0,floatBitsToUint(sp));    // fastest cube, as float bits; speeds above the physical ceiling are solver glitches and are ignored
        return;
    }
    if(command==7) {
        // Freeze: hold a freshly spawned pile exactly where it was put (asleep, no velocity) until its blast is released (command 5 wakes it).
        if(k>=uint(commandCount)) return;
        uint i=(uint(startSlot)+k)%uint(capacity);
        Cube c=src[i];
        c.vy.xyz=vec3(0.0); c.flags=vec4(1.0,0.0,0.0,0.0);
        c.anchor.xyz=c.ps.xyz; c.anchor.w=0.0;
        dst[i]=c; return;
    }
    if(command==6) {
        // Delete: the slot becomes a tombstone parked 1000 km up, asleep, with no velocity. Nothing reaches it, so it is inert and never drawn.
        if(k>=uint(commandCount)) return;
        uint i=(uint(startSlot)+k)%uint(capacity);
        Cube c=src[i];
        c.ps.xyz=vec3(float(i)*5.0,1.0e6,0.0); c.vy.xyz=vec3(0.0); c.flags=vec4(1.0,1.0,1.0,0.0);
        c.anchor.xyz=c.ps.xyz; c.anchor.w=0.0;
        dst[i]=c; return;
    }
    if(command==2) {
        if(k>=uint(commandCount)) return;
        uint i=(uint(startSlot)+k)%uint(capacity);
        Cube c=src[i]; c.vy.xyz*=velocityScale; c.flags.x=0.0; c.anchor.w=0.0;
        dst[i]=c; return;
    }
    if(k>=uint(n)) return;
    Cube c=src[k];
    vec3 delta=c.ps.xyz-centre;
    bool near=length(delta)<radius*2.0;
    near=near || (length(delta.xz)<radius && delta.y>=0.0 && delta.y<columnUp);
    if(c.ps.y>1.0e5) { dst[k]=c; return; }                       // deleted cubes stay deleted
    if(command==1 || near) { c.flags.x=0.0; c.anchor.w=0.0; c.anchor.xyz=c.ps.xyz; }
    dst[k]=c;
}
'''
_GPU_VERTEX = r'''#version 430 compatibility
struct Cube { vec4 ps; vec4 vy; vec4 colour; vec4 anchor; vec4 flags; };
layout(std430,binding=0) readonly buffer Source { Cube cubes[]; };
layout(location=0) in vec3 vertex;
layout(location=1) in vec3 faceNormal;
uniform int activityView;      // 1: red = awake, yellow = asleep (shown with the graph panel)
uniform int stateView;         // 1: colour every cube by what it is doing (CubeStateManager, key G)
uniform int selected;          // slot of the inspected cube (-1: none); drawn larger and pulsing
uniform int hiddenStates;      // bit k set: cubes in state k are not drawn (only while stateView is on)
uniform float pulse;
out vec3 tint;
out vec3 normal;
// Same rules as CubeStateManager.classify on the CPU. Keep the two in step.
int cubeState(Cube c) {
    float speed=length(c.vy.xyz), hs=length(c.vy.xz);
    bool near=distance(c.ps.xyz,c.anchor.xyz)<c.ps.w*.03;
    bool slow=speed<.15 || (c.flags.z>.5 && near);                  // not really moving (the sleep shader's rule)
    if(c.flags.x>.5) return c.flags.z>.5 ? 1 : 2;                  // SLEEPING / SLEEPING_UNSUPPORTED
    if(c.flags.y<.5) {
        if(slow && near && c.anchor.w>=.1) return 10;               // WEDGED
        if(c.vy.y>.15) return 7;                                    // RISING
        if(c.vy.y<-.15) return 8;                                   // FALLING
        return 9;                                                   // DRIFTING
    }
    if(slow) return c.anchor.w>0.0 ? 3 : 4;                        // SETTLING / RESTING
    return hs>=.15 ? 5 : 6;                                         // SLIDING / BOUNCING
}
vec3 stateColour(int s) {
    if(s==1) return vec3(.20,.42,.95);
    if(s==2) return vec3(1.0,.1,.9);
    if(s==3) return vec3(.1,.9,.9);
    if(s==4) return vec3(.3,.85,.25);
    if(s==5) return vec3(1.0,.6,.1);
    if(s==6) return vec3(.95,.95,.95);
    if(s==7) return vec3(1.0,.95,.3);
    if(s==8) return vec3(1.0,.15,.1);
    if(s==9) return vec3(1.0,.55,.7);
    return vec3(.6,.3,1.0);
}
void main() {
    Cube c=cubes[gl_InstanceID];
    if(stateView==1 && ((hiddenStates>>cubeState(c))&1)!=0) { gl_Position=vec4(0.0); return; }   // a hidden state: collapsed, not drawn
    float co=cos(c.vy.w), si=sin(c.vy.w);
    mat3 R=mat3(vec3(co,0,-si),vec3(0,1,0),vec3(si,0,co));
    float grow=(gl_InstanceID==selected) ? 1.35 : 1.0;
    vec3 p=c.ps.xyz+R*vertex*c.ps.w*grow;
    normal=R*faceNormal; tint=c.colour.rgb;
    if(activityView==1) tint=(c.flags.x>.5) ? vec3(1.0,.86,.1) : vec3(1.0,.1,.08);
    if(stateView==1) tint=stateColour(cubeState(c));
    if(gl_InstanceID==selected) tint=mix(tint,vec3(1.0),.35+.45*pulse);
    gl_Position=gl_ModelViewProjectionMatrix*vec4(p,1);
}
'''
_GPU_FRAGMENT = r'''#version 430 compatibility
in vec3 tint;
in vec3 normal;
out vec4 outColour;
void main() {
    float light=.4+.6*max(dot(normalize(normal),normalize(vec3(.45,1,.35))),0.0);
    outColour=vec4(tint*light,1);
}
'''


class GpuDebris:
    """GPU-only loose cubes. Host uploads spawn events and changed obstacle grids.
    Only four telemetry integers are read back, at most four times a second.
    Simulation and rendering use the same resident SSBO; no NumPy physics path.
    """
    activity_view = False                           # draw cubes red (awake) / yellow (asleep) instead of their own colour
    hidden_mask = 0                                 # bit k set: cubes in state k are hidden (Cube state tab's tick boxes)
    state_view = False                              # draw cubes coloured by what each is doing (key G)
    selected = -1                                   # slot of the inspected cube, or -1
    pulse = 0.0
    MAX = 100000                                    # allocated slots
    BASE_CAP = 4000                                 # slots used while old cubes are recycled
    STRIDE = 80
    ITERATIONS = 3
    POLL_SIM = 0.1                                  # the GPU reports its fastest cube at least this often (simulated seconds)

    def __init__(self, E):
        self.E = E
        version = gl.glGetString(gl.GL_VERSION)
        if version is None or not gl.glDispatchCompute:
            raise RuntimeError('GPU debris requires an OpenGL 4.3 compatibility context.')
        self.programs = {}
        self.buffers = []
        self.vao = None
        try:
            for name, source in [('integrate', _GPU_INTEGRATE), ('clear_grid', _GPU_CLEAR_GRID),
                                 ('build_grid', _GPU_BUILD_GRID), ('count', _GPU_COUNT),
                                 ('solve', _GPU_SOLVE), ('sleep', _GPU_SLEEP), ('command', _GPU_COMMAND)]:
                self.programs[name] = self._program('#version 430\nlayout(local_size_x=128) in;\n' + _GPU_COMMON + source)
            self.draw_program = self._program(_GPU_VERTEX, _GPU_FRAGMENT)
            self.buffers = [int(gl.glGenBuffers(1)) for _ in range(9)]
            self.state = [self.buffers[0], self.buffers[1]]
            for handle, size in zip(self.buffers, [self.MAX*self.STRIDE]*2 + [8192*4, self.MAX*4, self.MAX*16, self.MAX*16, 128, 4, 16]):
                gl.glBindBuffer(gl.GL_SHADER_STORAGE_BUFFER, handle)
                gl.glBufferData(gl.GL_SHADER_STORAGE_BUFFER, size, None, gl.GL_DYNAMIC_DRAW)
            self.front = 0
            self.locations = {}
            self._make_cube()
            self.blast_count = 0
            self.states = CubeStateManager(self)
            self.clear()
        except Exception:
            self.close()
            raise

    @staticmethod
    def _program(source, fragment=None):
        from OpenGL.GL.shaders import compileShader, compileProgram
        if fragment is None:
            shader = compileShader(source, gl.GL_COMPUTE_SHADER)
            try:
                return int(compileProgram(shader))
            finally:
                gl.glDeleteShader(shader)
        vs = compileShader(source, gl.GL_VERTEX_SHADER)
        fs = compileShader(fragment, gl.GL_FRAGMENT_SHADER)
        try:
            return int(compileProgram(vs, fs))
        finally:
            gl.glDeleteShader(vs); gl.glDeleteShader(fs)

    def _make_cube(self):
        vertices = []
        for axis in range(3):
            for sign in (-1., 1.):
                u, v = (axis+1)%3, (axis+2)%3
                corners = []
                for a, b in ((-1,-1),(1,-1),(1,1),(-1,1)):
                    q=np.zeros(3); q[axis]=sign; q[u]=a; q[v]=b
                    corners.append(q*.5)
                order=(0,1,2,0,2,3) if sign>0 else (0,2,1,0,3,2)
                normal=np.zeros(3); normal[axis]=sign
                for k in order: vertices.append(np.concatenate([corners[k],normal]))
        data=np.asarray(vertices,np.float32)
        self.vao=int(gl.glGenVertexArrays(1)); self.cube_vbo=int(gl.glGenBuffers(1))
        gl.glBindVertexArray(self.vao); gl.glBindBuffer(gl.GL_ARRAY_BUFFER,self.cube_vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER,data.nbytes,data,gl.GL_STATIC_DRAW)
        for index, offset in ((0,0),(1,12)):
            gl.glEnableVertexAttribArray(index)
            gl.glVertexAttribPointer(index,3,gl.GL_FLOAT,False,24,ctypes.c_void_p(offset))
        gl.glBindVertexArray(0)

    def clear(self):
        self._n=0; self._cursor=0; self.kick_scale=1.0
        self.recycle=True; self.cap=self.BASE_CAP; self.dropped=0
        self._spawn_batches=[]; self._batch_active=False; self._batch_max_launch=0.0
        self._max_size=0.0; self._min_size=math.inf; self._max_launch=0.0; self._max_height=0.0; self._max_area_mass=1.0
        self._awake=0; self._asleep=0; self._unsupported=0; self._known_sleep=True; self._stats_time=0.0
        self._pending=[]; self._pop_t=0.0              # blasts waiting out their squeeze hold; seconds of pop left after a launch
        self.hold_s=getattr(self,'hold_s',0.0); self.pop=getattr(self,'pop',0.0)
        if hasattr(self,'states'): self.states.reset()
        self.selected=-1
        self._obstacle_key=None; self._object_count=0; self._object_bytes=None
        self._blast_events=[]
        self._injected=0.0                              # the original bound: grows with every blast / spawn, never measured, only cleared here
        self._measured_ok=False                         # True once the GPU has reported a usable fastest-cube speed
        self._since_poll=0.0                            # simulated seconds since the GPU last reported its fastest cube
        self.last_steps=0; self.last_bound=0.0          # what the last advance() used (shown in the panel)
        self.rng=np.random.default_rng(99)

    def set_recycle(self, flag):
        flag=bool(flag)
        if flag==self.recycle: return
        self.recycle=flag
        self.cap=self.BASE_CAP if flag else self.MAX
        if flag and self._n>self.cap: self.cap=self._n      # keep what exists; wraps over the oldest from here
        if flag: self._cursor%=self.cap

    @property
    def n(self): return self._n

    def begin_spawn_batch(self):
        self._spawn_batches=[]; self._batch_max_launch=0.0; self._batch_active=True

    def _upload(self, buffer, data, offset=0, resize=False):
        gl.glBindBuffer(gl.GL_SHADER_STORAGE_BUFFER,buffer)
        if resize: gl.glBufferData(gl.GL_SHADER_STORAGE_BUFFER,max(data.nbytes,4),data if data.nbytes else None,gl.GL_DYNAMIC_DRAW)
        elif data.nbytes: gl.glBufferSubData(gl.GL_SHADER_STORAGE_BUFFER,offset,data.nbytes,data)

    def spawn_chunks(self,P,V,sizes,rgb,world=None,escape_normal=None,material=None,straight_time=0.0):
        P=np.asarray(P,np.float32).reshape(-1,3)
        if not len(P): return
        V=np.broadcast_to(np.asarray(V,np.float32),P.shape)
        sizes=np.broadcast_to(np.asarray(sizes,np.float32),(len(P),))
        rgb=np.broadcast_to(np.asarray(rgb,np.float32),P.shape)
        if np.any(sizes<=0) or not np.isfinite(P).all() or not np.isfinite(V).all():
            raise ValueError('Debris spawn requires finite positions/velocities and positive sizes.')
        rho=np.ones(len(P),np.float32)*1.9 if material is None else np.broadcast_to(self.E._S_RHO[np.asarray(material,dtype=np.int64)],(len(P),))
        data=np.zeros((len(P),5,4),np.float32)
        data[:,0,:3]=P; data[:,0,3]=sizes
        data[:,1,:3]=V; data[:,1,3]=self.rng.uniform(0,math.pi*.5,len(P))
        data[:,2,:3]=rgb; data[:,2,3]=rho*sizes**3
        data[:,3,:3]=P
        if self.recycle: data=data[-self.cap:]
        else:
            room=self.cap-self._n
            self.dropped+=max(0,len(data)-max(0,room))
            data=data[:max(0,room)]
        data=np.ascontiguousarray(data); k=len(data)
        if not k: return
        start=self._cursor; first=min(k,self.cap-start)
        self._upload(self.state[self.front],data[:first],start*self.STRIDE)
        if first<k: self._upload(self.state[self.front],data[first:],0)
        self.states.on_spawn(start,first,data[:first])
        if first<k: self.states.on_spawn(0,k-first,data[first:])
        if self._batch_active: self._spawn_batches.append((start,k))
        self._cursor=(start+k)%self.cap; self._n=min(self.cap,self._n+k)
        self._max_size=max(self._max_size,float(sizes.max()))
        self._min_size=min(self._min_size,float(sizes.min()))
        launch=float(np.linalg.norm(V,axis=1).max())
        self._max_launch=max(self._max_launch,launch); self._injected=max(self._injected,launch)
        self._max_area_mass=max(self._max_area_mass,float((.38/(rho*sizes)).max()))
        self._max_height=max(self._max_height,float(P[:,1].max()))
        if self._batch_active: self._batch_max_launch=max(self._batch_max_launch,launch)
        self._known_sleep=False; self._stats_time=0.0
        gl.glMemoryBarrier(gl.GL_BUFFER_UPDATE_BARRIER_BIT | gl.GL_SHADER_STORAGE_BARRIER_BIT)
        # Sections detached just after a blast inherit its wave, rather than
        # spawning with only the structural system's tiny downward scatter.
        if not self._batch_active and self._blast_events:
            event=self._blast_events[-1]
            self._blast_new_slots([(start,k)],event)

    def _bind(self):
        gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,0,self.state[self.front])
        gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,1,self.state[1-self.front])
        for i in range(2,9): gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,i,self.buffers[i])

    def _uniform(self,program,name,value):
        key=(program,name)
        if key not in self.locations: self.locations[key]=gl.glGetUniformLocation(program,name)
        loc=self.locations[key]
        if loc<0: return
        if isinstance(value,(int,np.integer)): gl.glUniform1i(loc,int(value))
        elif isinstance(value,(tuple,list,np.ndarray)): gl.glUniform3f(loc,*map(float,value))
        else: gl.glUniform1f(loc,float(value))

    def _dispatch(self,name,count=None,swap=False,**uniforms):
        count=self._n if count is None else count
        if count<=0: return
        program=self.programs[name]; gl.glUseProgram(program); self._bind()
        self._uniform(program,'n',self._n)
        for key,value in uniforms.items(): self._uniform(program,key,value)
        gl.glDispatchCompute((count+127)//128,1,1)
        gl.glMemoryBarrier(gl.GL_SHADER_STORAGE_BARRIER_BIT | gl.GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT | gl.GL_BUFFER_UPDATE_BARRIER_BIT)
        if swap: self.front=1-self.front
        gl.glUseProgram(0)

    def wake_sphere(self,centre,radius,column_up=0.0):
        self._dispatch('command',swap=True,command=0,centre=centre,radius=float(radius),columnUp=float(column_up))
        self._known_sleep=False; self._stats_time=0.0

    def wake_all(self,*args,**kwargs):
        self._dispatch('command',swap=True,command=1)
        self._known_sleep=False; self._stats_time=0.0



    def _blast_uniforms(self,event):
        return dict(centre=event['centre'], radius=event['radius'], blastPower=event['power'],
                    velocityScale=event['scale']*max(0.0,1.0-event['age']/.35), blastNormal=event['normal'], blastFocus=event.get('focus',0.5),
                    blastDome=event.get('dome',0.2), blastJitter=event.get('jitter',0.22), capacity=self.cap)

    def _blast_new_slots(self,batches,event):
        if not batches or not self._n: return
        gl.glBindBuffer(gl.GL_COPY_READ_BUFFER,self.state[self.front])
        gl.glBindBuffer(gl.GL_COPY_WRITE_BUFFER,self.state[1-self.front])
        gl.glCopyBufferSubData(gl.GL_COPY_READ_BUFFER,gl.GL_COPY_WRITE_BUFFER,0,0,self._n*self.STRIDE)
        uniforms=self._blast_uniforms(event)
        for start,count in batches:
            self._dispatch('command',count=count,command=5,startSlot=start,commandCount=count,**uniforms)
        self.front=1-self.front
        bound=min(80.0,12.0*math.sqrt(max(0.0,event['power']))*max(0.0,event['scale'])*self._max_area_mass)
        self._max_launch=max(self._max_launch,bound); self._injected=max(self._injected,bound)
        self._known_sleep=False; self._stats_time=0.0

    POP_SECONDS = 0.45                                   # how long after a launch the pop spring is active

    def _freeze_slots(self,batches):
        gl.glBindBuffer(gl.GL_COPY_READ_BUFFER,self.state[self.front])
        gl.glBindBuffer(gl.GL_COPY_WRITE_BUFFER,self.state[1-self.front])
        gl.glCopyBufferSubData(gl.GL_COPY_READ_BUFFER,gl.GL_COPY_WRITE_BUFFER,0,0,self._n*self.STRIDE)
        for start,count in batches:
            self._dispatch('command',count=count,command=7,startSlot=start,commandCount=count,capacity=self.cap)
        self.front=1-self.front
        self._known_sleep=False; self._stats_time=0.0

    def _release_due(self,dt):
        """Launch any blast whose squeeze hold has run out."""
        if not self._pending: return
        for p in self._pending: p['t']-=float(dt)
        due=[p for p in self._pending if p['t']<=0.0]
        self._pending=[p for p in self._pending if p['t']>0.0]
        for p in due:
            self._blast_new_slots(p['batches'],p['event'])
            self._pop_t=self.POP_SECONDS

    def apply_blast(self,centre,radius,power=1.0,velocity_scale=1.0,normal=None,spray=0.5):
        direction=np.zeros(3) if normal is None else np.asarray(normal,np.float64)
        length=float(np.linalg.norm(direction))
        direction=direction/length if length>1e-9 else np.zeros(3)
        event=dict(centre=np.asarray(centre,np.float64), radius=float(radius), power=float(power),
                   scale=float(velocity_scale), normal=direction, focus=float(spray), age=0.0)
        # Existing loose cubes receive an additional impulse, including sleepers.
        if self._n:
            added=min(80.0,12.0*math.sqrt(max(0.0,power))*max(0.0,velocity_scale)*self._max_area_mass)
            self._max_launch=max(self._max_launch,min(80.0,self._max_launch+added))
            self._injected=max(self._injected,min(80.0,self._injected+added))
        self._dispatch('command',swap=True,command=4,**self._blast_uniforms(event))
        # Direct fragments receive one coherent GPU launch, replacing the old
        # random launch and its hard 1 m/s upward clamp (no double application).
        if self.hold_s>0.0 and self._spawn_batches:
            # SQUEEZE HOLD: the fresh pile is frozen where it was placed; the launch is released after hold_s seconds.
            batches=list(self._spawn_batches)
            self._freeze_slots(batches)
            self._pending.append(dict(t=self.hold_s,batches=batches,event=dict(event,age=0.0)))
        else:
            self._blast_new_slots(self._spawn_batches,event)
            if self._spawn_batches: self._pop_t=self.POP_SECONDS
        self._spawn_batches=[]; self._batch_active=False
        self._blast_events.append(event)
        self.blast_count+=1
        self._since_poll=self.POLL_SIM                   # read the real speeds at the next advance, not up to 0.1 s later
        self._known_sleep=False; self._stats_time=0.0

    def _prepare_objects(self,objects):
        objects=[o for o in objects if o.live_count>0]
        key=tuple((id(o),o.mesh_ver,o.mat.shape) for o in objects)
        changed=key!=self._obstacle_key
        occupancy=[]; meta=np.zeros((len(objects),8,4),np.float32); offset=0
        for i,o in enumerate(objects):
            meta[i,0,:3]=o.frame_pos; meta[i,0,3]=o.cs
            meta[i,1,:3]=o.corner
            meta[i,2].view(np.int32)[:]=[*o.mat.shape,offset]
            for k in range(3): meta[i,3+k,:3]=o.R[:,k]
            meta[i,6,:3]=getattr(o,'v',np.zeros(3)); meta[i,7,:3]=getattr(o,'w',np.zeros(3))
            if changed:
                # Occupancy plus six exposed-face bits; internal voxel seams are not collision surfaces.
                mask=np.asarray(o.alive,np.uint32).copy()
                for face in range(6): mask|=np.asarray(o.expo[...,face],np.uint32)<<np.uint32(face+1)
                occupancy.append(mask.ravel())
            offset+=o.alive.size
        if changed:
            data=np.concatenate(occupancy) if occupancy else np.zeros(1,np.uint32)
            self._upload(self.buffers[7],data,resize=True)
            self._obstacle_key=key; self._known_sleep=False
        raw=meta.tobytes()
        if raw!=self._object_bytes:
            self._upload(self.buffers[6],meta,resize=True); self._object_bytes=raw
            self._known_sleep=False
        self._object_count=len(objects)

    def advance(self,dt,substeps,objects):
        for event in self._blast_events: event['age']+=float(dt)
        self._blast_events=[event for event in self._blast_events if event['age']<.35]
        self._release_due(dt)
        if not self._n: return
        self._prepare_objects(objects)
        if self._known_sleep: return
        self._since_poll+=float(dt)
        if self._since_poll>=self.POLL_SIM:
            self._poll()                              # resets _max_launch to the speed the fastest cube really has
            if self._known_sleep: return
        # Bound travel to under half a smallest cube. Ceiling (the original rule): spawn/blast speed + freefall from the
        # scene's current top. When the GPU has reported its fastest cube, a tighter bound is used instead if it is lower:
        # 1.25 x that speed, plus what gravity can add since the reading. It can only lower the ceiling, never raise it.
        g=max(0.0,float(self.E.STRUCT_GRAVITY))
        height=max([float(o.aabb()[1][1]) for o in objects]+[1.0,self._max_height])
        speed=self._injected+math.sqrt(2*g*max(height,1.0))
        if self._measured_ok:
            speed=min(speed,1.25*self._max_launch+g*self._since_poll+0.5)
        popK=self.pop if self._pop_t>0.0 else 0.0
        if self._pop_t>0.0: self._pop_t=max(0.0,self._pop_t-float(dt))
        speed+=min(40.0,0.25*popK)                        # the pop spring can add speed beyond the launch speed
        required=math.ceil(float(dt)*max(speed,1.0)/(.4*self._min_size))
        steps=max(int(substeps),required,1)
        self.last_steps=steps; self.last_bound=speed
        h=float(dt)/steps
        common=dict(dt=h,gravity=float(self.E.STRUCT_GRAVITY),objectCount=self._object_count,
                    cellSize=self._max_size*1.8,tumble=float(self.kick_scale),popStrength=float(popK))
        # One substep is 14 dispatches and a frame can run hundreds, so each dispatch must cost as few GL calls as possible:
        # the buffers that never change and every uniform (all constant for this call) are set once here, not once per dispatch.
        self._begin_solver(common)
        for _ in range(steps):
            self._run('integrate',swap=True)
            for iteration in range(self.ITERATIONS):
                self._run('clear_grid',count=8192)
                self._run('build_grid')
                self._run('count')
                self._run('solve',swap=True)
            self._run('sleep',swap=True)
        gl.glUseProgram(0)

    SOLVER_PROGRAMS=('integrate','clear_grid','build_grid','count','solve','sleep')

    def _begin_solver(self,uniforms):
        for i in range(2,9): gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,i,self.buffers[i])
        self._bound_front=None                      # buffers 0/1 (the ping-pong pair) are bound lazily by _run
        for name in self.SOLVER_PROGRAMS:
            program=self.programs[name]; gl.glUseProgram(program)
            self._uniform(program,'n',self._n)
            for key,value in uniforms.items(): self._uniform(program,key,value)

    def _run(self,name,count=None,swap=False):
        """_dispatch without the per-call binding and uniform work; only valid between _begin_solver and the end of advance."""
        gl.glUseProgram(self.programs[name])
        if self._bound_front!=self.front:
            gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,0,self.state[self.front])
            gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,1,self.state[1-self.front])
            self._bound_front=self.front
        gl.glDispatchCompute(((self._n if count is None else count)+127)//128,1,1)
        gl.glMemoryBarrier(gl.GL_SHADER_STORAGE_BARRIER_BIT | gl.GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT | gl.GL_BUFFER_UPDATE_BARRIER_BIT)
        if swap: self.front=1-self.front

    def _poll(self):
        """Read back awake / asleep counts and the fastest cube's speed (one small readback)."""
        self._upload(self.buffers[8],np.zeros(4,np.uint32))
        ceiling=max(self.last_bound,self._injected)+20.0 if self.last_bound>0 else 1.0e4
        self._dispatch('command',command=3,velocityScale=float(ceiling))
        gl.glBindBuffer(gl.GL_SHADER_STORAGE_BUFFER,self.buffers[8])
        counters=np.frombuffer(gl.glGetBufferSubData(gl.GL_SHADER_STORAGE_BUFFER,0,16),np.uint32)
        self._awake,self._asleep=map(int,counters[:2])
        self._unsupported=int(counters[3])
        self._asleep=max(0,self._asleep-self.states.dead_count)       # deleted cubes are parked asleep: not real sleepers
        self._known_sleep=self._awake==0
        self._stats_time=time.perf_counter()
        fastest=float(counters[2:3].view(np.float32)[0])
        self._measured_ok=math.isfinite(fastest)
        if self._measured_ok: self._max_launch=fastest
        self._since_poll=0.0

    def sleep_count(self):
        if self._n and time.perf_counter()-self._stats_time>=.25:
            self._poll()
        return min(self._asleep,self._n)

    def render(self):
        if not self._n: return
        gl.glUseProgram(self.draw_program)
        gl.glUniform1i(gl.glGetUniformLocation(self.draw_program,'activityView'),1 if self.activity_view else 0)
        gl.glUniform1i(gl.glGetUniformLocation(self.draw_program,'stateView'),1 if self.state_view else 0)
        gl.glUniform1i(gl.glGetUniformLocation(self.draw_program,'hiddenStates'),int(self.hidden_mask))
        gl.glUniform1i(gl.glGetUniformLocation(self.draw_program,'selected'),int(self.selected))
        gl.glUniform1f(gl.glGetUniformLocation(self.draw_program,'pulse'),float(self.pulse))
        gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER,0,self.state[self.front])
        gl.glBindVertexArray(self.vao)
        gl.glDrawArraysInstanced(gl.GL_TRIANGLES,0,36,self._n)
        gl.glBindVertexArray(0); gl.glUseProgram(0)

    def close(self):
        for program in getattr(self,'programs',{}).values(): gl.glDeleteProgram(program)
        if hasattr(self,'draw_program'): gl.glDeleteProgram(self.draw_program)
        if getattr(self,'buffers',None): gl.glDeleteBuffers(len(self.buffers),self.buffers)
        if getattr(self,'vao',None): gl.glDeleteVertexArrays(1,[self.vao])
        if hasattr(self,'cube_vbo'): gl.glDeleteBuffers(1,[self.cube_vbo])
        self.programs={}; self.buffers=[]; self.vao=None


Debris = GpuDebris


# ------------------------------------------------------------------------------------------------ cube state manager
# Every loose cube is classified from the five vec4s the GPU keeps for it (the same fields the shaders use), and the manager
# keeps a life record per cube: when it spawned and why, how long it has been in each state, how far it has moved, how often it
# was woken or hit. The GPU does all the physics; the manager only READS (a full read-back about 4 times a second, 10 while a
# cube is selected, one 80-byte read per frame for the selected cube, and nothing at all while the feature is off).
(ST_EMPTY, ST_SLEEP, ST_SLEEP_UNSUP, ST_SETTLING, ST_RESTING, ST_SLIDING, ST_BOUNCING,
 ST_RISING, ST_FALLING, ST_DRIFTING, ST_WEDGED) = range(11)
STATE_NAMES = ['(deleted)', 'SLEEPING', 'SLEEP, NO SUPPORT', 'SETTLING', 'RESTING', 'SLIDING', 'BOUNCING',
               'RISING', 'FALLING', 'DRIFTING', 'WEDGED IN AIR']
STATE_RGB = [(90, 90, 90), (51, 107, 242), (255, 26, 230), (26, 230, 230), (77, 217, 64), (255, 153, 26), (242, 242, 242),
             (255, 242, 77), (255, 38, 26), (255, 140, 179), (153, 77, 255)]       # = stateColour() in the vertex shader
ORIGIN_TEXT = {0: 'unknown', 1: 'direct blast fragment', 2: 'detached just after a blast', 3: 'collapse (lost its support)'}


class CubeStateManager:
    SLOW = 0.15            # m/s: below this a cube counts as slow (same constant as the sleep shader)
    NEAR = 0.03            # anchor radius, as a fraction of the cube's size (sleep shader)
    SLEEP_T = 0.5          # seconds immobile before the sleep shader freezes a cube
    WEDGE_T = 0.1          # seconds immobile, with no support, before a cube is called WEDGED
    IDLE_HZ, SELECTED_HZ = 4.0, 10.0
    HISTORY = 12           # state changes remembered for the selected cube

    def __init__(self, debris):
        self.d = debris
        self.t = 0.0                                   # simulated seconds (advances only while the bench is running)
        self.ui_open = False                           # the manager window (Ctrl+click opens / closes it)
        self.panel_rects = []                          # screen rects of the manager's windows (clicks on them never explode the wall)
        self.rows, self.list_rect, self.scroll = [], None, 0
        self.reset()

    # ---- bookkeeping ----------------------------------------------------------------------------------------------
    def reset(self):
        M = self.d.MAX
        self.snap, self.snap_n, self.snap_wall, self.t_update = None, 0, 0.0, self.t
        self.code = np.zeros(M, np.int8)
        self.fresh = np.zeros(M, bool)                 # spawned since the last read: no previous state to compare with
        self.gen = np.zeros(M, np.int32)               # how many cubes have used this slot
        self.birth_t = np.zeros(M, np.float32); self.state_since = np.zeros(M, np.float32)
        self.origin = np.zeros(M, np.int8); self.origin_blast = np.zeros(M, np.int32)
        self.birth_pos = np.zeros((M, 3), np.float32); self.prev_pos = np.zeros((M, 3), np.float32)
        self.prev_hit = np.zeros(M, bool)
        self.travelled = np.zeros(M, np.float32); self.max_speed = np.zeros(M, np.float32); self.max_height = np.zeros(M, np.float32)
        self.transitions = np.zeros(M, np.int32); self.wakes = np.zeros(M, np.int32)
        self.sleeps = np.zeros(M, np.int32); self.impacts = np.zeros(M, np.int32)
        self.awake_time = np.zeros(M, np.float32); self.asleep_time = np.zeros(M, np.float32)
        self.counts = np.zeros(len(STATE_NAMES), np.int64)
        self.awake_idx = np.zeros(0, np.int64)         # slots of the awake cubes, longest in their state first
        self.listed_idx = np.zeros(0, np.int64)        # what the manager lists: awake cubes + cubes asleep with no support
        self.dead = np.zeros(M, bool); self.dead_count = 0                 # deleted cubes (tombstones on the GPU)
        self.awake_since = np.zeros(M, np.float32)     # when the cube last became awake (spawn, or woken from sleep)
        self.scroll = 0
        self.sel_slot, self.sel_cube, self.sel_code, self.sel_touch = -1, None, -1, None
        self.sel_hist = deque(maxlen=self.HISTORY); self.sel_hit = False
        self.d.selected = -1

    def tick(self, dt):
        self.t += float(dt)

    def active(self):
        return bool(self.d.state_view or self.d.selected >= 0 or self.ui_open)

    def on_spawn(self, start, count, data):
        """A batch of new cubes was written to slots start..start+count (GpuDebris.spawn_chunks)."""
        if count <= 0:
            return
        d, sl = self.d, slice(start, start + count)
        kind = 1 if d._batch_active else (2 if d._blast_events else 3)
        blast = d.blast_count + 1 if kind == 1 else d.blast_count
        self.gen[sl] += 1; self.fresh[sl] = True; self.code[sl] = ST_EMPTY
        self.birth_t[sl] = self.t; self.state_since[sl] = self.t; self.awake_since[sl] = self.t
        self.dead[sl] = False; self.dead_count = int(self.dead[:max(self.d.n, start + count)].sum())
        self.origin[sl] = kind; self.origin_blast[sl] = blast
        self.birth_pos[sl] = data[:count, 0, :3]; self.prev_pos[sl] = data[:count, 0, :3]; self.prev_hit[sl] = False
        for a in (self.travelled, self.max_speed, self.transitions, self.wakes, self.sleeps, self.impacts,
                  self.awake_time, self.asleep_time):
            a[sl] = 0
        self.max_height[sl] = data[:count, 0, 1]
        if start <= self.sel_slot < start + count:
            self.sel_hist.append((self.t, 'slot reused: a new cube spawned here'))
            self.sel_code = -1

    # ---- reading the GPU ------------------------------------------------------------------------------------------
    def _read(self, slot0, count):
        d = self.d
        gl.glBindBuffer(gl.GL_SHADER_STORAGE_BUFFER, d.state[d.front])
        raw = gl.glGetBufferSubData(gl.GL_SHADER_STORAGE_BUFFER, slot0 * d.STRIDE, count * d.STRIDE)
        return np.frombuffer(raw, np.float32).reshape(count, 5, 4).copy()

    @classmethod
    def classify(cls, A):
        """State code of every cube in A (n x 5 x 4: ps, vy, colour, anchor, flags). Mirrors cubeState() in the vertex shader."""
        ps, vy, an, fl = A[:, 0], A[:, 1], A[:, 3], A[:, 4]
        speed = np.linalg.norm(vy[:, :3], axis=1); hs = np.hypot(vy[:, 0], vy[:, 2])
        near = np.linalg.norm(ps[:, :3] - an[:, :3], axis=1) < ps[:, 3] * cls.NEAR
        settled, asleep, sup = fl[:, 2] > .5, fl[:, 0] > .5, fl[:, 1] > .5
        slow = (speed < cls.SLOW) | (settled & near)           # the sleep shader's rule in this file
        timer = an[:, 3]
        code = np.full(len(A), ST_DRIFTING, np.int8)
        air = ~asleep & ~sup
        code[air & (vy[:, 1] > cls.SLOW)] = ST_RISING
        code[air & (vy[:, 1] < -cls.SLOW)] = ST_FALLING
        code[air & slow & near & (timer >= cls.WEDGE_T)] = ST_WEDGED
        held = ~asleep & sup
        code[held & slow & (timer > 0)] = ST_SETTLING
        code[held & slow & ~(timer > 0)] = ST_RESTING
        code[held & ~slow & (hs >= cls.SLOW)] = ST_SLIDING
        code[held & ~slow & ~(hs >= cls.SLOW)] = ST_BOUNCING
        code[asleep & settled] = ST_SLEEP
        code[asleep & ~settled] = ST_SLEEP_UNSUP
        return code

    def update(self):
        """Call once per frame, after the simulation step. Reads the GPU only while the manager / state view / a selection is on,
        or while the Cube state tab is open."""
        d = self.d
        if not d.n:
            return
        now = time.perf_counter()
        if self.active():
            period = 1.0 / (self.SELECTED_HZ if d.selected >= 0 else self.IDLE_HZ)
            if self.snap is None or now - self.snap_wall >= period:
                self.snapshot()
            self.refresh_selected()

    def snapshot(self):
        """Read every cube, classify it, and fold the change since the last read into each cube's life record."""
        d, n = self.d, self.d.n
        A = self._read(0, n)
        code = self.classify(A)
        dead = A[:, 0, 1] > 1.0e5                       # tombstone: parked 1000 km up by command 6
        code[dead] = ST_EMPTY
        self.dead[:n] = dead; self.dead_count = int(dead.sum())
        old, fresh = self.code[:n], self.fresh[:n]
        dt = max(0.0, self.t - self.t_update)
        was_asleep = (old == ST_SLEEP) | (old == ST_SLEEP_UNSUP)
        now_asleep = (code == ST_SLEEP) | (code == ST_SLEEP_UNSUP)
        changed = (old != code) & ~fresh
        self.transitions[:n] += changed
        self.wakes[:n] += changed & was_asleep & ~now_asleep
        self.sleeps[:n] += changed & now_asleep & ~was_asleep
        self.state_since[:n] = np.where(changed | fresh, np.float32(self.t), self.state_since[:n])
        hit = A[:, 4, 3] > .5
        self.impacts[:n] += hit & ~self.prev_hit[:n]
        pos = A[:, 0, :3]
        self.travelled[:n] += np.where(fresh, 0.0, np.linalg.norm(pos - self.prev_pos[:n], axis=1)).astype(np.float32)
        self.max_speed[:n] = np.maximum(self.max_speed[:n], np.linalg.norm(A[:, 1, :3], axis=1))
        self.max_height[:n] = np.maximum(self.max_height[:n], pos[:, 1])
        step = np.float32(dt) * ~fresh
        self.awake_time[:n] += step * (~now_asleep & ~dead)
        self.asleep_time[:n] += step * now_asleep
        self.awake_since[:n] = np.where(now_asleep | dead, np.float32(self.t), self.awake_since[:n])
        self.prev_pos[:n] = pos; self.prev_hit[:n] = hit
        self.code[:n] = code; self.fresh[:n] = False
        self.counts = np.bincount(code, minlength=len(STATE_NAMES))
        idx = np.flatnonzero(~now_asleep & ~dead)
        self.awake_idx = idx[np.argsort(self.state_since[idx], kind='stable')]
        both = np.concatenate([idx, np.flatnonzero(code == ST_SLEEP_UNSUP)])
        self.listed_idx = both[np.argsort(self.state_since[both], kind='stable')]
        self.snap, self.snap_n, self.snap_wall, self.t_update = A, n, time.perf_counter(), self.t

    # ---- the selected cube ----------------------------------------------------------------------------------------

    def row_text(self, slot):
        """One line of the awake list for a cube: its tag, state, time in that state and speed."""
        code = int(self.code[slot])
        speed = float(np.linalg.norm(self.snap[slot, 1, :3])) if self.snap is not None and slot < self.snap_n else 0.0
        return '#%-6d %-17s %5.1fs  v%.2f' % (slot, STATE_NAMES[code], max(0.0, self.t - float(self.state_since[slot])), speed), STATE_RGB[code]

    def select(self, slot):
        d = self.d
        d.selected = int(slot) if slot is not None and 0 <= slot < d.n else -1
        self.sel_slot = d.selected
        self.sel_hist.clear(); self.sel_code = -1; self.sel_cube = None; self.sel_touch = None; self.sel_hit = False
        if d.selected >= 0:
            self.snapshot()
            self.refresh_selected()

    def pick(self, origin, direction, max_t=math.inf):
        """The loose cube nearest along a ray (and nearer than max_t), or None. Uses a fresh read so it matches what is on screen."""
        if not self.d.n:
            return None
        self.snapshot()
        A = self.snap
        P, r = A[:, 0, :3].astype(np.float64), A[:, 0, 3].astype(np.float64) * 0.75
        oc = P - np.asarray(origin, np.float64)
        t = oc @ np.asarray(direction, np.float64)
        hit = (t > 0) & (t < max_t) & ((oc * oc).sum(1) - t * t < r * r)
        idx = np.flatnonzero(hit)
        return int(idx[np.argmin(t[idx])]) if len(idx) else None

    def refresh_selected(self):
        slot, d = self.sel_slot, self.d
        if slot < 0:
            return
        if slot >= d.n:
            self.select(-1); return
        cube = self._read(slot, 1)[0]
        code = int(self.classify(cube[None])[0])
        hit = bool(cube[4, 3] > .5)
        if code != self.sel_code:
            if self.sel_code >= 0:
                self.sel_hist.append((self.t, '%s -> %s  (|v| %.2f m/s)' % (STATE_NAMES[self.sel_code], STATE_NAMES[code],
                                                                          float(np.linalg.norm(cube[1, :3])))))
            else:
                self.sel_hist.append((self.t, 'selected while %s' % STATE_NAMES[code]))
        elif hit and not self.sel_hit and self.t - getattr(self, '_last_impact_log', -9.0) > 1.0:
            self._last_impact_log = self.t
            self.sel_hist.append((self.t, 'impact while %s  (|v| %.2f m/s)' % (STATE_NAMES[code], float(np.linalg.norm(cube[1, :3])))))
        self.sel_code, self.sel_hit, self.sel_cube = code, hit, cube
        # keep the per-cube record current for the selected cube too (it is read every frame, so its state is never stale)
        if self.code[slot] != code and not self.fresh[slot]:
            self.code[slot] = code
        self.sel_touch = self._touching(slot, cube)

    def _touching(self, slot, cube):
        """Cubes in contact with the selected one, from the latest full read (at most 0.1 s old)."""
        A, n = self.snap, self.snap_n
        p, s = cube[0, :3].astype(np.float64), float(cube[0, 3])
        out = dict(below=0, side=0, above=0, asleep=0, awake=0, floor=bool(p[1] - s / 2 < 0.06), codes=[])
        if A is None or n <= 1:
            return out
        P, S = A[:n, 0, :3].astype(np.float64), A[:n, 0, 3].astype(np.float64)
        dv = P - p
        dist = np.linalg.norm(dv, axis=1)
        m = dist < (S + s) * 0.5 * 1.45
        if 0 <= slot < n:
            m[slot] = False
        idx = np.flatnonzero(m)
        if not len(idx):
            return out
        horizontal = np.maximum(np.abs(dv[idx, 0]), np.abs(dv[idx, 2]))
        vertical = np.abs(dv[idx, 1]) >= horizontal * 0.9
        out['below'] = int((vertical & (dv[idx, 1] < 0)).sum()); out['above'] = int((vertical & (dv[idx, 1] > 0)).sum())
        out['side'] = int((~vertical).sum())
        sl = (self.code[idx] == ST_SLEEP) | (self.code[idx] == ST_SLEEP_UNSUP)
        out['asleep'] = int(sl.sum()); out['awake'] = int((~sl).sum())
        return out

    # ---- the description ------------------------------------------------------------------------------------------
    def doing(self, cube, code):
        v = cube[1, :3]; speed = float(np.linalg.norm(v)); hs = float(np.hypot(v[0], v[2])); timer = float(cube[3, 3])
        g = float(self.d.E.STRUCT_GRAVITY)
        drift = float(np.linalg.norm(cube[0, :3] - cube[3, :3])); limit = float(cube[0, 3]) * self.NEAR
        return {
            ST_SLEEP: 'Asleep on a settled support. Frozen: no physics until a blast, wake command or impact from an awake cube.',
            ST_SLEEP_UNSUP: 'Asleep but with NO settled support: frozen where it was wedged. Nothing will wake it unless a blast or impact reaches it.',
            ST_SETTLING: 'Awake and almost still. Sleep timer %.2f of %.2f s: it sleeps when this reaches the limit without leaving its anchor.' % (timer, self.SLEEP_T),
            ST_RESTING: 'Awake and supported, barely moving, but the sleep timer is 0: it moved %.4f m from its anchor (limit %.4f m) so the count restarted.' % (drift, limit),
            ST_SLIDING: 'Touching something and sliding or rolling along it at %.2f m/s sideways (%.2f m/s overall).' % (hs, speed),
            ST_BOUNCING: 'In contact but moving mostly vertically (%.2f m/s): bouncing, or being pushed up or down by neighbours.' % float(v[1]),
            ST_RISING: 'Airborne and rising at %.2f m/s (%.2f m/s overall). Nothing is holding it; gravity %.1f m/s^2 is slowing it.' % (float(v[1]), speed, g),
            ST_FALLING: 'Airborne and falling at %.2f m/s (%.2f m/s overall) under gravity %.1f m/s^2. Nothing is holding it.' % (-float(v[1]), speed, g),
            ST_DRIFTING: ('Awake, with no support flag, and stored speed %.2f m/s, but it has not moved from its anchor (%.4f m): jammed between neighbours. Residual velocity only.' % (speed, drift)
                          if drift < limit else
                          'Airborne, vertical speed near 0 (top of its arc), moving %.2f m/s overall. Nothing is holding it.' % speed),
            ST_WEDGED: 'Held in the air by contacts but not counted as supported. Immobile for %.2f s; it sleeps at %.2f s.' % (timer, self.SLEEP_T),
        }.get(code, '')

    def lines(self):
        """The selected cube as [(text, colour)], or None. Plain text, at most ~60 characters per line."""
        if self.sel_slot < 0 or self.sel_cube is None:
            return None
        import textwrap
        c, slot, code = self.sel_cube, self.sel_slot, self.sel_code
        ps, vy, col, an, fl = c
        speed, hs = float(np.linalg.norm(vy[:3])), float(np.hypot(vy[0], vy[2]))
        T, W, DIM, HI = (225, 230, 240), (255, 214, 120), (150, 158, 176), STATE_RGB[code]
        drift = float(np.linalg.norm(ps[:3] - an[:3])); limit = float(ps[3]) * self.NEAR
        tc = self.sel_touch or {}
        out = [('CUBE #%d   (cube number %d in this slot)' % (slot, int(self.gen[slot])), W),
               ('%s   for %.2f s' % (STATE_NAMES[code], max(0.0, self.t - float(self.state_since[slot]))), HI)]
        out += [(t, T) for t in textwrap.wrap(self.doing(c, code), 60)]
        out += [('', T),
                ('position  %8.3f %8.3f %8.3f m' % tuple(ps[:3]), T),
                ('bottom is %.3f m above the floor' % (ps[1] - ps[3] / 2), T),
                ('size %.3f m   mass %.4f   yaw %.0f deg' % (ps[3], col[3], math.degrees(float(vy[3])) % 360.0), T),
                ('velocity  %8.3f %8.3f %8.3f m/s' % tuple(vy[:3]), T),
                ('speed %.3f   sideways %.3f   vertical %.3f' % (speed, hs, vy[1]), T),
                ('', T),
                ('asleep %s   supported %s   settled support %s' % tuple('yes' if x > .5 else 'no' for x in (fl[0], fl[1], fl[2])), T),
                ('contact this step: %s' % ('yes (impact-level)' if fl[3] > .5 else 'no'), T),
                ('sleep timer %.2f / %.2f s   drift %.4f / %.4f m' % (an[3], self.SLEEP_T, drift, limit), T)]
        if tc:
            under = 'floor' if tc['floor'] else ('%d cube(s) below' % tc['below'] if tc['below'] else
                    ('static structure (inferred)' if fl[1] > .5 else 'nothing'))
            out += [('touching %d cubes: %d below, %d beside, %d above' % (tc['below'] + tc['side'] + tc['above'], tc['below'], tc['side'], tc['above']), T),
                    ('neighbours asleep %d, awake %d   resting on: %s' % (tc['asleep'], tc['awake'], under), T)]
        out += [('', T),
                ('origin: %s%s' % (ORIGIN_TEXT[int(self.origin[slot])], (' #%d' % self.origin_blast[slot]) if self.origin_blast[slot] else ''), T),
                ('age %.1f s   awake %.1f s   asleep %.1f s' % (self.t - self.birth_t[slot], self.awake_time[slot], self.asleep_time[slot]), T),
                ('travelled %.1f m (sampled)   top speed %.1f m/s' % (self.travelled[slot], self.max_speed[slot]), T),
                ('highest point %.1f m   spawned at y %.1f m' % (self.max_height[slot], self.birth_pos[slot][1]), T),
                ('impacts %d   woken %d   slept %d   state changes %d' % (self.impacts[slot], self.wakes[slot], self.sleeps[slot], self.transitions[slot]), T)]
        if self.sel_hist:
            out += [('', T), ('recent events (newest last)', W)]
            for t, text in list(self.sel_hist)[-6:]:
                out += [(t2, DIM) for t2 in textwrap.wrap('t=%.2f  %s' % (t, text), 60, subsequent_indent='   ')]
        return out



# ------------------------------------------------------------------------------------------------ meshes
STOPS = [0.0, 0.2, 0.5, 0.8, 1.0]                          # the cannon's damage colours: yellow, orange, red, dark
DMG_RGB = np.array([[240, 205, 70], [240, 205, 70], [244, 138, 36], [222, 52, 40], [120, 18, 52]], np.float64) / 255.0
DMG_A = [0.0, 0.6, 0.75, 0.85, 0.92]


def cell_colour(E, mat, tint, dmg):
    base = E._S_RGB[mat].astype(np.float64) * tint[:, None]
    d = np.clip(dmg, 0.0, 1.0)
    col = np.stack([np.interp(d, STOPS, DMG_RGB[:, k]) for k in range(3)], axis=1)
    a = np.interp(d, STOPS, DMG_A)[:, None]
    return base + (col - base) * a


def stress_colours(E, o, ii):
    """Completed structural load ratios; grey means unmeasured, not safe."""
    valid = (hasattr(o,'anch') and o.live_count <= E.STRUCT_UNBREAKABLE_CELLS
             and getattr(o,'stress_ver',0) > 0)
    if not valid: return np.full((len(ii[0]),3),.43,np.float64)
    ratio=np.clip(o.stress[ii],0.,1.)
    return np.stack([np.interp(ratio,[0,.5,1],[.12,.98,.95]),
                     np.interp(ratio,[0,.5,1],[.72,.78,.12]),
                     np.interp(ratio,[0,.5,1],[.24,.08,.05])],axis=1)


def build_crack_lines(o):
    """Surface damage marks: deterministic paths grow with actual cell damage."""
    out=[]
    damage=np.clip(np.maximum(o.cdmg/.85,o.idmg),0.,1.)
    for face in range(6):
        idx=np.argwhere(o.expo[...,face] & (damage>.04))
        if not len(idx): continue
        amount=damage[tuple(idx.T)]
        axis=face//2; u,v=(axis+1)%3,(axis+2)%3
        # Offsets stay within the damaged cell; surface normals keep depth tests correct.
        centre=(idx.astype(float)+.5)*o.cs+o.corner
        centre[:,axis]+=(-1 if face%2==0 else 1)*o.cs*.502
        seed=((idx[:,0]*73856093)^(idx[:,1]*19349663)^(idx[:,2]*83492791)^face)&3
        length=o.cs*(.12+.70*amount)
        paths=[]
        for step,offset in enumerate((-.5,-.18,.12,.5)):
            q=centre.copy();q[:,u]+=offset*length
            q[:,v]+=np.where((seed+step)%2==0,-1.,1.)*length*.13
            paths.append(q)
        colour=np.column_stack((.12+.28*amount,.025+.035*amount,np.full(len(idx),.015)))
        for a,b in zip(paths[:-1],paths[1:]):
            lines=np.empty((len(idx),2,6),np.float32)
            lines[:,0,:3]=a;lines[:,1,:3]=b;lines[:,:,3:]=colour[:,None,:]
            out.append(lines.reshape(-1,6))
    return np.concatenate(out) if out else np.zeros((0,6),np.float32)


MESH_FLOATS = 12                                           # per vertex: position 3, normal 3, colour 3, texture u, v and tile layer


def build_mesh(E, o, stress_debug=False):
    """(triangles (n, 9) float32 [pos, normal, colour], line vertices (m, 3)) for the exposed faces of a grid object, in its own frame."""
    cs = o.cs
    tris, lines = [], []
    on_floor = isinstance(o, E.Structure) and abs(float(o.frame_pos[1])) < 1e-4       # a fixed structure standing on the floor (y = 0)
    for f in range(6):
        idx = np.argwhere(o.expo[..., f])
        if on_floor and f == 2:                                  # its lowest layer's downward faces lie on the floor: nobody can see them, so they are not drawn
            idx = idx[idx[:, 1] != 0]
        if not len(idx):
            continue
        ax, sg = f // 2, (1.0 if f % 2 else -1.0)
        u, v = (ax + 1) % 3, (ax + 2) % 3
        base = idx.astype(np.float64)
        base[:, ax] += 1.0 if sg > 0 else 0.0
        corners = []
        for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)):
            p = base.copy(); p[:, u] += du; p[:, v] += dv
            corners.append(p)
        order = (0, 1, 2, 0, 2, 3) if sg > 0 else (0, 2, 1, 0, 3, 2)
        tri = np.stack([corners[k] for k in order], axis=1) * cs + o.corner
        ii = (idx[:, 0], idx[:, 1], idx[:, 2])
        col = stress_colours(E,o,ii) if stress_debug else cell_colour(E, o.mat[ii], o.tint[ii], o.idmg[ii])
        nrm = np.zeros(3); nrm[ax] = sg
        arr = np.empty((len(idx), 6, MESH_FLOATS), np.float32)
        arr[:, :, 0:3] = tri
        arr[:, :, 3:6] = nrm
        arr[:, :, 6:9] = col[:, None, :]
        # texture coordinates: object-frame metres (one tile per metre), so the pattern runs unbroken from cell to cell and turns with a toppled piece
        if ax == 0:   arr[:, :, 9], arr[:, :, 10] = tri[:, :, 2], -tri[:, :, 1]
        elif ax == 1: arr[:, :, 9], arr[:, :, 10] = tri[:, :, 0], tri[:, :, 2]
        else:         arr[:, :, 9], arr[:, :, 10] = tri[:, :, 0], -tri[:, :, 1]
        arr[:, :, 11] = -1.0 if stress_debug else E._S_TEXLAYER[o.mat[ii]][:, None]      # -1 = plain colour (stress view, materials with no tile)
        tris.append(arr.reshape(-1, MESH_FLOATS))
        quad = np.stack(corners, axis=1) * cs + o.corner
        ln = np.stack([quad, np.roll(quad, -1, axis=1)], axis=2)
        lines.append(ln.reshape(-1, 3).astype(np.float32))
    if not tris:
        return np.zeros((0, MESH_FLOATS), np.float32), np.zeros((0, 3), np.float32)
    return np.concatenate(tris), np.concatenate(lines)


class MeshCache:
    def __init__(self, E):
        self.E = E
        self.items = {}                                    # id(obj) -> [key, vbo_tri, n_tri, vbo_line, n_line, last_frame]
        self.frame = 0

    def get(self, o, stress_debug=False):
        key = (o.mesh_ver, o.alive.shape, float(o.cs), tuple(o.corner), int(o.mat.sum()), int(o.alive.sum()), round(float(o.idmg.sum()), 3), bool(stress_debug), getattr(o,'stress_ver',0) if stress_debug else 0, round(float(o.cdmg.sum()),4) if stress_debug else 0)
        it = self.items.get(id(o))
        if it is None:
            it = self.items[id(o)] = [None, int(gl.glGenBuffers(1)), 0, int(gl.glGenBuffers(1)), 0, 0, int(gl.glGenBuffers(1)), 0]
        if it[0] != key:
            tri, ln = build_mesh(self.E, o, stress_debug)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, it[1])
            gl.glBufferData(gl.GL_ARRAY_BUFFER, max(tri.nbytes, 4), tri if len(tri) else None, gl.GL_DYNAMIC_DRAW)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, it[3])
            gl.glBufferData(gl.GL_ARRAY_BUFFER, max(ln.nbytes, 4), ln if len(ln) else None, gl.GL_DYNAMIC_DRAW)
            cracks=build_crack_lines(o) if stress_debug else np.zeros((0,6),np.float32)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER,it[6])
            gl.glBufferData(gl.GL_ARRAY_BUFFER,max(cracks.nbytes,4),cracks if len(cracks) else None,gl.GL_DYNAMIC_DRAW)
            it[7]=len(cracks)
            it[0], it[2], it[4] = key, len(tri), len(ln)
        it[5] = self.frame
        return it

    def sweep(self):
        for k in [k for k, it in self.items.items() if it[5] < self.frame]:
            it = self.items.pop(k)
            gl.glDeleteBuffers(3, [it[1], it[3], it[6]])
        self.frame += 1


# ------------------------------------------------------------------------------------------------ blast effect (from Shatterlands)
FX_DETAIL = 9                # the game's default cube detail and debris size: they fix the effect's cube sizes and count
FX_SIZE = 1.5
FX_REF_R = 0.7875            # the game's default blast radius (C4_RADIUS x blast scale), in metres: the effect scales with radius / this
FX_BLAST_SCALE = 0.525       # the game's default blast scale (BLAST_BASE_SCALE x TNT size)


class BlastFX:
    """The Shatterlands blast effect (its smoke column is added by the bench): a white-hot flash, then a fireball of big burning cubes that bursts out,
    leans up and cools from white through yellow and orange to red, a low ring of dust racing over the ground (ground blasts) and a
    spray of sparks. Purely visual: the cubes are not physics bodies; they test the bench's structures and floor so fire and dust
    stop at walls and sparks bounce. They are drawn by the engine's DirtBodyRenderer (the cube shader's uBlastFX branch picks each
    cube's colour and size from its age), then the glow pass makes the bright yellow and orange parts bloom.
    It has `n` and `gpu_instances()`, which is all the renderer asks for."""
    gpu_colour_size = True
    FIRE, SMOKE, SPARK, DUST, ROCKET, STAR = 0, 1, 2, 3, 4, 5     # the numbers the cube shader expects (SMOKE is the grey smoke column; ROCKET and STAR are the fireworks)
    MAX = 4000              # most effect cubes alive at once
    FIREBALL_LIFE = 1.4     # how long the fireball burns, x the original (1.0 = the old, very brief one)
    FIREBALL_LEAN = 1.6     # how far the fireball's cubes lean upward when they burst out
    FIRE_RISE = 5.5         # upward acceleration of burning cubes in blocks per second squared: bigger lifts the fireball higher
    SPARKS = True           # False: no spark spray
    DUST_RING = False       # False: no dust ring over the ground
    SPARK_GRAVITY = 14.0

    def __init__(self):
        self.clear()

    def clear(self):
        self.pos = np.zeros((0, 3))
        self.vel = np.zeros((0, 3))
        self.size = np.zeros(0)
        self.age = np.zeros(0)          # negative while waiting for its start delay
        self.life = np.zeros(0)
        self.glow = np.zeros(0)
        self.kind = np.zeros(0, np.int64)

    @property
    def n(self):
        return int((self.age >= 0).sum())

    def spawn(self, solid, centre, normal, radius, fireball_size=2.0, cell=0.2, delay=0.0):
        """Start the effect at a blast. `solid(P)` says which points are inside rock or brick; `normal` is the way the surface faces
        (up for the ground, out from a wall); `radius` is the blast radius in metres (the effect grows with it); fireball_size
        multiplies just the fire (the game's default is 2.0)."""
        rng = np.random.default_rng()
        unit = 1.0 / FX_DETAIL
        mult = float(np.clip((0.2 / unit) ** 2, 0.25, 8.0))        # the game's cube-count multiplier at its default detail

        def N(k):
            return max(1, int(round(k * mult)))
        up = np.array([0.0, 1.0, 0.0])
        normal = np.asarray(normal, np.float64)
        normal = normal / max(float(np.linalg.norm(normal)), 1e-9)
        origin = np.asarray(centre, np.float64) + normal * 0.3
        for _ in range(10):                                         # the open air in front of the surface, not inside the brick
            if not bool(solid(origin.reshape(1, 3))[0]):
                break
            origin = origin + normal * float(cell)
        else:
            origin = np.asarray(centre, np.float64) + np.array([0.0, 0.6, 0.0])
        on_ground = float(normal[1]) > 0.7

        def dirs(n, lean):                                          # random directions on the open side of the surface
            v = rng.normal(size=(n, 3))
            v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)
            d = v @ normal
            v = np.where((d < 0)[:, None], v - 2.0 * d[:, None] * normal, v)
            v = v + normal * lean
            return v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)

        def ring(n):                                                # random horizontal directions
            a = rng.uniform(0.0, 2.0 * np.pi, n)
            return np.stack([np.cos(a), np.zeros(n), np.sin(a)], axis=1)

        U = rng.uniform
        parts = []
        bs = float(radius) * FX_BLAST_SCALE / FX_REF_R              # a bigger blast is physically bigger: offsets, sizes and speeds all grow

        def add(kind, p, v, size, life, glow=0.0, wait=0.0):
            n = len(p)
            p = np.asarray(p, np.float64)
            scale = bs * fireball_size if kind == self.FIRE else bs
            if scale != 1.0:
                p = origin + (p - origin) * scale
                v = np.asarray(v, np.float64) * scale
                size = np.asarray(size, np.float64) * scale
            bad = solid(p)                                          # a start inside brick goes back to the origin
            p[bad] = origin
            parts.append((p, np.asarray(v, np.float64), size * FX_SIZE, life, np.full(n, float(glow)) if np.isscalar(glow) else glow,
                          np.full(n, kind, np.int64), -(np.full(n, float(delay)) + wait)))

        # white-hot flash: a few huge cubes that pop and are gone
        n = N(4)
        add(self.FIRE, origin + rng.normal(0, 0.2, (n, 3)), np.zeros((n, 3)), unit * U(7.0, 10.0, n), U(0.10, 0.16, n))
        # fireball: big burning cubes bursting out, leaning up
        n = N(30)
        add(self.FIRE, origin + rng.normal(0, 0.35, (n, 3)), dirs(n, self.FIREBALL_LEAN) * U(3.0, 8.0, n)[:, None],
            unit * U(3.0, 6.5, n), U(0.50, 0.95, n) * self.FIREBALL_LIFE)
        if self.DUST_RING and on_ground:                            # shockwave: a low ring of dust racing out over the ground
            n = N(28)
            r = ring(n)
            add(self.DUST, origin + up * 0.1 + r * 0.4, r * U(7.0, 12.0, n)[:, None], unit * U(1.5, 3.2, n), U(0.45, 0.85, n))
        if self.SPARKS:                                             # sparks: a fast spray
            n = N(60)
            add(self.SPARK, origin + np.zeros((n, 3)), dirs(n, 1.0) * U(6.0, 16.0, n)[:, None], unit * U(0.35, 0.6, n), U(0.8, 1.7, n))

        P, V, S, L, G, K, A = (np.concatenate([a[i] for a in parts]) for i in range(7))
        room = max(0, self.MAX - len(self.age))
        if room <= 0:
            return
        P, V, S, L, G, K, A = P[:room], V[:room], S[:room], L[:room], G[:room], K[:room], A[:room]
        self.pos = np.concatenate([self.pos, P]); self.vel = np.concatenate([self.vel, V])
        self.size = np.concatenate([self.size, S]); self.life = np.concatenate([self.life, L])
        self.glow = np.concatenate([self.glow, G]); self.kind = np.concatenate([self.kind, K])
        self.age = np.concatenate([self.age, A])

    def add(self, kind, pos, vel, size, life, delay=0.0, glow=0.0):
        """Add a few effect cubes of one kind by hand (the oil fires use it); sizes are before the effect's overall size scale."""
        pos = np.asarray(pos, np.float64).reshape(-1, 3)
        n = min(len(pos), max(0, self.MAX - len(self.age)))
        if n <= 0:
            return
        sz = np.broadcast_to(np.asarray(size, np.float64), (len(pos),))[:n] * FX_SIZE
        lf = np.broadcast_to(np.asarray(life, np.float64), (len(pos),))[:n]
        self.pos = np.concatenate([self.pos, pos[:n]]); self.vel = np.concatenate([self.vel, np.asarray(vel, np.float64).reshape(-1, 3)[:n]])
        self.size = np.concatenate([self.size, sz]); self.life = np.concatenate([self.life, lf])
        self.glow = np.concatenate([self.glow, np.broadcast_to(np.asarray(glow, np.float64), (len(pos),))[:n]]); self.kind = np.concatenate([self.kind, np.full(n, kind, np.int64)])
        self.age = np.concatenate([self.age, -np.broadcast_to(np.asarray(delay, np.float64), (len(pos),))[:n]])

    def _move(self, solid, pos, vel, size, k, dt, step_len):
        """Move cubes one axis at a time in small steps, testing the brick ahead (fire and dust stop dead, sparks bounce)."""
        fire, spark, dust, star = (k == self.FIRE), (k == self.SPARK), (k == self.DUST), (k == self.STAR)
        smoke = (k == self.SMOKE)
        vmax = float(np.abs(vel).max()) if len(vel) else 0.0
        steps = int(min(6, max(1, math.ceil(vmax * dt / step_len))))
        sdt = dt / steps
        for _ in range(steps):
            for axis in (1, 0, 2):
                new = pos.copy()
                new[:, axis] += vel[:, axis] * sdt
                probe = new.copy()
                probe[:, axis] += np.sign(vel[:, axis]) * size * 0.5
                hit = solid(probe)
                pos[~hit] = new[~hit]
                if hit.any():
                    vb = vel[:, axis].copy()
                    vel[hit & spark, axis] = -vb[hit & spark] * 0.4           # sparks bounce
                    vel[hit & (fire | dust | star | smoke), axis] = 0.0        # fire, dust, smoke and fireworks stars stop dead
                    if axis == 1:
                        floor = hit & spark & (vb < 0.0)
                        vel[floor, 0] *= 0.7
                        vel[floor, 2] *= 0.7
                        vel[floor & (np.abs(vel[:, 1]) < 0.6), 1] = 0.0       # a spark that has stopped bouncing lies still
        return pos, vel

    def update(self, solid, dt):
        if not len(self.age):
            return
        dt = min(float(dt), 0.05)
        waiting = self.age < 0
        act = np.nonzero(~waiting)[0]
        self.age[waiting] += dt
        if len(act):
            pos, vel, size, k = self.pos[act], self.vel[act], self.size[act], self.kind[act]
            fire, spark, dust, star, smoke = k == self.FIRE, k == self.SPARK, k == self.DUST, k == self.STAR, k == self.SMOKE
            # forces: fire slows quickly and drifts up; sparks fall; dust skims the ground
            vel[fire] *= math.exp(-2.2 * dt)
            vel[fire, 1] += self.FIRE_RISE * dt
            vel[spark, 1] -= self.SPARK_GRAVITY * dt
            vel[smoke, 1] += 2.4 * dt                                 # smoke is lighter than air: it rises, drifts and slows
            vel[smoke] *= math.exp(-0.9 * dt)
            if smoke.any():
                vel[smoke, 0] += np.random.normal(0.0, 0.5, int(smoke.sum())) * dt
                vel[smoke, 2] += np.random.normal(0.0, 0.5, int(smoke.sum())) * dt
            vel[star, 1] -= 6.5 * dt                                  # fireworks stars fall slowly and slow down fast
            vel[star] *= math.exp(-1.6 * dt)
            vel[spark] *= math.exp(-0.4 * dt)
            vel[dust, 1] -= 6.0 * dt
            vel[dust, 0] *= math.exp(-2.0 * dt)
            vel[dust, 2] *= math.exp(-2.0 * dt)
            for grp, step_len in ((spark, 0.12), (~spark, 0.3)):      # sparks are tiny and fast, so they take finer steps
                if grp.any():
                    pg, vg = self._move(solid, pos[grp], vel[grp], size[grp], k[grp], dt, step_len)
                    pos[grp], vel[grp] = pg, vg
            self.pos[act], self.vel[act] = pos, vel
            self.age[act] += dt
        keep = self.age < self.life
        if not keep.all():
            for name in ('pos', 'vel', 'size', 'age', 'life', 'glow', 'kind'):
                setattr(self, name, getattr(self, name)[keep])

    def gpu_instances(self):
        """Particle state for the renderer; the palette and size animation are worked out by its vertex shader."""
        act = self.age >= 0
        out = np.empty((int(act.sum()), 8), np.float32)
        out[:, :3] = self.pos[act]
        out[:, 3] = self.age[act]
        out[:, 4] = self.life[act]
        out[:, 5] = self.glow[act]
        out[:, 6] = self.kind[act]
        out[:, 7] = self.size[act]
        return out


_RT_DENOISE = """
#version 330 core
in vec2 vUV;
out vec4 fragColor;
uniform sampler2D uNew;      // this frame's ray-traced picture
uniform sampler2D uHist;     // the average of the frames before it
uniform vec2 uTexel;
uniform float uAlpha;        // how much of this frame goes into the average (1 = no history)
uniform float uSpatial;      // strength of the edge-keeping blur (0 = none)
void main() {
    vec3 c = texture(uNew, vUV).rgb;
    if (uSpatial > 0.0) {                                         // 5 x 5 bilateral blur: pixels of about the same colour are averaged, strong edges are kept
        float sig = 0.05 + 0.10 * uSpatial;
        vec3 acc = vec3(0.0); float wsum = 0.0;
        for (int j = -2; j <= 2; ++j) for (int i = -2; i <= 2; ++i) {
            vec3 q = texture(uNew, vUV + vec2(i, j) * uTexel).rgb;
            vec3 d = q - c;
            float w = exp(-dot(d, d) / (2.0 * sig * sig)) * (1.0 - 0.12 * float(abs(i) + abs(j)));
            acc += q * w; wsum += w;
        }
        c = acc / max(wsum, 1e-4);
    }
    vec3 h = texture(uHist, vUV).rgb;
    float a = uAlpha;
    if (length(h - c) > 0.22) a = 1.0;                            // something moved here: take the new frame
    fragColor = vec4(mix(h, c, a), 1.0);
}
"""

_BLOOM_COMP = """
#version 330 core
in vec2 vUV;
out vec4 fragColor;
uniform sampler2D uScene;
uniform sampler2D uBloomA;   // half size glow: tight
uniform sampler2D uBloomB;   // quarter size glow: wide
uniform float uBloom;
uniform float uSharp;        // sharpening strength (0 = none)
uniform vec2 uTexel;         // one texel of the scene target
uniform vec3 uTone;          // brightness, contrast, gamma (1, 1, 1 = untouched)
void main() {
    vec3 c = texture(uScene, vUV).rgb;
    if (uSharp > 0.0) {                                           // unsharp mask: push each pixel away from the average of its four neighbours
        vec3 n = texture(uScene, vUV + vec2(uTexel.x, 0.0)).rgb + texture(uScene, vUV - vec2(uTexel.x, 0.0)).rgb
               + texture(uScene, vUV + vec2(0.0, uTexel.y)).rgb + texture(uScene, vUV - vec2(0.0, uTexel.y)).rgb;
        c += (c - n * 0.25) * uSharp;
    }
    if (uBloom > 0.0) {                                           // only adds glow: the rest of the picture is untouched
        vec3 b = texture(uBloomA, vUV).rgb * 0.7 + texture(uBloomB, vUV).rgb * 1.0;
        c += b * uBloom;
    }
    c = (c - 0.5) * uTone.y + 0.5;                                // contrast about mid-grey, then brightness, then gamma
    c = max(c * uTone.x, 0.0);
    c = pow(c, vec3(1.0 / max(uTone.z, 0.05)));
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""


# ------------------------------------------------------------------------------------------------ ray-traced lighting
# A compute-shader pass (OpenGL 4.3, no RTX hardware needed) that runs on the finished scene picture. For every pixel it rebuilds the world
# position from the depth buffer, finds the voxel face there, and traces rays through the cell grids of every structure and loose body
# (a voxel stepper, so the cost does not grow with the number of cells): a ray to the sun for shadows, a few cosine rays for ambient occlusion
# and one bounce of colour from nearby surfaces, and a mirror ray for glossy materials (steel, glass, painted metal). The raster picture is only
# re-lit by a ratio (ray-traced light / the raster's own light), so textures, cell edge lines and loose cubes (which are not in the grids) are kept.
_RT_COMMON = r'''#version 430
struct Obj { vec4 lo; vec4 hi; vec4 pos; vec4 corner; ivec4 dims; vec4 r0; vec4 r1; vec4 r2; };
layout(std430, binding=0) readonly buffer Objs { Obj objs[]; };
layout(std430, binding=1) readonly buffer Vox { uint vox[]; };
layout(std430, binding=2) readonly buffer Props { vec4 props[]; };
uniform int objCount;
uniform float uAoDist;
uniform float uShadow, uSoft, uAO, uBounce, uRefl;
uniform int uSamples;
uniform uint uSeed;
uniform float uFloorK;

const vec3 SUN = normalize(vec3(0.45, 1.0, 0.35));        // the raster's GL_LIGHT0 (a direction in world space)
const vec3 SUN_COL = vec3(0.95, 0.93, 0.88);
const vec3 SKY_AMB = vec3(0.58, 0.60, 0.66);               // the raster's ambient: light ambient (0.38, 0.40, 0.46) + the global 0.2

struct Hit { float t; vec3 n; vec3 alb; int mat; };

uint pcg(uint v) { uint s = v * 747796405u + 2891336007u; uint w = ((s >> ((s >> 28u) + 4u)) ^ s) * 277803737u; return (w >> 22u) ^ w; }
float rnd(inout uint st) { st = pcg(st); return float(st) * (1.0 / 4294967296.0); }
vec3 nz(vec3 v) { return vec3(abs(v.x) < 1e-8 ? 1e-8 : v.x, abs(v.y) < 1e-8 ? 1e-8 : v.y, abs(v.z) < 1e-8 ? 1e-8 : v.z); }
vec3 wordAlbedo(uint w) { return vec3(float((w >> 8u) & 255u), float((w >> 16u) & 255u), float(w >> 24u)) / 255.0; }

uint occ(Obj o, ivec3 c) {
    if (any(lessThan(c, ivec3(0))) || any(greaterThanEqual(c, o.dims.xyz))) return 0u;
    return vox[o.dims.w + (c.x * o.dims.y + c.y) * o.dims.z + c.z];
}

// One object's grid: a voxel stepper in the object's own frame (the ray is rotated into it, so loose bodies work too). t is in world metres.
bool traceObj(int i, vec3 ro, vec3 rd, float tmax, out float tHit, out vec3 nW, out uint word) {
    Obj o = objs[i];
    vec3 rdn = nz(rd);
    vec3 inv = 1.0 / rdn;
    vec3 t0 = (o.lo.xyz - ro) * inv, t1 = (o.hi.xyz - ro) * inv;
    vec3 tn = min(t0, t1), tf = max(t0, t1);
    if (max(max(tn.x, tn.y), max(tn.z, 0.0)) > min(min(tf.x, tf.y), min(tf.z, tmax))) return false;
    vec3 p = ro - o.pos.xyz;
    vec3 lp = vec3(dot(o.r0.xyz, p), dot(o.r1.xyz, p), dot(o.r2.xyz, p));
    vec3 ld = nz(vec3(dot(o.r0.xyz, rd), dot(o.r1.xyz, rd), dot(o.r2.xyz, rd)));
    float cs = o.pos.w;
    vec3 g0 = (lp - o.corner.xyz) / cs;
    vec3 gd = ld / cs;
    vec3 dm = vec3(o.dims.xyz);
    vec3 a0 = (vec3(0.0) - g0) / gd, a1 = (dm - g0) / gd;
    vec3 an = min(a0, a1), af = max(a0, a1);
    float enter = max(max(an.x, an.y), an.z);
    float tE = max(enter, 0.0), tX = min(min(af.x, af.y), min(af.z, tmax));
    if (tE >= tX) return false;
    int ax = (an.x >= an.y && an.x >= an.z) ? 0 : (an.y >= an.z ? 1 : 2);
    vec3 g = g0 + gd * (tE + 1e-5);
    ivec3 c = clamp(ivec3(floor(g)), ivec3(0), o.dims.xyz - 1);
    ivec3 stp = ivec3(sign(gd));
    vec3 tDelta = abs(1.0 / gd);
    vec3 tMax = (vec3(c) + vec3(greaterThan(gd, vec3(0.0))) - g0) / gd;
    float tCur = tE;
    int maxSteps = o.dims.x + o.dims.y + o.dims.z + 3;
    for (int s = 0; s < maxSteps; ++s) {
        uint w = vox[o.dims.w + (c.x * o.dims.y + c.y) * o.dims.z + c.z];
        if (w != 0u) {
            vec3 nl = vec3(0.0);
            if (s == 0 && enter <= 0.0) { int a = (abs(ld.x) >= abs(ld.y) && abs(ld.x) >= abs(ld.z)) ? 0 : (abs(ld.y) >= abs(ld.z) ? 1 : 2); nl[a] = -sign(ld[a]); }
            else nl[ax] = -float(stp[ax]);
            tHit = tCur; nW = o.r0.xyz * nl.x + o.r1.xyz * nl.y + o.r2.xyz * nl.z; word = w;
            return true;
        }
        ax = (tMax.x < tMax.y) ? ((tMax.x < tMax.z) ? 0 : 2) : ((tMax.y < tMax.z) ? 1 : 2);
        tCur = tMax[ax];
        if (tCur > tX) break;
        c[ax] += stp[ax];
        if (c[ax] < 0 || c[ax] >= o.dims[ax]) break;
        tMax[ax] += tDelta[ax];
    }
    return false;
}

vec3 floorAlbedo(vec3 q) { return ((int(floor(q.x / (2.0 * uFloorK))) + int(floor(q.z / (2.0 * uFloorK)))) & 1) == 0 ? vec3(0.30, 0.34, 0.30) : vec3(0.26, 0.30, 0.26); }

// The nearest thing a ray meets: a cell face of any object, or the floor (y = 0, the checker the raster draws).
bool traceScene(vec3 ro, vec3 rd, float tmax, out Hit h) {
    h.t = tmax; h.n = vec3(0.0, 1.0, 0.0); h.alb = vec3(0.5); h.mat = 0;
    bool found = false;
    for (int i = 0; i < objCount; ++i) {
        float t; vec3 n; uint w;
        if (traceObj(i, ro, rd, h.t, t, n, w)) { h.t = t; h.n = normalize(n); h.alb = wordAlbedo(w); h.mat = int(w & 255u); found = true; }
    }
    if (rd.y < -1e-5 && ro.y > 0.0) {
        float tf = -ro.y / rd.y;
        if (tf > 1e-4 && tf < h.t) {
            vec3 q = ro + rd * tf;
            if (abs(q.x) < 60.0 * uFloorK && abs(q.z) < 60.0 * uFloorK) { h.t = tf; h.n = vec3(0.0, 1.0, 0.0); h.alb = floorAlbedo(q); h.mat = 254; found = true; }
        }
    }
    return found;
}

bool occluded(vec3 ro, vec3 rd, float tmax) {
    for (int i = 0; i < objCount; ++i) { float t; vec3 n; uint w; if (traceObj(i, ro, rd, tmax, t, n, w)) return true; }
    return false;
}

vec3 cosDir(vec3 n, vec2 u) {
    float r = sqrt(u.x), a = 6.2831853 * u.y;
    vec3 t = normalize(abs(n.y) < 0.99 ? cross(n, vec3(0.0, 1.0, 0.0)) : cross(n, vec3(1.0, 0.0, 0.0)));
    vec3 b = cross(n, t);
    return normalize(t * (r * cos(a)) + b * (r * sin(a)) + n * sqrt(max(1.0 - u.x, 0.0)));
}

vec3 skyColour(vec3 d) { return mix(vec3(0.78, 0.86, 0.94), vec3(0.50, 0.66, 0.86), clamp(d.y * 1.3, 0.0, 1.0)); }

// Which cell face of which object is at world point P (the depth buffer gives P only): the nearest grid plane to P that has one solid and one empty cell
// beside it. Returns its outward normal, the cell's colour and material.
bool identify(vec3 P, out vec3 N, out vec3 alb, out int mat) {
    float best = 0.25; bool found = false;
    N = vec3(0.0, 1.0, 0.0); alb = vec3(0.5); mat = 0;
    for (int i = 0; i < objCount; ++i) {
        Obj o = objs[i];
        float pad = 0.05 + 0.3 * o.pos.w;
        if (any(lessThan(P, o.lo.xyz - pad)) || any(greaterThan(P, o.hi.xyz + pad))) continue;
        vec3 p = P - o.pos.xyz;
        vec3 g = (vec3(dot(o.r0.xyz, p), dot(o.r1.xyz, p), dot(o.r2.xyz, p)) - o.corner.xyz) / o.pos.w;
        vec3 dm = vec3(o.dims.xyz);
        for (int a = 0; a < 3; ++a) {
            float k = round(g[a]);
            float err = abs(g[a] - k);
            if (err >= best) continue;
            ivec3 c = ivec3(0);
            bool ok = true;
            for (int b = 0; b < 3; ++b) {
                if (b == a) continue;
                if (g[b] < -0.002 || g[b] > dm[b] + 0.002) { ok = false; break; }
                c[b] = int(clamp(floor(g[b]), 0.0, dm[b] - 1.0));
            }
            if (!ok) continue;
            ivec3 cl = c, ch = c;
            cl[a] = int(k) - 1; ch[a] = int(k);
            uint wl = occ(o, cl), wh = occ(o, ch);
            if ((wl != 0u) == (wh != 0u)) continue;
            if (wh != 0u && a == 1 && int(k) == 0 && abs(o.pos.y) < 1e-4) continue;     // the bottom face of a structure on the floor (not drawn)
            vec3 nl = vec3(0.0); nl[a] = (wh != 0u) ? -1.0 : 1.0;
            best = err; found = true;
            N = normalize(o.r0.xyz * nl.x + o.r1.xyz * nl.y + o.r2.xyz * nl.z);
            uint w = (wh != 0u) ? wh : wl;
            alb = wordAlbedo(w); mat = int(w & 255u);
        }
    }
    return found;
}
'''

_RT_MAIN = r'''
layout(local_size_x=8, local_size_y=8) in;
layout(rgba8, binding=0) uniform image2D sceneImg;
uniform sampler2D depthTex;
uniform mat4 uInvVP;
uniform vec3 uEye;
uniform ivec2 uSize;

// What the finished surface at P/N/mat looks like when it is hit by a ray (used for reflections and bounce light).
vec3 shadeHit(Hit h, vec3 P, bool withShadow) {
    float nl = max(dot(h.n, SUN), 0.0);
    float vis = 1.0;
    if (withShadow && uShadow > 0.0 && nl > 0.0 && occluded(P + h.n * 0.01, SUN, 300.0)) vis = 1.0 - uShadow;
    return h.alb * (SKY_AMB * 0.75 + SUN_COL * nl * vis);
}

void main() {
    ivec2 px = ivec2(gl_GlobalInvocationID.xy);
    if (px.x >= uSize.x || px.y >= uSize.y) return;
    float d = texelFetch(depthTex, px, 0).r;
    if (d >= 0.99999) return;                                   // sky
    vec2 uv = (vec2(px) + 0.5) / vec2(uSize);
    vec4 wp = uInvVP * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    vec3 P = wp.xyz / wp.w;
    // The surface is found by tracing this pixel's own view ray through the cell grids (exact: the depth buffer alone is too coarse at grazing angles),
    // and accepted only if it is where the depth buffer says the picture's surface is: a loose cube or an effect in front of it keeps the raster colour.
    vec4 pf = uInvVP * vec4(uv * 2.0 - 1.0, 1.0, 1.0);
    vec3 rd0 = normalize(pf.xyz / pf.w - uEye);
    float tDepth = length(P - uEye);
    Hit h0;
    if (!traceScene(uEye, rd0, tDepth + 1.0, h0)) return;
    if (abs(h0.t - tDepth) > 0.06 + 0.004 * tDepth) return;
    P = uEye + rd0 * h0.t;
    vec3 N = h0.n, alb = h0.alb; int mat = h0.mat;
    vec3 V = normalize(uEye - P);
    if (dot(N, V) < 0.0) N = -N;
    uint st = pcg(uint(px.x) * 1973u + uint(px.y) * 9277u + uSeed * 26699u + 1u);
    vec3 org = P + N * 0.01;
    vec4 src = imageLoad(sceneImg, px);

    float nl = max(dot(N, SUN), 0.0);
    // sun: hard or soft shadow
    float vis = 1.0;
    if (uShadow > 0.0 && nl > 0.0) {
        int ns = uSoft > 0.001 ? clamp(uSamples, 1, 4) : 1;
        int blocked = 0;
        for (int s = 0; s < ns; ++s) {
            vec3 j = vec3(rnd(st), rnd(st), rnd(st)) * 2.0 - 1.0;
            vec3 L = normalize(SUN + j * (uSoft * 0.10));
            if (occluded(org, L, 300.0)) ++blocked;
        }
        vis = 1.0 - uShadow * float(blocked) / float(ns);
    }
    // ambient light: occlusion by nearby geometry, plus one bounce of colour from what the rays hit
    vec3 amb = SKY_AMB;
    if (uAO > 0.0) {
        vec3 acc = vec3(0.0);
        int n = max(uSamples, 1);
        for (int s = 0; s < n; ++s) {
            vec3 dir = cosDir(N, vec2(rnd(st), rnd(st)));
            Hit h;
            if (traceScene(org, dir, uAoDist, h)) acc += uBounce * shadeHit(h, org + dir * h.t, false);
            else acc += SKY_AMB;
        }
        amb = mix(SKY_AMB, acc / float(n), uAO);
    }
    vec3 lightRaster = SKY_AMB + SUN_COL * nl;
    vec3 lightRT = amb + SUN_COL * nl * vis;
    vec3 col = src.rgb * clamp(lightRT / max(lightRaster, vec3(0.05)), 0.0, 2.0);

    // mirror reflection for glossy materials
    vec4 pr = props[mat];
    if (uRefl > 0.0 && pr.x > 0.002) {
        vec3 R = reflect(-V, N);
        R = normalize(R + (vec3(rnd(st), rnd(st), rnd(st)) * 2.0 - 1.0) * (pr.y * 0.5));
        R = normalize(R + N * max(0.0, 0.03 - dot(R, N)));
        Hit h; vec3 rc;
        if (traceScene(org, R, 150.0, h)) rc = shadeHit(h, org + R * h.t, true);
        else rc = skyColour(R);
        // Schlick Fresnel, but a rough surface never turns mirror-like at a grazing angle: its tiny bumps scatter the light, so the edge glare is capped by how smooth it is
        float cap = max(pr.x, (1.0 - pr.y) * (1.0 - pr.y));
        float F = clamp((pr.x + (cap - pr.x) * pow(1.0 - max(dot(N, V), 0.0), 5.0)) * uRefl, 0.0, 1.0);
        vec3 tint = mix(vec3(1.0), clamp(alb * 2.4, 0.0, 1.0), pr.z);          // metals tint what they reflect
        col = mix(col, rc * tint, F);
    }
    imageStore(sceneImg, px, vec4(clamp(col, 0.0, 1.0), src.a));
}
'''

_RT_TEST = r'''
layout(local_size_x=64) in;
struct RayIn { vec4 o; vec4 d; };
layout(std430, binding=3) readonly buffer RaysIn { RayIn rin[]; };
layout(std430, binding=4) buffer RaysOut { vec4 rout[]; };
uniform int rayCount;
uniform int testMode;      // 0: trace the scene   1: identify the face at a point
void main() {
    uint i = gl_GlobalInvocationID.x;
    if (i >= uint(rayCount)) return;
    RayIn r = rin[i];
    if (testMode == 0) {
        Hit h;
        bool ok = traceScene(r.o.xyz, normalize(r.d.xyz), r.o.w, h);
        rout[2u * i] = vec4(ok ? h.t : -1.0, h.n);
        rout[2u * i + 1u] = vec4(float(h.mat), h.alb);
    } else {
        vec3 N, alb; int mat;
        bool ok = identify(r.o.xyz, N, alb, mat);
        rout[2u * i] = vec4(ok ? 1.0 : -1.0, N);
        rout[2u * i + 1u] = vec4(float(mat), alb);
    }
}
'''

RT_MAX_OBJECTS = 64
RT_MATERIAL_PROPS = {            # material name -> (reflectance at normal incidence, roughness 0..1, metal 0/1)
    'STEEL': (0.30, 0.35, 1.0), 'GLASS': (0.28, 0.03, 0.0), 'CONCRETE_RED': (0.16, 0.20, 0.0), 'CONCRETE_BLUE': (0.16, 0.20, 0.0),
    'BRICK': (0.05, 0.75, 0.0), 'PLANKS': (0.14, 0.40, 0.0), 'WOOD': (0.05, 0.55, 0.0), 'DIRT': (0.0, 0.95, 0.0), 'STONE': (0.05, 0.6, 0.0),
    'CONCRETE_WHITE': (0.08, 0.55, 0.0)}
RT_SHINE_DEFAULTS = {}                                     # the Settings tab's per-material sliders start at the table above: rs_<NAME> reflectivity %, rr_<NAME> roughness %
for _n in ('DIRT', 'STEEL', 'BRICK', 'GLASS', 'PLANKS'):
    RT_SHINE_DEFAULTS['rs_' + _n] = int(round(RT_MATERIAL_PROPS[_n][0] * 100))
    RT_SHINE_DEFAULTS['rr_' + _n] = int(round(RT_MATERIAL_PROPS[_n][1] * 100))


class RayLight:
    """The ray-traced lighting pass (see the comment above). Made on first use; if the shaders do not build here it reports why and stays off."""
    def __init__(self, E):
        self.E = E
        self.cache = {}                  # id(object) -> (key, uint32 cell words)
        self.vox_ids = None
        self.offsets = {}
        self.n_obj = 0
        self.loc = {}
        self.prog = self._program(_RT_COMMON + _RT_MAIN)
        self.prog_test = self._program(_RT_COMMON + _RT_TEST)
        self.bufs = [int(gl.glGenBuffers(1)) for _ in range(5)]          # objects, cells, materials, test rays in, test rays out
        props = np.zeros((256, 4), np.float32)
        props[:, 1] = 0.6
        for name, (f0, rough, metal) in RT_MATERIAL_PROPS.items():
            if hasattr(E, name):
                props[int(getattr(E, name))] = (f0, rough, metal, 0.0)
        self._upload(self.bufs[2], props)

    @staticmethod
    def _program(source):
        from OpenGL.GL.shaders import compileShader, compileProgram
        shader = compileShader(source, gl.GL_COMPUTE_SHADER)
        try:
            return int(compileProgram(shader))
        finally:
            gl.glDeleteShader(shader)

    @staticmethod
    def _upload(buf, arr):
        arr = np.ascontiguousarray(arr)
        gl.glBindBuffer(gl.GL_SHADER_STORAGE_BUFFER, buf)
        gl.glBufferData(gl.GL_SHADER_STORAGE_BUFFER, max(arr.nbytes, 16), arr if arr.nbytes else None, gl.GL_DYNAMIC_DRAW)

    def _u(self, prog, name):
        k = (prog, name)
        if k not in self.loc:
            self.loc[k] = gl.glGetUniformLocation(prog, name)
        return self.loc[k]

    def _words(self, o):
        """One uint32 per cell: 0 = empty, else material id (low 8 bits) and the cell's colour (the colour the raster draws it in, 8 bits a channel)."""
        w = np.zeros(o.alive.shape, np.uint32)
        idx = np.nonzero(o.alive)
        if len(idx[0]):
            col = cell_colour(self.E, o.mat[idx], o.tint[idx], o.idmg[idx])
            c8 = np.clip(col * 255.0 + 0.5, 0, 255).astype(np.uint32)
            w[idx] = (o.mat[idx].astype(np.uint32) & 255) | (c8[:, 0] << 8) | (c8[:, 1] << 16) | (c8[:, 2] << 24)
        return w

    def update_scene(self, objects):
        """Upload every live object's cell grid (only when its cells changed) and its position / rotation (every frame)."""
        objs = [o for o in objects if o.alive.any()][:RT_MAX_OBJECTS]
        changed = False
        words = []
        for o in objs:
            key = (o.mesh_ver, o.mat.shape, int(o.alive.sum()), round(float(o.idmg.sum()), 3))
            ent = self.cache.get(id(o))
            if ent is None or ent[0] != key:
                ent = self.cache[id(o)] = (key, self._words(o))
                changed = True
            words.append(ent[1])
        ids = tuple(id(o) for o in objs)
        if changed or ids != self.vox_ids:
            live = set(ids)
            self.cache = {k: v for k, v in self.cache.items() if k in live}
            flat = np.concatenate([w.ravel() for w in words]) if words else np.zeros(1, np.uint32)
            self._upload(self.bufs[1], flat.astype(np.uint32))
            offs, run = [], 0
            for w in words:
                offs.append(run)
                run += int(w.size)
            self.offsets = offs
            self.vox_ids = ids
        meta = np.zeros((max(len(objs), 1), 32), np.float32)
        iv = meta.view(np.int32)
        for i, o in enumerate(objs):
            lo, hi = o.aabb()
            meta[i, 0:3], meta[i, 4:7] = lo, hi
            meta[i, 8:11], meta[i, 11] = o.frame_pos, o.cs
            meta[i, 12:15] = o.corner
            iv[i, 16:19] = o.mat.shape
            iv[i, 19] = self.offsets[i]
            Rt = np.asarray(o.R, np.float64).T                  # rows of R^T: world -> the object's own frame
            meta[i, 20:23], meta[i, 24:27], meta[i, 28:31] = Rt[0], Rt[1], Rt[2]
        self._upload(self.bufs[0], meta)
        self.n_obj = len(objs)

    def _bind_scene(self):
        for i in range(3):
            gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER, i, self.bufs[i])

    def _set_params(self, prog, p, seed):
        gl.glUniform1i(self._u(prog, 'objCount'), int(self.n_obj))
        gl.glUniform1f(self._u(prog, 'uAoDist'), float(p.get('dist', 6.0)))
        gl.glUniform1f(self._u(prog, 'uShadow'), float(p.get('shadow', 1.0)))
        gl.glUniform1f(self._u(prog, 'uSoft'), float(p.get('soft', 0.3)))
        gl.glUniform1f(self._u(prog, 'uAO'), float(p.get('ao', 1.0)))
        gl.glUniform1f(self._u(prog, 'uBounce'), float(p.get('bounce', 0.6)))
        gl.glUniform1f(self._u(prog, 'uRefl'), float(p.get('refl', 1.0)))
        gl.glUniform1i(self._u(prog, 'uSamples'), int(p.get('samples', 6)))
        gl.glUniform1ui(self._u(prog, 'uSeed'), int(seed) & 0xFFFFFF)
        gl.glUniform1f(self._u(prog, 'uFloorK'), float(p.get('floor_k', 1.0)))

    def set_materials(self, mats):
        """mats: material name -> (reflectance, roughness) from the Settings sliders. Uploads the table again only when something changed."""
        key = tuple(sorted((n, round(float(v[0]), 3), round(float(v[1]), 3)) for n, v in mats.items()))
        if key == getattr(self, '_mat_key', None):
            return
        self._mat_key = key
        props = np.zeros((256, 4), np.float32)
        props[:, 1] = 0.6
        for name, (f0, rough, metal) in RT_MATERIAL_PROPS.items():
            if hasattr(self.E, name):
                if name in mats:
                    f0, rough = mats[name]
                props[int(getattr(self.E, name))] = (f0, rough, metal, 0.0)
        self._upload(self.bufs[2], props)

    def run(self, scene_tex, depth_tex, size, mv, proj, params, seed=0):
        """Re-light the scene texture in place. mv / proj: the modelview and projection matrices the scene was drawn with (4x4, column-vector convention)."""
        w, h = size
        if 'mats' in params:
            self.set_materials(params['mats'])
        inv = np.linalg.inv(np.asarray(proj, np.float64) @ np.asarray(mv, np.float64))
        eye = np.linalg.inv(np.asarray(mv, np.float64))[:3, 3]
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)
        gl.glUseProgram(self.prog)
        self._bind_scene()
        self._set_params(self.prog, params, seed)
        gl.glUniformMatrix4fv(self._u(self.prog, 'uInvVP'), 1, gl.GL_FALSE, np.ascontiguousarray(inv.T, np.float32))
        gl.glUniform3f(self._u(self.prog, 'uEye'), *[float(v) for v in eye])
        gl.glUniform2i(self._u(self.prog, 'uSize'), int(w), int(h))
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, depth_tex)
        gl.glUniform1i(self._u(self.prog, 'depthTex'), 0)
        gl.glBindImageTexture(0, scene_tex, 0, gl.GL_FALSE, 0, gl.GL_READ_WRITE, gl.GL_RGBA8)
        gl.glMemoryBarrier(gl.GL_FRAMEBUFFER_BARRIER_BIT | gl.GL_TEXTURE_FETCH_BARRIER_BIT)
        gl.glDispatchCompute((w + 7) // 8, (h + 7) // 8, 1)
        gl.glMemoryBarrier(gl.GL_SHADER_IMAGE_ACCESS_BARRIER_BIT | gl.GL_TEXTURE_FETCH_BARRIER_BIT | gl.GL_FRAMEBUFFER_BARRIER_BIT)
        gl.glUseProgram(0)

    def test(self, mode, origins, dirs_or_unused, tmax=100.0, params=None):
        """For the tests: mode 0 traces rays (origin, direction) through the uploaded scene; mode 1 identifies the face at each origin point.
        Returns an (n, 2, 4) array: mode 0 [[t or -1, nx, ny, nz], [material, r, g, b]]."""
        o = np.asarray(origins, np.float32).reshape(-1, 3)
        n = len(o)
        rin = np.zeros((n, 2, 4), np.float32)
        rin[:, 0, :3] = o
        rin[:, 0, 3] = tmax
        rin[:, 1, :3] = np.asarray(dirs_or_unused, np.float32).reshape(-1, 3) if dirs_or_unused is not None else 0.0
        self._upload(self.bufs[3], rin)
        self._upload(self.bufs[4], np.zeros((n, 2, 4), np.float32))
        gl.glUseProgram(self.prog_test)
        self._bind_scene()
        gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER, 3, self.bufs[3])
        gl.glBindBufferBase(gl.GL_SHADER_STORAGE_BUFFER, 4, self.bufs[4])
        self._set_params(self.prog_test, params or {}, 0)
        gl.glUniform1i(self._u(self.prog_test, 'rayCount'), n)
        gl.glUniform1i(self._u(self.prog_test, 'testMode'), int(mode))
        gl.glMemoryBarrier(gl.GL_BUFFER_UPDATE_BARRIER_BIT | gl.GL_SHADER_STORAGE_BARRIER_BIT)
        gl.glDispatchCompute((n + 63) // 64, 1, 1)
        gl.glMemoryBarrier(gl.GL_SHADER_STORAGE_BARRIER_BIT)
        gl.glUseProgram(0)
        gl.glBindBuffer(gl.GL_SHADER_STORAGE_BUFFER, self.bufs[4])
        out = np.frombuffer(gl.glGetBufferSubData(gl.GL_SHADER_STORAGE_BUFFER, 0, n * 32), np.float32).reshape(n, 2, 4).copy()
        return out

    def close(self):
        for p in (self.prog, self.prog_test):
            gl.glDeleteProgram(p)
        gl.glDeleteBuffers(len(self.bufs), self.bufs)



class Bloom:
    """The scene pass. The 3D scene is drawn into an offscreen target (at the Resolution setting's share of the window size) and goes
    to the window through one shader that can sharpen it (the Sharpness setting) and add the game's glow (its PostFX, bloom only: the
    bright warm parts, fire, sparks and flashes, are shrunk to half and quarter size, blurred, and added back on top).
    Only used while a blast effect is alive or Resolution / Sharpness are changed, so otherwise the bench draws straight to the window as before."""
    def __init__(self, E):
        self.broken = False
        self.size = (0, 0)                           # the offscreen target's size (what the scene is drawn at)
        self.win = (0, 0)                            # the window's size
        self.fbo = self.tex = self.rb = None
        self.t = []
        self.vao = gl.glGenVertexArrays(1)           # an empty one: the corners are made in the vertex shader
        def prog(src):
            return E._link_program(E._compile_shader(E._POST_VERT, gl.GL_VERTEX_SHADER), E._compile_shader(src, gl.GL_FRAGMENT_SHADER))
        self.p_down, self.p_blur, self.p_comp = prog(E._POST_DOWN), prog(E._POST_BLUR), prog(_BLOOM_COMP)
        self.p_dn = prog(_RT_DENOISE)
        self.u_dn = tuple(gl.glGetUniformLocation(self.p_dn, n) for n in ("uNew", "uHist", "uTexel", "uAlpha", "uSpatial"))
        self.dn, self.dn_n = [], 0                                   # the denoiser's two targets (result, history) and how many still frames are in the average
        loc = gl.glGetUniformLocation
        self.u_down = (loc(self.p_down, "uTex"), loc(self.p_down, "uTexel"), loc(self.p_down, "uThresh"))
        self.u_blur = (loc(self.p_blur, "uTex"), loc(self.p_blur, "uDir"))
        self.u_comp = tuple(loc(self.p_comp, n) for n in ("uScene", "uBloomA", "uBloomB", "uBloom", "uSharp", "uTexel", "uTone"))

    @staticmethod
    def _target(w, h, depth=False):
        tex = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, w, h, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, None)
        for q, v in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR),
                     (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
            gl.glTexParameteri(gl.GL_TEXTURE_2D, q, v)
        fbo = gl.glGenFramebuffers(1)
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, fbo)
        gl.glFramebufferTexture2D(gl.GL_FRAMEBUFFER, gl.GL_COLOR_ATTACHMENT0, gl.GL_TEXTURE_2D, tex, 0)
        rb = None
        if depth:                                    # a depth TEXTURE (not a renderbuffer) so the ray-tracing pass can read it
            rb = gl.glGenTextures(1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, rb)
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_DEPTH_COMPONENT24, w, h, 0, gl.GL_DEPTH_COMPONENT, gl.GL_UNSIGNED_INT, None)
            for q, v in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_NEAREST), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_NEAREST),
                         (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
                gl.glTexParameteri(gl.GL_TEXTURE_2D, q, v)
            gl.glFramebufferTexture2D(gl.GL_FRAMEBUFFER, gl.GL_DEPTH_ATTACHMENT, gl.GL_TEXTURE_2D, rb, 0)
        ok = gl.glCheckFramebufferStatus(gl.GL_FRAMEBUFFER) == gl.GL_FRAMEBUFFER_COMPLETE
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)
        if not ok:
            raise RuntimeError("glow target not complete")
        return (fbo, tex, w, h, rb)

    def _free(self):
        for fbo, tex, _w, _h, rb in ([] if self.fbo is None else [self.fbo]) + self.t:
            gl.glDeleteFramebuffers(1, [fbo])
            gl.glDeleteTextures(1, [tex])
            if rb is not None:
                gl.glDeleteTextures(1, [rb])
        for fbo, tex, _w, _h, rb in self.dn:
            gl.glDeleteFramebuffers(1, [fbo]); gl.glDeleteTextures(1, [tex])
        self.dn, self.dn_n = [], 0
        self.fbo, self.t = None, []

    def begin(self, w, h, scale=1.0):
        """Start drawing the scene offscreen, at `scale` times the window size (w, h). The caller draws the scene at self.size.
        False: not available, draw to the window as usual."""
        if self.broken:
            return False
        rw, rh = max(8, int(round(w * scale))), max(8, int(round(h * scale)))
        try:
            if (rw, rh) != self.size or (w, h) != self.win or self.fbo is None:
                self._free()
                hw, hh, qw, qh = max(8, rw // 2), max(8, rh // 2), max(4, rw // 4), max(4, rh // 4)
                self.fbo = self._target(rw, rh, depth=True)
                self.t = [self._target(hw, hh), self._target(hw, hh), self._target(qw, qh), self._target(qw, qh)]
                self.size, self.win = (rw, rh), (w, h)
        except Exception as err:
            self.broken = True
            self._free()
            print("The blast glow is not available on this graphics card: %s" % err)
            return False
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, self.fbo[0])
        gl.glViewport(0, 0, rw, rh)
        return True

    def denoise(self, strength, still):
        """Clean up the ray-traced picture in the scene target: an edge-keeping blur, and (while the view is still) an average over the last
        few frames, whose random ray patterns differ. `strength` 0..1; `still` False restarts the average."""
        w, h = self.size
        if not self.dn or (self.dn[0][2], self.dn[0][3]) != (w, h):
            for fbo, tex, _w, _h, rb in self.dn:
                gl.glDeleteFramebuffers(1, [fbo]); gl.glDeleteTextures(1, [tex])
            self.dn = [self._target(w, h), self._target(w, h)]
            self.dn_n = 0
        self.dn_n = self.dn_n + 1 if still else 0
        frames = 1 + int(round(15 * strength))
        alpha = 1.0 / (1 + min(self.dn_n, frames)) if self.dn_n > 0 else 1.0
        res, hist = self.dn
        gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_BLEND)
        gl.glBindVertexArray(self.vao)
        gl.glUseProgram(self.p_dn)
        for unit, tex in ((0, self.fbo[1]), (1, hist[1])):
            gl.glActiveTexture(gl.GL_TEXTURE0 + unit)
            gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
            gl.glUniform1i(self.u_dn[unit], unit)
        gl.glUniform2f(self.u_dn[2], 1.0 / w, 1.0 / h)
        gl.glUniform1f(self.u_dn[3], float(alpha))
        gl.glUniform1f(self.u_dn[4], float(strength))
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, res[0])
        gl.glViewport(0, 0, w, h)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 3)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindVertexArray(0)
        gl.glUseProgram(0)
        gl.glBindFramebuffer(gl.GL_READ_FRAMEBUFFER, res[0])
        for dst in (hist[0], self.fbo[0]):                              # the result becomes both the history and the picture the glow and window pass use
            gl.glBindFramebuffer(gl.GL_DRAW_FRAMEBUFFER, dst)
            gl.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, gl.GL_COLOR_BUFFER_BIT, gl.GL_NEAREST)
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)

    def _pass(self, prog, target, src_tex):
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, target[0])
        gl.glViewport(0, 0, target[2], target[3])
        gl.glUseProgram(prog)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, src_tex)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 3)

    def _blur(self, a, b):
        gl.glUseProgram(self.p_blur)
        gl.glUniform1i(self.u_blur[0], 0)
        gl.glUniform2f(self.u_blur[1], 1.0 / a[2], 0.0)
        self._pass(self.p_blur, b, a[1])
        gl.glUniform2f(self.u_blur[1], 0.0, 1.0 / a[3])
        self._pass(self.p_blur, a, b[1])

    def apply(self, amount, sharp=0.0, tone=(1.0, 1.0, 1.0)):
        """Draw the offscreen scene to the window, sharpened by `sharp` (0 = not) and with the glow added (amount 0.7 is the game's default,
        0 = no glow, and then the glow is not even worked out)."""
        w, h = self.size
        ww, wh = self.win
        gl.glDisable(gl.GL_DEPTH_TEST)
        gl.glDisable(gl.GL_BLEND)
        gl.glBindVertexArray(self.vao)
        A, B, C, D = self.t
        if amount > 0.0:
            gl.glUseProgram(self.p_down)
            gl.glUniform1i(self.u_down[0], 0)
            gl.glUniform2f(self.u_down[1], 1.0 / w, 1.0 / h)
            gl.glUniform1f(self.u_down[2], 0.82)
            self._pass(self.p_down, A, self.fbo[1])                     # the bright parts, at half size
            self._blur(A, B)
            gl.glUseProgram(self.p_down)
            gl.glUniform2f(self.u_down[1], 1.0 / A[2], 1.0 / A[3])
            gl.glUniform1f(self.u_down[2], -2.0)                        # no threshold: just shrink the glow to quarter size
            self._pass(self.p_down, C, A[1])
            self._blur(C, D)
            self._blur(C, D)                                            # twice: a wide, soft halo
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)
        gl.glViewport(0, 0, ww, wh)
        gl.glUseProgram(self.p_comp)
        for unit, tex in ((0, self.fbo[1]), (1, A[1]), (2, C[1])):
            gl.glActiveTexture(gl.GL_TEXTURE0 + unit)
            gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
            gl.glUniform1i(self.u_comp[unit], unit)
        gl.glUniform1f(self.u_comp[3], float(amount))
        gl.glUniform1f(self.u_comp[4], float(sharp))
        gl.glUniform2f(self.u_comp[5], 1.0 / w, 1.0 / h)
        gl.glUniform3f(self.u_comp[6], float(tone[0]), float(tone[1]), float(tone[2]))
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 3)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindVertexArray(0)
        gl.glUseProgram(0)


def draw_rings(bench):
    """Shockwave rings: a flat band racing outwards from the blast (perpendicular to the surface it hit), brightest at the front, fading as it goes."""
    rings = bench.rings
    if not len(rings):
        return
    gl.glPushAttrib(gl.GL_ENABLE_BIT | gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)          # restored below, so nothing else is affected
    gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_CULL_FACE)
    gl.glEnable(gl.GL_BLEND); gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE)
    gl.glDepthMask(gl.GL_FALSE)
    ang = np.linspace(0.0, 2.0 * np.pi, 73)
    for c, n, age, life, rmax in ((q[0:3], q[3:6], q[6], q[7], q[8]) for q in rings):
        t = min(max(age / life, 0.0), 1.0)
        rad = rmax * (1.0 - (1.0 - t) ** 2.5)                      # fast at first, slowing
        wid = 0.06 * rmax + 0.35 * rad * (1.0 - t)
        alpha = 0.5 * (1.0 - t) ** 1.4
        u = np.cross(n, [0.0, 0.0, 1.0] if abs(n[2]) < 0.9 else [1.0, 0.0, 0.0])
        u /= max(float(np.linalg.norm(u)), 1e-9)
        v = np.cross(n, u)
        base = c + n * 0.06
        gl.glBegin(gl.GL_QUAD_STRIP)
        for a in ang:
            d = u * math.cos(a) + v * math.sin(a)
            gl.glColor4f(1.0, 0.85, 0.6, 0.0); gl.glVertex3f(*(base + d * max(rad - wid, 0.0)))        # soft inner edge
            gl.glColor4f(1.0, 0.92, 0.75, alpha); gl.glVertex3f(*(base + d * rad))                       # bright front
        gl.glEnd()
        gl.glBegin(gl.GL_QUAD_STRIP)
        for a in ang:
            d = u * math.cos(a) + v * math.sin(a)
            gl.glColor4f(1.0, 0.92, 0.75, alpha); gl.glVertex3f(*(base + d * rad))
            gl.glColor4f(1.0, 0.85, 0.6, 0.0); gl.glVertex3f(*(base + d * (rad + 0.12 * wid)))        # thin soft outer edge
        gl.glEnd()
    gl.glPopAttrib()


def draw_blastfx(bench):
    """Draw the blast effect cubes with the engine's cube renderer, using the camera as set up by draw_scene."""
    fx = bench.blastfx
    if fx.n == 0:
        return
    if bench.fx_gl is None:
        bench.fx_gl = bench.E.DirtBodyRenderer()
    P = np.array(gl.glGetDoublev(gl.GL_PROJECTION_MATRIX), np.float64).T      # GL hands matrices over column by column
    M = np.array(gl.glGetDoublev(gl.GL_MODELVIEW_MATRIX), np.float64).T
    gl.glEnable(gl.GL_DEPTH_TEST); gl.glDepthMask(gl.GL_TRUE)
    gl.glDisable(gl.GL_BLEND); gl.glDisable(gl.GL_CULL_FACE); gl.glDisable(gl.GL_TEXTURE_2D)
    bench.fx_gl.render(P @ M, 1.0, 0.0, 0.0, bodies=fx)
    gl.glUseProgram(0); gl.glBindVertexArray(0); gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)


# ------------------------------------------------------------------------------------------------ scene
# ------------------------------------------------------------------------------------------------ fire, embers and spilled oil
EMBER_TAG, FLAME_TAG = 77.0, 88.0      # BlastFX 'glow' values (the cube shader ignores glow for SPARK and FIRE cubes): they mark the cubes this system made


class Reactive:
    """Fire, embers and spilled oil (the first slice of the Grain Lab elements: Fire, Ember, Oil).

    It lives beside the engine and talks to structures only through cells and tints, the same way `scorch` does.
      Oil     spilled oil is a puddle row in bench.oil with an unlit state (its 'seconds until it catches' is infinity). Burning
              puddles, embers, torch flames and blasts light unlit puddles, and a burning puddle lights its neighbours.
      Fire    timber cells (planks, logs, leaves) carry a burn value: 0 = cold, 0.5 = alight, 1 = burnt away. Heat comes from burning
              puddles, the torch, embers and blasts, and from burning neighbours (flames climb faster than they spread sideways).
              Burnt cells are removed with the engine's own cell removal, so a burnt-through post drops what it was holding.
      Ember   a SPARK effect cube tagged EMBER_TAG. Thrown by blasts, burning timber and burning oil. They glow yellow -> orange -> red
              as they cool, rest where they land and can light the timber or oil they rest on.
    Everything runs from one 10 Hz tick on numpy arrays. Loose chunks that break off a burning structure stop burning (known limit)."""
    TICK = 0.1
    MAX_EMBERS = 300
    FLAMMABLE = ('PLANKS', 'WOOD', 'WOOD_OAK', 'WOOD_BIRCH', 'WOOD_SPRUCE', 'WOOD_DARK', 'WOOD_JUNGLE', 'WOOD_ACACIA', 'LEAVES')
    DIRS = np.array([[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1],
                     [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1]])               # fire climbs: the up and the four up-diagonal cells are heated too
    DIR_W = np.array([1.25, 0.4, 1.0, 1.0, 1.0, 1.0, 0.4, 0.4, 0.4, 0.4])
    FACES = np.array([[0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, -1, 0]])

    def __init__(self, bench):
        self.b = bench
        self.lut = np.zeros(256, bool)
        for n in self.FLAMMABLE:
            v = getattr(bench.E, n, None)
            if v is not None:
                self.lut[int(v)] = True
        self._sten = {}
        self.rng = np.random.default_rng()
        self.reset()

    def reset(self):
        self.torches = np.zeros((0, 5))                            # torch flames: x, y, z, reach, seconds left
        self.flash = []                                            # one-off heat pulses from blasts: (point, reach, amount)
        self.stain_q = []                                          # spilled-oil patches waiting to darken the ground
        self.heat_pts = np.zeros((0, 5))                           # where fire is: the drums' cook-off reads it
        self.t = self.tint_t = self.stain_t = 0.0
        self.clock = 0.0                                           # seconds of reactive time (when each stain is due)
        self.stat = dict(burning=0, embers=0, lit=0, unlit=0)
        self.gone = 0                                              # timber cells burnt away since the scene was built

    def k(self, key, default):
        return float(self.b.cfg.get(key, default))

    # ---- tools and events --------------------------------------------------------------------------------------
    def torch(self, pt, obj=None, dt=0.1):
        """The Torch tool: a flame at the point. Lights oil, timber and drums."""
        pt = np.asarray(pt, np.float64)
        r = self.k('torchr', 15.0) / 100.0
        self.torches = np.concatenate([self.torches, [[pt[0], pt[1] + 0.02, pt[2], r, 1.5]]])[-80:]
        fx, rng = self.b.blastfx, self.rng
        n = 3
        pos = pt + rng.normal(0.0, 0.4 * r, (n, 3))
        pos[:, 1] = pt[1] + rng.uniform(0.03, 0.2, n)
        vel = np.stack([rng.uniform(-0.2, 0.2, n), rng.uniform(0.5, 1.4, n), rng.uniform(-0.2, 0.2, n)], axis=1)
        if len(fx.age) < fx.MAX - 400:
            fx.add(fx.FIRE, pos, vel, rng.uniform(0.08, 0.16, n) * (0.5 + r / 0.15 * 0.5), rng.uniform(0.35, 0.7, n), glow=FLAME_TAG)
        self.light_puddles(pt, r + 0.35, 1.0)
        if obj is not None and getattr(obj, 'is_drum', False):
            obj.heat = getattr(obj, 'heat', 0.0) + dt * 1.5

    def pour(self, pt):
        """The Pour oil tool: unlit puddles around the point, on whatever ground is under them."""
        b, rng = self.b, self.rng
        pt = np.asarray(pt, np.float64)
        n = max(1, int(round(self.k('opour', 12) * 0.4)))          # a little each call: the hold-to-pour tool calls this often, so it builds up smoothly
        ang = rng.uniform(0.0, 2.0 * np.pi, n)
        dist = 0.40 * np.sqrt(rng.uniform(0.0, 1.0, n))
        xz = np.stack([pt[0] + np.cos(ang) * dist, pt[2] + np.sin(ang) * dist], axis=1)
        try:                                                       # on a wall face the oil starts just off the wall and runs down to the ground beside it
            origin = pt + b.face_normal(pt) * 0.08
        except Exception:
            origin = pt
        xz = b.clip_to_open(origin, xz, pt[1] + 0.25)
        gy = b.ground_below(xz, pt[1] + 0.25)
        burn = self.k('dburn', 8.0) * rng.uniform(0.7, 1.3, n)
        pos = np.stack([xz[:, 0], gy, xz[:, 1]], axis=1)
        # a thin stream of small droplets falls from above the point; each puddle (and its dark stain) appears when its drop lands
        top = pt[1] + 0.9
        drop = np.stack([xz[:, 0] + rng.normal(0, 0.015, n), np.maximum(top, gy + 0.3), xz[:, 1] + rng.normal(0, 0.015, n)], axis=1)
        fall = np.sqrt(2.0 * np.maximum(drop[:, 1] - gy, 0.05) / 6.0)
        b.blastfx.add(b.blastfx.DUST, drop, np.zeros((n, 3)), rng.uniform(0.035, 0.06, n), fall + 0.12)
        new = np.column_stack([pos, np.full(n, np.inf), burn])
        b.oil = np.concatenate([b.oil[b.oil[:, 4] > 0.0], new])[-500:]
        self.stain_q.append((self.clock + fall, pos))

    def light_puddles(self, point, reach, prob, delay=(0.1, 0.5)):
        o = self.b.oil
        if not len(o):
            return 0
        unlit = ~np.isfinite(o[:, 3])
        if not unlit.any():
            return 0
        d = np.linalg.norm(o[:, :3] - np.asarray(point, np.float64), axis=1)
        hit = unlit & (d < reach) & (self.rng.random(len(o)) < prob)
        o[hit, 3] = self.rng.uniform(delay[0], delay[1], int(hit.sum()))
        return int(hit.sum())

    def blast(self, point, r, normal=None):
        """An explosion: a heat pulse that sets fuel alight, and a spray of embers."""
        point = np.asarray(point, np.float64)
        self.flash.append((point.copy(), float(r) * 1.15, 1.5))
        n = int(min(160, round(20.0 * float(r) * self.k('fblast', 100.0) / 100.0)))
        if n <= 0:
            return
        rng = self.rng
        nrm = np.array([0.0, 1.0, 0.0]) if normal is None else np.asarray(normal, np.float64)
        nrm = nrm / max(float(np.linalg.norm(nrm)), 1e-9)
        v = rng.normal(size=(n, 3))
        v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)
        d = v @ nrm
        v = np.where((d < 0)[:, None], v - 2.0 * d[:, None] * nrm, v) + nrm * 0.8 + np.array([0.0, 0.4, 0.0])
        v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)
        speed = rng.uniform(2.5, 8.0, n) * (0.6 + 0.12 * min(float(r), 6.0))
        self.throw_embers(point + nrm * 0.12 + v * 0.15, v * speed[:, None])

    def throw_embers(self, pos, vel, life=None):
        fx, rng = self.b.blastfx, self.rng
        pos, vel = np.asarray(pos, np.float64).reshape(-1, 3), np.asarray(vel, np.float64).reshape(-1, 3)
        have = int(((fx.kind == fx.SPARK) & (fx.glow == EMBER_TAG)).sum()) if len(fx.age) else 0
        n = min(len(pos), max(0, self.MAX_EMBERS - have), max(0, fx.MAX - len(fx.age) - 400))
        if n <= 0:
            return
        life = rng.uniform(2.5, 6.0, n) if life is None else np.asarray(life)[:n]
        fx.add(fx.SPARK, pos[:n], vel[:n], rng.uniform(0.05, 0.09, n), life, glow=EMBER_TAG)

    # ---- the 10 Hz tick ----------------------------------------------------------------------------------------
    def update(self, dt):
        self.t += dt
        if self.t < self.TICK:
            return
        dt, self.t = self.t, 0.0
        self.clock += dt
        b, rng = self.b, self.rng
        fx = b.blastfx
        raw = b.E.STRUCTS.structs
        burning_any = any(getattr(o, '_bb', None) is not None for o in raw)
        oil = b.oil
        em = (fx.kind == fx.SPARK) & (fx.glow == EMBER_TAG) & (fx.age >= 0) if len(fx.age) else np.zeros(0, bool)
        n_em = int(em.sum())
        if not (len(self.torches) or self.flash or len(oil) or burning_any or n_em or self.stain_q):
            self.stat.update(burning=0, embers=0, lit=0, unlit=0)
            self.heat_pts = self.heat_pts[:0]
            return
        structs = [o for o in raw if not getattr(o, 'is_drum', False) and o.alive.any()]
        tburn = max(2.0, self.k('tburn', 10.0))
        fsp = self.k('fspread', 100.0) / 100.0
        fem = self.k('fember', 100.0) / 100.0
        kheat = 4.0 / tburn                                        # burn per second from one unit of heat power (so about a quarter of the burn time to light)
        epos = fx.pos[em] if n_em else np.zeros((0, 3))
        efrac = (1.0 - fx.age[em] / np.maximum(fx.life[em], 1e-6)) if n_em else np.zeros(0)

        # oil: which puddles catch from what ------------------------------------------------------------------------
        lit = np.zeros(len(oil), bool)
        if len(oil):
            lit = (oil[:, 3] <= 0.0) & (oil[:, 4] > 0.0)
            unlit = ~np.isfinite(oil[:, 3]) & (oil[:, 4] > 0.0)
            if unlit.any():
                up = oil[unlit, :3]
                catch = np.zeros(len(up), bool)
                if int(b.cfg.get('ospread', 1)) == 1 and lit.any() and fsp > 0:         # a burning puddle lights its neighbours
                    D = np.linalg.norm(up[:, None, :] - oil[lit, :3][None, :, :], axis=2)
                    catch |= ((D < 0.5).any(axis=1)) & (rng.random(len(up)) < 1.0 - np.exp(-1.2 * fsp * dt))
                if n_em:                                                                   # a hot ember that lands in oil lights it
                    D = np.linalg.norm(up[:, None, :] - epos[None, :, :], axis=2)
                    catch |= ((D < 0.25) & (efrac[None, :] > 0.1)).any(axis=1) & (rng.random(len(up)) < 0.6)
                if len(self.heat_pts):                                                     # so do burning timber and the torch
                    D = np.linalg.norm(up[:, None, :] - self.heat_pts[None, :, :3], axis=2)
                    catch |= ((D < 0.5).any(axis=1)) & (rng.random(len(up)) < 0.5)
                for p, reach, amount in self.flash:                                        # a blast lights everything in reach, the nearer first
                    d = np.linalg.norm(up - p, axis=1)
                    near = d < reach
                    if near.any():
                        idx = np.flatnonzero(unlit)[near]
                        oil[idx, 3] = 0.05 + 0.6 * d[near] / reach
                if catch.any():
                    idx = np.flatnonzero(unlit)[catch]
                    oil[idx, 3] = rng.uniform(0.2, 0.7, len(idx))

        # heat sources for timber -------------------------------------------------------------------------------------
        P, R, M = [], [], []                                                              # sources that heat for as long as they last (heat per second x dt) ...
        PI, RI, MI = [], [], []                                                           # ... and one-off pulses (the amount is added once)
        if len(self.torches):
            P.append(self.torches[:, :3]); R.append(self.torches[:, 3]); M.append(np.full(len(self.torches), 3.0 * kheat * dt))
        if lit.any():
            P.append(oil[lit, :3] + np.array([0.0, 0.05, 0.0])); R.append(np.full(int(lit.sum()), 0.32)); M.append(np.full(int(lit.sum()), 1.2 * kheat * dt))
        if n_em:
            roll = rng.random(n_em) < 0.02 * efrac                                          # an ember sometimes lights the wood it rests on (more when it is fresh and hot)
            if roll.any():
                PI.append(epos[roll]); RI.append(np.full(int(roll.sum()), 0.45)); MI.append(np.full(int(roll.sum()), 0.9))
        for p, reach, amount in self.flash:
            PI.append(p[None, :]); RI.append(np.array([reach])); MI.append(np.array([amount]))
        self.flash = []
        def pack(P, R, M):
            if not P:
                return np.zeros((0, 3)), np.zeros(0), np.zeros(0)
            P, R, M = np.concatenate(P), np.concatenate(R), np.concatenate(M)
            if len(P) > 400:
                keep = rng.permutation(len(P))[:400]
                P, R, M = P[keep], R[keep], M[keep]
            return P, R, M
        P, R, M = pack(P, R, M)
        PI, RI, MI = pack(PI, RI, MI)
        rate_cap = 3.0 * kheat * dt                                                       # the torch is the hottest rate source; nothing goes past it

        # timber ------------------------------------------------------------------------------------------------------
        flames, burning_n = [], 0
        self.tint_t += dt
        do_tint = self.tint_t >= 0.3
        if do_tint:
            self.tint_t = 0.0
        crowded = len(fx.age) > 3200
        for o in structs:
            fl = getattr(o, '_flam', None)
            if fl is None:
                fl = o._flam = bool(self.lut[o.mat].any())
            if not fl:
                continue
            lo_w, hi_w = o.aabb()
            for Pg, Rg, Mg, cap in ((P, R, M, rate_cap), (PI, RI, MI, 1.0)):
                if len(Pg):
                    pad = Rg[:, None] + o.cs
                    sel = np.all((Pg >= lo_w - pad) & (Pg <= hi_w + pad), axis=1)
                    if sel.any():
                        self._deposit(o, Pg[sel], Rg[sel], Mg[sel], cap)
            if getattr(o, '_bb', None) is None:
                continue
            burning_n += self._burn(o, dt, tburn, fsp, fem, do_tint, flames, crowded)

        # embers from burning oil -------------------------------------------------------------------------------------
        if lit.any() and fem > 0:
            rows = np.flatnonzero(lit)
            pick = rows[rng.random(len(rows)) < min(1.0, 0.06 * fem * dt)]
            if len(pick):
                n = len(pick)
                vel = np.stack([rng.normal(0, 0.7, n), rng.uniform(1.5, 4.0, n), rng.normal(0, 0.7, n)], axis=1)
                self.throw_embers(oil[pick, :3] + np.array([0.0, 0.2, 0.0]), vel)

        # bookkeeping -------------------------------------------------------------------------------------------------
        if len(self.torches):
            self.torches[:, 4] -= dt
            self.torches = self.torches[self.torches[:, 4] > 0.0]
        pts = [self.torches[:, :3]] if len(self.torches) else []
        if flames:
            pts.append(np.concatenate(flames)[:60])
        self.heat_pts = np.column_stack([np.concatenate(pts), np.zeros((sum(len(p) for p in pts), 2))]) if pts else np.zeros((0, 5))
        if self.stain_q:                                                              # oil darkens the ground it lies on, a little at a time once the drops land
            due, keep = [], []
            for tt, pp in self.stain_q:
                m_ = tt <= self.clock
                if m_.any():
                    due.append(pp[m_])
                if (~m_).any():
                    keep.append((tt[~m_], pp[~m_]))
            self.stain_q = keep
            if due:
                b.scorch(np.concatenate(due)[-80:], 0.26, 0.5)
        oil = b.oil
        self.stat.update(burning=burning_n, embers=n_em,
                         lit=int(((oil[:, 3] <= 0.0) & (oil[:, 4] > 0.0)).sum()) if len(oil) else 0,
                         unlit=int((~np.isfinite(oil[:, 3])).sum()) if len(oil) else 0)

    # ---- timber ------------------------------------------------------------------------------------------------
    def _stencil(self, rc):
        s = self._sten.get(rc)
        if s is None:
            r = np.arange(-rc, rc + 1)
            s = self._sten[rc] = np.stack(np.meshgrid(r, r, r, indexing='ij'), -1).reshape(-1, 3)
        return s

    def _grow(self, o, lo, hi):
        lo, hi = np.maximum(np.asarray(lo, np.int64), 0), np.minimum(np.asarray(hi, np.int64), np.array(o.alive.shape))
        bb = getattr(o, '_bb', None)
        o._bb = (lo, hi) if bb is None else (np.minimum(bb[0], lo), np.maximum(bb[1], hi))

    def _deposit(self, o, P, R, M, cap):
        """Add heat to the flammable cells round each source: M x a falloff that is 1 at the source and 0 at its reach. Overlapping
        sources add up, but no cell takes more than `cap` in one tick (fifty puddles on one spot are not fifty times hotter)."""
        cs, fp, shape = o.cs, np.asarray(o.frame_pos, np.float64), np.array(o.alive.shape)
        Reff = np.maximum(R, 0.75 * cs)
        rc = int(min(3, np.ceil(float(Reff.max()) / cs)))
        offs = self._stencil(rc)
        rel = (P - fp) / cs
        cells = np.floor(rel).astype(np.int64)[:, None, :] + offs[None, :, :]
        d = np.linalg.norm(cells + 0.5 - rel[:, None, :], axis=2) * cs
        w = np.clip(1.0 - d / Reff[:, None], 0.0, 1.0) * M[:, None]
        ok = np.all((cells >= 0) & (cells < shape), axis=2) & (w > 0)
        c, w = cells[ok], w[ok]
        keep = o.alive[c[:, 0], c[:, 1], c[:, 2]] & self.lut[o.mat[c[:, 0], c[:, 1], c[:, 2]]]
        c, w = c[keep], w[keep]
        if not len(c):
            return
        if getattr(o, '_burn', None) is None:
            o._burn = np.zeros(o.alive.shape, np.float32)
        flat = np.ravel_multi_index((c[:, 0], c[:, 1], c[:, 2]), o._burn.shape)
        u, inv = np.unique(flat, return_inverse=True)
        o._burn.reshape(-1)[u] += np.minimum(np.bincount(inv, weights=w), cap).astype(np.float32)
        self._grow(o, c.min(axis=0), c.max(axis=0) + 1)

    def _burn(self, o, dt, tburn, fsp, fem, do_tint, flames, crowded):
        """One tick of burning for one structure. Returns how many cells are alight."""
        b, rng, fx = self.b, self.rng, self.b.blastfx
        cs, fp, shape = o.cs, np.asarray(o.frame_pos, np.float64), np.array(o.alive.shape)
        lo, hi = o._bb
        lo, hi = np.maximum(lo - 1, 0), np.minimum(hi + 1, shape)                          # one cell of margin: heat goes to the neighbours
        sl = tuple(slice(int(a), int(c)) for a, c in zip(lo, hi))
        B, A = o._burn[sl], o.alive[sl]
        B[~A] = 0.0
        burning = (B >= 0.5) & A
        B[burning] += dt / tburn                                                           # an alight cell burns for about half the burn-time setting
        if burning.any() and fsp > 0:
            idx = np.argwhere(burning) + lo
            if len(idx) > 5000:
                idx = idx[rng.permutation(len(idx))[:5000]]
            kspread = 0.20 * fsp * (10.0 / tburn) * dt
            for dvec, wgt in zip(self.DIRS, self.DIR_W):
                nb = idx + dvec
                inb = np.all((nb >= 0) & (nb < shape), axis=1)
                nb = nb[inb]
                if not len(nb):
                    continue
                ok = o.alive[nb[:, 0], nb[:, 1], nb[:, 2]] & self.lut[o.mat[nb[:, 0], nb[:, 1], nb[:, 2]]] & (o._burn[nb[:, 0], nb[:, 1], nb[:, 2]] < 0.5)
                nb = nb[ok]
                if len(nb):
                    np.add.at(o._burn, (nb[:, 0], nb[:, 1], nb[:, 2]), np.float32(kspread * wgt))
        np.minimum(B, 1.2, out=B)
        dead = (B >= 1.0) & A
        if dead.any():                                                                     # burnt through: the cell is gone, the engine re-checks what it held
            cells = np.argwhere(dead)
            pick = cells[rng.permutation(len(cells))[:6]] + lo
            if fem > 0 and rng.random() < 0.7:
                pos = fp + (pick + 0.5) * cs
                n = len(pos)
                vel = np.stack([rng.normal(0, 0.8, n), rng.uniform(0.8, 2.5, n), rng.normal(0, 0.8, n)], axis=1)
                self.throw_embers(pos, vel)
            o._remove(dead, box=([int(v) for v in lo], [int(v) for v in hi]))
            B[dead] = 0.0
            self.gone += int(dead.sum())
            A = o.alive[sl]
        burning = (B >= 0.5) & A
        n_burn = int(burning.sum())
        if n_burn:
            idx = np.argwhere(burning) + lo
            pick = idx[rng.permutation(len(idx))[:60]]
            nb = pick[:, None, :] + self.FACES[None, :, :]
            inb = np.all((nb >= 0) & (nb < shape), axis=2)
            free = np.ones(inb.shape, bool)
            free[inb] = ~o.alive[nb[inb][:, 0], nb[inb][:, 1], nb[inb][:, 2]]
            has = free.any(axis=1)
            first = free.argmax(axis=1)
            pick, face = pick[has], self.FACES[first[has]]
            pos = fp + (pick + 0.5) * cs + face * (0.5 * cs + 0.02)
            if len(pos):
                flames.append(pos)
                if not crowded:
                    m = min(len(pos), 24)
                    sz = rng.uniform(0.10, 0.20, m) * float(np.clip(cs / 0.2, 0.6, 1.5))
                    vel = face[:m] * 0.3 + np.stack([rng.uniform(-0.2, 0.2, m), rng.uniform(0.4, 1.2, m), rng.uniform(-0.2, 0.2, m)], axis=1)
                    fx.add(fx.FIRE, pos[:m], vel, sz, rng.uniform(0.45, 0.85, m), glow=FLAME_TAG)
                    sk = float(b.cfg.get('smoke', 100)) / 100.0
                    ns = int(min(10, rng.poisson(0.12 * len(pos) * sk)))
                    if ns > 0:
                        sp = pos[rng.integers(0, len(pos), ns)] + np.array([0.0, 0.2, 0.0])
                        fx.add(fx.SMOKE, sp, np.stack([rng.uniform(-0.2, 0.2, ns), rng.uniform(0.6, 1.5, ns), rng.uniform(-0.2, 0.2, ns)], axis=1),
                               rng.uniform(0.15, 0.3, ns), rng.uniform(1.8, 3.2, ns))
                    ne = int(min(6, rng.poisson(0.04 * len(pos) * fem)))
                    if ne > 0:
                        ep = pos[rng.integers(0, len(pos), ne)]
                        self.throw_embers(ep, np.stack([rng.normal(0, 0.8, ne), rng.uniform(1.0, 3.5, ne), rng.normal(0, 0.8, ne)], axis=1))
        if do_tint:                                                                        # wood chars as it heats
            m = B > 0.05
            if m.any():
                tgt = np.where(m, 1.0 - 0.8 * np.clip(B / 0.5, 0.0, 1.0), 1.0).astype(np.float32)
                cur = o.tint[sl]
                new = np.minimum(cur, tgt)
                if float((cur - new).max()) > 0.03:
                    o.tint[sl] = new
                    o.mesh_ver += 1
        nz = np.argwhere(B > 0)                                                            # tighten the box round what is still hot
        o._bb = None if not len(nz) else (nz.min(axis=0) + lo, nz.max(axis=0) + lo + 1)
        return n_burn


class Bench:
    def __init__(self, E, shots=None):
        self.E = E
        if not hasattr(E, '_g_base'):
            E._g_base = float(E.STRUCT_GRAVITY)
        self.g0 = E._g_base                           # the engine's own gravity (24 m/s^2); the Gravity slider is a percentage of it
        self.cfg = dict(material=0, spin=0, spinfocus=0, shake=50, res=100, speed=100, sharp=0, dsize=60, jr=6, jp=2, js=65, jv=100, jd=20, jf=30, dchain=0, doil=1, dburn=8, dthrow=100, dfire=1, dcook=3, smoke=100, scorch=100, wave=100, shape=0, anchor=1, bond=2, chunks=1, w=120, h=80, t=10, cubes=1, keep=1, brick=15, tcm=25, sub=7, wsub=3, scale=1, str=1,
                        xr=6, xp=1, xv=100, xs=65, xq=60, xh=0, xk=50, xf=30, xd=20, tumble=100, grav=100,
                        bloom=100, bloomall=0, cull=1, rt=0, rtsh=100, rtsoft=40, rtao=100, rtgi=60, rtrf=100, rtn=6, dwm=14, dws=60, dwh=10, dwk=0, rmm=0, rmv=6, rmf=16, rms=8, rmk=10, rmw=100, adn=3, adr=3, adh=6, adk=1,
                        fspread=100, tburn=10, fember=100, fblast=100, ospread=1, opour=12, torchr=15,
                        looksens=100, invy=0, fov=70, camspd=100, crosshair=1,
                        fpscap=120, vsync=0, bright=100, contrast=100, gamma=100, rtdn=60, toolbar=1, textures=1, texdepth=100, rec_res=3, rec_fps=2, **RT_SHINE_DEFAULTS)
        self.blastfx = BlastFX()                                   # the blast effect (flash, fireball, dust, sparks)
        self.fx_gl = None                                          # its cube renderer (made on first use, once there is a GL context)
        self.bloom = None                                          # the glow pass (made on first use)
        self.rt = None                                             # the ray-traced lighting pass (made on first use; False = not available)
        self.bp_scroll = 0                                         # how far the BLAST menu content is scrolled, in pixels
        self.blast_tab = 5                                         # the BLAST menu's tab: 0 Toggles, 1 Cube state, 2 Objects, 3 Weapons
        self.drums = []                                            # the placed oil drums (small Structures, flagged is_drum)
        self.fpcam = None                                          # the first-person camera object (None until one is placed from the Objects tab)
        self.fp_hot = None                                         # which of its arrows the mouse is on / is dragging (0 X, 1 Y, 2 Z)
        self.armed = None                                          # an Objects-tab item picked by a click: the next world click places it
        self.pick_obj = None                                       # the structure the last pick() ray hit
        self.weapon = 'explode'                                    # the Weapons tab's choice: 'explode' (the default click blast) or 'gun'
        self.bullets = []                                          # flying bullets: [position, velocity, age]
        self.thrown = []                                           # barrels in flight: [centre, velocity, size, age]; each one sticks where it first touches something
        self.weights = []                                          # drop-weight bodies alive (newest last; the oldest is removed past MAX_WEIGHTS)
        self.ram = None                                            # the ram body (one at a time)
        self.drop_log = None                                       # telemetry of the latest drop weight
        self.last_drop = None                                      # where / how the last weight was dropped
        self.frame_ms = 16.7                                       # smoothed real frame time (set by the main loop), for the add-debris readout
        self.debris_best = {}                                      # most cubes alive while the frame rate held: {fps target: cube count}
        self._tool_t = 0.0
        self._tool_stats = (0, 0, 0)
        self.chain = []                                            # drums primed by a neighbour's blast: [seconds until it goes off, drum]
        self.export_path = None                                    # the last settings file written by the Export tab
        self.rings = np.zeros((0, 9))                              # shockwave rings: centre xyz, normal xyz, age, life, final radius
        self.rockets = np.zeros((0, 9))                            # fireworks rockets in flight: x, y, z, vx, vy, vz, seconds to the burst, hue, trail timer
        self.oil = np.zeros((0, 5))                                # burning oil on the ground: x, y, z, seconds until it catches, seconds of burning left
        self.oil_t = 0.0
        self.react = Reactive(self)                                # fire, embers and spilled oil (see the Reactive class)
        self._react_err = False
        self.blast_pos = None                                      # where the last blast went off: the camera spin can circle it
        self.shake = 0.0                                           # screenshake left over from the last blast (0..1), decays; the Screenshake setting scales it
        self.gun_held = False                                      # the mouse is held down with the gun: it keeps firing
        self.gun_cd = 0.0
        self._drum_t = 0.0
        self.paused = False
        self.debris = Debris(E)
        self.bonds0 = 1
        self.floor_k = 1.0
        self.cells0 = 1
        self.note = ''
        self.note_t = 0.0
        self.sim_speed = 100
        self.blasts = self.last_blast = 0
        # the engine's world services, replaced by the bench's own
        E.BODIES = self.debris
        E.SFX = type('NoSound', (), {'__getattr__': lambda s, n: (lambda *a, **k: None)})()
        E._cell_contact = self.floor_contact
        E.CONFIG.update(debris_on=True, debris_amount=1.0, debris_detail=1)
        E._S_RGB[E.BRICK] = (0.72, 0.31, 0.22)
        E._S_RGB[E.STEEL] = (0.42, 0.45, 0.52)
        E._S_RGB[E.CONCRETE_RED] = (0.72, 0.12, 0.10)         # the oil drum's material: plain red (its debris is red too)
        E._S_HARD[E.CONCRETE_RED] = 0.4                       # thin metal: much weaker than stone, so the drum is easy to destroy
        E._S_RGB[E.CONCRETE_BLUE] = (0.52, 0.16, 0.72)        # the fireworks box's material: purple (its debris is purple too)
        E._S_HARD[E.CONCRETE_BLUE] = 0.4
        self.build()

    @staticmethod
    def floor_contact(world, Q, reach=0.06):
        y = Q[:, 1]
        n = np.zeros((len(Q), 3)); n[:, 1] = 1.0
        return -y, n, y < reach

    def apply_live(self):
        """Push the settings that act at once (no rebuild) into the engine: bond strength and the loose bodies' physics substeps.
        (A big group of bricks cut off from the ground now falls as one rigid body, see STRUCT_FALL_AS_BODY; 'wsub' is how many times per
        frame the loose debris cubes are stepped, see step.)"""
        self.E.BOND['strength'] = int(self.cfg['bond'])
        self.debris.set_recycle(int(self.cfg.get('keep', 0)) == 0)
        self.E.STRUCT_KEEP_ALL = int(self.cfg.get('keep', 0)) == 1
        self.E.STRUCT_FALL_AS_BODY = True                      # a piece cut off from the ground falls as one rigid piece and breaks up when it lands
        self.debris.kick_scale = float(self.cfg['tumble']) / 100.0
        self.E.STRUCT_GRAVITY = self.g0 * float(self.cfg['grav']) / 100.0       # one gravity for the debris cubes and any loose body
        self.E.STRUCT_SUBSTEPS = max(1, int(self.cfg['sub']))
        self.E.CONFIG['debris_size'] = self.cs                                   # debris cube size applies at once (new debris only)
        # Stress from a structure's own weight grows with its height, so a brick cube bigger than about 30 m crushes itself.
        # The engine's global STRENGTH scales how much a brick can carry (not the impact bonds): it follows the cube's scale.
        self.E.STRENGTH['k'] = float(self.cfg['str']) * max(1.0, self.cfg['scale'] / 6.0)

    def settings_snapshot(self):
        """Every setting in use: all the sliders and toggles (the whole cfg), the chosen weapon and the hidden cube states. A readable copy
        (each slider's label and value as the panel shows them) is added for anyone opening the file."""
        cfg = {}
        for k, v in sorted(self.cfg.items()):
            if isinstance(v, (bool, int, float, np.integer, np.floating)):
                cfg[k] = float(v) if isinstance(v, (float, np.floating)) else int(v)
        readable = {}
        for sl in BLAST_SLIDERS + [x for x in SLIDERS if 'key' in x and x['key'] not in {y['key'] for y in BLAST_SLIDERS}]:
            if sl['key'] in self.cfg:
                try:
                    readable[sl['label']] = sl['fmt'](self.cfg[sl['key']])
                except Exception:
                    pass
        return dict(app='ShatterEngine2.0', version=1, saved=time.strftime('%Y-%m-%d %H:%M:%S'), weapon=self.weapon,
                    hidden_cube_states=int(self.debris.hidden_mask), settings=cfg, readable=readable,
                    first_person_camera=None if self.fpcam is None else dict(position=[round(float(v), 3) for v in self.fpcam.pos], yaw=round(float(self.fpcam.yaw), 4), pitch=round(float(self.fpcam.pitch), 4)))

    def export_settings(self):
        """Write every setting to shatter_settings_<time>.json next to this script and say where it went."""
        path = os.path.join(HERE, 'shatter_settings_%s.json' % time.strftime('%Y%m%d_%H%M%S'))
        snap = self.settings_snapshot()
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(snap, f, indent=2)
        except OSError as e:
            self.say('Could not save the settings: %s' % e, 6.0, force=True)
            return None
        self.export_path = path
        self.say('Saved %d settings to %s' % (len(snap['settings']), os.path.basename(path)), 6.0)
        print('settings written to', path, flush=True)
        return path

    @property
    def cs(self):
        return self.cfg['brick'] / 100.0 * self.cfg['scale']       # world size of a DEBRIS cube: its cm size x the whole-cube scale

    @property
    def tcs(self):
        return self.cfg['tcm'] / 100.0 * self.cfg['scale']         # world size of a TERRAIN cube (independent of the debris cubes)

    def build(self):
        E = self.E
        self.apply_live()
        E.CONFIG['debris_size'] = self.cs
        S = E.STRUCTS
        S.structs, S.bodies = [], []
        self.drums = []
        self.bullets = []
        self.thrown = []
        self.weights = []
        self.ram = None
        self.drop_log = None
        self.debris_best = {}
        self.chain = []
        self.oil = np.zeros((0, 5))
        self.react.reset()
        self.rockets = np.zeros((0, 9))
        self.rings = np.zeros((0, 9))
        self.blast_pos = None
        self.debris.clear(); self._dropped_seen = 0
        self.blastfx.clear()
        self.debris.set_recycle(int(self.cfg.get("keep", 0)) == 0)
        self.debris.kick_scale = float(self.cfg['tumble']) / 100.0
        self.blasts = self.last_blast = 0
        # Chunks of dirt, each TERRAIN_SIZE cells (width, height, depth), standing on the floor in a k x k grid.
        # k comes from the 'Chunks' slider (1, 4, 9 ... 25 chunks). Each chunk is its own structure, with a small gap between them.
        # The terrain keeps its physical size (TERRAIN_SIZE cells of TERRAIN_REF_CUBE metres); the Terrain cube size slider changes
        # how many cells that is, so smaller cubes = finer terrain. Debris cubes have their own size (Debris cube size slider).
        shape = SHAPES[int(self.cfg.get('shape', 0)) % len(SHAPES)][1]       # None = the flat terrain slab; otherwise a cube, pillar or wall (Q cycles them)
        W0, H0, T0 = TERRAIN_SIZE if shape is None else (m / TERRAIN_REF_CUBE for m in shape)
        g0 = max(1, int(self.cfg.get('chunks', 1))) if shape is None else 1     # the Chunks slider only tiles the flat terrain
        cs = self.tcs
        while True:
            W = max(1, int(round(W0 * TERRAIN_REF_CUBE * self.cfg['scale'] / cs)))
            H = max(1, int(round(H0 * TERRAIN_REF_CUBE * self.cfg['scale'] / cs)))
            T = max(1, int(round(T0 * TERRAIN_REF_CUBE * self.cfg['scale'] / cs)))
            if g0 * g0 * W * H * T <= TERRAIN_MAX_CELLS:
                break
            cs *= 1.08                                        # too many cells: use slightly bigger terrain cubes
        if cs > self.tcs * 1.001:
            self.say('Terrain cubes made %.0f cm (the most cells allowed is %d)' % (cs / max(self.cfg['scale'], 1e-9) * 100.0, TERRAIN_MAX_CELLS))
        g = g0                                               # the slider's value is the grid side: 1 -> 1 chunk, 2 -> 4, 3 -> 9 ...
        # The chunks are joined into ONE structure: no gaps, and the bonds run across the joins, so the surface stays whole.
        material_id = getattr(E, BENCH_MATERIALS[int(self.cfg.get('material',0)) % len(BENCH_MATERIALS)][1])
        mat = np.full((g * W, H, g * T), material_id, np.int16)
        total_x, total_z = g * W * cs, g * T * cs
        origin = np.array([-total_x / 2, 0.0, -total_z / 2])
        rng = np.random.default_rng(7)
        tint = (0.86 + 0.24 * rng.random(mat.shape)).astype(np.float32)
        st = E.Structure(mat, origin, cs, tint=tint)
        if int(self.cfg.get('anchor', 1)) == 1:
            st.anch[:, 0, :] = mat[:, 0, :] > 0              # the bottom layer stands on the floor (toggle 'Anchor terrain' off: nothing is anchored)
        st.unanch[:] = False
        S.structs.append(st)
        self.cells0 = int(st.alive.sum())
        self.bonds0 = max(1, sum(int(b.sum()) for b in st.bond))
        self.size = np.array(mat.shape) * cs
        self.floor_k = max(1.0, float(max(self.size[0], self.size[2])) / 40.0)     # the floor grows with a big area of chunks
        if self.cells0 > E.STRUCT_UNBREAKABLE_CELLS:
            self.say('%d cells: over %d, so it will not collapse under its own weight (impacts still break it)' % (self.cells0, E.STRUCT_UNBREAKABLE_CELLS))

    def cycle_material(self):
        """E rebuilds the current test shape using the next material."""
        self.cfg['material'] = (int(self.cfg.get('material',0)) + 1) % len(BENCH_MATERIALS)
        self.build()

    def say(self, text, secs=5.0, force=False):
        """The pop-up notice line is switched off: hints and confirmations are not shown. Only a call with force=True (a failed settings save) is."""
        if not force:
            return
        self.note, self.note_t = text, secs

    # ---- what the mouse points at
    def pick(self, cam, mx, my, w, h):
        """(ray origin, ray direction, first brick point under the mouse or None)."""
        o, d = cam.ray(mx, my, w, h)
        reach = cam.dist * 3.0 + float(max(self.size)) * 2.0
        hit = self.E.STRUCTS.raycast(o, d, reach, step=max(0.04, min(self.cs, self.tcs) / 3.0))
        self.pick_obj = None if hit is None else hit[2]        # what the ray hit (a click on a drum blows it up)
        return o, d, (None if hit is None else o + d * hit[0])

    def face_normal(self, point):
        """The fixed outward direction of the wall face at `point`: one of the six world axes (+-X, +-Y, +-Z). It depends only on where the
        bricks are, never on the camera, so a given face always throws its debris the same way however you look at it. It is the side
        of `point` with the least solid brick around it; if that is unclear, the nearest face of the structure's bounding box."""
        point = np.asarray(point, np.float64)
        structs = self.E.STRUCTS.structs
        st = None                                               # the chunk the point is on (or nearest to) when there are several
        if structs:
            def _box_dist(s):
                lo_s = np.asarray(s.frame_pos, np.float64); hi_s = lo_s + np.array(s.alive.shape) * s.cs
                return float(np.linalg.norm(np.maximum(0.0, np.maximum(lo_s - point, point - hi_s))))
            st = min(structs, key=_box_dist)
        n = None
        if st is not None:
            g = (point - st.frame_pos) / st.cs
            rr = int(np.clip(float(self.cfg['xr']) * self.tcs / st.cs * 0.75, 3, 14))
            shape = st.alive.shape
            lo = [max(int(math.floor(g[k])) - rr, 0) for k in range(3)]
            hi = [min(int(math.ceil(g[k])) + rr, shape[k]) for k in range(3)]
            if all(hi[k] > lo[k] for k in range(3)):
                idx = np.argwhere(st.alive[tuple(slice(lo[k], hi[k]) for k in range(3))])
                if len(idx):
                    off = idx + np.array(lo, np.float64) + 0.5 - g
                    off = off[np.einsum('ij,ij->i', off, off) <= rr * rr]
                    if len(off):
                        v = -off.sum(0)
                        if float(np.linalg.norm(v)) > 1e-6:
                            n = v
        if n is None and st is not None:                        # no clear surface: the nearest face of the structure's box
            lo_b = np.asarray(st.frame_pos, np.float64); hi_b = lo_b + np.array(st.alive.shape) * st.cs
            gaps = np.concatenate([point - lo_b, hi_b - point])
            k = int(np.argmin(gaps)); n = np.zeros(3); n[k % 3] = -1.0 if k < 3 else 1.0
        if n is None:
            return np.array([0.0, 0.0, 1.0])
        a = int(np.argmax(np.abs(n)))
        out = np.zeros(3); out[a] = 1.0 if n[a] > 0 else -1.0     # snapped to an axis: the direction is fixed
        return out

    def solid_at(self, P):
        """Bool per point: inside the floor or a live cell of a fixed structure. The blast effect cubes use it to stop at walls."""
        P = np.asarray(P, np.float64).reshape(-1, 3)
        hit = P[:, 1] < 0.0
        for o in self.E.STRUCTS.structs:
            ij = np.floor((P - np.asarray(o.frame_pos, np.float64)) / o.cs).astype(np.int64)
            ok = np.all((ij >= 0) & (ij < np.array(o.alive.shape)), axis=1)
            if ok.any():
                q = ij[ok]
                hit[ok] |= o.alive[q[:, 0], q[:, 1], q[:, 2]]
        return hit

    # ---- the explosion
    def explode(self, point, launch_normal=None, power_mult=1.0, drum=None, radius=None, fx=True):
        """Blow up at a world point with the engine's own blast: bricks in the radius are destroyed (or cracked, further out),
        and whatever then has no path to the ground falls. It also starts the Shatterlands blast effect (the Fireball size slider; 0 = off)."""
        K = 'j' if (drum is not None and not getattr(drum, 'fw', False)) else 'x'    # a jerry can (oil drum) goes off with its own copy of the Explosion sliders
        r = float(self.cfg[K + 'r']) * self.tcs if radius is None else float(radius)     # radius: a bullet's tiny chip passes its own
        before = self.stats()[0]
        q = float(self.cfg['xq'])                                  # squeeze amount: 0 loose, 50 as the engine spawns it, 100 packed hard
        self.E.BLAST_SQUEEZE = 1.0 + (50.0 - q) / 50.0 * 0.25 if q < 50 else 1.0 - (q - 50.0) / 50.0 * 0.4
        self.debris.hold_s = float(self.cfg['xh']) / 1000.0        # squeeze hold: seconds the pile stays frozen before the blast releases
        self.debris.pop = float(self.cfg['xk']) / 100.0 * 150.0    # pop strength: spring (1/s) giving the squeezed pile's overlap back as speed
        self.debris.begin_spawn_batch()
        point=np.asarray(point,np.float64)
        spray = float(self.cfg[K + 's']) / 100.0
        self.E.BLAST_SPRAY = spray
        self.E.BLAST_KEEP = max(0.0, min(1.0, float(self.cfg.get(K + 'd', 100)) / 100.0))   # Debris amount: share of destroyed cells that survive as cubes
        power = float(self.cfg[K + 'p']) * power_mult               # the Blast power slider (the jerry can has its own)
        if drum is not None and drum in self.E.STRUCTS.structs:
            self.E.STRUCTS.structs.remove(drum)                     # the drum is handled below, with its own (much smaller) share of survivors
        caught = []                                                # other drums in reach are burnt up with the blast: no cubes are left behind
        for o in list(self.E.STRUCTS.structs):
            if getattr(o, 'is_drum', False) and o is not drum and o.alive.any():
                lo_, hi_ = o.aabb()
                if not ((point < lo_ - r).any() or (point > hi_ + r).any()):
                    caught.append(o)
                    self.E.STRUCTS.structs.remove(o)
        self.E.STRUCTS.blast(None, point, r, power=power, debris_normal=launch_normal)
        for o in caught:
            o.blast(point, r, power)                               # the cells it destroys vanish (their cubes are not thrown)
            self.E.STRUCTS.structs.append(o)
        if fx:                                                     # the engine's support check only looks at a small box round the blast and treats everything outside it as held up,
            for o in self.E.STRUCTS.structs:                       # so a thin neck never feels the weight above it: check the whole piece (bigger blasts only, not bullet chips)
                if not getattr(o, 'is_drum', False):
                    o.dirty_all = o.stress_dirty = True
        if drum is not None:
            drum.blast(drum.frame_pos + 0.5 * np.array(drum.alive.shape) * drum.cs, float(max(drum.alive.shape)) * drum.cs * 2.0, 1.0, shatter=True)   # every cell goes, and none comes back as a cube: the drum is incinerated
        self.debris.apply_blast(point,r,power=power,
                                velocity_scale=float(self.cfg[K + 'v'])/100.0,normal=launch_normal,spray=spray)
        fs = float(self.cfg.get(K + 'f', 100)) / 100.0              # fireball size: 0 = off, 100% = the game's default look
        if fs > 0 and fx:
            n = np.array([0.0, 1.0, 0.0]) if launch_normal is None else np.asarray(launch_normal, np.float64)
            self.blastfx.spawn(self.solid_at, point, n, r, fireball_size=2.0 * fs, cell=self.tcs)
        if fx:
            self.scorch(point[None, :], 1.7 * r, 0.8)
            self.react.blast(point, r, launch_normal)               # the blast lights fuel in reach and throws embers
            self.blast_ring(point, launch_normal, r, power)
        if fx:
            self.blasts += 1
            self.blast_pos = np.array(point, np.float64)
            self.shake = max(self.shake, min(1.0, 0.25 + 0.1 * math.sqrt(max(power, 1.0)) + 0.1 * min(r, 5.0)))     # a bigger blast shakes the screen harder
        if self.debris.dropped and self.debris.dropped!=getattr(self,'_dropped_seen',0):
            self._dropped_seen=self.debris.dropped; self.say('Cube limit (%d) reached: new cubes dropped' % self.debris.MAX, 6.0)
        if fx:
            self.last_blast = max(0, before - self.stats()[0])

    # ---- placeable objects: the oil drum (a plain red cube)
    def drum_base_y(self, x0, z0, size):
        """Height of the tallest thing under the drum's footprint (the floor is 0): the drum rests on that."""
        top = 0.0
        for o in self.E.STRUCTS.structs:
            sh = o.alive.shape
            fp, cs = o.frame_pos, o.cs
            i0, i1 = max(int(math.floor((x0 - fp[0]) / cs)), 0), min(int(math.ceil((x0 + size - fp[0]) / cs)), sh[0])
            k0, k1 = max(int(math.floor((z0 - fp[2]) / cs)), 0), min(int(math.ceil((z0 + size - fp[2]) / cs)), sh[2])
            if i1 <= i0 or k1 <= k0:
                continue
            ys = np.nonzero(o.alive[i0:i1, :, k0:k1].any(axis=(0, 2)))[0]
            if len(ys):
                top = max(top, float(fp[1] + (int(ys[-1]) + 1) * cs))
        return top

    def refresh_drum(self, d):
        """Same rule the engine uses for what a structure stands on: a cell with nothing under it is held up when something solid
        (terrain, the floor, another drum) is just below its bottom face. Blast the ground away and the drum loses its footing.
        A barrel that was thrown and stuck is held by anything solid touching any of its faces (a wall, a ceiling): it lets go only when
        all of that is gone."""
        if getattr(d, 'stuck', False):
            c = d.frame_pos + 0.5 * np.array(d.alive.shape) * d.cs
            half = 0.5 * float(max(d.alive.shape)) * d.cs
            offs = np.array([(a, b, e) for a in (-1, 0, 1) for b in (-1, 0, 1) for e in (-1, 0, 1) if (a, b, e) != (0, 0, 0)], np.float64)
            held = bool(self.solid_at(c + offs * (half + STICK_MARGIN)).any())
            new = d.alive.copy() if held else np.zeros_like(d.anch)
            new &= ~d.unanch
            if not np.array_equal(new, d.anch):
                d.anch = new
                d.detach_dirty = d.stress_dirty = d.dirty_all = True
            return
        below = np.zeros_like(d.alive)
        below[:, 1:, :] = d.alive[:, :-1, :]
        idx = np.argwhere(d.alive & ~below)
        new = np.zeros_like(d.anch)
        if len(idx):
            P = d.frame_pos + (idx + np.array([0.5, 0.0, 0.5])) * d.cs - np.array([0.0, 0.01, 0.0])
            new[idx[:, 0], idx[:, 1], idx[:, 2]] = self.solid_at(P)
        new &= ~d.unanch
        if not np.array_equal(new, d.anch):
            d.anch = new
            d.detach_dirty = d.stress_dirty = d.dirty_all = True

    def _place_box(self, point, material, fireworks=False):
        """Stand a flat-coloured cube (the Objects tab's 'Drum size', in metres: it does not depend on the terrain settings) on the ground at `point`."""
        E = self.E
        n = max(2, int(round(float(self.cfg['dsize']) / 100.0 / DRUM_CELL)))
        size = n * DRUM_CELL
        x0, z0 = float(point[0]) - size / 2, float(point[2]) - size / 2
        y0 = self.drum_base_y(x0, z0, size)
        mat = np.full((n, n, n), material, np.int16)
        tint = np.ones(mat.shape, np.float32)                                  # one flat colour: no per-cell shading, so no visible grid
        st = E.Structure(mat, np.array([x0, y0, z0]), DRUM_CELL, tint=tint)
        st.unanch[:] = False
        st.is_drum = True                                                      # drums and fireworks boxes share the click / bullet / fire / chain handling
        st.fw = fireworks
        self.refresh_drum(st)
        if not st.anch.any():
            self.say('Nothing to stand it on there', 3.0)
            return None
        E.STRUCTS.structs.append(st)
        self.drums.append(st)
        return st

    def place_drum(self, point):
        st = self._place_box(point, self.E.CONCRETE_RED)
        if st is not None:
            self.say('Oil drum placed: click it or shoot it to blow it up', 4.0)
        return st

    # ---- the playable character (the first-person camera in 'play' mode)
    _PL_RING = np.array([[0.0, 0.0]] + [[math.cos(a) * PLAYER_R, math.sin(a) * PLAYER_R] for a in np.linspace(0.0, 2.0 * math.pi, 8, endpoint=False)])
    _PL_HEIGHTS = np.array([0.02, 0.3, 0.6, 0.9, 1.2, 1.5, 1.78])

    def player_hits(self, feet, k=1.0):
        """True when the character's body, standing with its feet at `feet`, is inside the floor or a cube. k scales the whole body
        (1 = the standard 1.7 m eye height), so a camera placed higher or lower makes a taller or smaller character."""
        P = np.empty((len(self._PL_HEIGHTS) * len(self._PL_RING), 3))
        P[:, 0] = np.tile(self._PL_RING[:, 0] * k, len(self._PL_HEIGHTS)) + feet[0]
        P[:, 2] = np.tile(self._PL_RING[:, 1] * k, len(self._PL_HEIGHTS)) + feet[2]
        P[:, 1] = np.repeat(self._PL_HEIGHTS * k, len(self._PL_RING)) + feet[1]
        return bool(self.solid_at(P).any())

    def start_player(self, fp):
        """Turn the camera into a character without moving the camera: its eyes stay exactly where the camera is, and the character's
        height is the camera's height above the ground under it. Raise or lower the camera first to make the character taller or smaller."""
        pos = fp.pos.copy()
        for _ in range(600):                                        # a camera that was dragged inside a cube is lifted out of it first
            if not bool(self.solid_at(pos[None, :])[0]):
                break
            pos[1] += 0.05
        y = float(pos[1])
        while y > 0.0 and not bool(self.solid_at(np.array([[pos[0], y, pos[2]]]))[0]):
            y -= 0.02                                               # walk down to the surface under the camera
        ground = max(0.0, y)
        fp.eye_h = float(max(0.25, pos[1] - ground))
        k = fp.eye_h / PLAYER_EYE
        feet = np.array([pos[0], pos[1] - fp.eye_h, pos[2]])
        feet[1] += 0.02 * k
        fp.eye_h = float(pos[1] - feet[1])
        for _ in range(400):                                        # still overlapping a neighbouring cube: lift the whole character
            if not self.player_hits(feet, k):
                break
            feet[1] += 0.05 * k
        fp.pos = np.array([pos[0], feet[1] + fp.eye_h, pos[2]])
        fp.mode, fp.vy, fp.grounded = 'play', 0.0, False

    def step_player(self, fp, dt, wish, jump=False, run=False):
        """Walk, fall, jump and step up onto cubes. wish: the wanted direction on the ground (x, z), length 0..1."""
        eh = float(getattr(fp, 'eye_h', PLAYER_EYE))
        k = eh / PLAYER_EYE                                         # body scale: a taller camera makes a bigger character (steps scale with it)
        feet = fp.pos - np.array([0.0, eh, 0.0])
        n = max(1, int(math.ceil(dt / (1.0 / 90.0))))
        h = dt / n
        for _ in range(n):
            mv = np.array([wish[0], wish[1]], np.float64) * (PLAYER_RUN if run else PLAYER_SPEED) * h
            for axis, i in ((0, 0), (2, 1)):                        # one axis at a time, so it slides along a wall
                if mv[i] == 0.0:
                    continue
                t = feet.copy(); t[axis] += mv[i]
                if not self.player_hits(t, k):
                    feet = t
                elif fp.grounded:
                    for up in (0.1 * k, 0.2 * k, 0.3 * k, 0.4 * k, PLAYER_STEP * k):      # a low step: walk straight up it
                        t2 = t.copy(); t2[1] += up
                        if not self.player_hits(t2, k):
                            feet = t2
                            break
            fp.grounded = self.player_hits(feet - np.array([0.0, 0.06 * max(k, 0.3), 0.0]), k)
            if fp.grounded and fp.vy <= 0.0:
                fp.vy = 0.0
                if jump:
                    fp.vy, fp.grounded = PLAYER_JUMP * max(0.5, min(2.0, math.sqrt(k))), False
            else:
                fp.vy += PLAYER_GRAV * h
            dy = fp.vy * h
            if dy != 0.0:
                steps = max(1, int(math.ceil(abs(dy) / (0.05 * max(k, 0.3)))))
                for _k in range(steps):
                    t = feet + np.array([0.0, dy / steps, 0.0])
                    if self.player_hits(t, k) or t[1] < 0.0:
                        if fp.vy < 0.0:
                            fp.grounded = True
                        fp.vy = 0.0
                        break
                    feet = t
        feet[1] = max(feet[1], 0.0)
        fp.pos = feet + np.array([0.0, eh, 0.0])

    def place_fpcam(self, point, cam):
        """Put the first-person camera at standing eye height above `point`, looking the way the view currently looks. Placing it again moves it."""
        p = np.asarray(point, np.float64) + np.array([0.0, PLAYER_EYE, 0.0])      # placed at standing eye height; drag the green arrow to change it
        if self.fpcam is None:
            self.fpcam = FirstPersonCamera(p, cam.yaw, 0.12)
        else:
            self.fpcam.pos = p
            self.fpcam.mode = 'spectate'
        return self.fpcam

    def place_fireworks(self, point):
        st = self._place_box(point, self.E.CONCRETE_BLUE, fireworks=True)
        if st is not None:
            self.say('Fireworks placed: click it, shoot it, or burn it', 4.0)
        return st

    def explode_drum(self, d):
        """A drum goes off, centred where it meets the ground, with the Objects tab's settings: its own multiple of the blast power, its own
        radius, and only a share of the drum itself kept as cubes (the rest is incinerated). With 'Chain reaction' on, drums inside the
        blast radius are primed and go off a moment later, the nearer ones first. Fireworks boxes in range always go off (they are fragile)."""
        if getattr(d, 'fw', False):
            return self.explode_fireworks(d)
        c = d.frame_pos + 0.5 * np.array(d.alive.shape) * d.cs
        base = np.array([c[0], d.frame_pos[1], c[2]])             # like a click on the surface under it
        oil_base = base
        up = np.array([0.0, 1.0, 0.0])
        if getattr(d, 'stuck', False):                             # stuck on a wall or ceiling: it goes off where it hangs, pushing away from that surface
            base = np.array(c, np.float64)
            up = np.asarray(getattr(d, 'stick_normal', up), np.float64)
        r = float(self.cfg['jr']) * self.tcs                       # the jerry can's own Blast radius slider
        chain = []
        for x in self.drums:
            if x is not d and x.alive.any() and (int(self.cfg['dchain']) == 1 or getattr(x, 'fw', False)):
                dist = float(np.linalg.norm(x.frame_pos + 0.5 * np.array(x.alive.shape) * x.cs - c))
                if dist < r:
                    chain.append((dist, x))
        for _, x in chain:                                        # primed drums sit this blast out (it would shred them), and go off a moment later
            if x in self.E.STRUCTS.structs:
                self.E.STRUCTS.structs.remove(x)
        self.explode(base, launch_normal=up, power_mult=1.0, drum=d, radius=r)
        for dist, x in chain:
            self.E.STRUCTS.structs.append(x)
            self.chain.append([0.1 + 0.3 * dist / max(r, 1e-6), x])
        self.drums = [x for x in self.drums if x is not d and x.alive.any()]
        if int(self.cfg.get('doil', 1)) == 1:
            self.splatter_oil(oil_base, r)

    def splatter_oil(self, centre, r):
        """The drum was full of oil: burning drops are flung out over the ground around it and each one lands as a puddle that catches fire
        and burns for the Objects tab's 'Oil fire burn time', then dies down."""
        rng = np.random.default_rng()
        k = float(self.cfg.get('dthrow', 100)) / 100.0           # the 'Oil throw range' slider: 100% = the normal reach
        base = max(0.8, 0.9 * float(r))
        reach = base * k
        n = int(min(48, round(16 * max(1.0, k))))                # a longer throw spreads more drops so the ground stays covered
        ang = rng.uniform(0.0, 2.0 * np.pi, n)
        dist = reach * np.sqrt(rng.uniform(0.05, 1.0, n))
        xz = np.stack([centre[0] + np.cos(ang) * dist, centre[2] + np.sin(ang) * dist], axis=1)
        top = float(centre[1]) + 0.6                              # drops fall from just above the drum (not from the top of the blast radius): a wall or cube beside it
        xz = self.clip_to_open(centre, xz, top)                   # stops them at its face, so they run down to the ground there instead of landing up on its side or top
        dist = np.hypot(xz[:, 0] - centre[0], xz[:, 1] - centre[2])
        step = max(0.5 * float(self.tcs), 0.05)
        ys = np.arange(top, -0.2, -step)                          # look down each column for the highest solid sample: the ground after the blast
        P = np.empty((n, len(ys), 3))
        P[:, :, 0], P[:, :, 2], P[:, :, 1] = xz[:, 0:1], xz[:, 1:2], ys[None, :]
        hit = self.solid_at(P.reshape(-1, 3)).reshape(n, len(ys))
        has = hit.any(axis=1)
        first = hit.argmax(axis=1)
        gy = ys[first] + 0.5 * step                               # the surface sits half a sample above the first solid one
        gy[~has] = 0.0
        gy = np.maximum(gy, 0.0)                                  # never below the floor
        ground = np.stack([xz[:, 0], gy, xz[:, 1]], axis=1)
        src = np.array([centre[0], centre[1] + 0.3, centre[2]])
        flight = 0.22 + 0.25 * dist / max(base, 1e-6)            # seconds in the air: nearer drops land first, far ones fly longer
        g = self.blastfx.SPARK_GRAVITY
        dv = ground - src
        vel = np.stack([dv[:, 0] / flight, (dv[:, 1] + 0.5 * g * flight ** 2) / flight, dv[:, 2] / flight], axis=1)
        self.blastfx.add(self.blastfx.SPARK, np.tile(src, (n, 1)), vel, rng.uniform(0.9, 1.4, n) / FX_DETAIL, rng.uniform(0.6, 1.0, n) + flight)
        burn = float(self.cfg.get('dburn', 8)) * rng.uniform(0.7, 1.3, n)
        new = np.column_stack([ground, flight, burn])
        self.oil = np.concatenate([self.oil[self.oil[:, 4] > 0.0], new])[-500:]

    def explode_fireworks(self, d):
        """A fireworks box goes off: a small blast where it stands, and a volley of coloured rockets leaves its top, each bursting into a
        shower of coloured stars a moment later."""
        c = d.frame_pos + 0.5 * np.array(d.alive.shape) * d.cs
        base = np.array([c[0], d.frame_pos[1], c[2]])
        top = np.array([c[0], d.frame_pos[1] + d.alive.shape[1] * d.cs + 0.1, c[2]])
        r = float(self.cfg['xr']) * self.tcs * 0.5
        self.explode(base, launch_normal=np.array([0.0, 1.0, 0.0]), power_mult=1.0, drum=d, radius=r)
        self.drums = [x for x in self.drums if x is not d and x.alive.any()]
        self.launch_rockets(top, FW_ROCKETS)

    def launch_rockets(self, origin, n):
        rng = np.random.default_rng()
        az = rng.uniform(0.0, 2.0 * np.pi, n)
        el = np.radians(rng.uniform(50.0, 88.0, n))                # angle above the horizon: mostly up, some leaning out
        sp = rng.uniform(11.0, 17.0, n)
        vel = np.stack([np.cos(az) * np.cos(el), np.sin(el), np.sin(az) * np.cos(el)], axis=1) * sp[:, None]
        hue = (rng.uniform(0.0, 1.0) + np.arange(n) * 0.618034 + rng.uniform(-0.05, 0.05, n)) % 1.0      # spread round the colour wheel
        new = np.column_stack([np.tile(origin, (n, 1)), vel, rng.uniform(0.55, 1.15, n), hue, np.zeros(n)])
        self.rockets = np.concatenate([self.rockets, new])[-120:]

    def burst_rocket(self, pos, hue):
        """The burst: a flash and a shell of coloured stars thrown out in every direction (a third of them in a second colour)."""
        rng = np.random.default_rng()
        n = FW_STARS
        v = rng.normal(size=(n, 3))
        v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)
        speed = rng.uniform(5.0, 8.5, n)
        h = np.where(rng.random(n) < 0.33, (hue + rng.uniform(0.25, 0.6)) % 1.0, hue)
        fx = self.blastfx
        fx.add(fx.STAR, np.tile(pos, (n, 1)) + v * 0.1, v * speed[:, None], rng.uniform(0.05, 0.09, n), rng.uniform(1.0, 1.7, n), glow=h)
        fx.add(fx.STAR, pos[None, :], np.zeros((1, 3)), 0.5, 0.14, glow=hue)           # the flash

    def update_rockets(self, dt):
        r = self.rockets
        if not len(r):
            return
        rng = np.random.default_rng()
        r[:, 4] -= FW_GRAVITY * dt
        r[:, :3] += r[:, 3:6] * dt
        r[:, 6] -= dt
        r[:, 8] += dt
        fx = self.blastfx
        fx.add(fx.ROCKET, r[:, :3], np.zeros((len(r), 3)), 0.12, max(2.0 * dt, 0.03), glow=r[:, 7])        # the rocket's head
        trail = rng.random(len(r)) < min(1.0, 70.0 * dt)                                                    # a short coloured trail
        if trail.any():
            m_ = int(trail.sum())
            fx.add(fx.STAR, r[trail, :3] + rng.normal(0.0, 0.03, (m_, 3)), rng.normal(0.0, 0.25, (m_, 3)), rng.uniform(0.04, 0.07, m_),
                   rng.uniform(0.3, 0.55, m_), glow=r[trail, 7])
        done = (r[:, 6] <= 0.0) | self.solid_at(r[:, :3])                                                   # the fuse is out, or it hit something
        for row in r[done]:
            self.burst_rocket(row[:3].copy(), float(row[7]))
        self.rockets = r[~done]

    def scorch(self, points, radius, strength):
        """Darken the ground around each point: the top layer or two of every cell within `radius` of it, most at the centre and fading out
        to a ragged edge. The Toggles tab's 'Scorch marks' slider scales it (0 = none). Repeat blasts darken it further."""
        k = float(self.cfg.get('scorch', 100)) / 100.0
        if k <= 0.0:
            return
        rng = np.random.default_rng()
        points = np.asarray(points, np.float64).reshape(-1, 3)
        radius = np.broadcast_to(np.asarray(radius, np.float64), (len(points),))
        for o in self.E.STRUCTS.structs:
            if getattr(o, 'is_drum', False) or not o.alive.any():
                continue
            fp, cs, shape = np.asarray(o.frame_pos, np.float64), o.cs, np.array(o.alive.shape)
            changed = False
            for p, R in zip(points, radius):
                lo = np.maximum(np.floor((p - R - fp) / cs).astype(int), 0)
                hi = np.minimum(np.ceil((p + R - fp) / cs).astype(int) + 1, shape)
                if np.any(hi <= lo):
                    continue
                sl = tuple(slice(int(a), int(b)) for a, b in zip(lo, hi))
                al = o.alive[sl]
                if not al.any():
                    continue
                ny = al.shape[1]
                ys = np.arange(ny)[None, :, None]
                top = np.where(al.any(axis=1), (ny - 1) - np.argmax(al[:, ::-1, :], axis=1), -1)          # highest live cell in each column of the box
                surface = al & (ys >= top[:, None, :] - 1)                                                  # the top two layers
                ix, iy, iz = np.meshgrid(*[(np.arange(int(a), int(b)) + 0.5) * cs + fp[i] for i, (a, b) in enumerate(zip(lo, hi))], indexing='ij')
                d = np.sqrt((ix - p[0]) ** 2 + (iy - p[1]) ** 2 + (iz - p[2]) ** 2)
                wgt = np.clip(1.0 - d / max(float(R), 1e-6), 0.0, 1.0) ** 0.8 * strength * k * rng.uniform(0.6, 1.2, d.shape)
                wgt = np.where(surface, np.clip(wgt, 0.0, 0.92), 0.0)
                if not (wgt > 0.0).any():
                    continue
                t = o.tint[sl]
                o.tint[sl] = np.maximum(t * (1.0 - wgt), np.minimum(t, 0.16)).astype(np.float32)
                changed = True
            if changed:
                o.mesh_ver += 1                                      # the mesh takes its colours from the tints: rebuild it

    def blast_ring(self, point, normal, r, power):
        """A shockwave ring on the bigger blasts (a drum, or a click with a lot of power or radius): a flat ring that races outwards and fades."""
        k = float(self.cfg.get('wave', 100)) / 100.0
        size = float(r) * math.sqrt(max(float(power), 1.0))
        if k <= 0.0 or size < SHOCK_MIN:
            return
        n = np.array([0.0, 1.0, 0.0]) if normal is None else np.asarray(normal, np.float64)
        n = n / max(float(np.linalg.norm(n)), 1e-9)
        ring = np.concatenate([np.asarray(point, np.float64), n, [0.0, 0.55, float(r) * 2.6 * k * min(1.6, size / SHOCK_MIN)]])
        self.rings = np.concatenate([self.rings, ring[None, :]])[-12:]

    def update_rings(self, dt):
        if len(self.rings):
            self.rings[:, 6] += dt
            self.rings = self.rings[self.rings[:, 6] < self.rings[:, 7]]

    def update_oil(self, dt):
        """Each burning puddle sends up small flames while it burns, thinning out over its last moments. A puddle whose ground has been
        blown away goes out."""
        o = self.oil
        if not len(o):
            return
        was = o[:, 3] <= 0.0
        o[:, 3] -= dt
        lit = o[:, 3] <= 0.0
        fresh = lit & ~was
        if fresh.any():
            self.scorch(o[fresh, :3], 0.45, 0.6)                  # a puddle leaves a dark patch where it catches fire
        o[lit, 4] -= dt
        self.oil_t += dt
        if self.oil_t >= 0.25:                                    # the ground under a puddle can be blown away
            self.oil_t = 0.0
            probe = o[:, :3] - np.array([0.0, min(0.08, 0.5 * float(self.tcs)), 0.0])
            gone = ~self.solid_at(probe)
            o[gone & (lit | ~np.isfinite(o[:, 3])), 4] = 0.0     # (an unlit puddle waits with 'seconds until it catches' = infinity)
        live = lit & (o[:, 4] > 0.0)
        if live.any():
            rng = np.random.default_rng()
            fade = np.clip(o[live, 4] / 1.5, 0.15, 1.0)           # thins out as it dies down
            go = rng.random(len(fade)) < np.minimum(1.0, 12.0 * dt * fade)
            if go.any():
                base = o[live][go, :3]
                m_ = len(base)
                pos = base + np.stack([rng.uniform(-0.15, 0.15, m_), rng.uniform(0.05, 0.15, m_), rng.uniform(-0.15, 0.15, m_)], axis=1)
                vel = np.stack([rng.uniform(-0.3, 0.3, m_), rng.uniform(0.4, 1.4, m_), rng.uniform(-0.3, 0.3, m_)], axis=1)
                self.blastfx.add(self.blastfx.FIRE, pos, vel, rng.uniform(0.10, 0.22, m_) * fade[go] ** 0.5, rng.uniform(0.45, 0.85, m_))
            sk = float(self.cfg.get('smoke', 100)) / 100.0
            if sk > 0.0:                                          # smoke rises from every burning puddle
                puff = rng.random(len(fade)) < np.minimum(1.0, 3.0 * sk * dt * (0.4 + 0.6 * fade))
                if puff.any():
                    base = o[live][puff, :3]
                    m_ = len(base)
                    pos = base + np.stack([rng.uniform(-0.15, 0.15, m_), rng.uniform(0.25, 0.4, m_), rng.uniform(-0.15, 0.15, m_)], axis=1)
                    vel = np.stack([rng.uniform(-0.2, 0.2, m_), rng.uniform(0.6, 1.5, m_), rng.uniform(-0.2, 0.2, m_)], axis=1)
                    self.blastfx.add(self.blastfx.SMOKE, pos, vel, rng.uniform(0.15, 0.3, m_), rng.uniform(1.8, 3.2, m_))
        self.oil = o[o[:, 4] > 0.0]

    def update_drum_heat(self, dt):
        """'Fire sets off drums': a drum standing in or beside a burning puddle heats up, and goes off once it has been in the fire for the
        'Cook-off delay'. Out of the fire it cools down at half the speed it heated."""
        if not self.drums:
            return
        on = int(self.cfg.get('dfire', 1)) == 1
        o = self.oil
        live = o[(o[:, 3] <= 0.0) & (o[:, 4] > 0.0)] if (on and len(o)) else o[:0]
        if on and len(self.react.heat_pts):                       # burning timber and the torch cook drums too
            live = np.concatenate([live, self.react.heat_pts])
        need = max(0.5, float(self.cfg.get('dcook', 3)))
        queued = [x for _, x in self.chain]
        for d in list(self.drums):
            if d not in self.drums or not d.alive.any() or d in queued:
                continue
            fp, sh, cs = np.asarray(d.frame_pos, np.float64), np.array(d.alive.shape), d.cs
            exposed = False
            if len(live):
                dx = np.maximum(np.maximum(fp[0] - live[:, 0], live[:, 0] - (fp[0] + sh[0] * cs)), 0.0)
                dz = np.maximum(np.maximum(fp[2] - live[:, 2], live[:, 2] - (fp[2] + sh[2] * cs)), 0.0)
                exposed = bool(((np.hypot(dx, dz) < 0.6) & (np.abs(live[:, 1] - fp[1]) < 0.4)).any())
            h = getattr(d, 'heat', 0.0)
            h = h + dt if exposed else max(0.0, h - 0.5 * dt)
            d.heat = h
            if h > 0.0 and np.random.random() < min(1.0, 10.0 * dt * min(1.0, h / need + 0.2)):     # it flames up as it heats
                top = np.array([fp[0] + sh[0] * cs * np.random.uniform(0.1, 0.9), fp[1] + sh[1] * cs, fp[2] + sh[2] * cs * np.random.uniform(0.1, 0.9)])
                self.blastfx.add(self.blastfx.FIRE, top[None, :], np.array([[0.0, 1.0, 0.0]]), np.random.uniform(0.10, 0.2), np.random.uniform(0.4, 0.7))
            if h >= need:
                d.heat = 0.0
                self.explode_drum(d)

    # ---- the gun
    def fire_gun(self, cam, mx, my, w, h):
        """Fire one bullet at the point under the mouse. It leaves from a muzzle held low and to the right of the camera (not from the camera
        itself: a bullet flying straight away from the eye along its own line of sight is just a stationary dot on the screen, and only
        showed up while the camera was moving, as in the spin mode) and is aimed at the spot you are pointing at."""
        o, d = cam.ray(mx, my, w, h)
        _, _, pt = self.pick(cam, mx, my, w, h)
        target = np.asarray(pt, np.float64) if pt is not None else o + d * (cam.dist * 3.0 + 50.0)
        f, s_, u = cam.basis()
        muzzle = o + s_ * (0.05 * cam.dist) - u * (0.04 * cam.dist)
        aim = target - muzzle
        self.fire_bullet(muzzle, aim / max(float(np.linalg.norm(aim)), 1e-9))

    # ---- the sticky barrel
    def _barrel_hits(self, centre, size):
        """True when a barrel of this size centred here touches the floor or a fixed structure: its centre, its face centres, edges and corners."""
        offs = np.array([(a, b, e) for a in (-1, 0, 1) for b in (-1, 0, 1) for e in (-1, 0, 1)], np.float64)
        return bool(self.solid_at(np.asarray(centre, np.float64) + offs * (0.5 * size)).any())

    def throw_barrel(self, cam, mx, my, w, h):
        """Lob one oil barrel from just in front of the camera so that it arrives at the point under the mouse. It flies an arc (the scene's gravity),
        and sticks to the first thing it touches."""
        n = max(2, int(round(float(self.cfg['dsize']) / 100.0 / DRUM_CELL)))
        size = n * DRUM_CELL
        o, d = cam.ray(mx, my, w, h)
        _, _, pt = self.pick(cam, mx, my, w, h)
        target = np.asarray(pt, np.float64) if pt is not None else o + d * (cam.dist * 3.0 + 50.0)
        f, s_, u = cam.basis()
        muzzle = o + s_ * (0.05 * cam.dist) - u * (0.04 * cam.dist)
        if self._barrel_hits(muzzle, size):
            self.say('Too close to throw: back off a little', 2.5)
            return False
        g = float(self.E.STRUCT_GRAVITY)
        dist = float(np.linalg.norm(target - muzzle))
        T = min(max(dist / THROW_SPEED, THROW_MIN_T), THROW_MAX_T)
        vel = (target - muzzle) / T + np.array([0.0, 0.5 * g * T, 0.0])    # the launch that reaches the target after T seconds
        self.thrown.append([muzzle, vel, size, 0.0])
        return True

    def update_thrown(self, dt):
        """Fly every barrel in small steps (a fraction of its own size, so none slips into a wall). At the first touch it is backed out to
        the last free spot and stuck there."""
        if not self.thrown:
            return
        g = float(self.E.STRUCT_GRAVITY)
        keep = []
        for b in self.thrown:
            pos, vel, size, age = b
            left, stuck_at, n_out = dt, None, None
            while left > 1e-9:
                h = min(left, 0.2 * size / max(float(np.linalg.norm(vel)), 1e-6))
                vel2 = vel - np.array([0.0, g * h, 0.0])
                new = pos + vel2 * h
                if self._barrel_hits(new, size):
                    lo, hi = 0.0, 1.0
                    for _ in range(10):                                    # bisect between the last free spot and the first touching one
                        mid = 0.5 * (lo + hi)
                        if self._barrel_hits(pos + (new - pos) * mid, size):
                            hi = mid
                        else:
                            lo = mid
                    stuck_at = pos + (new - pos) * lo
                    n_out = self._contact_normal(new, size, vel2)
                    break
                pos, vel = new, vel2
                left -= h
            if stuck_at is not None:
                self._stick_barrel(stuck_at, size, n_out)
            elif age + dt < 10.0 and float(np.abs(pos).max()) < 600.0 and pos[1] > -50.0:
                b[0], b[1], b[3] = pos, vel, age + dt
                keep.append(b)
        self.thrown = keep

    def _contact_normal(self, centre, size, vel):
        """Which way the surface faces: away from the sample points of the barrel that are inside something (falls back to against the flight)."""
        offs = np.array([(a, b, e) for a in (-1, 0, 1) for b in (-1, 0, 1) for e in (-1, 0, 1)], np.float64)
        inside = self.solid_at(np.asarray(centre, np.float64) + offs * (0.5 * size))
        m = -offs[inside].sum(axis=0) if inside.any() else np.zeros(3)
        L = float(np.linalg.norm(m))
        if L < 1e-6:
            m = -np.asarray(vel, np.float64); L = float(np.linalg.norm(m))
        return m / max(L, 1e-9)

    def _stick_barrel(self, centre, size, normal):
        """Turn a barrel in flight into a fixed oil drum at this spot. It behaves like any placed drum (click, bullet, fire and chain set it
        off) but is held by whatever it touches, so it stays on a wall or ceiling until that is destroyed."""
        E = self.E
        n = max(2, int(round(size / DRUM_CELL)))
        mat = np.full((n, n, n), E.CONCRETE_RED, np.int16)
        st = E.Structure(mat, np.asarray(centre, np.float64) - 0.5 * size, DRUM_CELL, tint=np.ones(mat.shape, np.float32))
        st.unanch[:] = False
        st.is_drum = True
        st.fw = False
        st.stuck = True
        st.stick_normal = np.asarray(normal, np.float64)
        self.refresh_drum(st)
        if not st.anch.any():
            return None
        E.STRUCTS.structs.append(st)
        self.drums.append(st)
        return st

    def fire_bullet(self, origin, direction):
        d = np.asarray(direction, np.float64) + np.random.normal(0.0, GUN_SPREAD, 3)
        d /= max(float(np.linalg.norm(d)), 1e-9)
        self.bullets.append([np.asarray(origin, np.float64) + d * 0.3, d * GUN_SPEED, 0.0])

    def update_bullets(self, dt):
        """Fly every bullet along its path in small steps (finer than a drum cell, so none slips through). A bullet that reaches a drum
        sets it off; one that reaches anything else (terrain, cubes, the floor) is simply gone and damages nothing."""
        if not self.bullets:
            return
        keep = []
        for b in self.bullets:
            pos, vel, age = b
            speed = float(np.linalg.norm(vel))
            dirn = vel / max(speed, 1e-9)
            dist = speed * dt
            n = max(1, int(math.ceil(dist / 0.03)))
            P = pos + np.outer(np.arange(1, n + 1) * (dist / n), dirn)
            best = None                                                     # (step index, object, outward normal)
            for o in self.E.STRUCTS.objects():
                if not o.alive.any():
                    continue
                sel, _, nrm = o.probe(P)
                if len(sel) and (best is None or int(sel[0]) < best[0]):
                    best = (int(sel[0]), o, nrm[0])
            under = np.nonzero(P[:, 1] < 0.0)[0]
            if len(under) and (best is None or int(under[0]) < best[0]):
                continue                                                    # hit the floor: gone
            if best is not None:
                k, o, nrm = best
                if getattr(o, 'is_drum', False):
                    self.explode_drum(o)                                    # only a drum reacts; a bullet that hits anything else just stops
                continue
            b[0], b[2] = P[-1], age + dt
            if b[2] < 6.0 and float(np.abs(P[-1]).max()) < 600.0:
                keep.append(b)
        self.bullets = keep

    # ---- simulation
    def step(self, dt):
        if self.paused:
            return
        self.shake = max(0.0, self.shake - dt * 1.5)
        self.update_bullets(dt)
        self.update_thrown(dt)
        self.update_oil(dt)
        try:
            self.react.update(dt)
        except Exception:                                       # a fault in the fire system must never take the bench down: report it once and carry on
            if not self._react_err:
                import traceback; traceback.print_exc()
                self._react_err = True
        self.update_rockets(dt)
        self.update_rings(dt)
        self.update_drum_heat(dt)
        if self.chain:
            for c in self.chain:
                c[0] -= dt
            due = [x for t, x in self.chain if t <= 0.0]
            self.chain = [c for c in self.chain if c[0] > 0.0]
            for x in due:
                if x.alive.any() and x in self.E.STRUCTS.structs:
                    self.explode_drum(x)
        if self.drums:                                          # drums re-check their footing a few times a second
            self._drum_t += dt
            if self._drum_t >= 0.2:
                self._drum_t = 0.0
                live = self.E.STRUCTS.structs
                self.drums = [d for d in self.drums if d.alive.any() and d in live]
                for d in self.drums:
                    self.refresh_drum(d)
        self.blastfx.update(self.solid_at, dt)
        E = self.E
        E.STRUCTS.update(None, dt)
        self.debris.advance(dt, max(1, int(self.cfg['wsub'])), E.STRUCTS.objects())
        self.debris.states.tick(dt)
        self.tick_tools(dt)

    # ---- test tools: drop weight, ram, add debris (Weapons tab)
    def _ground_point(self, cam, mx, my, w, h):
        """The point under the mouse: the first solid hit, else where the ray meets the floor (y = 0), else None."""
        o, d, pt = self.pick(cam, mx, my, w, h)
        if pt is not None:
            return np.asarray(pt, np.float64)
        if d[1] < -1e-6 and o[1] > 0.0:
            return np.asarray(o + d * (-o[1] / d[1]), np.float64)
        return None

    def clip_to_open(self, origin, xz, y):
        """Pull each target (x, z) back along the straight line from `origin` until the air at height y is clear, so spilled oil
        never lands inside a wall. A target with a wall in the way ends at the wall's face."""
        origin = np.asarray(origin, np.float64)
        xz = np.asarray(xz, np.float64).reshape(-1, 2)
        t = np.linspace(0.1, 1.0, 10)
        P = np.empty((len(xz), len(t), 3))
        P[:, :, 0] = origin[0] + (xz[:, 0:1] - origin[0]) * t[None, :]
        P[:, :, 2] = origin[2] + (xz[:, 1:2] - origin[2]) * t[None, :]
        P[:, :, 1] = y
        hit = self.solid_at(P.reshape(-1, 3)).reshape(len(xz), len(t))
        first = np.where(hit.any(axis=1), hit.argmax(axis=1), len(t))
        k = np.where(first >= len(t), 1.0, np.where(first == 0, 0.0, t[np.maximum(first - 1, 0)]))
        return np.stack([origin[0] + (xz[:, 0] - origin[0]) * k, origin[2] + (xz[:, 1] - origin[2]) * k], axis=1)

    def ground_below(self, xz, top, depth=3.0):
        """Height of the highest solid under each (x, z), looking down from `top` (the floor is 0). Spilled oil uses it to lie on the ground."""
        xz = np.asarray(xz, np.float64).reshape(-1, 2)
        step = max(0.5 * float(self.tcs), 0.05)
        ys = np.arange(top, min(top - depth, -step), -step)
        n = len(xz)
        P = np.empty((n, len(ys), 3))
        P[:, :, 0], P[:, :, 2], P[:, :, 1] = xz[:, 0:1], xz[:, 1:2], ys[None, :]
        hit = self.solid_at(P.reshape(-1, 3)).reshape(n, len(ys))
        has, first = hit.any(axis=1), hit.argmax(axis=1)
        gy = ys[first] + 0.5 * step
        gy[~has] = 0.0
        return np.maximum(gy, 0.0)

    def use_flame_tool(self, kind, cam, mx, my, w, h):
        """The Torch and Pour oil tools (Weapons tab): one use at the point under the mouse."""
        pt = self._ground_point(cam, mx, my, w, h)
        if pt is None:
            return False
        if kind == 'torch':
            self.react.torch(pt, self.pick_obj)
        else:
            self.react.pour(pt)
        return True

    def use_tool(self, kind, cam, mx, my, w, h):
        pt = self._ground_point(cam, mx, my, w, h)
        if pt is None:
            return False
        if kind == 'drop':
            return self.drop_weight(pt) is not None
        if kind == 'ram':
            return self.fire_ram(pt, cam) is not None
        return self.add_debris(pt) > 0

    def _tool_body(self, dims, cs, mass, centre):
        """A solid steel box of dims = (cells x, y, z) of size cs, whose TOTAL mass is set directly: mass and size are separate controls.
        It is flagged is_tool (not counted as a structure body, never made into debris by the body cap)."""
        E = self.E
        mat = np.full(tuple(int(n) for n in dims), E.STEEL, np.int16)
        body = E.RigidBody(mat, np.zeros(mat.shape, np.float32), np.ones(mat.shape, np.float32), cs, np.array(mat.shape, np.float64) * cs * 0.5)
        body.cell_mass = np.where(body.alive, float(mass) / max(1, int(body.alive.sum())), 0.0)
        body._mass_props()
        body.frame_pos = np.asarray(centre, np.float64).copy()
        body.v = np.zeros(3)
        body.w = np.zeros(3)
        body.grace = 0.0
        body.is_tool = True
        return body

    def _add_tool_body(self, body):
        S = self.E.STRUCTS
        body.wake()
        S.bodies.append(body)
        S._cap_bodies(None)

    # drop weight
    def drop_weight(self, pt, spec=None):
        """Release a steel cube from rest, `height` metres above the point `pt` (to the weight's underside), square to the world axes with no spin.
        spec (a dict from last_drop) repeats an earlier drop exactly; otherwise the sliders decide. Mass, size and height are independent."""
        c = self.cfg
        spec = dict(spec) if spec else dict(pt=np.asarray(pt, np.float64), side=float(c['dws']) / 100.0, mass=dw_mass(c['dwm']),
                                           height=float(c['dwh']), breakable=bool(int(c['dwk'])))
        side, pt = spec['side'], np.asarray(spec['pt'], np.float64)
        n = max(3, min(12, int(round(side / 0.1))))
        cs = side / n
        centre = pt + np.array([0.0, spec['height'] + 0.5 * side, 0.0])
        body = self._tool_body((n, n, n), cs, spec['mass'], centre)
        body.unbreakable = not spec['breakable']                  # unbreakable at first: only the target breaks, so the results are easy to read
        body.is_weight = True
        S = self.E.STRUCTS
        while len(self.weights) >= MAX_WEIGHTS:                   # keep the newest few so earlier drops stay visible for comparison
            old = self.weights.pop(0)
            if old in S.bodies:
                S.bodies.remove(old)
        self.weights.append(body)
        self._add_tool_body(body)
        self.last_drop = spec
        cells, _, loose = self.stats()
        self.drop_log = dict(body=body, spec=spec, pre=0.0, hit=None, t=0.0, cells0=cells, broken=0, loose=loose, fell=0.0, done=False, vmax=0.0)
        return body

    def repeat_drop(self):
        if self.last_drop is None:
            return None
        return self.drop_weight(None, spec=self.last_drop)

    # ram
    def fire_ram(self, pt, cam):
        """Place a ram (a steel block on a motor) facing the point `pt` and start it. It pushes along a horizontal line: straight into the wall face
        when you click a wall, or away from the camera (snapped to an axis) when you click a top surface. Speed control advances at the set speed
        but never pushes harder than the force limit; force control pushes with the force limit until the speed cap. A stalled ram just holds."""
        c = self.cfg
        width = float(c['rmw']) / 100.0
        length = RAM_LENGTH
        nside = max(2, min(10, int(round(width / 0.1))))
        cs = width / nside
        nx = max(2, int(round(length / cs)))
        n = np.asarray(self.face_normal(pt), np.float64)
        if abs(n[1]) > 0.5:                                       # a top surface: push away from the camera along the nearest horizontal axis
            f_, _, _ = cam.basis()
            f_ = np.array([f_[0], 0.0, f_[2]])
            a = 0 if abs(f_[0]) >= abs(f_[2]) else 2
            axis = np.zeros(3); axis[a] = 1.0 if f_[a] >= 0 else -1.0
        else:
            axis = -n
        axis = axis / max(float(np.linalg.norm(axis)), 1e-9)
        total = nx * cs
        gap = RAM_GAP
        y = max(float(pt[1]), 0.5 * width + 0.12)
        centre = np.array([pt[0], y, pt[2]]) - axis * (gap + 0.5 * total)
        centre[1] = y
        body = self._tool_body((nx, nside, nside), cs, ram_mass(c['rmk']), centre)
        ang = math.atan2(-axis[2], axis[0])                        # turn the block's long (local x) axis onto the push direction
        body.q = np.array([math.cos(0.5 * ang), 0.0, math.sin(0.5 * ang), 0.0])
        body._sync()
        body.is_ram = True
        body.unbreakable = True                                    # the ram is a tool, not a target: only what it pushes on breaks
        body.gscale = 0.0
        body.ram_axis, body.ram_p0, body.ram_q0 = axis, centre.copy(), body.q.copy()
        body.ram_mode, body.ram_speed = int(c['rmm']), float(c['rmv'])
        body.ram_force, body.ram_stroke = ram_force(c['rmf']), float(c['rms'])
        body.ram_push, body.ram_state, body.ram_stall_t, body.ram_face = 0.0, 'advancing', 0.0, width
        body.drive = ram_drive
        S = self.E.STRUCTS
        if self.ram is not None and self.ram in S.bodies:
            S.bodies.remove(self.ram)
        self.ram = body
        self._add_tool_body(body)
        return body

    # add debris
    def add_debris(self, pt):
        """Drop N loose debris cubes in a column above `pt` (a jittered lattice so they do not start inside each other), to find how many the
        GPU debris can hold. Uses the Debris cube size slider; stops at the buffer limit (or recycles the oldest when 'Keep debris' is off)."""
        d = self.debris
        n = int(ADD_COUNTS[int(self.cfg['adn']) % len(ADD_COUNTS)])
        size = float(self.cs)
        sp = size * 1.12
        radius = max(float(self.cfg['adr']), 3 * sp)
        k = int(math.ceil(radius / sp))
        g = np.arange(-k, k + 1) * sp
        gx, gz = np.meshgrid(g, g)
        inside = (gx * gx + gz * gz) <= radius * radius
        gx, gz = gx[inside], gz[inside]
        per = len(gx)
        layers = int(math.ceil(n / per))
        while layers * sp > 60.0 and per < n:                      # a column taller than 60 m: widen it instead
            radius *= 1.25
            k = int(math.ceil(radius / sp))
            g = np.arange(-k, k + 1) * sp
            gx, gz = np.meshgrid(g, g)
            inside = (gx * gx + gz * gz) <= radius * radius
            gx, gz = gx[inside], gz[inside]
            per = len(gx)
            layers = int(math.ceil(n / per))
        X = np.tile(gx, layers)[:n]
        Z = np.tile(gz, layers)[:n]
        Y = np.repeat(np.arange(layers), per)[:n] * sp
        rng = np.random.default_rng()
        jit = rng.uniform(-0.06, 0.06, (n, 2)) * size
        P = np.stack([pt[0] + X + jit[:, 0], pt[1] + float(self.cfg['adh']) + Y, pt[2] + Z + jit[:, 1]], axis=1)
        shade = rng.uniform(0.35, 0.8, (n, 1))
        rgb = (shade * np.array([1.0, 0.78, 0.55])).astype(np.float32)
        before = d.n
        saved = d._blast_events
        d._blast_events = []                                       # new cubes must not inherit the wave of a blast that just went off
        try:
            d.spawn_chunks(P, np.zeros(3), size, rgb)
        finally:
            d._blast_events = saved
        return max(0, d.n - before) if not d.recycle else n

    def tick_tools(self, dt):
        """Per-step bookkeeping for the test tools (cheap; the heavier counts refresh a few times a second)."""
        S = self.E.STRUCTS
        self.weights = [b for b in self.weights if b in S.bodies]
        if self.ram is not None and self.ram not in S.bodies:
            self.ram = None
        L = self.drop_log
        if L is not None and not L['done']:
            b = L['body']
            if b not in S.bodies:
                L['done'] = True
            else:
                L['t'] += dt
                sp = float(np.linalg.norm(b.v))
                L['vmax'] = max(L['vmax'], sp)
                if L['hit'] is None:
                    if getattr(b, '_touching', False):
                        L['hit'] = L['pre']                        # the speed one step before it first touched anything
                    else:
                        L['pre'] = sp
        self._tool_t += dt
        if self._tool_t >= 0.25 and (L is not None or self.ram is not None):
            self._tool_t = 0.0
            self._tool_stats = self.stats()
            if L is not None:
                L['broken'] = max(0, L['cells0'] - self._tool_stats[0])
                L['loose'] = self._tool_stats[2]

    def tool_readout(self):
        """Lines (text, rgb) for the small readout shown while a test tool is selected."""
        INK, DIM, HOT = (233, 235, 238), (174, 177, 181), (255, 167, 70)
        out = []
        if self.weapon == 'drop':
            c = self.cfg
            side, mass = float(c['dws']) / 100.0, dw_mass(c['dwm'])
            steel = 7.8 * side ** 3
            out.append(('DROP WEIGHT   click: drop it above the point   R: reset the scene', INK))
            out.append(('Next: mass %.0f   size %.2f m   height %.1f m   (solid steel this size = %.0f)   %s' % (
                mass, side, float(c['dwh']), steel, 'breakable' if int(c['dwk']) else 'unbreakable'), DIM))
            L = self.drop_log
            if L is None:
                out.append(('No drop yet.', DIM))
            else:
                sp = L['spec']
                out.append(('Last: mass %.0f  size %.2f m  from %.1f m   fell for %.2f s' % (sp['mass'], sp['side'], sp['height'], L['t']), INK))
                out.append(('Speed before contact: %s    peak speed %.1f m/s' % (('%.1f m/s' % L['hit']) if L['hit'] is not None else 'not touched yet', L['vmax']), HOT))
                out.append(('Cells released from the target: %d    loose pieces: %d' % (L['broken'], L['loose']), HOT))
        elif self.weapon == 'ram':
            c = self.cfg
            out.append(('RAM   click a wall to push it (or a top surface: pushes away from you)', INK))
            out.append(('Next: %s   %s   force limit %.0f   stroke %.1f m   mass %.0f   face %.2f m' % (
                'force control' if int(c['rmm']) else 'speed control', 'cap %.1f m/s' % float(c['rmv']), ram_force(c['rmf']), float(c['rms']), ram_mass(c['rmk']), float(c['rmw']) / 100.0), DIM))
            r = self.ram
            if r is None:
                out.append(('No ram placed.', DIM))
            else:
                travelled = float(np.dot(r.frame_pos - r.ram_p0, r.ram_axis))
                out.append(('Ram: %s    travelled %.2f / %.1f m    speed %.2f m/s' % (r.ram_state.upper(), travelled, r.ram_stroke, float(np.dot(r.v, r.ram_axis))), HOT))
                out.append(('Push %.0f of %.0f limit (%d%%)' % (r.ram_push, r.ram_force, int(round(100.0 * r.ram_push / max(r.ram_force, 1e-9)))), HOT))
        elif self.weapon in ('torch', 'pour'):
            s = self.react.stat
            out.append(('TORCH   click or hold: set the point alight (oil, timber, drums)' if self.weapon == 'torch' else
                        'POUR OIL   click or hold: spill oil, then light it (Torch, ember, blast, burning neighbour)', INK))
            out.append(('Oil puddles: %d unlit, %d burning      Timber cells alight: %d      burnt away: %d      embers: %d' % (
                s['unlit'], s['lit'], s['burning'], self.react.gone, s['embers']), HOT))
            out.append(('Material (E key) must be Timber for the wood to burn; Q picks a wall, pillar or cube to burn.', DIM))
        elif self.weapon == 'debris':
            d = self.debris
            n, cap = d.n, d.cap
            awake, asleep = int(d._awake), int(d.sleep_count()) if n else 0
            fps = 1000.0 / max(self.frame_ms, 0.01)
            out.append(('ADD DEBRIS   click: add %s cubes%s   C / Clear debris: remove them' % (format(int(ADD_COUNTS[int(self.cfg['adn']) % len(ADD_COUNTS)]), ','),
                                                                                       ' (hold to keep adding)' if int(self.cfg['adk']) else ''), INK))
            out.append(('Cubes: %s / %s   awake %s   asleep %s   not added (buffer full): %s' % (format(n, ','), format(cap, ','), format(awake, ','), format(asleep, ','), format(int(d.dropped), ',')), HOT))
            out.append(('Frame %.1f ms (%.0f fps)   simulation speed %d%%   cube size %d cm' % (self.frame_ms, fps, int(self.sim_speed), int(self.cfg['brick'])), INK))
            b = self.debris_best
            out.append(('Most cubes alive while the frame rate held:   60 fps: %s    30 fps: %s    (buffer limit %s%s)' % (
                format(b.get(60, 0), ','), format(b.get(30, 0), ','), format(d.MAX, ','), '; Keep debris OFF recycles at %s' % format(d.BASE_CAP, ',') if d.recycle else ''), DIM))
        return out

    def note_frame(self, dt_real):
        """Called every frame with the real frame time: keeps a smoothed frame time and the most cubes seen while 60 / 30 fps held."""
        self.frame_ms += (1000.0 * dt_real - self.frame_ms) * 0.08
        n = self.debris.n
        if n:
            for target, limit in ((60, 1000.0 / 57.0), (30, 1000.0 / 28.5)):
                if self.frame_ms <= limit and n > self.debris_best.get(target, 0):
                    self.debris_best[target] = n

    def tool_lines(self):
        d = self.debris
        return ['Blasts: %d   last: %d bricks' % (self.blasts, self.last_blast),
                'Radius %.1f m   power x%d' % (float(self.cfg['xr']) * self.tcs, int(self.cfg['xp'])),
                'Substeps %d  fastest %s  bound %.0f m/s' % (d.last_steps, ('%.0f' % d._max_launch) if d._measured_ok else '?', d.last_bound)]

    def stats(self):
        E = self.E
        cells = bonds = bodies = 0
        for o in E.STRUCTS.structs:
            cells += int(o.alive.sum()); bonds += sum(int(b.sum()) for b in o.bond)
        for o in E.STRUCTS.bodies:
            if getattr(o, 'unbreakable', False) or getattr(o, 'is_tool', False):
                continue
            cells += int(o.alive.sum()); bonds += sum(int(b.sum()) for b in o.bond); bodies += 1
        return cells, bonds, bodies


# ------------------------------------------------------------------------------------------------ camera
class Camera:
    def __init__(self):
        self.yaw, self.pitch, self.dist = 0.55, 0.28, 14.0
        self.max_dist = 300.0
        self.target = np.array([0.0, 2.0, 0.0])
        self.fovy = math.radians(50.0)

    def frame(self, size):
        self.target = np.array([0.0, size[1] * 0.4, 0.0])
        self.dist = max(6.0, float(max(size[0], size[1] * 1.6)) * 1.15)
        self.max_dist = max(300.0, self.dist * 6.0)              # a giant cube can be zoomed out much further

    def eye(self):
        cp = math.cos(self.pitch)
        return self.target + self.dist * np.array([cp * math.sin(self.yaw), math.sin(self.pitch), cp * math.cos(self.yaw)])

    def basis(self):
        f = self.target - self.eye(); f /= np.linalg.norm(f)
        s = np.cross(f, [0.0, 1.0, 0.0]); s /= np.linalg.norm(s)
        u = np.cross(s, f)
        return f, s, u

    def apply(self, w, h):
        far = max(600.0, self.max_dist * 3.0)
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity()
        near = max(0.1, self.dist * 0.002)
        top = near * math.tan(self.fovy / 2); right = top * w / max(h, 1)
        gl.glFrustum(-right, right, -top, top, near, far)
        gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()
        f, s, u = self.basis()
        M = np.array([[*s, 0], [*u, 0], [*-f, 0], [0, 0, 0, 1.0]])
        gl.glMultMatrixd(M.T.flatten())
        e = self.eye()
        gl.glTranslated(-e[0], -e[1], -e[2])

    def zoom_at(self, mx, my, w, h, steps, anchor=None):
        """Dolly/scale around the point under the cursor in either camera mode.
        Keeping the eye and target at the same scale about the anchor preserves
        its screen position, rather than pulling the view toward screen centre.
        """
        if not steps:
            return
        old = self.dist
        new = min(self.max_dist, max(1.5, old * 0.9 ** max(-100.0, min(100.0, float(steps)))))
        if new == old:
            return
        if anchor is None:
            origin, direction = self.ray(mx, my, w, h)
            forward, _, _ = self.basis()
            denom = float(direction @ forward)
            distance = float((self.target - origin) @ forward) / denom if abs(denom) > 1e-9 else 0.0
            anchor = origin + direction * distance
        ratio = new / old
        anchor = np.asarray(anchor, np.float64)
        self.target = anchor + (self.target - anchor) * ratio
        self.dist = new

    def ray(self, mx, my, w, h):
        f, s, u = self.basis()
        x, y = 2.0 * mx / w - 1.0, 1.0 - 2.0 * my / h
        top = math.tan(self.fovy / 2); right = top * w / max(h, 1)
        d = f + s * (x * right) + u * (y * top)
        return self.eye(), d / np.linalg.norm(d)

    def project(self, p, w, h):
        """Where a world point lands on screen: (x, y, depth), or None when it is behind the camera."""
        f, s, u = self.basis()
        q = np.asarray(p, np.float64) - self.eye()
        z = float(q @ f)
        if z <= 1e-4:
            return None
        top = math.tan(self.fovy / 2); right = top * w / max(h, 1)
        return (0.5 + 0.5 * float(q @ s) / (z * right)) * w, (0.5 - 0.5 * float(q @ u) / (z * top)) * h, z


class FirstPersonCamera(Camera):
    """The first-person camera: an object placed in the scene (drawn with its XYZ arrows) that is also a view you can look through.
    yaw / pitch use the orbit camera's convention, so right-drag looks around the same way."""

    def __init__(self, pos, yaw, pitch):
        self.pos = np.array(pos, np.float64)
        self.yaw, self.pitch = yaw, pitch
        self.dist = 7.0                                          # only sets the walking speed (dist * 0.9 m/s) and the near plane
        self.max_dist = 300.0
        self.fovy = math.radians(70.0)
        self.mode = 'spectate'                                   # 'spectate' (a free camera) or 'play' (a character that walks on the cubes)
        self.vy, self.grounded = 0.0, False
        self.eye_h = PLAYER_EYE                                  # as a character: eye height above the feet (set from the camera's height when you press Play)

    def fwd(self):
        cp = math.cos(self.pitch)
        return -np.array([cp * math.sin(self.yaw), math.sin(self.pitch), cp * math.cos(self.yaw)])

    def eye(self):
        return self.pos

    @property
    def target(self):                                            # the walking / panning code moves `target`: for this camera that moves the camera itself
        return self.pos + self.fwd()

    @target.setter
    def target(self, v):
        self.pos = np.asarray(v, np.float64) - self.fwd()

    def basis(self):
        f = self.fwd()
        s = np.cross(f, [0.0, 1.0, 0.0]); s /= np.linalg.norm(s)
        return f, s, np.cross(s, f)

    def frame(self, size):
        pass

    def zoom_at(self, *args, **kwargs):
        pass


GIZ_AXES = (np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0]))
GIZ_COLS = ((0.95, 0.25, 0.22), (0.35, 0.85, 0.30), (0.30, 0.52, 1.0))      # X red, Y green, Z blue


def giz_len(cam, fp):
    """Arrow length: grows with distance so the arrows keep about the same size on screen."""
    return max(0.45, float(np.linalg.norm(fp.pos - cam.eye())) * 0.16)


def fpcam_hit(cam, fp, mx, my, w, h):
    """What the mouse is on: 'body' (the camera), 0 / 1 / 2 (the X / Y / Z arrow), or None."""
    p0 = cam.project(fp.pos, w, h)
    if p0 is None:
        return None
    m = np.array([mx, my], np.float64)
    c0 = np.array(p0[:2])
    top = math.tan(cam.fovy / 2)
    body_px = max(16.0, 0.30 * h / (2.0 * p0[2] * top))              # the camera box is about 0.6 m across
    if float(np.linalg.norm(m - c0)) < body_px:
        return 'body'
    L = giz_len(cam, fp)
    best, best_d = None, 10.0
    for i, a in enumerate(GIZ_AXES):
        p1 = cam.project(fp.pos + a * L, w, h)
        if p1 is None:
            continue
        seg = np.array(p1[:2]) - c0
        n2 = float(seg @ seg)
        if n2 < 1.0:
            continue
        t = float((m - c0) @ seg) / n2
        if t < 0.0 or t > 1.08:
            continue
        d = float(np.linalg.norm(m - (c0 + seg * t)))
        if d < best_d:
            best, best_d = i, d
    return best


def giz_axis_param(cam, origin, axis, mx, my, w, h):
    """Where along the line (origin + t * axis) the mouse ray passes closest. None when the ray is parallel to the axis."""
    o, d = cam.ray(mx, my, w, h)
    r = o - origin
    B = float(d @ axis)
    den = 1.0 - B * B
    if den < 1e-4:
        return None
    return (float(axis @ r) - float(d @ r) * B) / den




# ------------------------------------------------------------------------------------------------ interface
def bond_text(v):
    v = int(v)
    if v <= 0:
        return 'off (no blast breaking)'
    if v >= 100:
        return 'unbreakable (blast)'
    return '%d  %s' % (v, 'weak glue' if v < 25 else 'mortar' if v < 60 else 'strong mortar' if v < 90 else 'very strong')


SLIDERS = [
    dict(key='bond', label='Bond strength', lo=0, hi=100, step=1, fmt=bond_text, rebuild=False),
    dict(key='str', label='Self-weight strength (x)', lo=1, hi=20, step=1, fmt=lambda v: 'x%d' % v, rebuild=False),
    dict(key='grav', label='Gravity', lo=25, hi=400, step=5, fmt=lambda v: '%d%%  (%.1f m/s2)' % (v, 24.0 * v / 100.0), rebuild=False),
    dict(key='tumble', label='Debris looseness', lo=0, hi=400, step=10, fmt=lambda v: '%d%%' % v, rebuild=False),
    dict(key='keep', label='Delete cubes', lo=0, hi=1, step=1, fmt=lambda v: 'ON (old + excess cubes deleted)' if v == 0 else 'OFF (1 cube per brick, kept)', rebuild=False),
    dict(header='SUBSTEPS  (more = steadier, slower)'),            # a heading row, not a slider
    dict(key='wsub', label='Debris cubes', lo=1, hi=24, step=1, fmt=lambda v: '%d' % v, rebuild=False),
    dict(key='sub', label='Loose bodies', lo=1, hi=24, step=1, fmt=lambda v: '%d' % v, rebuild=False),
    dict(header='EXPLOSION'),
    dict(key='xr', label='Explosion radius (bricks)', lo=1, hi=40, step=1, fmt=lambda v: '%d' % v, rebuild=False),
    dict(key='xp', label='Explosion strength', lo=1, hi=100, step=1, fmt=lambda v: 'x%d' % v, rebuild=False),
    dict(key='xs', label='Debris spread (0 tight .. 100 wide)', lo=0, hi=100, step=5, fmt=lambda v: '%d%%' % v, rebuild=False),
    dict(key='xq', label='Squeeze amount (0 loose .. 100 packed)', lo=0, hi=100, step=5, fmt=lambda v: '%d%%' % v, rebuild=False),
    dict(key='xh', label='Squeeze hold (ms)', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d ms' % v, rebuild=False),
    dict(key='xk', label='Pop strength', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, rebuild=False),
    dict(key='xv', label='Explosion: cube speed', lo=0, hi=400, step=10, fmt=lambda v: '%d%%' % v, rebuild=False),
]
PANEL_W, ROW_H, PANEL_X, PANEL_Y = 340, 34, 10, 10
HEAD = 70                                                  # panel space above the sliders: title, tool and view buttons
PANEL_EXTRA = 192                                          # panel height below the sliders (stats, tool counters, note)


def visible(bench):
    """The sliders listed in the panel."""
    return SLIDERS


# NOTE: THE SETTINGS PANEL (the left-hand panel of sliders, the View button and the stats text) IS NOT IN USE.
# The settings are finished and their defaults live in Bench.cfg, so the panel is hidden and ignores the mouse.
# All of its code (SLIDERS, render_panel, slider hit-testing) is kept as it was; set SETTINGS_PANEL_IN_USE = True to bring it back.
# The right-hand GPU activity graphs still show with Tab.
SETTINGS_PANEL_IN_USE = False


def panel_h(bench):
    return HEAD + len(visible(bench)) * ROW_H + PANEL_EXTRA



GRAPH_W, MENU_GAP = 360, 12


class ComputeMonitor:
    """15 seconds of process CPU and device GPU activity, sampled without blocking frames.
    CPU uses process time (one busy core = 100%). nvidia-smi GPU utilization
    includes graphics and compute; it is not a compute-only or per-process metric.
    """
    WINDOW = 15.0
    INTERVAL = 0.25

    def __init__(self, E):
        self.history = deque(maxlen=128)
        self.last_wall = time.perf_counter()
        self.last_cpu = time.process_time()
        self.cpu_cores = 0.0
        self.frame_times = deque(maxlen=60)
        self.frame_ms = None
        self.gpu = E.GpuPoller(interval=0.5)

    def record_frame(self, seconds):
        if math.isfinite(seconds) and seconds > 0:
            self.frame_times.append(float(seconds))
            self.frame_ms = 1000.0 * sum(self.frame_times) / len(self.frame_times)

    def tick(self):
        now = time.perf_counter()
        elapsed = now - self.last_wall
        if elapsed < self.INTERVAL:
            return
        cpu = time.process_time()
        self.cpu_cores = max(0.0, (cpu - self.last_cpu) / elapsed)
        self.last_wall, self.last_cpu = now, cpu
        stats = self.gpu.stats
        util = None if stats is None else stats.get('util')
        if util is not None and not math.isfinite(util):
            util = None
        util = None if util is None else min(100.0, max(0.0, util))
        self.history.append((now, self.cpu_cores, util))
        while self.history and self.history[0][0] < now - self.WINDOW:
            self.history.popleft()

    def reset(self):
        self.history.clear()
        self.last_wall = time.perf_counter()
        self.last_cpu = time.process_time()
        self.cpu_cores = 0.0
        self.frame_times.clear()
        self.frame_ms = None

    def stop(self):
        self.gpu.stop()


def menu_scale(bench, win):
    """Both columns fit above the help bar, including on short/resized windows."""
    w, h = win
    return max(0.01, min(1.0, (w - 2 * PANEL_X) / (PANEL_W + MENU_GAP + GRAPH_W),
                         (h - PANEL_Y - 94) / max(panel_h(bench), 545)))



def graph_screen_rect(bench, win):
    """Compact diagnostics card, independently sized at the top right."""
    scale=min(1.0,max(0.01,(win[0]-20)/300.0),max(0.01,(win[1]-20)/285.0))
    width,height=max(1,round(300*scale)),max(1,round(285*scale))
    return pygame.Rect(max(0,win[0]-10-width),10,width,height)


def menu_position(bench, pos, win):
    scale = menu_scale(bench, win)
    return (PANEL_X + (pos[0] - PANEL_X) / scale,
            PANEL_Y + (pos[1] - PANEL_Y) / scale)


def render_compute(monitor, fonts, debris=None, bench=None):
    """Compact live values and real 15-second CPU/GPU sparklines."""
    width, height = 300, 285
    s = pygame.Surface((width, height), pygame.SRCALPHA)
    pygame.draw.rect(s, (34, 36, 38, 248), s.get_rect(), border_radius=8)
    pygame.draw.rect(s, (105, 108, 111), s.get_rect(), 1, border_radius=8)
    font = pygame.font.SysFont('segoeui,arial,dejavusans',16)
    bold = pygame.font.SysFont('segoeui,arial,dejavusans',17,bold=True)
    text, muted, accent = (233,235,238), (192,195,198), (255,137,24)
    s.blit(bold.render('LIVE DIAGNOSTICS',True,text),(18,12))
    pygame.draw.line(s,(89,92,95),(18,39),(width-18,39))
    frame_ms = getattr(monitor,'frame_ms',None)
    if debris is None:
        awake = asleep = None
    else:
        asleep = int(debris.sleep_count())  # throttled GPU counters, includes current awake count
        live = max(0,debris.n-getattr(debris.states,'dead_count',0))
        asleep = min(live,max(0,asleep))
        awake = min(live-asleep,max(0,int(debris._awake)))
    simulation = 'N/A' if bench is None else ('Paused' if bench.paused else '%d%%'%bench.sim_speed)
    rows = [('Frame time','N/A' if frame_ms is None else '%.1f ms'%frame_ms),
            ('Awake cubes','N/A' if awake is None else format(awake,',')),
            ('Sleeping cubes','N/A' if asleep is None else format(asleep,',')),
            ('Simulation',simulation)]
    for i,(label,value) in enumerate(rows):
        y=51+i*25
        s.blit(font.render(label,True,text),(18,y))
        img=font.render(value,True,muted);s.blit(img,(width-18-img.get_width(),y))
    pygame.draw.line(s,(89,92,95),(18,158),(width-18,158))
    now=time.perf_counter()
    samples=[v for v in monitor.history if now-monitor.WINDOW <= v[0] <= now]
    cpu_max=max(1.,float(math.ceil(max((v[1] for v in samples if math.isfinite(v[1])),default=0.))))
    for label,column,y,ceiling in [('CPU',1,177,cpu_max),('GPU',2,227,100.)]:
        s.blit(font.render(label,True,text),(18,y+1))
        chart=pygame.Rect(69,y,213,33)
        runs=[]; points=[]
        for sample in samples:
            value=sample[column]
            if value is None or not math.isfinite(value):
                if points:runs.append(points);points=[]
                continue
            x=chart.x+round((sample[0]-(now-monitor.WINDOW))/monitor.WINDOW*(chart.w-1))
            py=chart.bottom-3-round(max(0.,min(1.,value/ceiling))*(chart.h-6))
            points.append((max(chart.left,min(chart.right-1,x)),py))
        if points:runs.append(points)
        if not runs:
            img=font.render('N/A',True,(135,139,143));s.blit(img,(chart.centerx-img.get_width()//2,chart.y+4))
        for points in runs:
            if len(points)>1:
                pygame.draw.polygon(s,(72,48,28),[(points[0][0],chart.bottom),*points,(points[-1][0],chart.bottom)])
                pygame.draw.lines(s,accent,False,points,2)
            else:pygame.draw.circle(s,accent,points[0],2)
    return s


class Overlay:
    """A pygame surface drawn over the 3D view as one textured quad."""

    def __init__(self):
        self.tex = int(gl.glGenTextures(1))

    def draw(self, surf, x, y, win):
        w, h = surf.get_size()
        data = pygame.image.tostring(surf, 'RGBA', True)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self.tex)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA, w, h, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, data)
        gl.glBegin(gl.GL_QUADS)
        for u, v, px, py in ((0, 0, x, y + h), (1, 0, x + w, y + h), (1, 1, x + w, y), (0, 1, x, y)):
            gl.glTexCoord2f(u, v); gl.glVertex2f(px, py)
        gl.glEnd()


MAP_SLIDERS = [
    dict(key='material', label='Material (E)', lo=0, hi=len(BENCH_MATERIALS)-1, step=1, fmt=lambda v: BENCH_MATERIALS[int(v)][0], rebuild=True),                                            # the Toggles tab: the map (terrain) settings only
    dict(key='anchor', label='Anchor terrain', lo=0, hi=1, step=1, fmt=lambda v: 'ON (fixed to the floor)' if v == 1 else 'OFF (free body)', rebuild=True),
    dict(key='bond', label='Bond strength', lo=0, hi=100, step=1, fmt=bond_text),
    dict(key='tcm', label='Cube detail', lo=5, hi=100, step=5, fmt=lambda v: '%d cm' % v, rebuild=True, short=True),
    dict(key='chunks', label='Chunks', lo=1, hi=5, step=1, fmt=lambda v: '%dx%d = %d chunks' % (v, v, v * v), rebuild=True, short=True),
]
EXPLODE_SLIDERS = [                                        # the Weapons tab, with Explode selected: how the explosion behaves
    dict(key='brick', label='Debris cube size', lo=5, hi=100, step=5, fmt=lambda v: '%d cm' % v),
    dict(key='xp', label='Blast power', lo=1, hi=100, step=1, fmt=lambda v: 'x%d' % v),
    dict(key='xs', label='Debris', lo=0, hi=100, step=5, fmt=lambda v: ('tight' if v <= 15 else 'wide' if v >= 70 else 'medium') + '  %d%%' % v),
    dict(key='xq', label='Squeeze', lo=0, hi=100, step=5, fmt=lambda v: ('loose' if v < 40 else 'packed' if v > 60 else 'normal') + '  %d%%' % v),
    dict(key='xh', label='Squeeze hold', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d ms' % v),
    dict(key='xk', label='Pop strength', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v),
    dict(key='xd', label='Debris amount (rest is incinerated)', lo=0, hi=100, step=5, fmt=lambda v: 'none' if v == 0 else '%d%%' % v),
    dict(key='xf', label='Fireball size', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v),
]
SYSTEM_SLIDERS = [                                         # the Toggles tab, under the map settings: the whole program, not one weapon or object
    dict(key='shake', label='Screenshake', lo=0, hi=200, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, section='SYSTEM', short=True),
    dict(key='res', label='Resolution', lo=25, hi=200, step=5, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='grav', label='Gravity', lo=25, hi=400, step=5, fmt=lambda v: '%d%% (%d m/s2)' % (v, round(24.0 * v / 100.0)), short=True),
    dict(key='speed', label='Simulation speed', lo=5, hi=200, step=5, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='sharp', label='Sharpness', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='cull', label='Back-face culling', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='textures', label='Material textures', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='texdepth', label='Texture depth (bumps and grooves)', lo=0, hi=300, step=10, fmt=lambda v: 'flat' if v == 0 else '%d%%' % v, short=True),
    dict(key='bloom', label='Bloom (100% = game glow; blasts only)', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='bloomall', label='Bloom always on', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='rt', label='Ray-traced lighting', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='rtsh', label='RT shadows', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='rtsoft', label='RT shadow softness', lo=0, hi=100, step=5, fmt=lambda v: 'hard' if v == 0 else '%d%%' % v, short=True),
    dict(key='rtao', label='RT ambient occlusion', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='rtgi', label='RT bounce light', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='rtrf', label='RT reflections (all materials)', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='rtn', label='RT rays per pixel (noise vs cost)', lo=1, hi=16, step=1, fmt=lambda v: '%d' % v, short=True),
    dict(key='rtdn', label='RT denoise (blur + still-frame average)', lo=0, hi=100, step=5, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='smoke', label='Oil smoke', lo=0, hi=300, step=25, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='scorch', label='Scorch marks', lo=0, hi=200, step=25, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='wave', label='Shockwave ring', lo=0, hi=200, step=25, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='spin', label='Camera spin', lo=-30, hi=30, step=1, fmt=lambda v: 'off' if v == 0 else '%+d deg/s (- = reverse)' % v, section='CAMERA', short=True),
    dict(key='spinfocus', label='Re-centre on blast', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
]
DRUM_SLIDERS = [                                           # the Objects tab: the oil drum's settings
    dict(key='dsize', label='Drum size (new drums)', lo=20, hi=120, step=5, fmt=lambda v: '%d cm' % v),
    dict(key='jr', label='Jerry can: blast radius (cells)', lo=1, hi=40, step=1, fmt=lambda v: '%d' % v),
    dict(key='jp', label='Jerry can: blast power', lo=1, hi=100, step=1, fmt=lambda v: 'x%d' % v),
    dict(key='js', label='Jerry can: debris spread', lo=0, hi=100, step=5, fmt=lambda v: ('tight' if v <= 15 else 'wide' if v >= 70 else 'medium') + '  %d%%' % v),
    dict(key='jv', label='Jerry can: launch speed', lo=0, hi=400, step=10, fmt=lambda v: '%d%%' % v),
    dict(key='jd', label='Jerry can: debris amount (rest is incinerated)', lo=0, hi=100, step=5, fmt=lambda v: 'none' if v == 0 else '%d%%' % v),
    dict(key='jf', label='Jerry can: fireball size', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v),
    dict(key='dchain', label='Blast chain reaction', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='doil', label='Oil splatter fires', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='dfire', label='Fire sets off drums', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='dcook', label='Cook-off delay', lo=1, hi=10, step=1, fmt=lambda v: '%d s' % v, short=True),
    dict(key='dthrow', label='Oil throw range', lo=25, hi=500, step=25, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='dburn', label='Oil fire burn time', lo=2, hi=30, step=1, fmt=lambda v: '%d s' % v, short=True),
]
FIRE_SLIDERS = [                                           # Objects tab (world behaviour) and the Torch / Pour oil weapons: fire, embers and spilled oil
    dict(key='fspread', label='Fire spread speed', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='tburn', label='Timber burn time', lo=2, hi=40, step=1, fmt=lambda v: '%d s' % v, short=True),
    dict(key='fember', label='Ember rate (burning timber and oil)', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='fblast', label='Blast embers', lo=0, hi=300, step=10, fmt=lambda v: 'off' if v == 0 else '%d%%' % v, short=True),
    dict(key='ospread', label='Burning oil lights its neighbours', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='opour', label='Oil poured per click', lo=1, hi=40, step=1, fmt=lambda v: '%d puddles' % v, short=True),
    dict(key='torchr', label='Torch flame size', lo=5, hi=60, step=5, fmt=lambda v: '%d cm' % v, short=True),
]
RT_MAT_SLIDERS = []                                        # Settings > MATERIAL SHINE: how reflective each material is under ray tracing
for _n, _lab in (('DIRT', 'Dirt'), ('STEEL', 'Steel'), ('BRICK', 'Brick'), ('GLASS', 'Glass'), ('PLANKS', 'Timber')):
    RT_MAT_SLIDERS.append(dict(key='rs_' + _n, label=_lab + ': reflectivity', lo=0, hi=100, step=5, fmt=lambda v: 'matte' if v == 0 else '%d%%' % v, short=True))
    RT_MAT_SLIDERS.append(dict(key='rr_' + _n, label=_lab + ': roughness (blurry reflection)', lo=0, hi=100, step=5, fmt=lambda v: 'mirror' if v == 0 else '%d%%' % v, short=True))
SETTINGS_SLIDERS = [
    dict(key='rec_res', label='Resolution (video height)', lo=0, hi=6, step=1, fmt=lambda v: '%dp' % REC_RES[int(v) % len(REC_RES)], short=True),       # the Record tab
    dict(key='rec_fps', label='Frame rate', lo=0, hi=4, step=1, fmt=lambda v: '%d fps' % REC_FPS[int(v) % len(REC_FPS)], short=True),                                        # the Settings tab: how the mouse, the camera and the on-screen text behave
    dict(key='looksens', label='Mouse look sensitivity', lo=20, hi=300, step=10, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='invy', label='Invert mouse look (up / down)', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='fov', label='Camera view field of view', lo=50, hi=110, step=5, fmt=lambda v: '%d°' % v, short=True),
    dict(key='camspd', label='Camera move speed (W A S D)', lo=25, hi=300, step=5, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='fpscap', label='FPS limit', lo=30, hi=250, step=10, fmt=lambda v: 'unlimited' if v >= 250 else '%d fps' % v, short=True),
    dict(key='vsync', label='VSync (applies next launch)', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF', short=True),
    dict(key='bright', label='Brightness', lo=50, hi=150, step=5, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='contrast', label='Contrast', lo=50, hi=150, step=5, fmt=lambda v: '%d%%' % v, short=True),
    dict(key='gamma', label='Gamma', lo=50, hi=200, step=5, fmt=lambda v: '%.2f' % (v / 100.0), short=True),
    dict(key='toolbar', label='Material and shape buttons (top)', lo=0, hi=1, step=1, fmt=lambda v: 'SHOWN' if v == 1 else 'HIDDEN', short=True),
    dict(key='crosshair', label='Crosshair (character view)', lo=0, hi=1, step=1, fmt=lambda v: 'SHOWN' if v == 1 else 'HIDDEN', short=True),
]
# (TOOL_SLIDERS is defined below, after the tool helpers it formats with)
BP_W, BP_ROW, BP_TOP, BP_MARGIN = 340, 58, 30, 10          # width (the same on every tab), row height (room for a 2-line label above each slider), top, margin
DRUM_CELL = 0.05                                           # the oil drum's own fixed cell size (a 60 cm drum is 12 x 12 x 12 cells), independent of the terrain / debris cube sliders
OBJ_ITEMS = (dict(key='fireworks', name='Fireworks', rgb=(133, 41, 184)),
             dict(key='camera', name='First person camera', hint='drag into the scene', rgb=(70, 140, 220)))    # what the Objects tab offers
ADD_COUNTS = (100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000)     # the Add debris tool's 'cubes per click' steps
TOOL_SLIDERS = [                                           # the Weapons tab, with Drop weight / Ram / Add debris selected
    dict(key='dwm', label='Weight mass (independent of size)', lo=0, hi=28, step=1, fmt=lambda v: '%.0f' % dw_mass(v)),
    dict(key='dws', label='Weight size (cube side)', lo=10, hi=300, step=5, fmt=lambda v: '%.2f m' % (v / 100.0)),
    dict(key='dwh', label='Drop height above the point', lo=0, hi=80, step=1, fmt=lambda v: '%d m' % v),
    dict(key='dwk', label='Weight can break (off = unbreakable)', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF'),
    dict(key='rmm', label='Force control (off = speed control)', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF'),
    dict(key='rmv', label='Ram speed (cap in force control)', lo=1, hi=40, step=1, fmt=lambda v: '%d m/s' % v),
    dict(key='rmf', label='Ram force limit', lo=0, hi=30, step=1, fmt=lambda v: '%.0f' % ram_force(v)),
    dict(key='rms', label='Ram stroke', lo=1, hi=40, step=1, fmt=lambda v: '%d m' % v),
    dict(key='rmk', label='Ram mass', lo=0, hi=20, step=1, fmt=lambda v: '%.0f' % ram_mass(v)),
    dict(key='rmw', label='Ram face width (plate = wide, tip = narrow)', lo=10, hi=300, step=10, fmt=lambda v: '%.2f m' % (v / 100.0)),
    dict(key='adn', label='Cubes added per click', lo=0, hi=len(ADD_COUNTS) - 1, step=1, fmt=lambda v: format(ADD_COUNTS[int(v)], ',')),
    dict(key='adr', label='Column radius (widens if too tall)', lo=1, hi=30, step=1, fmt=lambda v: '%d m' % v),
    dict(key='adh', label='Drop height above the point', lo=0, hi=60, step=1, fmt=lambda v: '%d m' % v),
    dict(key='adk', label='Hold the mouse to keep adding', lo=0, hi=1, step=1, fmt=lambda v: 'ON' if v == 1 else 'OFF'),
]
BLAST_SLIDERS = MAP_SLIDERS + SYSTEM_SLIDERS + EXPLODE_SLIDERS + DRUM_SLIDERS + FIRE_SLIDERS + SETTINGS_SLIDERS + RT_MAT_SLIDERS + TOOL_SLIDERS

MAX_WEIGHTS = 3                                            # drop weights kept at once (the oldest goes when a new one is dropped)
RAM_LENGTH, RAM_GAP = 1.5, 0.4                             # the ram block's length (m) and how far its face starts from the target (m)


def dw_mass(k): return 5.0 * 1.3 ** float(k)               # drop weight mass from its slider: 5 ... about 6,000
def ram_mass(k): return 20.0 * 1.35 ** float(k)            # ram mass from its slider: 20 ... about 8,000
def ram_force(k): return 500.0 * 1.5 ** float(k)           # ram force limit from its slider: 500 ... about 1e8 (a brick cell holds about 1,500 x its bond-strength factor)


def ram_drive(b, h, phase):
    """The ram's motor, called by RigidBody.step every sub-step. It can only change the ram's speed along its axis, by at most force x h / mass
    per sub-step, so against an immovable wall it presses with at most the force limit (it stalls); the wall's resistance goes through the
    normal contact solver, so the real velocity and the real contact force are what the target and the loose debris feel."""
    ax = b.ram_axis
    rel = b.frame_pos - b.ram_p0
    if phase == 'post':
        along = min(float(np.dot(rel, ax)), b.ram_stroke)          # the end of the stroke is a hard stop, whatever the motor's force
        b.frame_pos = b.ram_p0 + ax * along                       # held on its line, square to it: contact pushes cannot swing or lift it
        b.q = b.ram_q0.copy()
        b._sync()
        b.w[:] = 0.0
        return
    vax = float(np.dot(b.v, ax))
    travelled = float(np.dot(rel, ax))
    cap = b.ram_force * h * b.invm                              # the most the motor can change the ram's speed in one sub-step
    if travelled >= b.ram_stroke:
        dv = -vax                                               # end of stroke: a hard stop (the ram holds there)
        state = 'at end of stroke'
    elif b.ram_mode == 0:
        dv = min(cap, max(-cap, b.ram_speed - vax))             # speed control: reach the set speed, within the force limit
        state = 'advancing'
    else:
        dv = min(cap, max(0.0, b.ram_speed - vax))              # force control: push with the force limit until the speed cap
        state = 'advancing'
    b.v = ax * (vax + dv)                                       # sideways and vertical speed are locked out
    b.ram_push = max(0.0, dv * b.mass / h) if travelled < b.ram_stroke else 0.0
    if state == 'advancing':
        want = b.ram_speed if b.ram_mode == 0 else 0.25 * b.ram_speed
        b.ram_stall_t = b.ram_stall_t + h if vax < 0.1 * want else 0.0
        if b.ram_stall_t > 0.15:
            state = 'stalled at force limit' if b.ram_push >= 0.9 * b.ram_force else 'blocked'
    b.ram_state = state
WEAPON_ITEMS = (dict(key='explode', name='Explode', hint='blast on click', rgb=(255, 150, 60)),
                dict(key='gun', name='Gun', hint='hold to shoot', rgb=(150, 158, 176)),
                dict(key='throw', name='Jerry can', hint='click to throw', rgb=(184, 31, 26)),
                dict(key='drop', name='Drop weight', hint='click to drop', rgb=(120, 128, 146)),
                dict(key='ram', name='Ram', hint='click a wall to push', rgb=(205, 120, 60)),
                dict(key='debris', name='Add debris', hint='click / hold to add cubes', rgb=(190, 160, 90)),
                dict(key='torch', name='Torch', hint='click / hold: set alight (fire, embers)', rgb=(255, 163, 73)),
                dict(key='pour', name='Pour oil', hint='click / hold: spill oil (spreads fire)', rgb=(170, 145, 72)))     # what the Weapons tab offers (the first is the default)
SHOCK_MIN = 1.8                                            # a blast gets a shockwave ring when its radius x sqrt(power) reaches this many metres
FW_ROCKETS = 14                                            # rockets per fireworks box
FW_STARS = 48                                              # stars in each rocket's burst
FW_GRAVITY = 9.0                                           # how fast a rocket slows on the way up, m/s2
EXPORT_ITEMS = (dict(key='export', name='Export settings', hint='save to a file', rgb=(110, 190, 140)),)     # what the Export tab offers
GUN_SPEED = 90.0                                           # bullet speed, m/s
GUN_PERIOD = 0.08                                          # seconds between shots while the mouse is held
GUN_SPREAD = 0.003                                         # random aim error, radians
THROW_SPEED = 26.0                                         # how fast a thrown barrel travels on average, m/s (it flies an arc that lands where you clicked)
THROW_MAX_T, THROW_MIN_T = 2.5, 0.25                       # longest and shortest flight, seconds (far throws are capped, so they fall short)
STICK_MARGIN = 0.03                                        # a stuck barrel counts as held while solid ground or wall is within this many metres of it
BP_ITEM_H, BP_ITEM_GAP = 48, 8


# Shared menu layout: drawing and hit tests consume the same rectangles.
BP_ORDER = (0, 5, 1, 2, 3, 4, 8, 6, 7)  # preserve existing tab IDs for scene/inspection code (6 is the Controls tab, 8 the Record tab); three tabs to a row
BP_LABELS = {0:'World', 5:'Physics', 1:'Cube state', 2:'Objects', 3:'Weapons', 4:'Export', 6:'Controls', 7:'Settings', 8:'Record'}
CONTROLS = (                                              # the Controls tab: every keyboard and mouse control, by section (keep in step with the key handlers)
    ('MOUSE (normal view)', (('Left click', 'use the selected weapon / tool at the point under the mouse (hold for Gun, Torch, Pour oil, Add debris)'),
                             ('Right-drag', 'orbit the camera'), ('Middle-drag', 'pan the camera'), ('Wheel', 'zoom at the cursor'),
                             ('Ctrl + click', 'select a cube to inspect it (Cube state tab)'),
                             ('Top buttons', 'click a material or a shape to rebuild with it (the same as E and Q; Settings can hide them)'))),
    ('KEYBOARD', (('W A S D', 'move the camera forward / left / back / right (hold Shift for 3x speed)'),
                  ('Tab', 'show / hide this menu'), ('Space', 'pause / resume the physics'), ('R', 'reset the scene (and the graphs)'),
                  ('C', 'clear loose debris'), ('E', 'change the material: dirt, steel, brick, glass, timber'),
                  ('Q', 'next shape: flat terrain, cube, pillar, wall'), ('G', 'show / hide the CPU / GPU diagnostics graph'),
                  ('Backspace', 'deselect the inspected cube'), ('Esc', 'close the camera menu, or quit'))),
    ('CAMERA OBJECT (Objects tab)', (('Drag arrows', 'move the placed camera along X, Y or Z'), ('Click camera', 'look through it'),
                                    ('V', 'look through the camera / back to the normal view'), ('Delete', 'remove the camera'),
                                    ('Right-click', 'in the camera view: menu (Play as character, Back to spectate, Record mode: opens the menu\'s Record tab, Delete camera)'))),
    ('PLAYING AS THE CHARACTER', (('Mouse', 'look around (the cursor is hidden; the crosshair is where tools aim)'),
                                 ('W A S D', 'walk (Shift to run)'), ('Space', 'jump'), ('Left click', 'use the selected weapon at the crosshair'),
                                 ('Tab', 'show the menu and free the cursor'), ('V', 'close the camera view'))),
)
BP_ACCENT = (255, 137, 24)
BP_TEXT = (233, 235, 238)
BP_MUTED = (174, 177, 181)
BP_TOP = 162                                              # (three rows of tabs now)
BP_W = 340


def bp_spec(key, label=None, kind=None):
    sources = BLAST_SLIDERS + [s for s in SLIDERS if 'key' in s]
    sl = dict(next(s for s in sources if s['key'] == key))
    sl.pop('section', None)
    if label: sl['label'] = label
    sl['kind'] = kind or ('toggle' if sl['lo'] == 0 and sl['hi'] == 1 else 'slider')
    if key == 'tcm':
        sl['reverse'] = True
        sl['fmt'] = lambda v: '%d%%' % round((100.0-v)*100.0/95.0)
    if key == 'grav': sl['fmt'] = lambda v: '%.1f m/s²' % (24.0*v/100.0)
    if key == 'str': sl['fmt'] = lambda v: '%.1f×' % v
    if key == 'bond': sl['fmt'] = bond_text
    return sl


def bp_groups(bench):
    if bench.blast_tab == 8:                                   # Record: the video's size and speed (Start and Stop are drawn under these)
        return [('VIDEO',1,[bp_spec('rec_res'),bp_spec('rec_fps')])]
    if bench.blast_tab == 7:                                   # Settings: how the program shows and runs (nothing here changes the physics)
        return [('GRAPHICS',1,[bp_spec(k) for k in ('res','sharp','cull','textures','texdepth','shake','bright','contrast','gamma')]),
                ('BLOOM',1,[bp_spec('bloom'),bp_spec('bloomall')]),
                ('RAY TRACING',1,[bp_spec(k) for k in ('rt','rtsh','rtsoft','rtao','rtgi','rtrf','rtn','rtdn')]),
                ('MATERIAL SHINE (needs RT reflections)',1,[bp_spec(sl['key']) for sl in RT_MAT_SLIDERS]),
                ('PERFORMANCE',1,[bp_spec('fpscap'),bp_spec('vsync')]),
                ('MOUSE & CAMERA',1,[bp_spec(k) for k in ('looksens','invy','fov','camspd','spin','spinfocus')]),
                ('ON SCREEN',1,[bp_spec('toolbar'),bp_spec('crosshair'),dict(key='_states',label='Show cube states',kind='toggle',lo=0,hi=1,step=1,fmt=str)])]
    if bench.blast_tab == 5:
        return [('SIMULATION',0,[bp_spec('grav'),bp_spec('speed'),bp_spec('wsub','Debris substeps','stepper'),bp_spec('sub','Chunk substeps','stepper')]),
                ('MATERIAL',0,[bp_spec('bond'),bp_spec('str','Self-weight strength'),bp_spec('tumble','Debris looseness')]),
                ('DEBRIS',1,[bp_spec('brick','Cube size'),bp_spec('keep','Keep debris'),bp_spec('xd','Debris amount')]),
                ('SUPPORT',1,[bp_spec('anchor')])]
    if bench.blast_tab == 0:                                   # World: the scene itself (display, camera and ray tracing are in Settings)
        return [('TERRAIN',0,[bp_spec('material'),bp_spec('tcm'),bp_spec('chunks')]),
                ('BLAST EFFECTS',1,[bp_spec(k) for k in ('smoke','scorch','wave')])]
    if bench.blast_tab == 2:
        return [('OIL & FIRE',1,[bp_spec(k) for k in ('dsize','dchain','doil','dfire','dcook','dthrow','dburn')]),
                ('FIRE & EMBERS',1,[bp_spec(k) for k in ('fspread','tburn','fember','fblast','ospread')])]
    if bench.blast_tab == 3 and bench.weapon == 'explode':
        return [('EXPLOSION',1,[bp_spec('xr','Blast radius (cells)'),bp_spec('xp'),bp_spec('xs','Debris spread'),bp_spec('xv','Launch speed'),bp_spec('xd','Debris amount'),bp_spec('xf')]),
                ('COMPRESSION',0,[bp_spec('xq'),bp_spec('xh'),bp_spec('xk')])]
    if bench.blast_tab == 3 and bench.weapon == 'drop':
        return [('DROP WEIGHT',1,[bp_spec('dwm'),bp_spec('dws'),bp_spec('dwh'),bp_spec('dwk')])]
    if bench.blast_tab == 3 and bench.weapon == 'ram':
        return [('RAM',1,[bp_spec('rmm'),bp_spec('rmv'),bp_spec('rmf'),bp_spec('rms'),bp_spec('rmk'),bp_spec('rmw')])]
    if bench.blast_tab == 3 and bench.weapon == 'debris':
        return [('ADD DEBRIS',1,[bp_spec('adn'),bp_spec('adr'),bp_spec('adh'),bp_spec('adk'),bp_spec('brick','Debris cube size')])]
    if bench.blast_tab == 3 and bench.weapon == 'torch':
        return [('TORCH',1,[bp_spec('torchr')]),
                ('FIRE & EMBERS',1,[bp_spec(k) for k in ('fspread','tburn','fember','fblast')])]
    if bench.blast_tab == 3 and bench.weapon == 'pour':
        return [('POUR OIL',1,[bp_spec('opour'),bp_spec('ospread'),bp_spec('dburn','Oil fire burn time')])]
    if bench.blast_tab == 3 and bench.weapon == 'throw':
        return [('EXPLOSION',1,[bp_spec('jr','Blast radius (cells)'),bp_spec('jp','Blast power'),bp_spec('js','Debris spread'),bp_spec('jv','Launch speed'),bp_spec('jd','Debris amount'),bp_spec('jf','Fireball size')])]
    return []


def bp_layout(bench, width):
    cw=width-36
    ys=[BP_TOP,BP_TOP]
    if bench.blast_tab in (2,3,4):
        count=len(OBJ_ITEMS if bench.blast_tab==2 else WEAPON_ITEMS if bench.blast_tab==3 else EXPORT_ITEMS)
        ys[0] += 40 + count*(BP_ITEM_H+BP_ITEM_GAP) + 66 + (44 if bench.blast_tab==2 else 0)      # (the Objects tab's longer hint needs room)
    cards=[]; controls=[]
    for title,col,specs in bp_groups(bench):
        col=0
        x=18; y=ys[0]; top=y+34
        for sl in specs:
            rh=36 if sl['kind'] in ('toggle','stepper') else 48
            controls.append((sl,pygame.Rect(x+14,top,cw-28,rh)))
            top+=rh
        cards.append((title,pygame.Rect(x,y,cw,top-y+10)))
        ys[col]=top+24
    height=max(ys)
    if bench.blast_tab==1:
        detail=bench.debris.states.lines() or []
        wrapped=sum(max(1,len(wrap_text(bp_fonts()[0],t,width-64))) for t,c in detail)
        height=BP_TOP+40+(len(STATE_NAMES)-1)*26+72+max(3,wrapped)*20
    if bench.blast_tab==4:
        height=max(height,BP_TOP+260+len(bench.settings_snapshot()['settings'])*22)
    if bench.blast_tab==8:
        height=max(height,rec_tab_rects(width)['card'].bottom+24)
    if bench.blast_tab==6:
        f_=bp_fonts()[0]; h_=BP_TOP
        for title_,rows_ in CONTROLS:
            h_+=34+sum(max(1,len(wrap_text(f_,act_,width-36-28-92)))*18+6 for _k,act_ in rows_)+26
        height=h_
    return cards,controls,height


def rec_tab_rects(width):
    """The Record tab's second card and its Start / Stop buttons, in the tab's own (content) coordinates."""
    cw=width-36; y=BP_TOP+34+96+24
    bw=(cw-28-10)//2
    return dict(card=pygame.Rect(18,y,cw,176),start=pygame.Rect(32,y+42,bw,40),stop=pygame.Rect(32+bw+10,y+42,bw,40))


def bp_fonts():
    if not hasattr(bp_fonts,'cache'):
        bp_fonts.cache=(pygame.font.SysFont('segoeui,arial,dejavusans',14),pygame.font.SysFont('segoeui,arial,dejavusans',14,bold=True),pygame.font.SysFont('segoeui,arial,dejavusans',19,bold=True))
    return bp_fonts.cache


def bp_sliders(bench):
    return [sl for title,col,specs in bp_groups(bench) for sl in specs], BP_TOP




def bp_rect(bench, win, menu_open):
    return pygame.Rect(10,10,min(BP_W,max(1,win[0]-20)),max(180,min(560,win[1]-20)))


def bp_scroll_max(bench,r): return max(0,bp_layout(bench,r.w)[2]-(r.h-72))


def bp_scroll_clamp(bench,r):
    bench.bp_scroll=max(0,min(int(getattr(bench,'bp_scroll',0)),bp_scroll_max(bench,r)))
    return bench.bp_scroll


def bp_content_rect(bench,r): return r.move(0,-bp_scroll_clamp(bench,r))


def bp_tab_rect(r,i):
    order=BP_ORDER.index(i); width=(r.w-36)/3                    # three tabs to a row (nine tabs: 3 + 3 + 3)
    return pygame.Rect(r.x+18+round((order%3)*width),r.y+61+(order//3)*30,round(width),30)


def bp_tab_hit(r,pos):
    return next((i for i in BP_ORDER if bp_tab_rect(r,i).collidepoint(pos)),None)


def bp_footer_rect(r,i):
    width=(r.w-54)//3
    return pygame.Rect(r.x+18+i*(width+9),r.bottom-54,width,38)


def bp_item_rect(r,i):
    return pygame.Rect(r.x+32,r.y+BP_TOP+38+i*(BP_ITEM_H+BP_ITEM_GAP),r.w-64,BP_ITEM_H)


def bp_item_hit(r,pos,items=OBJ_ITEMS):
    return next((i for i in range(len(items)) if bp_item_rect(r,i).collidepoint(pos)),None)


def bp_slider_rect(r,i,sliders,y0=BP_TOP):
    # Attached row geometry is refreshed by bp_hit/render and the main drag handler.
    row=sliders[i].get('_rect',pygame.Rect(32,BP_TOP,r.w//2-50,62))
    return pygame.Rect(r.x+row.x,r.y+row.y+31,row.w,12)


def bp_bind_rows(bench,width):
    return [dict(sl,_rect=row) for sl,row in bp_layout(bench,width)[1]]


def bp_hit(r,pos,sliders,y0=BP_TOP):
    return next((i for i,sl in enumerate(sliders) if sl['kind']=='slider' and bp_slider_rect(r,i,sliders).inflate(0,6).collidepoint(pos)),None)


def bp_control_click(bench,r,pos):
    viewport=pygame.Rect(r.x+10,r.y+BP_TOP,r.w-20,max(0,r.h-BP_TOP-72))
    if not viewport.collidepoint(pos): return False
    cr=bp_content_rect(bench,r)
    for sl,row in bp_layout(bench,r.w)[1]:
        if sl['kind']=='slider' or not row.move(cr.topleft).collidepoint(pos): continue
        key=sl['key']
        if key=='_states': bench.show_cube_states=not getattr(bench,'show_cube_states',False)
        elif sl['kind']=='toggle': bench.cfg[key]=1-int(bench.cfg[key])
        else:
            step=sl['step'] if pos[1] < cr.y+row.centery else -sl['step']
            bench.cfg[key]=max(sl['lo'],min(sl['hi'],bench.cfg[key]+step))
        if key!='_states':
            bench.apply_live()
            if sl.get('rebuild'): bench.build()
        return True
    return False


def bp_value(bench,sl):
    if sl['key']=='_states': return int(getattr(bench,'show_cube_states',False))
    return bench.cfg[sl['key']]


def bp_card(s,rect,title,fonts):
    pygame.draw.rect(s,(34,36,38),rect,border_radius=7)
    pygame.draw.rect(s,(66,68,70),rect,1,border_radius=7)
    band=pygame.Rect(rect.x+1,rect.y+1,rect.w-2,29)
    pygame.draw.rect(s,(49,51,53),band,border_radius=6)
    s.blit(fonts[1].render(title,True,BP_TEXT),(rect.x+12,rect.y+5))


def render_blast_panel(bench,fonts,r,drag):
    fonts=bp_fonts(); font,bold,title=fonts
    scroll=bp_scroll_clamp(bench,r)
    cards,rows,total=bp_layout(bench,r.w)
    content=pygame.Surface((r.w,max(total+10,r.h)),pygame.SRCALPHA)
    for label,rect in cards: bp_card(content,rect,label,fonts)
    for i,(sl,row) in enumerate(rows):
        val=bp_value(bench,sl); label=sl['label']
        if sl['kind']=='toggle':
            content.blit(font.render(label,True,BP_TEXT),(row.x,row.y+10))
            toggle=pygame.Rect(row.right-44,row.y+9,44,23)
            pygame.draw.rect(content,BP_ACCENT if val else (91,93,95),toggle,border_radius=12)
            pygame.draw.circle(content,(248,248,248),(toggle.right-12 if val else toggle.left+12,toggle.centery),9)
        elif sl['kind']=='stepper':
            content.blit(font.render(label,True,BP_TEXT),(row.x,row.y+9))
            box=pygame.Rect(row.right-66,row.y+5,66,29)
            pygame.draw.rect(content,(45,47,49),box,border_radius=5);pygame.draw.rect(content,(99,101,103),box,1,border_radius=5)
            content.blit(font.render(str(val),True,BP_TEXT),(box.x+18,box.y+4))
            x=box.right-11;y=box.y+9
            pygame.draw.polygon(content,BP_TEXT,[(x-4,y+2),(x+4,y+2),(x,y-3)])
            pygame.draw.polygon(content,BP_TEXT,[(x-4,y+9),(x+4,y+9),(x,y+14)])
        else:
            value=sl['fmt'](val)
            if sl['key']=='bond': value='Off' if val==0 else 'Attack-proof' if val==100 else '%d%%'%val
            # Keep labels and values separate, wrapping long labels above the track.
            value_img=font.render(value,True,BP_TEXT)
            available=max(45,row.w-value_img.get_width()-10)
            lines=wrap_text(font,label,available)
            for j,line in enumerate(lines[:2]): content.blit(font.render(line,True,BP_TEXT),(row.x,row.y+j*17))
            content.blit(value_img,(row.right-value_img.get_width(),row.y))
            track=pygame.Rect(row.x,row.y+35,row.w,5)
            t=max(0.,min(1.,(val-sl['lo'])/float(sl['hi']-sl['lo'])))
            pygame.draw.rect(content,(99,101,103),track,border_radius=3)
            if sl.get('reverse'): t=1.0-t
            end=track.x+round(t*track.w)
            if end>track.x: pygame.draw.rect(content,BP_ACCENT,(track.x,track.y,end-track.x,5),border_radius=3)
            pygame.draw.circle(content,(255,167,70) if drag==i else BP_ACCENT,(end,track.centery),7)
    bench.debris.states.close_rect=None;bench.debris.state_rows=[]
    if bench.blast_tab==8:                                     # Record: the buttons, a status line and what will be made
        R_=rec_tab_rects(r.w); rc=getattr(bench,'rec',None); on_=bool(rc and rc.active)
        bp_card(content,R_['card'],'RECORDING',fonts)
        for key_,label_,live_ in (('start','Start',not on_),('stop','Stop',on_)):
            br_=R_[key_]
            base_=(196,52,46) if key_=='start' else (92,96,102)
            if not live_: base_=(52,54,57)
            pygame.draw.rect(content,base_,br_,border_radius=7)
            ink_=(255,255,255) if live_ else (125,127,131)
            if key_=='start': pygame.draw.circle(content,ink_,(br_.x+22,br_.centery),7)
            else: pygame.draw.rect(content,ink_,(br_.x+16,br_.centery-7,14,14))
            t_=bold.render(label_,True,ink_); content.blit(t_,(br_.x+42,br_.centery-t_.get_height()//2))
        ow_,oh_=rec_size(getattr(bench,'_win',(1280,720)),REC_RES[int(bench.cfg.get('rec_res',3))%len(REC_RES)])
        y_=R_['start'].bottom+14
        if on_:
            content.blit(bold.render('Recording  %02d:%02d'%(int(rc.elapsed())//60,int(rc.elapsed())%60),True,(255,110,100)),(32,y_))
        else:
            content.blit(font.render('Not recording',True,BP_TEXT),(32,y_))
        y_+=24
        for line_ in wrap_text(font,'Video: %d x %d at %d fps (the size follows your window\'s shape).'%(ow_,oh_,REC_FPS[int(bench.cfg.get('rec_fps',2))%len(REC_FPS)]),R_['card'].w-28):
            content.blit(font.render(line_,True,BP_MUTED),(32,y_)); y_+=18
        note_=getattr(bench,'rec_note','')
        if note_:
            for line_ in wrap_text(font,note_,R_['card'].w-28):
                content.blit(font.render(line_,True,BP_ACCENT),(32,y_)); y_+=18
    if bench.blast_tab==6:                                     # Controls: a card per section, key on the left and what it does on the right
        cw=r.w-36; y=BP_TOP
        for title_,rows_ in CONTROLS:
            lines_=[wrap_text(font,act_,cw-28-92) or [''] for _k,act_ in rows_]
            ch=34+sum(len(l_)*18+6 for l_ in lines_)+4
            bp_card(content,pygame.Rect(18,y,cw,ch),title_,fonts)
            yy=y+34
            for (key_,_a),ls_ in zip(rows_,lines_):
                content.blit(bold.render(key_,True,BP_ACCENT),(32,yy))
                for j_,l_ in enumerate(ls_): content.blit(font.render(l_,True,BP_TEXT),(32+92,yy+j_*18))
                yy+=len(ls_)*18+6
            y+=ch+22
    if bench.blast_tab in (2,3,4):
        items=OBJ_ITEMS if bench.blast_tab==2 else WEAPON_ITEMS if bench.blast_tab==3 else EXPORT_ITEMS
        cw=r.w-36
        bp_card(content,pygame.Rect(18,BP_TOP,cw,40+len(items)*(BP_ITEM_H+BP_ITEM_GAP)+52+(44 if bench.blast_tab==2 else 0)),BP_LABELS[bench.blast_tab].upper(),fonts)
        for i,it in enumerate(items):
            ir=bp_item_rect(pygame.Rect(0,0,*r.size),i)
            on=bench.armed==it['key'] if bench.blast_tab==2 else bench.weapon==it['key'] if bench.blast_tab==3 else False
            pygame.draw.rect(content,(65,57,47) if on else (47,49,51),ir,border_radius=5)
            pygame.draw.rect(content,BP_ACCENT if on else (82,84,86),ir,1,border_radius=5)
            pygame.draw.rect(content,it['rgb'],(ir.x+8,ir.y+10,26,26),border_radius=4)
            content.blit(font.render(it['name'],True,BP_TEXT),(ir.x+43,ir.y+5))
            content.blit(font.render('Selected' if on else it.get('hint','Drag or click'),True,BP_MUTED),(ir.x+43,ir.y+25))
        hint='Drag into the world or click to arm. Camera: drag its coloured arrows to move it along X, Y or Z; click the camera to look through it (V toggles the view, Delete removes it).' if bench.blast_tab==2 else 'Choose a tool, then click the world.' if bench.blast_tab==3 else 'Save all current settings to JSON.'
        y=BP_TOP+42+len(items)*(BP_ITEM_H+BP_ITEM_GAP)
        for line in wrap_text(font,hint,cw-28):content.blit(font.render(line,True,BP_MUTED),(32,y));y+=18
    if bench.blast_tab==4:
        y=BP_TOP+250
        content.blit(bold.render('CURRENT SETTINGS',True,BP_TEXT),(32,y));y+=32
        snap=bench.settings_snapshot()
        for i,(key,val) in enumerate(sorted(snap['settings'].items())):
            content.blit(font.render('%s  %s'%(key,val),True,BP_MUTED),(32,y+i*22))
        if getattr(bench,'export_path',None):
            content.blit(font.render('Saved: '+os.path.basename(bench.export_path),True,BP_ACCENT),(32,BP_TOP+210))
    if bench.blast_tab==1:
        y=BP_TOP
        content.blit(bold.render('CUBE STATES',True,BP_TEXT),(32,y));y+=34
        for k in range(1,len(STATE_NAMES)):
            shown=not (bench.debris.hidden_mask>>k)&1
            pygame.draw.rect(content,BP_ACCENT if shown else (85,87,89),(32,y+3,17,17),border_radius=4)
            pygame.draw.rect(content,STATE_RGB[k],(60,y+4,14,14),border_radius=3)
            content.blit(font.render(STATE_NAMES[k],True,BP_TEXT if shown else BP_MUTED),(86,y))
            count=font.render(str(bench.debris.states.counts[k]),True,BP_MUTED);content.blit(count,(r.w-40-count.get_width(),y))
            screen=pygame.Rect(r.x+24,r.y+y-scroll,r.w-48,25).clip(pygame.Rect(r.x,r.y+BP_TOP,r.w,max(0,r.h-BP_TOP-72)))
            if screen.h:bench.debris.state_rows.append((screen,k))
            y+=26
        y+=18;content.blit(bold.render('CUBE DETAIL',True,BP_TEXT),(32,y));y+=32
        detail=bench.debris.states.lines() or [('Ctrl+click a cube to inspect it.',BP_MUTED),('Backspace: deselect',BP_MUTED)]
        for txt,col in detail:
            for line in wrap_text(font,txt,r.w-64):content.blit(font.render(line,True,col),(32,y));y+=20
    s=pygame.Surface(r.size,pygame.SRCALPHA)
    pygame.draw.rect(s,(29,31,33,248),s.get_rect(),border_radius=9)
    pygame.draw.rect(s,(88,91,94),s.get_rect(),1,border_radius=9)
    viewport=pygame.Rect(10,BP_TOP,r.w-20,max(0,r.h-BP_TOP-72))
    s.set_clip(viewport);s.blit(content,(0,-scroll));s.set_clip(None)
    s.blit(title.render('SHATTERENGINE 2.0',True,BP_TEXT),(18,7))
    s.blit(font.render('Physics test bench · '+BENCH_MATERIALS[int(bench.cfg.get('material',0))%len(BENCH_MATERIALS)][0],True,BP_MUTED),(19,34))
    close=pygame.Rect(r.w-92,13,75,25)
    pygame.draw.rect(s,(54,56,58),(close.x,close.y,32,22),border_radius=4)
    small=pygame.font.SysFont('segoeui,arial,dejavusans',12,bold=True)
    s.blit(small.render('TAB',True,BP_TEXT),(close.x+4,close.y+3));s.blit(small.render('Close',True,BP_MUTED),(close.x+39,close.y+3))
    pygame.draw.line(s,(89,91,93),(18,BP_TOP-9),(r.w-18,BP_TOP-9))
    for tab in BP_ORDER:
        tr=bp_tab_rect(pygame.Rect(0,0,*r.size),tab)
        tabfont = (bold if bench.blast_tab==tab else font) if r.w >= 560 else pygame.font.SysFont('segoeui,arial,dejavusans',13,bold=bench.blast_tab==tab)
        img=tabfont.render(BP_LABELS[tab],True,BP_TEXT if bench.blast_tab==tab else BP_MUTED)
        s.blit(img,(tr.centerx-img.get_width()//2,tr.y+5))
        if bench.blast_tab==tab:pygame.draw.rect(s,BP_ACCENT,(tr.x,tr.bottom-3,tr.w,4))
    pygame.draw.line(s,(81,83,85),(18,r.h-68),(r.w-18,r.h-68))
    for i,label in enumerate(('Resume' if bench.paused else 'Pause','Reset scene','Clear debris')):
        fr=bp_footer_rect(pygame.Rect(0,0,*r.size),i)
        pygame.draw.rect(s,(54,56,58),fr,border_radius=6);pygame.draw.rect(s,(108,110,112),fr,1,border_radius=6)
        buttonfont=pygame.font.SysFont('segoeui,arial,dejavusans',12,bold=True)
        img=buttonfont.render(label,True,BP_TEXT);s.blit(img,(fr.centerx-img.get_width()//2,fr.centery-img.get_height()//2))
    if bp_scroll_max(bench,r):
        track=pygame.Rect(r.w-8,BP_TOP,3,viewport.h)
        pygame.draw.rect(s,(65,67,69),track,border_radius=2)
        thumb=max(20,int(track.h*track.h/(track.h+bp_scroll_max(bench,r))))
        ty=track.y+round((track.h-thumb)*scroll/bp_scroll_max(bench,r))
        pygame.draw.rect(s,BP_ACCENT,(track.x,ty,3,thumb),border_radius=2)
    return s


def slider_rect(i):
    return pygame.Rect(PANEL_X + 14, PANEL_Y + HEAD + i * ROW_H + 18, PANEL_W - 28, 11)




def value_from_x(sl, x, rect):
    t = min(1.0, max(0.0, (x - rect.x) / rect.w))
    if sl.get('reverse'): t = 1.0 - t
    v = sl['lo'] + t * (sl['hi'] - sl['lo'])
    return int(round(v / sl['step']) * sl['step'])


def render_panel(bench, fonts, stats, fps, drag):
    vis = visible(bench)
    n = len(vis)
    h = panel_h(bench)
    s = pygame.Surface((PANEL_W, h), pygame.SRCALPHA)
    pygame.draw.rect(s, (14, 16, 24, 205), (0, 0, PANEL_W, h), border_radius=8)
    s.blit(fonts[1].render('BRICK BENCH  [TAB]', True, (255, 214, 120)), (14, 8))
    for i, sl in enumerate(vis):
        y = HEAD + i * ROW_H
        if 'header' in sl:
            s.blit(fonts[0].render(sl['header'], True, (255, 214, 120)), (14, y + 8))
            pygame.draw.line(s, (90, 98, 120), (14, y + 28), (PANEL_W - 15, y + 28))
            continue
        v = bench.cfg[sl['key']]
        s.blit(fonts[0].render('%s: %s' % (sl['label'], sl['fmt'](v)), True, (230, 234, 242)), (14, y))
        r = pygame.Rect(14, y + 18, PANEL_W - 28, 11)
        pygame.draw.rect(s, (52, 58, 74, 255), r, border_radius=6)
        t = (v - sl['lo']) / (sl['hi'] - sl['lo'])
        col = (224, 118, 60, 255) if drag != i else (255, 170, 90, 255)
        pygame.draw.rect(s, col, (r.x, r.y, max(8, int(r.w * t)), r.h), border_radius=6)
    cells, bonds, bodies = stats
    y = HEAD + n * ROW_H + 6
    sleeping = bench.debris.sleep_count()
    lines = ['Bricks standing: %d / %d' % (cells, bench.cells0),
             'Bonds intact: %d / %d (%d%%)' % (bonds, bench.bonds0, round(100.0 * bonds / bench.bonds0)),
             'Loose pieces: %d  debris cubes: %d' % (bodies, bench.debris.n),
             'Cubes awake: %d   asleep: %d' % (bench.debris.n - sleeping, sleeping),
             'FPS: %d   sim speed: %d%%%s' % (fps, bench.sim_speed, '   PAUSED' if bench.paused else '')] + bench.tool_lines()
    for k, t in enumerate(lines):
        s.blit(fonts[0].render(t, True, (200, 206, 220)), (14, y + k * 20))
    if bench.note_t > 0:
        s.blit(fonts[0].render(bench.note[:48], True, (255, 190, 120)), (14, y + 164))
    return s


def wrap_text(font, text, maxw):
    """Split text into lines no wider than maxw pixels (a single long word is kept whole)."""
    out, cur = [], ''
    for word in text.split(' '):
        trial = word if not cur else cur + ' ' + word
        if not cur or font.size(trial)[0] <= maxw:
            cur = trial
        else:
            out.append(cur); cur = word
    out.append(cur)
    return out


def render_states(bench, fonts):
    """The cube manager: [(surface, x, y)]. Left: the AWAKE cubes only (count, breakdown, one clickable tag per cube).
    Right: the selected cube's full detail. With the manager closed, S still shows a colour legend."""
    sm = bench.debris.states
    out, LH = [], 19
    sm.rows, sm.list_rect, sm.panel_rects = [], None, []
    note = bench.note if bench.note_t > 0 else ''
    left_w = 0
    if sm.ui_open:
        LW, VISIBLE = 410, 14
        awake = sm.listed_idx                                   # awake cubes + cubes asleep with no support (pink)
        total = bench.debris.n - sm.dead_count
        sm.scroll = max(0, min(sm.scroll, max(0, len(awake) - VISIBLE)))
        h = 34 + 5 * LH + 10 + LH + VISIBLE * LH + 28 + LH
        s = pygame.Surface((LW, h), pygame.SRCALPHA)
        pygame.draw.rect(s, (14, 16, 24, 225), (0, 0, LW, h), border_radius=8)
        s.blit(fonts[1].render('CUBE MANAGER', True, (255, 214, 120)), (12, 7))
        n_awake, n_unsup = len(sm.awake_idx), int(sm.counts[ST_SLEEP_UNSUP])
        head = '%d awake  %d no support' % (n_awake, n_unsup)
        s.blit(fonts[1].render(head, True, (255, 120, 90) if (n_awake or n_unsup) else (120, 220, 140)), (LW - 12 - fonts[1].size(head)[0], 7))
        shown = [ST_SLEEP_UNSUP] + list(range(3, len(STATE_NAMES)))     # the awake states, plus asleep-with-no-support (pink)
        for i_, k in enumerate(shown):
            col, row = i_ % 2, i_ // 2
            x, y = 12 + col * 195, 34 + row * LH
            pygame.draw.rect(s, STATE_RGB[k], (x, y + 3, 12, 12))
            label = 'NO SUPPORT' if k == ST_SLEEP_UNSUP else STATE_NAMES[k][:12]
            s.blit(fonts[0].render('%-12s%4d' % (label, sm.counts[k]), True, (214, 220, 232)), (x + 18, y))
        y0 = 34 + 5 * LH + 10
        s.blit(fonts[0].render('awake + no-support cubes, oldest first (click one)', True, (150, 158, 176)), (12, y0))
        y0 += LH
        for n_, k in enumerate(range(sm.scroll, min(len(awake), sm.scroll + VISIBLE))):
            slot = int(awake[k])
            text, colour = sm.row_text(slot)
            ry = y0 + n_ * LH
            if slot == sm.sel_slot:
                pygame.draw.rect(s, (70, 80, 110, 255), (6, ry, LW - 12, LH), border_radius=4)
            pygame.draw.rect(s, colour, (12, ry + 3, 12, 12))
            s.blit(fonts[0].render(text, True, (230, 234, 242)), (30, ry))
            sm.rows.append((pygame.Rect(PANEL_X + 6, PANEL_Y + ry, LW - 12, LH), slot))
        if not len(awake):
            s.blit(fonts[0].render('Nothing awake, nothing hanging: all asleep.', True, (120, 220, 140)), (12, y0 + 4))
        elif len(awake) > VISIBLE:
            s.blit(fonts[0].render('%d-%d of %d   (wheel to scroll)' % (sm.scroll + 1, min(len(awake), sm.scroll + VISIBLE), len(awake)),
                                   True, (150, 158, 176)), (12, h - 24 + 6))
        sm.list_rect = pygame.Rect(PANEL_X, PANEL_Y, LW, h); sm.panel_rects.append(sm.list_rect)
        out.append((s, PANEL_X, PANEL_Y)); left_w = LW + 10
    if note:
        s = pygame.Surface((560, 26), pygame.SRCALPHA)
        pygame.draw.rect(s, (14, 16, 24, 225), (0, 0, 560, 26), border_radius=6)
        s.blit(fonts[0].render(note[:66], True, (255, 190, 120)), (10, 4))
        if out:
            ny = 10 + max(o[0].get_height() for o in out) + 8
        else:                                                              # no manager list: the note goes just under the BLAST panel
            ny = bp_rect(bench, pygame.display.get_surface().get_size(), True).bottom + 10
        out.append((s, PANEL_X, ny))
    return out


TB_BTN, TB_GAP, TB_PAD = 46, 6, 8                          # the top toolbar: button size, gap between buttons, padding


def toolbar_layout(w):
    """The top-centre toolbar: [(rect, kind, index)] with kind 'material' or 'shape' (rects in window coordinates), and the bar's rect."""
    nm, ns = len(BENCH_MATERIALS), len(SHAPES)
    sep = 14
    fixed = 2 * TB_PAD + (nm - 1 + ns - 1) * TB_GAP + sep + 16                 # everything that is not a button (and a little room at the sides)
    b = int(max(24, min(TB_BTN, (w - fixed) // (nm + ns))))                    # a narrow window shrinks the buttons so the bar always fits on screen
    inner = (nm + ns) * b + (nm - 1 + ns - 1) * TB_GAP + sep
    bar = pygame.Rect(0, 8, inner + 2 * TB_PAD, b + 2 * TB_PAD + 14)
    bar.centerx = w // 2
    bar.x = max(0, min(bar.x, w - bar.w))
    x, y = bar.x + TB_PAD, bar.y + TB_PAD
    out = []
    for i in range(nm):
        out.append((pygame.Rect(x, y, b, b + 14), 'material', i)); x += b + TB_GAP
    x += sep - TB_GAP
    for i in range(ns):
        out.append((pygame.Rect(x, y, b, b + 14), 'shape', i)); x += b + TB_GAP
    return out, bar


_SWATCHES = {}


def material_swatch(E, name, w, h):
    """The middle of a material's texture tile, scaled to a toolbar swatch (None when it has no tile)."""
    key = (name, w, h)
    if key not in _SWATCHES:
        lay = float(E._S_TEXLAYER[getattr(E, name)])
        if lay < 0:
            _SWATCHES[key] = None
        else:
            t = E.TILE_RGB[int(lay)]
            surf = pygame.image.frombuffer(np.ascontiguousarray(t[40:216, 40:216]).tobytes(), (176, 176), 'RGB')
            _SWATCHES[key] = pygame.transform.smoothscale(surf, (max(w, 2), max(h, 2)))
    return _SWATCHES[key]


def render_toolbar(bench, fonts, w):
    """Draw the toolbar: a swatch per material and a small picture per shape, the ones in use outlined in orange. Returns (surface, x, y)."""
    btns, bar = toolbar_layout(w)
    b = btns[0][0].w
    s_ = pygame.Surface(bar.size, pygame.SRCALPHA)
    pygame.draw.rect(s_, (24, 26, 29, 215), s_.get_rect(), border_radius=9)
    pygame.draw.rect(s_, (88, 91, 94), s_.get_rect(), 1, border_radius=9)
    small = pygame.font.SysFont('segoeui,arial,dejavusans', 11)
    mat_now, shape_now = int(bench.cfg.get('material', 0)) % len(BENCH_MATERIALS), int(bench.cfg.get('shape', 0)) % len(SHAPES)
    mp = pygame.mouse.get_pos()
    for r, kind, i in btns:
        lr = pygame.Rect(r.x - bar.x, r.y - bar.y, r.w, r.h)
        on = (i == mat_now) if kind == 'material' else (i == shape_now)
        hot = r.collidepoint(mp)
        box = pygame.Rect(lr.x, lr.y, b, b)
        pygame.draw.rect(s_, (62, 65, 69) if hot else (44, 46, 50), box, border_radius=6)
        if kind == 'material':
            c = E_MAT_RGB(BENCH_MATERIALS[i][1])
            inner = box.inflate(-max(8, b // 3), -max(8, b // 3))
            tile = material_swatch(bench.E, BENCH_MATERIALS[i][1], inner.w, inner.h)
            if tile is not None:
                s_.blit(tile, inner.topleft)
            else:
                pygame.draw.rect(s_, c, inner, border_radius=4)
            pygame.draw.rect(s_, tuple(max(0, int(v * 0.55)) for v in c), inner, 2, border_radius=4)
            label = BENCH_MATERIALS[i][0]
        else:
            c = (196, 200, 206)
            name = SHAPES[i][0]
            cx, base = box.centerx, box.bottom - 9
            if name == 'Flat terrain':
                pygame.draw.rect(s_, c, (box.x + 5, base - 7, b - 10, 7))
            elif name == 'Cube':
                pygame.draw.rect(s_, c, (cx - 12, base - 24, 24, 24))
            elif name == 'Pillar':
                pygame.draw.rect(s_, c, (cx - 6, base - 31, 12, 31))
            elif name == 'Wall':
                pygame.draw.rect(s_, c, (box.x + 5, base - 20, b - 10, 20))
            else:
                pygame.draw.rect(s_, c, (box.x + 5, base - 20, b - 10, 20))
            label = name.replace(' terrain', '')
        if on:
            pygame.draw.rect(s_, (255, 137, 24), box, 2, border_radius=6)
        img = small.render(label, True, (255, 167, 70) if on else (190, 193, 197))
        s_.blit(img, (lr.centerx - img.get_width() // 2, lr.y + b + 1))
    return s_, bar.x, bar.y


def E_MAT_RGB(name):
    """The swatch colour of a bench material (the engine's own colour for it)."""
    return {'DIRT': (166, 102, 38), 'STEEL': (112, 133, 163), 'BRICK': (217, 102, 77), 'GLASS': (191, 230, 250), 'PLANKS': (204, 166, 77)}.get(name, (160, 160, 160))


def render_help(bench, fonts):
    first = {'explode': 'Left click: explode at the point under the mouse',
             'drop': 'Left click: drop a weight above the point', 'ram': 'Left click: run the ram into the wall',
             'debris': 'Left click (hold): add loose debris cubes',
             'throw': 'Left click: throw a sticky jerry can at the point under the mouse',
             'torch': 'Left click (hold): set the point under the mouse alight',
             'pour': 'Left click (hold): spill oil at the point under the mouse; light it with the Torch'}.get(bench.weapon, 'Left click (hold): fire the gun at the point under the mouse')
    lines = [first + '      Wheel: zoom at cursor      Middle-drag: pan' + '      Right-drag: orbit',
             'Tab: cube states   Q: shape   E: material   G: diagnostics   Space: pause',
             'R: reset scene + graphs      C: clear debris      WASD: move camera (Shift: faster)',
             'Cube manager: Ctrl+click (a cube inspects it)   Backspace deselect']
    w = 820
    s = pygame.Surface((w, 96), pygame.SRCALPHA)
    pygame.draw.rect(s, (14, 16, 24, 170), (0, 0, w, 96), border_radius=6)
    for k, t in enumerate(lines):
        s.blit(fonts[0].render(t, True, (190, 196, 210)), (10, 6 + k * 22))
    return s


# ------------------------------------------------------------------------------------------------ drawing
def make_floor():
    pos, col = [], []
    N, step = 30, 2.0
    for i in range(-N, N):
        for j in range(-N, N):
            c = (0.30, 0.34, 0.30) if (i + j) % 2 == 0 else (0.26, 0.30, 0.26)
            x0, z0 = i * step, j * step
            for dx, dz in ((0, 0), (0, 1), (1, 1), (0, 0), (1, 1), (1, 0)):
                pos.append((x0 + dx * step, 0.0, z0 + dz * step)); col.append(c)
    n = len(pos)
    arr = np.zeros((n, 9), np.float32)
    arr[:, 0:3] = pos; arr[:, 4] = 1.0; arr[:, 6:9] = col
    vbo = int(gl.glGenBuffers(1))
    gl.glBindBuffer(gl.GL_ARRAY_BUFFER, vbo)
    gl.glBufferData(gl.GL_ARRAY_BUFFER, arr.nbytes, arr, gl.GL_STATIC_DRAW)
    return vbo, n


_TEX_VERT = """
#version 330 compatibility
out vec3 vN;
out vec3 vT;
out vec3 vB;
out vec3 vEye;
void main() {
    vec3 n = gl_Normal, a = abs(n), T, B;                // faces are axis aligned: the texture's own directions (u, v) on each are known
    if (a.x > 0.5)      { T = vec3(0.0, 0.0, 1.0); B = vec3(0.0, -1.0, 0.0); }
    else if (a.y > 0.5) { T = vec3(1.0, 0.0, 0.0); B = vec3(0.0, 0.0, 1.0); }
    else                { T = vec3(1.0, 0.0, 0.0); B = vec3(0.0, -1.0, 0.0); }
    vN = gl_NormalMatrix * n; vT = gl_NormalMatrix * T; vB = gl_NormalMatrix * B;
    vEye = (gl_ModelViewMatrix * gl_Vertex).xyz;
    gl_FrontColor = gl_Color;
    gl_TexCoord[0] = gl_MultiTexCoord0;
    gl_Position = ftransform();                          // exactly the fixed pipeline's position, so the cell lines drawn after do not flicker against it
}
"""

_TEX_FRAG = """
#version 330 compatibility
uniform sampler2DArray uTiles;
uniform vec3 uAvg[16];
uniform float uRelief[16];      // each tile's relief depth in metres; negative = its light parts are the low ones (brick mortar)
uniform float uDepth;           // the Settings slider, 1.0 = as made
in vec3 vN;
in vec3 vT;
in vec3 vB;
in vec3 vEye;
// how high the surface is at a texture spot, 0..1, read from the tile's own brightness
float elev(vec2 uv, int k) {
    float l = dot(texture(uTiles, vec3(uv, float(k))).rgb, vec3(0.30, 0.59, 0.11));
    return uRelief[k] < 0.0 ? 1.0 - l : l;
}
void main() {
    vec3 N = normalize(vN);
    vec3 base = gl_Color.rgb;
    float layer = gl_TexCoord[0].z;
    vec3 L = normalize(gl_LightSource[0].position.xyz);
    vec3 amb = gl_LightModel.ambient.rgb + gl_LightSource[0].ambient.rgb;
    vec3 dif = gl_LightSource[0].diffuse.rgb;
    if (layer < -0.5) {
        gl_FragColor = vec4(clamp(base * (amb + max(dot(N, L), 0.0) * dif), 0.0, 1.0), 1.0);
        return;
    }
    int k = int(layer + 0.5);
    vec2 uv = gl_TexCoord[0].xy;
    vec3 T = normalize(vT), B = normalize(vB);
    float depth = abs(uRelief[k]) * uDepth;
    // parallax: the pattern slides a little with the view direction, so the raised parts seem to stand out of the surface
    vec3 V = normalize(-vEye);
    vec2 vt = vec2(dot(V, T), dot(V, B)) / max(dot(V, N), 0.3);
    uv += vt * (elev(uv, k) - 0.5) * depth * 2.0;
    // bump: tilt the surface's normal along the slope of the heights
    float d = 1.5 / 256.0;
    float gx = (elev(uv + vec2(d, 0.0), k) - elev(uv - vec2(d, 0.0), k)) / (2.0 * d);
    float gy = (elev(uv + vec2(0.0, d), k) - elev(uv - vec2(0.0, d), k)) / (2.0 * d);
    vec3 Np = normalize(N - depth * (gx * T + gy * B));
    float e = elev(uv, k);
    float cavity = mix(1.0 - clamp(depth * 32.0, 0.0, 0.55), 1.0, smoothstep(0.05, 0.65, e));      // low spots catch less light
    vec3 texel = texture(uTiles, vec3(uv, float(k))).rgb;
    vec3 lit = clamp(base * (amb + max(dot(Np, L), 0.0) * dif), 0.0, 1.0);
    gl_FragColor = vec4(lit * texel / uAvg[k] * cavity, 1.0);
}
"""


def tex_program(E):
    """The structure texture shader: colours the cells with their material's tile, with relief (bump + parallax + cavity shading) and the same sun as the
    fixed pipeline. Made once, needs a GL context."""
    if getattr(E, '_struct_tex_prog', None) is None:
        try:
            vs = E._compile_shader(_TEX_VERT, gl.GL_VERTEX_SHADER)
            fs = E._compile_shader(_TEX_FRAG, gl.GL_FRAGMENT_SHADER)
            prog = gl.glCreateProgram()
            gl.glAttachShader(prog, vs)
            gl.glAttachShader(prog, fs)
            gl.glLinkProgram(prog)
            if not gl.glGetProgramiv(prog, gl.GL_LINK_STATUS):
                raise RuntimeError(gl.glGetProgramInfoLog(prog).decode())
            gl.glUseProgram(prog)
            avg = (E.TILE_RGB.reshape(len(E.TILE_RGB), -1, 3).mean(axis=1) / 255.0).astype(np.float32)
            full = np.ones((16, 3), np.float32); full[:len(avg)] = np.maximum(avg, 0.02)
            gl.glUniform3fv(gl.glGetUniformLocation(prog, 'uAvg'), 16, full)
            rel = np.full(16, 0.006, np.float32)
            for mat_, depth_ in ((E.DIRT, 0.020), (E.BRICK, -0.014), (E.PLANKS, 0.012), (E.STEEL, 0.007), (E.CONCRETE_WHITE, 0.008), (E.WOOD, 0.030), (E.GLASS, 0.005)):
                rel[int(E._S_TEXLAYER[mat_])] = depth_
            gl.glUniform1fv(gl.glGetUniformLocation(prog, 'uRelief'), 16, rel)
            gl.glUniform1i(gl.glGetUniformLocation(prog, 'uTiles'), 0)
            E._struct_tex_depth_loc = gl.glGetUniformLocation(prog, 'uDepth')
            gl.glUseProgram(0)
            E._struct_tex_prog = int(prog)
        except Exception as ex:
            print('structure textures unavailable:', ex)
            E._struct_tex_prog = 0
    return E._struct_tex_prog


def draw_tris(vbo, n, mesh=False):
    if not n:
        return
    stride = 4 * MESH_FLOATS if mesh else 36               # cell meshes carry texture coordinates too; the floor does not
    gl.glBindBuffer(gl.GL_ARRAY_BUFFER, vbo)
    gl.glVertexPointer(3, gl.GL_FLOAT, stride, ctypes.c_void_p(0))
    gl.glNormalPointer(gl.GL_FLOAT, stride, ctypes.c_void_p(12))
    gl.glColorPointer(3, gl.GL_FLOAT, stride, ctypes.c_void_p(24))
    if mesh:
        gl.glTexCoordPointer(3, gl.GL_FLOAT, stride, ctypes.c_void_p(36))
    gl.glDrawArrays(gl.GL_TRIANGLES, 0, n)


def draw_scene(bench, cam, cache, floor, win, debris_vbo, stress_debug=False):
    E = bench.E
    w, h = win
    gl.glViewport(0, 0, w, h)
    gl.glClearColor(0.55, 0.70, 0.86, 1.0)
    gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)
    gl.glEnable(gl.GL_DEPTH_TEST)
    cam.apply(w, h)
    bench._rt_mats = (np.array(gl.glGetDoublev(gl.GL_MODELVIEW_MATRIX), np.float64).T, np.array(gl.glGetDoublev(gl.GL_PROJECTION_MATRIX), np.float64).T)
    gl.glEnable(gl.GL_LIGHTING); gl.glEnable(gl.GL_LIGHT0)
    gl.glLightfv(gl.GL_LIGHT0, gl.GL_POSITION, (0.45, 1.0, 0.35, 0.0))
    gl.glLightfv(gl.GL_LIGHT0, gl.GL_DIFFUSE, (0.95, 0.93, 0.88, 1.0))
    gl.glLightfv(gl.GL_LIGHT0, gl.GL_AMBIENT, (0.38, 0.40, 0.46, 1.0))
    gl.glEnable(gl.GL_COLOR_MATERIAL)
    gl.glColorMaterial(gl.GL_FRONT_AND_BACK, gl.GL_AMBIENT_AND_DIFFUSE)
    gl.glEnableClientState(gl.GL_VERTEX_ARRAY); gl.glEnableClientState(gl.GL_NORMAL_ARRAY); gl.glEnableClientState(gl.GL_COLOR_ARRAY)
    gl.glPushMatrix(); gl.glScaled(bench.floor_k, 1.0, bench.floor_k)
    draw_tris(*floor)
    gl.glPopMatrix()
    gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(1.0, 1.0)
    cull = int(bench.cfg.get('cull', 1)) == 1                  # back-face culling for the cell meshes and the loose cubes (every face is wound counter-clockwise from outside)
    if cull:
        gl.glFrontFace(gl.GL_CCW); gl.glCullFace(gl.GL_BACK); gl.glEnable(gl.GL_CULL_FACE)
    objs = E.STRUCTS.objects()
    tprog = tex_program(E) if int(bench.cfg.get('textures', 1)) == 1 else 0
    if tprog:
        gl.glUseProgram(tprog)
        gl.glUniform1f(E._struct_tex_depth_loc, float(bench.cfg.get('texdepth', 100)) / 100.0)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindTexture(gl.GL_TEXTURE_2D_ARRAY, E.tile_texture())
        gl.glEnableClientState(gl.GL_TEXTURE_COORD_ARRAY)
    for o in objs:
        if not o.alive.any():
            continue
        it = cache.get(o, stress_debug)
        gl.glPushMatrix()
        gl.glTranslated(*o.frame_pos)
        M = np.eye(4); M[:3, :3] = o.R
        gl.glMultMatrixd(M.T.flatten())
        draw_tris(it[1], it[2], True)
        gl.glPopMatrix()
    if tprog:
        gl.glDisableClientState(gl.GL_TEXTURE_COORD_ARRAY)
        gl.glUseProgram(0)
    # loose cubes
    bench.debris.render()
    gl.glDisable(gl.GL_CULL_FACE)                              # everything after this (lines, effects, rings) is drawn two-sided as before
    gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
    gl.glDisableClientState(gl.GL_NORMAL_ARRAY); gl.glDisableClientState(gl.GL_COLOR_ARRAY)
    # brick edges
    gl.glDisable(gl.GL_LIGHTING)
    gl.glEnable(gl.GL_BLEND); gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
    gl.glColor4f(0.05, 0.04, 0.04, 0.10 if tprog else 0.55)       # with textures on, the cell grid only whispers
    gl.glLineWidth(1.0)
    for o in objs:
        if not o.alive.any() or getattr(o, 'unbreakable', False) or getattr(o, 'is_drum', False):     # (an oil drum is a plain red cube: no cell lines)
            continue
        it = cache.get(o, stress_debug)
        if not it[4]:
            continue
        gl.glPushMatrix()
        gl.glTranslated(*o.frame_pos)
        M = np.eye(4); M[:3, :3] = o.R
        gl.glMultMatrixd(M.T.flatten())
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, it[3])
        gl.glVertexPointer(3, gl.GL_FLOAT, 12, ctypes.c_void_p(0))
        gl.glDrawArrays(gl.GL_LINES, 0, it[4])
        gl.glPopMatrix()
    if stress_debug:
        gl.glEnableClientState(gl.GL_COLOR_ARRAY)
        gl.glLineWidth(2.0)
        for obj in objs:
            if not obj.alive.any() or getattr(obj,'is_drum',False): continue
            item=cache.get(obj,True)
            if not item[7]: continue
            gl.glPushMatrix();gl.glTranslated(*obj.frame_pos)
            matrix=np.eye(4);matrix[:3,:3]=obj.R;gl.glMultMatrixd(matrix.T.flatten())
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER,item[6])
            gl.glVertexPointer(3,gl.GL_FLOAT,24,ctypes.c_void_p(0))
            gl.glColorPointer(3,gl.GL_FLOAT,24,ctypes.c_void_p(12))
            gl.glDrawArrays(gl.GL_LINES,0,item[7]);gl.glPopMatrix()
        gl.glDisableClientState(gl.GL_COLOR_ARRAY)
        gl.glLineWidth(1.0)
    if bench.bullets:                                          # bullets: a short bright tracer each
        gl.glLineWidth(3.0)
        gl.glColor4f(1.0, 0.88, 0.4, 1.0)
        gl.glBegin(gl.GL_LINES)
        for pos_, vel_, _age in bench.bullets:
            tail = pos_ - vel_ * 0.008
            gl.glVertex3f(*tail); gl.glVertex3f(*pos_)
        gl.glEnd()
        gl.glLineWidth(1.0)
    gl.glDisableClientState(gl.GL_VERTEX_ARRAY)
    gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)
    if bench.thrown:                                           # barrels in flight: a flat red cube each, shaded by face so it reads as a solid
        gl.glPushAttrib(gl.GL_ENABLE_BIT)
        gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_CULL_FACE); gl.glDisable(gl.GL_TEXTURE_2D)
        gl.glBegin(gl.GL_QUADS)
        for pos_, vel_, size_, _age in bench.thrown:
            hs = 0.5 * float(size_)
            for axis, sign, shade in ((0, 1, .82), (0, -1, .62), (1, 1, 1.0), (1, -1, .45), (2, 1, .72), (2, -1, .55)):
                gl.glColor3f(0.72 * shade, 0.12 * shade, 0.10 * shade)
                a1, a2 = [k for k in range(3) if k != axis]
                for u_, v_ in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                    q = np.array(pos_, np.float64)
                    q[axis] += sign * hs; q[a1] += u_ * hs; q[a2] += v_ * hs
                    gl.glVertex3f(*q)
        gl.glEnd()
        gl.glPopAttrib()
    draw_rings(bench)
    draw_blastfx(bench)
    draw_fpcam(bench, cam, win)
    cache.sweep()


def draw_fpcam(bench, cam, win):
    """The first-person camera in the scene: a small camera body that shows where it looks, with the three arrows on top."""
    fp = bench.fpcam
    if fp is None or cam is fp:
        return
    f, s, u = fp.basis()
    P = fp.pos
    gl.glPushAttrib(gl.GL_ENABLE_BIT | gl.GL_LINE_BIT | gl.GL_CURRENT_BIT | gl.GL_DEPTH_BUFFER_BIT)
    gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_TEXTURE_2D); gl.glDisable(gl.GL_CULL_FACE)
    gl.glEnable(gl.GL_DEPTH_TEST)

    def box(c, hs, hu, hf, col):
        axes = ((s, hs), (u, hu), (f, hf))
        shades = (((.75, .6)), ((1.0, .45)), ((.85, .65)))                 # (+ side, - side) shade of each axis, so the box reads as solid
        gl.glBegin(gl.GL_QUADS)
        for k in range(3):
            a1, a2 = [axes[j] for j in range(3) if j != k]
            for sign, shade in ((1, shades[k][0]), (-1, shades[k][1])):
                gl.glColor3f(col[0] * shade, col[1] * shade, col[2] * shade)
                ctr = c + axes[k][0] * sign * axes[k][1]
                for p_, q_ in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                    gl.glVertex3f(*(ctr + a1[0] * p_ * a1[1] + a2[0] * q_ * a2[1]))
        gl.glEnd()

    box(P, 0.18, 0.12, 0.14, (0.24, 0.26, 0.30))                         # body
    box(P + f * 0.22, 0.08, 0.08, 0.08, (0.10, 0.12, 0.16))              # lens barrel
    box(P + f * 0.31, 0.05, 0.05, 0.005, (0.25, 0.55, 0.95))             # lens glass
    box(P + u * 0.16 - f * 0.02, 0.04, 0.04, 0.06, (0.80, 0.15, 0.12))   # viewfinder
    top = math.tan(fp.fovy / 2); asp = 16.0 / 9.0
    far = 1.6
    corners = [P + f * far + s * sx * far * top * asp + u * sy * far * top for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    gl.glLineWidth(1.0)
    gl.glBegin(gl.GL_LINES)                                              # the view cone: what the camera sees
    gl.glColor3f(0.95, 0.95, 0.55)
    for c_ in corners:
        gl.glVertex3f(*(P + f * 0.3)); gl.glVertex3f(*c_)
    for i in range(4):
        gl.glVertex3f(*corners[i]); gl.glVertex3f(*corners[(i + 1) % 4])
    gl.glEnd()
    gl.glDisable(gl.GL_DEPTH_TEST)                                       # the arrows are drawn on top of everything so they can always be grabbed
    L = giz_len(cam, fp)
    for i, a in enumerate(GIZ_AXES):
        col = (1.0, 0.85, 0.2) if bench.fp_hot == i else GIZ_COLS[i]
        tip = P + a * L
        base = P + a * L * 0.80
        gl.glColor3f(*col); gl.glLineWidth(4.0 if bench.fp_hot == i else 3.0)
        gl.glBegin(gl.GL_LINES); gl.glVertex3f(*P); gl.glVertex3f(*base); gl.glEnd()
        h_ = np.array([0.0, 1.0, 0.0]) if i != 1 else np.array([1.0, 0.0, 0.0])
        p1 = np.cross(a, h_); p1 /= np.linalg.norm(p1)
        p2 = np.cross(a, p1)
        gl.glBegin(gl.GL_TRIANGLE_FAN); gl.glVertex3f(*tip)
        for k in range(9):
            ang = 2.0 * math.pi * k / 8.0
            gl.glVertex3f(*(base + (p1 * math.cos(ang) + p2 * math.sin(ang)) * L * 0.055))
        gl.glEnd()
    gl.glLineWidth(1.0)
    gl.glPopAttrib()


def draw_overlay(ov, surf, x, y, win):
    w, h = win
    gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING)
    gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity(); gl.glOrtho(0, w, h, 0, -1, 1)
    gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()
    gl.glEnable(gl.GL_TEXTURE_2D); gl.glEnable(gl.GL_BLEND); gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
    gl.glColor4f(1, 1, 1, 1)
    ov.draw(surf, x, y, win)
    gl.glDisable(gl.GL_TEXTURE_2D)


def screenshot(path, win):
    w, h = win
    gl.glPixelStorei(gl.GL_PACK_ALIGNMENT, 1)
    data = gl.glReadPixels(0, 0, w, h, gl.GL_RGB, gl.GL_UNSIGNED_BYTE)
    img = pygame.image.fromstring(bytes(data), (w, h), 'RGB', True)
    pygame.image.save(img, path)


# ------------------------------------------------------------------------------------------------ video recording (camera view's "Record mode")
REC_RES = (240, 360, 480, 720, 1080, 1440, 2160)              # the Record mode resolution slider's stops (video height; the width follows the window's shape)
REC_FPS = (15, 24, 30, 45, 60)
REC_DIR = os.path.join(HERE, 'recordings')


def rec_size(win, height):
    """The video's size for a window: the chosen height, the window's aspect, both even (video codecs want that)."""
    ow = int(round(win[0] * height / max(1, win[1])))
    return max(2, ow - ow % 2), max(2, height - height % 2)


class Recorder:
    """Records the finished 3D picture (before the menus, buttons and red dot are drawn on it) to an .mp4 in a `recordings` folder next to the script.
    Frames are handed to a writer thread so the game stays smooth. With no OpenCV (pip install opencv-python) it saves a folder of PNG frames instead."""
    def __init__(self):
        self.active = False
        self.path = ''
        self.t0 = 0.0
        self.sent = 0
        self.fps = 30
        self.size = (2, 2)
        self.thread = None
        self.kind = 'png'

    def start(self, win, height, fps):
        import datetime, queue, threading
        self.size = rec_size(win, height)
        self.fps = int(fps)
        os.makedirs(REC_DIR, exist_ok=True)
        stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        self.cv2, self.writer, n = None, None, 0
        self.kind = 'png'
        try:
            import cv2
            self.path = os.path.join(REC_DIR, 'shatter_%s.mp4' % stamp)
            wr = cv2.VideoWriter(self.path, cv2.VideoWriter_fourcc(*'mp4v'), self.fps, self.size)
            if not wr.isOpened():
                raise RuntimeError('video writer would not open')
            self.cv2, self.writer, self.kind = cv2, wr, 'mp4'
        except Exception:
            self.path = os.path.join(REC_DIR, 'shatter_%s' % stamp)           # no video writer here: a folder of numbered PNGs
            os.makedirs(self.path, exist_ok=True)
        self.q = queue.Queue(maxsize=10)
        self.t0, self.sent, self.active = time.perf_counter(), 0, True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        return self.path

    def _run(self):
        n = 0
        while True:
            item = self.q.get()
            if item is None:
                break
            data, (w, h), count = item
            try:
                if self.cv2 is not None:
                    img = np.frombuffer(data, np.uint8).reshape(h, w, 3)[::-1]
                    if (w, h) != self.size:
                        img = self.cv2.resize(np.ascontiguousarray(img), self.size, interpolation=self.cv2.INTER_AREA)
                    img = self.cv2.cvtColor(np.ascontiguousarray(img), self.cv2.COLOR_RGB2BGR)
                    for _ in range(count):
                        self.writer.write(img)
                else:
                    surf = pygame.transform.flip(pygame.image.frombuffer(data, (w, h), 'RGB'), False, True)
                    if (w, h) != self.size:
                        surf = pygame.transform.smoothscale(surf, self.size)
                    for _ in range(count):
                        pygame.image.save(surf, os.path.join(self.path, 'frame_%06d.png' % n)); n += 1
            except Exception as err:
                print('recording frame failed:', err)

    def grab(self, win):
        """Called once per drawn frame: takes a picture when one is due at the chosen frame rate (a slow frame is repeated, so the video keeps real time)."""
        if not self.active:
            return
        due = int((time.perf_counter() - self.t0) * self.fps) - self.sent
        if due <= 0 or self.q.full():
            return
        w, h = win
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)
        gl.glReadBuffer(gl.GL_BACK)
        gl.glPixelStorei(gl.GL_PACK_ALIGNMENT, 1)
        data = bytes(gl.glReadPixels(0, 0, w, h, gl.GL_RGB, gl.GL_UNSIGNED_BYTE))
        self.q.put_nowait((data, (w, h), min(due, 8)))
        self.sent += due

    def elapsed(self):
        return time.perf_counter() - self.t0 if self.active else 0.0

    def stop(self):
        if not self.active:
            return ''
        self.active = False
        self.q.put(None)
        self.thread.join(timeout=60)
        if self.writer is not None:
            self.writer.release()
        return self.path


def render_rec_dot(fonts, secs):
    """The red recording dot (it blinks slowly) and the running time, top left."""
    on = int(secs * 1.6) % 2 == 0
    t = fonts[1].render('REC  %02d:%02d' % (int(secs) // 60, int(secs) % 60), True, (255, 255, 255))
    s_ = pygame.Surface((t.get_width() + 46, 34), pygame.SRCALPHA)
    pygame.draw.rect(s_, (20, 22, 26, 200), s_.get_rect(), border_radius=17)
    pygame.draw.circle(s_, (235, 36, 36) if on else (120, 30, 30), (18, 17), 8)
    s_.blit(t, (34, 17 - t.get_height() // 2))
    return s_


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--shots', help='self-test: run a scripted shot sequence, save PNGs in this folder and quit')
    ap.add_argument('--size', default='1360x800')
    ap.add_argument('--no-gl-checks', action='store_true', help='skip PyOpenGL per-call error checking (faster, GL errors go unreported)')
    ap.add_argument('--max-debris', type=int, default=0, help='size of the GPU loose-cube buffer (default 100000); raise it to find the real limit of your GPU')
    args = ap.parse_args()
    if args.max_debris > 0:
        GpuDebris.MAX = int(args.max_debris)
    E = load_engine()

    pygame.init()
    W, H = (int(v) for v in args.size.lower().split('x'))
    # Keep the existing fixed-function scene/UI, with hardware compute for debris.
    pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 4)
    pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 3)
    pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_COMPATIBILITY)
    PREFS = os.path.join(HERE, 'shatter_prefs.json')           # settings that can only apply when the window is made (VSync): kept between runs
    try:
        with open(PREFS, 'r', encoding='utf-8') as f_:
            vs_saved = 1 if int(json.load(f_).get('vsync', 0)) == 1 else 0
    except Exception:
        vs_saved = 0
    try:
        try:
            pygame.display.set_mode((W, H), DOUBLEBUF | OPENGL | RESIZABLE, vsync=vs_saved)
        except Exception:
            pygame.display.set_mode((W, H), DOUBLEBUF | OPENGL | RESIZABLE)       # (an older pygame without the vsync option)
        renderer = (gl.glGetString(gl.GL_RENDERER) or b'unknown').decode(errors='replace')
        if any(name in renderer.lower() for name in ('llvmpipe', 'softpipe', 'software rasterizer', 'gdi generic', 'swiftshader')) and os.environ.get('SHATTER_ALLOW_SOFTWARE_GL') != '1':    # (SHATTER_ALLOW_SOFTWARE_GL=1: for automated tests on a machine with no GPU)
            raise RuntimeError('A software OpenGL renderer was selected: ' + renderer)
        if int(gl.glGetIntegerv(gl.GL_MAX_COMPUTE_SHADER_STORAGE_BLOCKS)) < 9:
            raise RuntimeError('The GPU must support at least 9 compute shader storage blocks.')
    except Exception as error:
        pygame.quit()
        raise SystemExit('GPU-only debris needs hardware OpenGL 4.3 compatibility. '
                         'Select the NVIDIA GPU and update its driver. No CPU debris fallback.\n' + str(error))
    pygame.display.set_caption('Brick bench - GPU debris')
    fonts = [pygame.font.SysFont('consolas,dejavusansmono,couriernew', 15), pygame.font.SysFont('consolas,dejavusansmono,couriernew', 17, bold=True)]
    try:
        bench = Bench(E)
    except Exception as error:
        pygame.quit()
        raise SystemExit('GPU debris initialization failed; no CPU fallback.\n' + str(error))
    print('GPU-only debris: ' + renderer, flush=True)
    bench.cfg['vsync'] = vs_saved
    menu_open = os.environ.get('SHATTER_NOMENU') != '1'
    cam = Camera()
    orbit_cam = cam                                    # the normal view; `cam` becomes the first-person camera while you look through it
    gstate = {}                                        # a drag on the first-person camera's arrows (or a press on its body)
    ov_camhint, ov_ctx, ov_cross, ov_toolbar = Overlay(), Overlay(), Overlay(), Overlay()
    ov_recdot, ov_toast = Overlay(), Overlay()
    rec, rec_toast = Recorder(), ('', 0.0)               # Record mode: the recorder and a 'Saved' message to show
    hint_h = 34                                        # the camera hint's height (set when it is drawn)

    def stack_y(w_):
        """Under the toolbar: where the red REC dot goes."""
        return (toolbar_layout(w_)[1].bottom if int(bench.cfg.get('toolbar', 1)) == 1 else 0) + 8

    bench.rec = rec
    look_on = False                                    # 'Play as character': the mouse is captured and moves the view (no right-drag needed)
    cross_img = pygame.Surface((22, 22), pygame.SRCALPHA)
    pygame.draw.line(cross_img, (255, 255, 255, 230), (11, 3), (11, 18), 2); pygame.draw.line(cross_img, (255, 255, 255, 230), (3, 11), (18, 11), 2)
    ctx = None                                         # the camera view's right-click menu: {'pos': (x, y)} while open
    rpress = {}                                        # a right-button press in the camera view (a click without a drag opens the menu)
    camhints = {}
    cam.frame(bench.size)
    cache = MeshCache(E)
    floor = make_floor()
    debris_vbo = int(gl.glGenBuffers(1))
    ov_panel, ov_compute, ov_help, ov_blast, ov_states = Overlay(), Overlay(), Overlay(), Overlay(), Overlay()
    clock = pygame.time.Clock()
    acc, drag, orbit, pan, last = 0.0, None, False, False, time.perf_counter()
    bdrag = None                                       # the BLAST panel's slider being dragged
    odrag, odrag_pos0, odrag_moved = None, (0, 0), False       # an Objects-tab item being pressed / dragged out into the world
    ov_ghost = Overlay()
    perf_mon, show_perf = None, False                  # G: rolling 15 s CPU / GPU graph
    stats, stats_t, fps, frames, fps_t = bench.stats(), 0.0, 0, 0, time.perf_counter()
    sim_t, sim_t0, bench.sim_speed = 0.0, 0.0, 100
    FIXED = 1.0 / 60.0

    shots = None
    if args.shots:
        os.makedirs(args.shots, exist_ok=True)
        shots = dict(frame=0, mouse=(W // 2, H // 2))

    def win_size():
        return pygame.display.get_window_size()

    def over_panel(pos):
        if show_perf and perf_mon is not None and graph_screen_rect(bench,win_size()).collidepoint(pos):
            return True
        if menu_open and not SETTINGS_PANEL_IN_USE and bp_rect(bench, win_size(), menu_open).collidepoint(pos):
            return True
        if not menu_open:
            return False
        win = win_size()
        settings_pos = menu_position(bench, pos, win)
        return SETTINGS_PANEL_IN_USE and pygame.Rect(PANEL_X, PANEL_Y, PANEL_W, panel_h(bench)).collidepoint(settings_pos)

    def manager_click(pos):
        """A click on the cube detail box: its X closes it, and a click on the box itself is taken (no explosion)."""
        sm = bench.debris.states
        close = getattr(sm, 'close_rect', None)
        if close is not None and sm.sel_slot >= 0 and close.collidepoint(pos):
            sm.select(None)
            return True
        for rect, slot in sm.rows:
            if rect.collidepoint(pos):
                sm.select(None if sm.sel_slot == slot else slot)
                return True
        return any(r.collidepoint(pos) for r in sm.panel_rects)

    def bp_drag_to(br, x):
        """Move the BLAST panel's slider being dragged (bdrag) to the mouse's x and apply it."""
        sl_, y0_ = bp_bind_rows(bench, br.w), BP_TOP
        if bdrag is None or bdrag >= len(sl_):
            return
        sl = sl_[bdrag]
        bench.cfg[sl['key']] = value_from_x(sl, x, bp_slider_rect(bp_content_rect(bench, br), bdrag, sl_, y0_)); bench.apply_live()

    def place_item(key, pos):
        """Put an Objects-tab item on the ground under the mouse. Returns True if it was placed."""
        w, h = win_size()
        o, d, pt = bench.pick(cam, pos[0], pos[1], w, h)
        if pt is None and abs(d[1]) > 1e-9:                    # not over the terrain: the bare floor under the mouse
            t = -float(o[1]) / float(d[1])
            if 0.0 < t <= cam.max_dist * 3.0:
                pt = o + d * t
        if pt is None:
            bench.say('Drop it on the ground', 3.0)
            return False
        if key == 'drum':
            return bench.place_drum(pt) is not None
        if key == 'fireworks':
            return bench.place_fireworks(pt) is not None
        if key == 'camera':
            return bench.place_fpcam(pt, cam) is not None
        return False

    CTX_ITEMS = (('Play as character', 'play'), ('Back to spectate', 'spectate'), ('Record mode', 'record'), ('Delete camera', 'delete'))

    def ctx_rects(pos):
        w_, h_ = win_size()
        x_, y_ = min(pos[0], w_ - 230), min(pos[1], h_ - 8 - 36 * len(CTX_ITEMS))
        return [(pygame.Rect(x_, y_ + 36 * i, 222, 34), key) for i, (_, key) in enumerate(CTX_ITEMS)]

    def ctx_apply(key):
        if not isinstance(cam, FirstPersonCamera):
            return
        if key == 'play' and cam.mode != 'play':
            bench.start_player(cam)
        elif key == 'spectate':
            cam.mode = 'spectate'

    def click_world(pos):
        if bench.fpcam is not None and not bench.armed and not isinstance(cam, FirstPersonCamera):
            w_, h_ = win_size()
            hit_ = fpcam_hit(cam, bench.fpcam, pos[0], pos[1], w_, h_)
            if hit_ == 'body':
                gstate.clear(); gstate.update(kind='body', pos=pos, moved=False)
                return
            if hit_ is not None:                               # an arrow: drag to move the camera along that axis
                t0_ = giz_axis_param(cam, bench.fpcam.pos, GIZ_AXES[hit_], pos[0], pos[1], w_, h_)
                if t0_ is not None:
                    gstate.clear(); gstate.update(kind='axis', axis=hit_, p0=bench.fpcam.pos.copy(), t0=t0_)
                    return
        if bench.armed:                                        # an Objects item was clicked: this click places it (once), no explosion
            if place_item(bench.armed, pos):
                bench.armed = None
            return
        if bench.weapon == 'gun' and not (pygame.key.get_mods() & KMOD_CTRL):
            bench.gun_held, bench.gun_cd = True, 0.0           # the gun fires from the main loop while the mouse is held
            return
        if bench.weapon in ('torch', 'pour') and not (pygame.key.get_mods() & KMOD_CTRL):
            w, h = win_size()
            bench.use_flame_tool(bench.weapon, cam, pos[0], pos[1], w, h)       # a click lights / pours once; holding the mouse keeps going (main loop)
            bench.gun_held, bench.gun_cd = True, 0.12
            return
        if bench.weapon in ('drop', 'ram', 'debris') and not (pygame.key.get_mods() & KMOD_CTRL):
            w, h = win_size()
            bench.use_tool(bench.weapon, cam, pos[0], pos[1], w, h)       # one use per click
            if bench.weapon == 'debris' and int(bench.cfg['adk']):
                bench.gun_held, bench.gun_cd = True, 0.3           # holding the mouse keeps adding cubes (see the main loop)
            return
        if bench.weapon == 'throw' and not (pygame.key.get_mods() & KMOD_CTRL):
            w, h = win_size()
            bench.throw_barrel(cam, pos[0], pos[1], w, h)      # one barrel per click, lobbed to the point under the mouse
            return
        if pygame.key.get_mods() & KMOD_CTRL:                  # Ctrl+click: select the cube under the mouse for its detail (no explosion)
            sm = bench.debris.states
            w, h = win_size()
            o, d, pt = bench.pick(cam, pos[0], pos[1], w, h)
            reach = math.inf if pt is None else float(np.linalg.norm(np.asarray(pt) - o)) + bench.cs
            slot = sm.pick(o, d, reach)
            if slot is not None:
                nonlocal menu_open
                menu_open = True; bench.blast_tab = 1                  # the inspect box lives in the menu's Cube state tab
                sm.select(None if sm.sel_slot == slot else slot)
            return
        w, h = win_size()
        o, d, pt = bench.pick(cam, pos[0], pos[1], w, h)
        if pt is not None and getattr(bench.pick_obj, 'is_drum', False):
            bench.explode_drum(bench.pick_obj)                 # a click on an oil drum: it goes up with the Objects tab's drum settings
            return
        if pt is None:
            bench.say('Click on the structure to explode there', 3.0)
        else:
            bench.explode(pt, launch_normal=bench.face_normal(pt))     # a fixed direction out of the wall face, not the camera ray

    running = True
    while running:
        now = time.perf_counter()
        dt_real = min(0.25, now - last)
        if perf_mon is not None: perf_mon.record_frame(now - last)
        last = now
        w, h = win_size(); bench._win = (w, h)
        for ev in pygame.event.get():
            if ev.type == QUIT:
                running = False
            elif ev.type == KEYDOWN:
                if ev.key == K_ESCAPE:
                    if ctx is not None: ctx = None                     # Esc closes the camera menu first
                    else: running = False
                elif ev.key == K_TAB:
                    # Tab switches the menu's tab (Toggles / Cube state). Finish a size edit first, so no invisible drag remains.
                    if drag is not None and visible(bench)[drag]['rebuild']:
                        bench.build(); cam.frame(bench.size)
                    drag = None
                    menu_open = not menu_open                   # Tab shows or hides the whole menu
                    if not menu_open: bench.armed = None; odrag = None
                elif ev.key == K_SPACE:
                    if not (isinstance(cam, FirstPersonCamera) and cam.mode == 'play'):      # (Space jumps while playing as the character)
                        bench.paused = not bench.paused
                elif ev.key == K_r:
                    bench.build(); cam.frame(bench.size)
                    if perf_mon is not None: perf_mon.reset()          # R also clears the CPU / GPU graph
                elif ev.key == K_c:
                    if bench.debris.recycle: bench.debris.clear()
                    else: bench.say('Delete cubes is OFF: C does nothing (press R to rebuild)', 4.0)
                elif ev.key == K_e:
                    bench.cycle_material()
                    if perf_mon is not None: perf_mon.reset()
                elif ev.key == K_q:
                    bench.cfg['shape'] = (int(bench.cfg.get('shape', 0)) + 1) % len(SHAPES)       # flat terrain -> cube -> pillar -> wall -> flat terrain ...
                    bench.build(); cam.frame(bench.size)
                    bench.say('Shape: ' + SHAPES[bench.cfg['shape']][0], 3.0)
                elif ev.key == K_g:
                    if perf_mon is None:
                        perf_mon = ComputeMonitor(E)               # starts polling nvidia-smi the first time the graph is opened
                    show_perf = not show_perf
                elif ev.key == K_BACKSPACE:
                    bench.debris.states.select(None)
                elif ev.key == K_v and (isinstance(cam, FirstPersonCamera) or bench.fpcam is not None):
                    if isinstance(cam, FirstPersonCamera):
                        cam.mode = 'spectate'; ctx = None
                        cam = orbit_cam                                 # V again: close the camera view and go back to the normal view
                    else:
                        cam = bench.fpcam                               # V: look through the camera
                    orbit = pan = False; gstate.clear()
                elif ev.key == K_DELETE and bench.fpcam is not None:
                    if isinstance(cam, FirstPersonCamera): cam = orbit_cam; orbit = pan = False; ctx = None
                    bench.fpcam = None; bench.fp_hot = None; gstate.clear()
            elif ev.type == MOUSEBUTTONDOWN:
                if ctx is not None:                                    # the camera menu is open: this click picks an item or closes it
                    if ev.button == 1:
                        for r_, key_ in ctx_rects(ctx['pos']):
                            if r_.collidepoint(ev.pos):
                                if key_ == 'delete':                    # Delete camera: same as the Delete key (back to the normal view, camera removed)
                                    if isinstance(cam, FirstPersonCamera): cam = orbit_cam; orbit = pan = False
                                    bench.fpcam = None; bench.fp_hot = None; gstate.clear()
                                elif key_ == 'record':                  # Record mode: opens the Tab menu on its Record tab
                                    menu_open = True; bench.blast_tab = 8; bench.bp_scroll = 0; bdrag = None
                                else:
                                    ctx_apply(key_)
                                    if key_ == 'play' and isinstance(cam, FirstPersonCamera) and cam.mode == 'play':
                                        menu_open = False; bdrag = None      # the menu closes so the mouse can look around (Tab brings it back)
                    ctx = None
                    continue
                if ev.button == 1 and int(bench.cfg.get('toolbar', 1)) == 1 and not look_on:
                    tb_hit = next(((k_, i_) for r_, k_, i_ in toolbar_layout(w)[0] if r_.collidepoint(ev.pos)), None)
                    if tb_hit is not None:                              # the top toolbar: pick a material or a shape (the same as the E and Q keys)
                        if tb_hit[0] == 'material': bench.cfg['material'] = tb_hit[1]
                        else: bench.cfg['shape'] = tb_hit[1]
                        bench.build(); cam.frame(bench.size)
                        continue
                if ev.button == 1 and manager_click(ev.pos):
                    continue
                if ev.button == 1 and menu_open and not SETTINGS_PANEL_IN_USE:
                    br = bp_rect(bench, (w, h), menu_open)
                    if br.collidepoint(ev.pos):
                        if pygame.Rect(br.right-96,br.y+10,82,30).collidepoint(ev.pos):
                            menu_open = False; bdrag = None
                            continue
                        footer = next((i for i in range(3) if bp_footer_rect(br,i).collidepoint(ev.pos)),None)
                        if footer is not None:
                            if footer == 0: bench.paused = not bench.paused
                            elif footer == 1: bench.build(); cam.frame(bench.size)
                            else: bench.debris.clear(); bench.apply_live()
                            bdrag = None
                            continue
                        if bp_control_click(bench,br,ev.pos):
                            continue
                        if not (br.y+61 <= ev.pos[1] < br.bottom-72):
                            continue
                        tab = bp_tab_hit(br, ev.pos)
                        if tab is not None:
                            bench.blast_tab = tab; bdrag = None; bench.bp_scroll = 0
                            bench.armed = None if tab != 2 else bench.armed
                            if tab != 2: bench.armed = None                    # leaving the Objects tab cancels a click-armed item
                            continue
                        if ev.pos[1] < br.y + BP_TOP: continue
                        bcr = bp_content_rect(bench, br)
                        if bench.blast_tab == 8:
                            R_ = rec_tab_rects(br.w)
                            if R_['start'].move(bcr.topleft).collidepoint(ev.pos) and not rec.active:
                                try:
                                    rec.start((w, h), REC_RES[int(bench.cfg.get('rec_res', 3)) % len(REC_RES)], REC_FPS[int(bench.cfg.get('rec_fps', 2)) % len(REC_FPS)])
                                    bench.rec_note = 'Making: ' + os.path.basename(rec.path) + ('' if rec.kind != 'png' else '  (no video encoder found: saving PNG pictures. pip install opencv-python for mp4)')
                                    rec_toast = ('', 0.0)
                                except Exception as err_:
                                    rec.active = False; bench.rec_note = 'Could not start recording: %s' % err_
                                continue
                            if R_['stop'].move(bcr.topleft).collidepoint(ev.pos) and rec.active:
                                p_ = rec.stop(); bench.rec_note = 'Saved: ' + p_
                                rec_toast = ('Saved: ' + p_, time.perf_counter() + 7.0)
                                continue
                        if bench.blast_tab == 3:
                            it = bp_item_hit(bcr, ev.pos, WEAPON_ITEMS)
                            if it is not None:
                                bench.weapon = WEAPON_ITEMS[it]['key']; bench.armed = None; bench.gun_held = False
                                bench.say('Weapon: ' + WEAPON_ITEMS[it]['name'], 2.5)
                                continue                                       # (a click elsewhere on this tab may be on one of the explosion sliders, below)
                        if bench.blast_tab == 4:
                            if bp_item_hit(bcr, ev.pos, EXPORT_ITEMS) is not None:
                                bench.export_settings()
                            continue
                        if bench.blast_tab == 2:
                            it = bp_item_hit(bcr, ev.pos)
                            if it is not None:
                                odrag, odrag_pos0, odrag_moved = OBJ_ITEMS[it]['key'], ev.pos, False
                                continue                                       # (a click elsewhere on this tab may be on one of the drum sliders, below)
                        if bench.blast_tab == 1:
                            hit = next((k for rect, k in getattr(bench.debris, 'state_rows', []) if rect.collidepoint(ev.pos)), None)
                            if hit is not None:
                                bench.debris.hidden_mask ^= (1 << hit); continue
                        bdrag = bp_hit(bcr, ev.pos, bp_bind_rows(bench, br.w)) if br.y + BP_TOP <= ev.pos[1] < br.bottom - 72 else None
                        if bdrag is not None:
                            bp_drag_to(br, ev.pos[0])
                        continue
                if ev.button == 1:
                    if not menu_open or not SETTINGS_PANEL_IN_USE:
                        if not over_panel(ev.pos): click_world(ev.pos)
                        continue
                    pos = menu_position(bench, ev.pos, (w, h))
                    hit = None
                    for i, sl in enumerate(visible(bench)):
                        if 'header' not in sl and slider_rect(i).inflate(0, 18).collidepoint(pos):
                            hit = i
                    if hit is not None:
                        drag = hit
                        sl = visible(bench)[hit]
                        bench.cfg[sl['key']] = value_from_x(sl, pos[0], slider_rect(hit))
                        bench.apply_live()
                    elif not over_panel(ev.pos):
                        click_world(ev.pos)
                elif ev.button == 3:
                    orbit = not over_panel(ev.pos)
                    rpress = dict(pos=ev.pos, d=0) if (orbit and isinstance(cam, FirstPersonCamera)) else {}
                elif ev.button == 2:
                    pan = not over_panel(ev.pos)
            elif ev.type == MOUSEBUTTONUP:
                if ev.button == 1:
                    bench.gun_held = False
                    if gstate.get('kind') == 'body' and not gstate.get('moved') and bench.fpcam is not None:
                        cam = bench.fpcam; orbit = pan = False             # a click on the camera: look through it
                    gstate.clear()
                    if odrag is not None:
                        if odrag_moved:                                        # dragged out: dropped on the world places it (dropped on the panel cancels)
                            if not over_panel(ev.pos):
                                place_item(odrag, ev.pos)
                        else:                                                  # a plain click on the item arms it (click again to disarm)
                            bench.armed = None if bench.armed == odrag else odrag
                            bench.say('Click the ground to place it' if bench.armed else 'Cancelled', 3.0)
                        odrag = None
                    if bdrag is not None and bdrag < len(bp_sliders(bench)[0]) and bp_sliders(bench)[0][bdrag].get('rebuild'):
                        bench.build(); cam.frame(bench.size)     # a chunk-count change rebuilds the scene when you let go
                    bdrag = None
                    if drag is not None:
                        if visible(bench)[drag]['rebuild']:
                            bench.build(); cam.frame(bench.size)
                        drag = None
                elif ev.button == 3:
                    orbit = False
                    if rpress and rpress['d'] < 6 and isinstance(cam, FirstPersonCamera):
                        ctx = dict(pos=ev.pos)                         # a right click (not a drag) in the camera view: open its menu
                    rpress = {}
                elif ev.button == 2:
                    pan = False
            elif ev.type == MOUSEMOTION:
                if odrag is not None and not odrag_moved and abs(ev.pos[0] - odrag_pos0[0]) + abs(ev.pos[1] - odrag_pos0[1]) > 6:
                    odrag_moved = True
                if gstate.get('kind') == 'body' and abs(ev.pos[0] - gstate['pos'][0]) + abs(ev.pos[1] - gstate['pos'][1]) > 6:
                    gstate['moved'] = True
                elif gstate.get('kind') == 'axis' and bench.fpcam is not None:
                    a_ = GIZ_AXES[gstate['axis']]
                    t_ = giz_axis_param(cam, gstate['p0'], a_, ev.pos[0], ev.pos[1], w, h)
                    if t_ is not None:
                        newp_ = gstate['p0'] + a_ * (t_ - gstate['t0'])
                        newp_[1] = max(0.1, newp_[1])                    # never below the floor
                        bench.fpcam.pos = newp_
                if bdrag is not None:
                    bp_drag_to(bp_rect(bench, (w, h), menu_open), ev.pos[0])
                if menu_open and drag is not None:
                    sl = visible(bench)[drag]
                    pos = menu_position(bench, ev.pos, (w, h))
                    bench.cfg[sl['key']] = value_from_x(sl, pos[0], slider_rect(drag))
                    bench.apply_live()
                if rpress and not look_on:
                    rpress['d'] += abs(ev.rel[0]) + abs(ev.rel[1])
                if orbit:
                    ls_ = 0.006 * float(bench.cfg.get('looksens', 100)) / 100.0
                    cam.yaw -= ev.rel[0] * ls_
                    lim_ = (-1.4, 1.4) if isinstance(cam, FirstPersonCamera) else (-0.1, 1.5)       # looking through the camera allows up and down
                    cam.pitch = max(lim_[0], min(lim_[1], cam.pitch + ev.rel[1] * ls_ * (-1.0 if (isinstance(cam, FirstPersonCamera) and int(bench.cfg.get('invy', 0)) == 1) else 1.0)))
                if pan and not (isinstance(cam, FirstPersonCamera) and cam.mode == 'play'):
                    f, s, u = cam.basis()
                    k = cam.dist * 0.0016
                    cam.target = cam.target - s * ev.rel[0] * k + u * ev.rel[1] * k
            elif ev.type == MOUSEWHEEL:                        # (pygame 2 also sends wheel clicks as buttons 4/5: ignored, or zoom would double)
                mouse_pos = pygame.mouse.get_pos()
                sm_ = bench.debris.states
                if menu_open and not SETTINGS_PANEL_IN_USE and bp_rect(bench, (w, h), menu_open).collidepoint(mouse_pos):
                    br_ = bp_rect(bench, (w, h), menu_open)                          # the wheel scrolls the BLAST menu, not the camera
                    bench.bp_scroll = max(0, min(bp_scroll_max(bench, br_), bp_scroll_clamp(bench, br_) - int(ev.y) * 48))
                elif sm_.ui_open and sm_.list_rect is not None and sm_.list_rect.collidepoint(mouse_pos):
                    sm_.scroll = max(0, sm_.scroll - 3 * int(ev.y))                # the wheel scrolls the awake list, not the camera
                elif not over_panel(mouse_pos):
                    origin, direction, anchor = bench.pick(cam, mouse_pos[0], mouse_pos[1], w, h)
                    # Empty space over the floor zooms to the floor; sky uses the target-depth plane.
                    if anchor is None and abs(direction[1]) > 1e-9:
                        ground_t = -float(origin[1]) / float(direction[1])
                        if 0.0 < ground_t <= cam.max_dist * 3.0:
                            anchor = origin + direction * ground_t
                    cam.zoom_at(mouse_pos[0], mouse_pos[1], w, h, ev.y, anchor)

        play_look = (isinstance(cam, FirstPersonCamera) and cam.mode == 'play' and ctx is None and not menu_open and shots is None
                     and pygame.mouse.get_focused())
        if play_look:                                                        # mouse look: the cursor is hidden and held at the centre, its movement turns the view
            if not look_on:
                pygame.mouse.set_visible(False); pygame.event.set_grab(True); pygame.mouse.get_rel(); look_on = True
            dx_, dy_ = pygame.mouse.get_rel()
            ls_ = 0.006 * float(bench.cfg.get('looksens', 100)) / 100.0
            cam.yaw -= dx_ * ls_
            cam.pitch = max(-1.4, min(1.4, cam.pitch + dy_ * ls_ * (-1.0 if int(bench.cfg.get('invy', 0)) == 1 else 1.0)))
            pygame.mouse.set_pos((w // 2, h // 2)); pygame.mouse.get_rel()
        elif look_on:
            pygame.mouse.set_visible(True); pygame.event.set_grab(False); look_on = False
        if shots is not None:
            dt_real = FIXED
        fov_ = math.radians(float(bench.cfg.get('fov', 70)))
        if isinstance(cam, FirstPersonCamera): cam.fovy = fov_      # the Settings tab's field of view (the camera object and the character view)
        if bench.fpcam is not None: bench.fpcam.fovy = fov_
        keys_ = pygame.key.get_pressed()                       # WASD moves the camera: W/S forward and back, A/D left and right (Shift: 3x faster)
        mods_ = pygame.key.get_mods()
        playing_ = isinstance(cam, FirstPersonCamera) and cam.mode == 'play'
        if playing_:                                           # the character: W A S D walk (Shift runs), Space jumps, it falls and climbs low steps
            f_, s_, u_ = cam.basis()
            fwd_ = np.array([f_[0], f_[2]]); nf_ = float(np.linalg.norm(fwd_))
            fwd_ = fwd_ / nf_ if nf_ > 1e-6 else np.array([0.0, -1.0])
            right_ = np.array([s_[0], s_[2]])
            wish_ = fwd_ * ((1.0 if keys_[K_w] else 0.0) - (1.0 if keys_[K_s] else 0.0)) + right_ * ((1.0 if keys_[K_d] else 0.0) - (1.0 if keys_[K_a] else 0.0))
            nw_ = float(np.linalg.norm(wish_))
            bench.step_player(cam, min(dt_real, 0.05), wish_ / max(nw_, 1.0), jump=bool(keys_[K_SPACE]), run=bool(mods_ & KMOD_SHIFT))
        if not playing_ and not (mods_ & (KMOD_CTRL | KMOD_ALT)):
            mv_f = (1.0 if keys_[K_w] else 0.0) - (1.0 if keys_[K_s] else 0.0)
            mv_r = (1.0 if keys_[K_d] else 0.0) - (1.0 if keys_[K_a] else 0.0)
            if mv_f or mv_r:
                f_, s_, u_ = cam.basis()
                fwd_ = np.array([f_[0], 0.0, f_[2]])                # walk over the ground: forward is where the camera looks, level
                nf_ = float(np.linalg.norm(fwd_))
                fwd_ = fwd_ / nf_ if nf_ > 1e-6 else np.array([0.0, 0.0, -1.0])
                speed_ = cam.dist * 0.9 * (3.0 if mods_ & KMOD_SHIFT else 1.0) * float(bench.cfg.get('camspd', 100)) / 100.0
                move_ = fwd_ * mv_f + s_ * mv_r
                nm_ = float(np.linalg.norm(move_))
                cam.target = cam.target + move_ / max(nm_, 1.0) * speed_ * dt_real
        if bench.gun_held and bench.weapon == 'gun' and not bench.paused:      # holding the mouse with the gun keeps firing at the pointer
            bench.gun_cd -= dt_real
            mp_ = pygame.mouse.get_pos()
            if bench.gun_cd <= 0.0:
                if not over_panel(mp_):
                    bench.fire_gun(cam, mp_[0], mp_[1], w, h)
                bench.gun_cd = GUN_PERIOD
        if bench.gun_held and bench.weapon in ('torch', 'pour') and not bench.paused:    # holding the mouse with the Torch / Pour oil keeps going
            bench.gun_cd -= dt_real
            if bench.gun_cd <= 0.0:
                mp_ = pygame.mouse.get_pos()
                if not over_panel(mp_):
                    bench.use_flame_tool(bench.weapon, cam, mp_[0], mp_[1], w, h)
                bench.gun_cd = 0.1 if bench.weapon == 'torch' else 0.04
        if bench.gun_held and bench.weapon == 'debris' and not bench.paused:    # holding the mouse with Add debris keeps adding cubes
            bench.gun_cd -= dt_real
            if bench.gun_cd <= 0.0:
                mp_ = pygame.mouse.get_pos()
                if not over_panel(mp_):
                    bench.use_tool('debris', cam, mp_[0], mp_[1], w, h)
                bench.gun_cd = 0.3
        bench.note_frame(dt_real)
        acc += dt_real
        n, t_steps = 0, time.perf_counter()
        # Catch up on the time a slow frame owes (up to 6 steps, within ~35 ms of work), so the simulation keeps real-time speed;
        # only if it is far behind is the time dropped. The panel's 'sim speed' shows whether it is keeping up.
        speed_k = max(0.05, min(2.0, float(bench.cfg['speed']) / 100.0))       # the Simulation speed setting: each step covers this share of real time
        while acc >= FIXED and n < 6 and (n == 0 or time.perf_counter() - t_steps < 0.035):
            bench.step(FIXED * speed_k)
            acc -= FIXED
            sim_t += FIXED * speed_k
            n += 1
        if acc > 0.25:
            acc = 0.25
        bench.note_t = max(0.0, bench.note_t - dt_real)
        stats_t -= dt_real
        if stats_t <= 0:
            stats, stats_t = bench.stats(), 0.25

        bench.debris.pulse = 0.5 + 0.5 * math.sin(now * 7.0)
        bench.debris.states.update()                    # reads the GPU only while the manager / state view / a selection is on
        # Tab's menu: the cube-states panel is open and the cubes are coloured by state, together.
        bench.debris.state_view = (menu_open and bench.blast_tab == 1) or getattr(bench, 'show_cube_states', False)      # the Cube state tab colours the cubes by state, while the menu is open
        bench.debris.activity_view = False
        glow = False
        res_k = max(0.25, min(2.0, float(bench.cfg['res']) / 100.0))      # the Resolution setting: the scene is drawn at this share of the window size
        sharp_k = max(0.0, float(bench.cfg['sharp']) / 100.0)             # the Sharpness setting
        draw_size = (w, h)
        # While a blast effect is alive, or Resolution / Sharpness are changed, the scene goes through the scene pass (offscreen, then to the window).
        bloom_k = max(0.0, float(bench.cfg.get('bloom', 100)) / 100.0)                 # the Bloom setting: 1.0 = the game's glow strength
        bloom_all = int(bench.cfg.get('bloomall', 0)) == 1 and bloom_k > 0.0           # glow every frame, not only while a blast effect is alive
        rt_on = int(bench.cfg.get('rt', 0)) == 1 and bench.rt is not False
        tone_ = (float(bench.cfg.get('bright', 100)) / 100.0, float(bench.cfg.get('contrast', 100)) / 100.0, float(bench.cfg.get('gamma', 100)) / 100.0)
        tone_on = abs(tone_[0] - 1.0) > 1e-3 or abs(tone_[1] - 1.0) > 1e-3 or abs(tone_[2] - 1.0) > 1e-3      # brightness / contrast / gamma changed: the scene pass is needed
        if bench.blastfx.n > 0 or abs(res_k - 1.0) > 1e-3 or sharp_k > 0.0 or bloom_all or rt_on or tone_on:
            if bench.bloom is None:
                try:
                    bench.bloom = Bloom(E)
                except Exception as err:
                    print('The scene pass (glow, resolution, sharpness) is not available: %s' % err)
                    bench.bloom = False
            glow = bool(bench.bloom) and bench.bloom.begin(w, h, res_k)
            if glow:
                draw_size = bench.bloom.size
        spin = float(bench.cfg['spin'])
        if spin != 0.0 and not isinstance(cam, FirstPersonCamera):                                 # camera spin: a slow orbit that runs in real time, whatever the Simulation speed is
            cam.yaw += math.radians(spin) * dt_real
            if int(bench.cfg['spinfocus']) == 1 and bench.blast_pos is not None:      # ...centred on the last blast, which the camera eases over to
                goal = bench.blast_pos + np.array([0.0, 0.3, 0.0])
                cam.target = cam.target + (goal - cam.target) * min(1.0, 3.0 * dt_real)
        shake_k = bench.shake * float(bench.cfg['shake']) / 100.0 if not bench.paused else 0.0
        cam_target = cam.target
        if shake_k > 0.002:                                               # screenshake: the camera is nudged for this frame only, then put back
            f_, s_, u_ = cam.basis()
            amp = shake_k * shake_k * 0.02 * cam.dist
            cam.target = cam.target + s_ * np.random.uniform(-amp, amp) + u_ * np.random.uniform(-amp, amp)
        if bench.fpcam is not None and not isinstance(cam, FirstPersonCamera):
            if gstate.get('kind') == 'axis':
                bench.fp_hot = gstate['axis']
            else:
                mp2_ = pygame.mouse.get_pos()
                hit2_ = None if over_panel(mp2_) else fpcam_hit(cam, bench.fpcam, mp2_[0], mp2_[1], w, h)
                bench.fp_hot = hit2_ if isinstance(hit2_, int) else None
        draw_scene(bench, cam, cache, floor, draw_size, debris_vbo)       # the graph panel no longer tints the scene with the stress overlay
        cam.target = cam_target
        if glow and rt_on:
            try:
                if bench.rt is None:
                    bench.rt = RayLight(E)
                bench.rt.update_scene([o for o in E.STRUCTS.objects()])
                c = bench.cfg
                bench.rt.run(bench.bloom.fbo[1], bench.bloom.fbo[4], bench.bloom.size, bench._rt_mats[0], bench._rt_mats[1],
                             dict(shadow=c['rtsh'] / 100.0, soft=c['rtsoft'] / 100.0, ao=c['rtao'] / 100.0, bounce=c['rtgi'] / 100.0 * 1.2,
                                  refl=c['rtrf'] / 100.0, samples=int(c['rtn']), dist=6.0, floor_k=bench.floor_k,
                                  mats={n: (c.get('rs_' + n, 0) / 100.0, c.get('rr_' + n, 60) / 100.0) for n in ('DIRT', 'STEEL', 'BRICK', 'GLASS', 'PLANKS')}), seed=int(now * 60.0))
                dn_ = float(c.get('rtdn', 60)) / 100.0
                if dn_ > 0.0:                                          # the Settings tab's RT denoise
                    mats_ = np.concatenate([np.asarray(bench._rt_mats[0], np.float64).ravel(), np.asarray(bench._rt_mats[1], np.float64).ravel()])
                    still_ = (getattr(bench, '_rt_prev', None) is not None and bench._rt_prev.shape == mats_.shape
                              and bool(np.allclose(bench._rt_prev, mats_, atol=1e-7)) and bench.blastfx.n == 0)
                    bench._rt_prev = mats_
                    bench.bloom.denoise(dn_, still_)
            except Exception as err:
                print('Ray-traced lighting is not available on this graphics card: %s' % err)
                bench.rt = False
                bench.cfg['rt'] = 0
        if glow:
            bench.bloom.apply(0.7 * bloom_k if (bench.blastfx.n > 0 or bloom_all) else 0.0, sharp_k, tone_)
        if rec.active:
            rec.grab((w, h))                                       # the finished 3D picture, before any menu or button is drawn over it
        if menu_open and SETTINGS_PANEL_IN_USE:
            settings = render_panel(bench, fonts, stats, fps, drag)
            scale = menu_scale(bench, (w, h))
            if scale < 1.0:
                settings = pygame.transform.smoothscale(settings, (max(1, int(settings.get_width() * scale)), max(1, int(settings.get_height() * scale))))
            draw_overlay(ov_panel, settings, PANEL_X, PANEL_Y, (w, h))
        if menu_open and not SETTINGS_PANEL_IN_USE:
            br = bp_rect(bench, (w, h), menu_open)
            draw_overlay(ov_blast, render_blast_panel(bench, fonts, br, bdrag), br.x, br.y, (w, h))
        if show_perf and perf_mon is not None:
            perf_mon.tick()
            gr = graph_screen_rect(bench, (w, h))
            gs = render_compute(perf_mon, fonts, bench.debris, bench)
            if gr.size != gs.get_size():
                gs = pygame.transform.smoothscale(gs, (gr.w, gr.h))
            draw_overlay(ov_compute, gs, gr.x, gr.y, (w, h))
        for surf_, x_, y_ in render_states(bench, fonts):
            draw_overlay(ov_states, surf_, x_, y_, (w, h))
        if (odrag is not None and odrag_moved) or bench.armed:                 # a red square follows the mouse while an item is dragged or armed
            mx_, my_ = pygame.mouse.get_pos()
            if not (menu_open and bp_rect(bench, (w, h), menu_open).collidepoint((mx_, my_))):
                ghost = pygame.Surface((36, 36), pygame.SRCALPHA)
                pygame.draw.rect(ghost, (210, 44, 38, 175), (0, 0, 36, 36), border_radius=3)
                pygame.draw.rect(ghost, (255, 190, 170, 220), (0, 0, 36, 36), width=2, border_radius=3)
                draw_overlay(ov_ghost, ghost, mx_ - 18, my_ - 18, (w, h))
        if isinstance(cam, FirstPersonCamera):                                  # a reminder while looking through the camera
            if cam.mode not in camhints:                                       # two short lines, so the hint stays narrow enough to sit between the side panels
                lines_ = (('PLAYING    W A S D: walk    Shift: run    Space: jump', 'mouse: look    right-click: menu    Tab: menu    V: close view') if cam.mode == 'play'
                          else ('CAMERA VIEW    V: close view    right-drag: look', 'W A S D: move    right-click: menu'))
                labs_ = [fonts[1].render(t_, True, (255, 255, 255)) for t_ in lines_]
                sf_ = pygame.Surface((max(l_.get_width() for l_ in labs_) + 24, sum(l_.get_height() for l_ in labs_) + 12), pygame.SRCALPHA)
                pygame.draw.rect(sf_, (20, 22, 26, 190), sf_.get_rect(), border_radius=6)
                yy_ = 6
                for l_ in labs_:
                    sf_.blit(l_, ((sf_.get_width() - l_.get_width()) // 2, yy_)); yy_ += l_.get_height()
                camhints[cam.mode] = sf_
            sf_ = camhints[cam.mode]
            hint_h = sf_.get_height()
            draw_overlay(ov_camhint, sf_, max(4, (w - sf_.get_width()) // 2), h - hint_h - 12, (w, h))     # camera controls: bottom centre
            if ctx is not None:                                                 # the right-click menu
                rects_ = ctx_rects(ctx['pos'])
                x0_, y0_ = rects_[0][0].x, rects_[0][0].y
                ms_ = pygame.Surface((222, 36 * len(rects_)), pygame.SRCALPHA)
                pygame.draw.rect(ms_, (30, 32, 36, 235), ms_.get_rect(), border_radius=6)
                pygame.draw.rect(ms_, (110, 112, 116, 255), ms_.get_rect(), 1, border_radius=6)
                mp3_ = pygame.mouse.get_pos()
                for (r_, key_), (label_, _k) in zip(rects_, CTX_ITEMS):
                    cur_ = (key_ == cam.mode)
                    lr_ = pygame.Rect(r_.x - x0_, r_.y - y0_ + 1, 222, 34)
                    if r_.collidepoint(mp3_) and not cur_:
                        pygame.draw.rect(ms_, (255, 150, 60, 255), lr_.inflate(-8, -4), border_radius=4)
                    col_ = (140, 142, 146) if cur_ else (255, 255, 255)
                    ms_.blit(fonts[0].render(label_ + ('   (now)' if cur_ else '') + ('   (open)' if key_ == 'record' and menu_open and bench.blast_tab == 8 else ''), True, col_), (lr_.x + 14, lr_.y + 8))
                draw_overlay(ov_ctx, ms_, x0_, y0_, (w, h))
        if rec.active:                                                          # the red dot: shown in every view while recording
            rd_ = render_rec_dot(fonts, rec.elapsed())
            draw_overlay(ov_recdot, rd_, (w - rd_.get_width()) // 2, stack_y(w), (w, h))     # top centre, under the toolbar
        if rec_toast[0] and time.perf_counter() < rec_toast[1]:
            tt_ = fonts[0].render(rec_toast[0], True, (255, 255, 255))
            ts_ = pygame.Surface((tt_.get_width() + 24, tt_.get_height() + 14), pygame.SRCALPHA)
            pygame.draw.rect(ts_, (20, 22, 26, 215), ts_.get_rect(), border_radius=6); ts_.blit(tt_, (12, 7))
            draw_overlay(ov_toast, ts_, max(8, (w - ts_.get_width()) // 2), h - ts_.get_height() - hint_h - 24, (w, h))
        if int(bench.cfg.get('toolbar', 1)) == 1:                               # always on screen, in every view
            tb_s, tb_x, tb_y = render_toolbar(bench, fonts, w)
            draw_overlay(ov_toolbar, tb_s, tb_x, tb_y, (w, h))
        if look_on and int(bench.cfg.get('crosshair', 1)) == 1:
            draw_overlay(ov_cross, cross_img, w // 2 - 11, h // 2 - 11, (w, h))        # a small crosshair where the tools aim
        pygame.display.flip()
        frames += 1
        if time.perf_counter() - fps_t >= 0.5:
            wall = time.perf_counter() - fps_t
            fps = int(frames / wall); frames, fps_t = 0, time.perf_counter()
            bench.sim_speed = int(round(100.0 * (sim_t - sim_t0) / wall)) if shots is None and not bench.paused else 100     # sim seconds per real second
            sim_t0 = sim_t

        if shots is not None:
            running = run_shots(shots, bench, cam, E, args.shots, (w, h), click_world)
        else:
            fc_ = int(bench.cfg.get('fpscap', 120))
            clock.tick(0 if fc_ >= 250 else fc_)             # the Settings tab's FPS limit (250 = unlimited)
            if int(bench.cfg.get('vsync', 0)) != vs_saved:   # VSync only takes effect when the window is made: remember it for the next launch
                vs_saved = int(bench.cfg.get('vsync', 0))
                try:
                    with open(PREFS, 'w', encoding='utf-8') as f_: json.dump({'vsync': vs_saved}, f_)
                except OSError: pass
    if rec.active: rec.stop()                                  # a recording still running is saved on the way out
    if perf_mon is not None: perf_mon.stop()
    bench.debris.close()
    pygame.quit()


def run_shots(sh, bench, cam, E, out, win, click):
    """Scripted self-test: an explosion, with screenshots before, just after and once it has settled."""
    f = sh['frame']
    sh['frame'] += 1
    w, h = win
    mid = (int(w * 0.62), int(h * 0.45))
    if f == 0:
        cam.yaw, cam.pitch = 0.65, 0.22
        if os.environ.get('SHATTER_RT') == '1':
            bench.cfg['rt'] = 1
        if os.environ.get('SHATTER_SCENE'):                       # self-test only: 'shape,material' (indices), photographed without the explosion
            sp, mt = os.environ['SHATTER_SCENE'].split(',')
            bench.cfg.update(shape=int(sp), material=int(mt)); bench.build()
            cam.yaw, cam.pitch = float(os.environ.get('SHATTER_YAW', 0.65)), 0.22
    if f == 8 and os.environ.get('SHATTER_SCENE'):
        screenshot(os.path.join(out, 'scene.png'), win)
        return False
    if f == 3:
        screenshot(os.path.join(out, '0_intact.png'), win)
    if f == 10:
        click(mid)
    if f == 12:
        screenshot(os.path.join(out, '3_explosion_t2.png'), win)
    if f == 120:
        cells, bonds, bodies = bench.stats()
        print('explosion: blasts %d, destroyed %d, bricks %d/%d, debris %d' % (bench.blasts, bench.last_blast, cells, bench.cells0, bench.debris.n), flush=True)
        screenshot(os.path.join(out, '4_explosion_settled.png'), win)
        return False
    return True


# ==============================================================================================================
# THE SHATTERLANDS ENGINE (bond-patched). Everything above is the bench; everything inside this string is the engine it runs on.
# Edit the bench freely above. Engine edits go inside the string (it must never contain three single quotes in a row).
# ==============================================================================================================
_ENGINE_SRC = r'''# shatterlands_engine.py
# Engine + renderer: world, chunk meshing, physics, structures, sound, and the OpenGL graphics layer.
# The UI (menus, HUD, main loop) is in shatterlands_ui.py, which imports this module.
import math, os, sys, time, ctypes, functools, subprocess, threading, collections
import logging
import numpy as np
import pygame
from pygame.locals import *
from OpenGL import GL as gl
from OpenGL.error import GLError, NullFunctionError

try:
    from scipy import ndimage as _ndi
    from scipy.sparse import coo_matrix as _coo_matrix
    from scipy.sparse.csgraph import connected_components as _connected_components
    HAS_SCIPY = True            # labels connected cells in compiled code: about 50x faster than the numpy fallback
except Exception:
    HAS_SCIPY = False


# ═══════════════════════════════════════════════
#  GPU COMPUTE (optional, CuPy). Started lazily from run(), never at import, so the mesh
#  worker processes do not each open a CUDA context. Everything falls back to numpy.
# ═══════════════════════════════════════════════
cp = None
GPU_OK = False
GPU_MIN_CELLS = 20000      # smaller grids are faster on the CPU than the copy to the GPU and back


logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(message)s")

# ═══════════════════════════════════════════════
#  >>> GLOBAL SHIMS & CONFIGURATION <<<
# ═══════════════════════════════════════════════


# Missing Globals required by the original script
GFX = {'ambient_floor': 0.35, 'physics_device': 'cpu'}

# ═══════════════════════════════════════════════
#  BLOCK IDs & DATA
# ═══════════════════════════════════════════════
(AIR, GRASS, DIRT, STONE, SAND, WOOD, LEAVES,
 WATER, SNOW, GRAVEL, PLANKS, GLASS, TORCH, BRICK, SLAB) = range(15)


(CLAY, CONCRETE_WHITE, CONCRETE_BLACK, CONCRETE_RED, CONCRETE_BLUE,
 WOOD_OAK, WOOD_BIRCH, WOOD_SPRUCE, WOOD_DARK, WOOD_JUNGLE, WOOD_ACACIA) = range(26, 37)



STEEL = 65


COLORS = {
    GRASS:  (0.34, 0.58, 0.20), DIRT:   (0.65, 0.40, 0.15), STONE:  (0.60, 0.60, 0.60),
    SAND:   (0.95, 0.90, 0.50), WOOD:   (0.55, 0.35, 0.12), LEAVES: (0.24, 0.55, 0.17),
    WATER:  (0.20, 0.50, 0.95), SNOW:   (0.98, 1.00, 1.00), GRAVEL: (0.70, 0.68, 0.65),
    PLANKS: (0.80, 0.65, 0.30), GLASS:  (0.75, 0.90, 0.98), TORCH:  (1.00, 0.85, 0.25),
    BRICK:  (0.85, 0.40, 0.30), SLAB:   (0.65, 0.65, 0.65), STEEL:  (0.44, 0.52, 0.64)
}

NEAR, FAR      = 0.05, 450.0      # far plane: past the far corner of the whole 15 x 15 chunk map (about 320 blocks across the diagonal)
CHUNK_SIZE     = 15
CELL = 0.2; GS = 5; NC = 75; NH = 57     # the ground cube grid: set by set_ground_res() below
PLAYER_HEIGHT  = 1.8
PLAYER_RADIUS  = 0.3

# ═══════════════════════════════════════════════
#  FLAT WORLD GENERATION
# ═══════════════════════════════════════════════

# ═══════════════════════════════════════════════
#  GROUND CUBES
# ═══════════════════════════════════════════════
# The ground is a grid of cubes CELL (half a block) wide. Each chunk keeps one array of them, +1 where a cube is solid and -1
# where it is air (world.dens). Digging takes cubes out; ground cut off from the rest falls (World.settle).

TERRAIN_GEN_MAX = 48                    # the generated land never rises above this many blocks
TERRAIN_MAX_H = TERRAIN_GEN_MAX              # tallest column the ground grid has room for, in blocks

MAX_GROUND_RES = 50                                         # most cubes per block the ground accepts (memory grows with its cube: see dense())


def set_ground_res(res):
    """Choose how big the ground cubes are: `res` cubes per block along each side (the same number the structures use, so
    ground cubes and tower cubes are the same size). The world has to be regenerated after this changes."""
    global CELL, GS, NC, NH
    GS = int(max(1, min(MAX_GROUND_RES, res)))
    CELL = 1.0 / GS
    NC = CHUNK_SIZE * GS                                    # ground cubes along a chunk's x and z
    NH = int(math.ceil((TERRAIN_MAX_H * GS + 2) / 15.0)) * 15   # along y: multiple of 15 so every LOD step divides it

set_ground_res(5)







# ---- disk cache: terrain generation and chunk meshes ------------------------------------------------------------------
# Two caches in a cache folder next to the running game (or SHATTERLANDS_CACHE_DIR), each switched on and off by a game
# through DISK_CACHE.terrain_on / DISK_CACHE.mesh_on:
#   terrain  the height of every ground column of a chunk (what generate_chunk makes), one small file per chunk
#   meshes   the finished mesh of a chunk, keyed by a hash of the cubes it was built from (and its neighbours' edge cubes), so a
#            chunk that has been dug, or whose neighbour has, misses and is built again









# ═══════════════════════════════════════════════
#  CORE CLASSES & GENERATION
# ═══════════════════════════════════════════════








# ═══════════════════════════════════════════════
#  CHUNK MESHER & CACHE LOOKUP
# ═══════════════════════════════════════════════
# Colour per block ID. Unknown IDs render magenta so gaps are easy to spot.
_COLOR_LUT = np.tile(np.array([1.0, 0.0, 1.0], dtype=np.float32), (256, 1))
for _blk, _rgb in COLORS.items():
    _COLOR_LUT[_blk] = _rgb







# ═══════════════════════════════════════════════
#  GRAPHICS QUALITY: presets, terrain level of detail, shadow levels
# ═══════════════════════════════════════════════
# The settings a preset drives, and the value each preset gives them. High is the game's original look.
# Level of detail -> (chunk distance where the 3-block mesh starts, where the 5-block mesh starts).




# ═══════════════════════════════════════════════
#  RENDERER (pygame window + OpenGL 3.3 core)
# ═══════════════════════════════════════════════

# Sun and shadows. A low sun in front and to the left of the spawn view. The shaders use the same direction (normalize(-0.70, 0.62, -0.40)).
SUN_DIR = np.array([-0.70, 0.62, -0.40])
SUN_DIR = SUN_DIR / np.linalg.norm(SUN_DIR)




# Depth-only pass: the scene drawn from the sun into the shadow map.


# Shadow lookup shared by the terrain and structure shaders: soft, 16 taps spread over a disc (Vogel spiral) and
# turned a little differently at every pixel, so the edge fades out over about a quarter of a block instead of stepping.

# One daylight model for terrain, structures, debris and sky: the same sun, sky fill and haze colour everywhere.
_LIGHT_GLSL = """
const vec3 SUN_DIR  = vec3(-0.6882, 0.6096, -0.3933);  // normalize(-0.70, 0.62, -0.40): low sun, front left
const vec3 SUN_COL  = vec3(1.00, 0.82, 0.56);          // warm golden sun
const vec3 SKY_TINT = vec3(0.72, 0.85, 1.08);          // sky fill: cool, so shadows lean blue
const vec3 BOUNCE_COL = vec3(0.95, 0.78, 0.55);        // warm light bounced off the ground onto upright faces
const vec3 HORIZON_COL = vec3(0.76, 0.83, 0.92);       // pale blue haze away from the sun
const vec3 SUN_HAZE = vec3(0.98, 0.90, 0.78);          // cream haze toward the sun
const vec3 FOG_COL  = HORIZON_COL;
// Haze colour looking along dir: pale blue, warming to cream toward the sun, so distance and sky blend.
vec3 fogColor(vec3 dir) {
    vec2 h = dir.xz, s = SUN_DIR.xz;
    float toward = max(dot(h, s) / max(length(h) * length(s), 1e-4), 0.0);
    return mix(HORIZON_COL, SUN_HAZE, 0.75 * toward * toward * toward);
}
// Light reaching a surface with normal n; sh is the sun visibility (0 in shadow, 1 in sun).
vec3 dayLight(vec3 n, float sh) {
    float sky = 0.5 + 0.5 * n.y;
    float diff = max(dot(n, SUN_DIR), 0.0);
    float side = 1.0 - abs(n.y);
    return SKY_TINT * (0.36 + 0.18 * sky) + BOUNCE_COL * (0.17 * side) + SUN_COL * (1.1 * diff * sh);
}
"""

# The sky: a full-screen pass drawn first. Blue gradient, warm glow around the sun, thin stretched clouds that drift.



# Colour is baked into the mesh (face shade * block colour); the grass texture
# is multiplied in on top faces only.




def _compile_shader(src, kind):
    sh = gl.glCreateShader(kind)
    gl.glShaderSource(sh, src)
    gl.glCompileShader(sh)
    if not gl.glGetShaderiv(sh, gl.GL_COMPILE_STATUS):
        raise RuntimeError(gl.glGetShaderInfoLog(sh).decode())
    return sh

def _link_program(vs, fs):
    prog = gl.glCreateProgram()
    gl.glAttachShader(prog, vs)
    gl.glAttachShader(prog, fs)
    gl.glLinkProgram(prog)
    if not gl.glGetProgramiv(prog, gl.GL_LINK_STATUS):
        raise RuntimeError(gl.glGetProgramInfoLog(prog).decode())
    gl.glDeleteShader(vs)
    gl.glDeleteShader(fs)
    return prog



# ═══════════════════════════════════════════════
#  RAY-MARCHED TERRAIN (optional; launch command `raymarch`)
# ═══════════════════════════════════════════════
# Instead of building a triangle mesh for every chunk, the ground cubes are kept on the GPU as a 3-D grid (one byte per cube) and
# every pixel marches a ray through it. Digging is then just a small upload (no re-meshing), and the sun shadow map is drawn the
# same way, so the chunk meshes (and their worker processes) are not needed at all while this is on. The picture matches the
# mesh path: the same grass/dirt/sand/water rules, tiles, light, haze and shadows, and it writes the same depth, so
# structures, debris, effects and the HUD draw over it as before.
#   voxel grid  R8UI  1 = solid cube, 0 = air, one texel per ground cube over the whole map
#   brick grid  R8UI  1 where an 8x8x8 block of cubes holds anything: empty blocks are jumped over in one step
#   top grid    R16UI per cube column, how many cubes up to its highest solid one (the mesher's side-face rule needs it)

_RAY_BOUNDS_GLSL = """
// A screen rectangle only limits which pixels launch rays. It supplies no surface depth.
vec4 rayBounds(mat4 vp, vec3 lo, vec3 hi, out vec2 ndc) {
    vec2 mn = vec2(1.0), mx = vec2(-1.0);
    bool nearClip = false;
    bool visible = false;
    for (int i = 0; i < 8; ++i) {
        vec3 b = vec3(float(i & 1), float((i >> 1) & 1), float((i >> 2) & 1));
        vec4 p = vp * vec4(mix(lo, hi, b), 1.0);
        visible = visible || p.w > 0.0 && p.z >= -p.w;
        if (p.w <= 0.0 || p.z < -p.w) {
            nearClip = true;
        } else {
            vec2 q = p.xy / p.w;
            mn = min(mn, q);
            mx = max(mx, q);
        }
    }
    if (!visible) {
        ndc = vec2(2.0);
    } else {
        const vec2 corners[6] = vec2[6](vec2(0,0), vec2(1,0), vec2(1,1), vec2(0,0), vec2(1,1), vec2(0,1));
        ndc = mix(nearClip ? vec2(-1.0) : max(mn, vec2(-1.0)),
                  nearClip ? vec2(1.0) : min(mx, vec2(1.0)), corners[gl_VertexID]);
        if (!nearClip && (mn.x > 1.0 || mn.y > 1.0 || mx.x < -1.0 || mx.y < -1.0)) ndc = vec2(2.0);
    }
    return vec4(ndc, 0.0, 1.0);
}
"""

_RAY_SEGMENT_GLSL = """
uniform mat4 uInvVP;
void pixelRay(vec2 ndc, out vec3 origin, out vec3 direction) {
    vec4 a = uInvVP * vec4(ndc, -1.0, 1.0);
    vec4 b = uInvVP * vec4(ndc, 1.0, 1.0);
    origin = a.xyz / a.w;
    direction = normalize(b.xyz / b.w - origin);
}
"""










# ═══════════════════════════════════════════════
#  GPU & FRAME STATS
# ═══════════════════════════════════════════════
class GpuPoller:
    """Polls nvidia-smi on a background thread so it never stalls a frame.
    `stats` is None until the first reading, or if nvidia-smi isn't available."""
    QUERY = "utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw,clocks.sm,clocks.mem,fan.speed"

    def __init__(self, interval=0.5):
        self.interval = interval
        self.stats = None
        self.available = True
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    @staticmethod
    def _num(s):
        try:
            return float(s)
        except ValueError:
            return None   # nvidia-smi prints [N/A] for unsupported fields

    def _run(self):
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)   # no console flash on Windows
        while not self._stop.is_set():
            try:
                out = subprocess.run(
                    ["nvidia-smi", f"--query-gpu={self.QUERY}", "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=3, creationflags=flags)
                if out.returncode != 0 or not out.stdout.strip():
                    raise RuntimeError("nvidia-smi returned no data")
                f = [self._num(v.strip()) for v in out.stdout.strip().splitlines()[0].split(",")]
                f = (f + [None] * 8)[:8]
                self.stats = {'util': f[0], 'mem_used': f[1], 'mem_total': f[2],
                              'temp': f[3], 'power': f[4],
                              'clock_sm': f[5], 'clock_mem': f[6], 'fan': f[7]}
            except Exception:
                self.available = False
                self.stats = None
                return
            self._stop.wait(self.interval)

    def stop(self):
        self._stop.set()

DEBRIS_AMOUNT = 200    # default percent of physical debris spawned
DEBRIS_DETAIL_DEFAULT = 9
DEBRIS_SIZE_DEFAULT = 1.50
STRUCT_SHARDS = True   # broken cells crumble off as loose cubes (capped per hit, see _throw_chunks)
STRUCT_FALL_AS_BODY = False   # True: a big group of cells cut off from the ground becomes one loose rigid body that falls as a piece and breaks on landing (set by the bench)
STRUCT_BODY_MAX_CELLS = 8000  # a cut-off group bigger than this still crumbles into loose cubes (a rigid body that big is too slow to simulate)
STRUCT_KEEP_ALL = False       # True: _throw_chunks never samples cells away (set by the bench's 'Delete cubes' toggle)
BLAST_SQUEEZE = 1.0           # scale of the freshly spawned pile about the blast axis: <1 packs the cubes into each other, >1 spaces them out (the bench's 'Squeeze amount' sets it)
BLAST_KEEP = 1.0              # share of destroyed cells that become debris cubes; the rest are incinerated (the bench's 'Debris amount' slider)
BLAST_SPRAY = 0.35            # 0 = a tight narrow jet, 1 = a wide spray (the bench's 'Debris spread' slider sets it)
BLAST_SPEED = (4.0, 14.0)     # launch speed along the wall normal (m/s): a wide range stretches the debris into a plume, not a ball
BLAST_CONE = 0.8              # sideways fan per unit of BLAST_SPRAY (fraction of launch speed per blast-radius of lateral offset)
BLAST_DOME = 0.20             # outward lean at the rim of the blast even at zero spread, as a fraction of the launch speed: a blast throws a DOME of debris outward, not a column straight up the surface normal
BLAST_JITTER = 0.22           # random sideways lean given to every cube (fraction of the launch speed), so cubes do not fly up and land back in the lattice column they were cut from
BLAST_LATTICE_JITTER = 0.10   # random spawn offset, as a fraction of a cell: breaks the perfectly regular grid the destroyed cells sit on
BLAST_SPREAD = 1.2            # random sideways scatter (m/s) per unit of BLAST_SPRAY
BLAST_LIFT = 0.4              # small upward bias (m/s); it used to be 2.0, which tilted every plume skyward
STRUCT_DEBRIS_SPLIT = 1       # 1: a cell destroyed by a blast is thrown as exactly one cube of its own size. 2: the old way, eight half-size cubes per cell
# ═══════════════════════════════════════════════
#  PLAYER PHYSICS (AABB vs voxels, gravity, jump, fly toggle)
# ═══════════════════════════════════════════════
def _density_at(world, x, y, z):
    """+1 where the ground has a cube at this position, -1 where it is air (unloaded counts as air)."""
    v = world.cell(math.floor(x / CELL), math.floor(y / CELL), math.floor(z / CELL))
    return -1.0 if v is None else float(v)

def _box_hits_solid(world, x, y, z):
    """True if the player's body at feet position (x, y, z) is inside the solid surface.
    Samples a ring of points at the feet and at the head, so slopes and crater edges are felt."""
    r, h = PLAYER_RADIUS, PLAYER_HEIGHT
    ring = ((-r, -r), (-r, 0.0), (-r, r), (0.0, -r), (0.0, 0.0), (0.0, r), (r, -r), (r, 0.0), (r, r))
    for y_s in (y + 0.002, y + 0.55, y + 1.05, y + h - 0.05):
        for dx, dz in ring:
            if _density_at(world, x + dx, y_s, z + dz) > 0.0:
                return True
    return STRUCTS.hits_box(x, y, z, r, h)          # structures and loose bodies are solid too

# ═══════════════════════════════════════════════
#  SOUND EFFECTS. Every sound is built in numpy from a tone-and-noise recipe (the same recipes as the Block Pad
#  sound board), rendered once at start-up into pygame Sounds, and played by name from the places in the game where
#  things happen. No sound files. With no audio device everything here quietly does nothing.
#  Sounds that happen somewhere in the world are placed: quieter with distance, panned left / right.
# ═══════════════════════════════════════════════
import random as _random
try:
    from scipy.signal import lfilter as _sp_lfilter
except Exception:
    _sp_lfilter = None

SFX_VOLUME = 0.6            # master level, 0..1
SFX_HEARD = 70.0            # a placed sound further than this from the player is not played
SFX_FALLOFF = 9.0           # distance at which a placed sound is down to half volume


def _blep(t, dt):
    """PolyBLEP correction that smooths the jump in a square or saw wave, so high notes do not alias."""
    out = np.zeros_like(t)
    lo = t < dt
    x = t[lo] / dt[lo]
    out[lo] = x + x - x * x - 1.0
    hi = t > 1.0 - dt
    x = (t[hi] - 1.0) / dt[hi]
    out[hi] = x * x + x + x + 1.0
    return out


def _biquad(kind, f, q, sr):
    """Coefficients of a Web Audio style biquad. Low / high pass take Q in dB, band pass takes it linear."""
    f = min(max(float(f), 10.0), sr * 0.45)
    w0 = 2.0 * math.pi * f / sr
    cw = math.cos(w0)
    alpha = math.sin(w0) / (2.0 * (10.0 ** (q / 20.0) if kind != 'bandpass' else q))
    if kind == 'lowpass':
        b = [(1 - cw) / 2, 1 - cw, (1 - cw) / 2]
    elif kind == 'highpass':
        b = [(1 + cw) / 2, -(1 + cw), (1 + cw) / 2]
    else:
        b = [alpha, 0.0, -alpha]
    a = [1 + alpha, -2 * cw, 1 - alpha]
    return np.array(b) / a[0], np.array(a) / a[0]


def _run_biquad(b, a, x, z):
    if _sp_lfilter is not None:
        return _sp_lfilter(b, a, x, zi=z)
    b0, b1, b2, a1, a2 = b[0], b[1], b[2], a[1], a[2]
    z1, z2 = z
    y = []
    for xv in x.tolist():
        yv = b0 * xv + z1
        z1 = b1 * xv - a1 * yv + z2
        z2 = b2 * xv - a2 * yv
        y.append(yv)
    return np.array(y), (z1, z2)


def _filtered(x, kind, f, f2, dur, q, sr):
    """Filter x. With f2 the cutoff sweeps exponentially from f to f2 over dur seconds, then holds."""
    if not f2 or abs(f2 - f) < 1e-6:
        b, a = _biquad(kind, f, q, sr)
        return _run_biquad(b, a, x, np.zeros(2))[0]
    out = np.empty_like(x)
    z = np.zeros(2)
    block = 256
    for i0 in range(0, len(x), block):
        frac = min(((i0 + block / 2) / sr) / dur, 1.0)
        b, a = _biquad(kind, f * (f2 / f) ** frac, q, sr)
        out[i0:i0 + block], z = _run_biquad(b, a, x[i0:i0 + block], z)
    return out


class _Synth:
    """Collects the tones and noise bursts of one sound. T and N take the same options as the Block Pad's."""

    def __init__(self, sr, rng):
        self.sr, self.rng = sr, rng
        self.layers = []                 # (start sample, samples)
        self.vs, self.ds = 1.0, 0.0      # volume scale and delay of the sound being layered in
        self.random = False              # True once the recipe used rnd(): that sound is worth several variants

    def rnd(self, a, b):
        self.random = True
        return a + (b - a) * self.rng.random()

    def layer(self, name, vol=1.0, delay=0.0):
        """Mix another recipe into this one."""
        old = (self.vs, self.ds)
        self.vs *= vol
        self.ds += delay
        SFX_RECIPES[name](self)
        self.vs, self.ds = old

    def T(self, type='square', f=440.0, f2=None, dur=0.2, vol=0.3, a=0.005, delay=0.0, lp=None, vib=None, vibDepth=20.0):
        sr = self.sr
        n = int((dur + 0.05) * sr)
        t = np.arange(n) / sr
        freq = f * (f2 / f) ** (np.minimum(t, dur) / dur) if f2 else np.full(n, float(f))
        if vib:
            freq = freq + vibDepth * np.sin(2 * math.pi * vib * t)
        freq = np.maximum(freq, 1.0)
        ph = (np.cumsum(freq) / sr) % 1.0
        dt = np.minimum(freq / sr, 0.49)
        if type == 'sine':
            w = np.sin(2 * math.pi * ph)
        elif type == 'triangle':
            w = 2.0 * np.abs(2.0 * ph - 1.0) - 1.0
        elif type == 'sawtooth':
            w = 2.0 * ph - 1.0 - _blep(ph, dt)
        else:
            w = np.where(ph < 0.5, 1.0, -1.0) + _blep(ph, dt) - _blep((ph + 0.5) % 1.0, dt)
        env = np.zeros(n)
        m1 = t < a
        env[m1] = 0.0001 + (vol - 0.0001) * t[m1] / a
        m2 = (t >= a) & (t < dur)
        env[m2] = vol * (0.0001 / vol) ** ((t[m2] - a) / max(dur - a, 1e-4))
        y = w * env
        if lp:
            y = _filtered(y, 'lowpass', lp, None, dur, 1.0, sr)
        self.layers.append((int((delay + self.ds) * sr), y * self.vs))

    def N(self, type='lowpass', f=1000.0, f2=None, dur=0.2, vol=0.3, a=0.003, delay=0.0, q=1.0, swell=False):
        sr = self.sr
        n = int((dur + 0.05) * sr)
        t = np.arange(n) / sr
        x = _filtered(self.noise(n), type, f, f2, dur, q, sr)
        env = np.zeros(n)
        m1 = t < a
        env[m1] = 0.0001 + (vol - 0.0001) * t[m1] / a
        if swell:
            m2 = (t >= a) & (t < dur * 0.8)
            env[m2] = vol
            m3 = (t >= dur * 0.8) & (t < dur)
            env[m3] = vol * (1.0 - (t[m3] - dur * 0.8) / (dur * 0.2))
        else:
            m2 = (t >= a) & (t < dur)
            env[m2] = vol * (0.0001 / vol) ** ((t[m2] - a) / max(dur - a, 1e-4))
        self.layers.append((int((delay + self.ds) * sr), x * env * self.vs))

    def noise(self, n):
        return self.np_rng.uniform(-1.0, 1.0, n)

    def mix(self):
        end = max((s + len(y) for s, y in self.layers), default=1)
        buf = np.zeros(end)
        for s, y in self.layers:
            buf[s:s + len(y)] += y
        return buf


def _note_hz(m):
    return 440.0 * 2.0 ** ((m - 69) / 12.0)


# Force 1.0 .. 5.0 in half steps is nine pling notes climbing a major scale from middle C.
PLING_SCALE = (0, 2, 4, 5, 7, 9, 11, 12, 14)


def _pling(deg):
    def r(s):
        f = _note_hz(60 + deg)
        s.T(type='square', f=f, dur=.35, vol=.15, lp=2500)
        s.T(type='sine', f=f * 2, dur=.3, vol=.2)
    return r


SFX_RECIPES = {
    # blocks
    'break_stone': lambda s: (s.N(f=2500, f2=400, dur=.28, vol=.5), s.N(type='highpass', f=3000, dur=.08, vol=.3),
                              s.T(type='square', f=140, f2=50, dur=.15, vol=.2)),
    'break_wood': lambda s: (s.T(type='triangle', f=260, f2=90, dur=.14, vol=.5), s.N(type='bandpass', f=900, dur=.15, vol=.4, q=2),
                             s.T(type='triangle', f=180, f2=70, dur=.12, vol=.3, delay=.07)),
    'break_gravel': lambda s: ([s.N(type='highpass', f=s.rnd(1200, 2800), dur=.06, vol=.3, delay=i * s.rnd(.02, .04)) for i in range(9)],
                               s.N(f=900, dur=.3, vol=.3)),
    'break_grass': lambda s: (s.N(type='bandpass', f=1800, f2=900, dur=.18, vol=.5, q=.8),
                              s.N(type='highpass', f=4000, dur=.1, vol=.2, delay=.03)),
    'place_block': lambda s: (s.T(type='sine', f=160, f2=60, dur=.12, vol=.7), s.N(f=700, f2=200, dur=.1, vol=.4)),
    'pickaxe_tink': lambda s: (s.T(type='square', f=1900, f2=1400, dur=.05, vol=.2), s.T(type='triangle', f=900, f2=700, dur=.08, vol=.25),
                               s.N(type='highpass', f=4000, dur=.04, vol=.3)),
    'glass_break': lambda s: (s.N(type='highpass', f=3500, dur=.35, vol=.5),
                              [s.T(type='sine', f=s.rnd(2500, 6000), dur=.12, vol=.1, delay=s.rnd(0, .3)) for _ in range(10)]),
    'anvil': lambda s: (s.T(type='square', f=700, dur=.5, vol=.25), s.T(type='square', f=1130, dur=.4, vol=.2),
                        s.T(type='triangle', f=1870, dur=.3, vol=.15), s.N(type='highpass', f=3000, dur=.05, vol=.4)),
    # steps and the player
    'step_grass': lambda s: s.N(type='bandpass', f=s.rnd(1500, 2200), dur=.1, vol=.45, q=.7),
    'step_sand': lambda s: s.N(type='bandpass', f=3000, f2=1500, dur=.14, vol=.35, q=.5),
    'step_stone': lambda s: (s.N(f=1400, f2=300, dur=.09, vol=.5), s.T(type='sine', f=110, f2=60, dur=.08, vol=.3)),
    'jump': lambda s: (s.T(type='sine', f=180, f2=320, dur=.08, vol=.2), s.N(type='bandpass', f=1500, dur=.06, vol=.12)),
    'fall_damage': lambda s: (s.T(type='sine', f=130, f2=40, dur=.25, vol=.7), s.N(f=1200, f2=150, dur=.2, vol=.45)),
    # loot and interface
    'level_up': lambda s: ([s.T(type='triangle', f=f, dur=.3, vol=.28, delay=i * .09) for i, f in enumerate((523, 659, 784, 1047, 1319))],
                           s.T(type='sine', f=2093, dur=.6, vol=.1, delay=.45)),
    'item_pickup': lambda s: (s.T(type='sine', f=500, f2=1000, dur=.1, vol=.3), s.T(type='sine', f=700, f2=1400, dur=.08, vol=.15, delay=.03)),
    'chest_open': lambda s: (s.T(type='sawtooth', f=90, f2=260, dur=.45, vol=.25, lp=700, vib=14, vibDepth=20),
                             s.N(type='bandpass', f=1500, dur=.3, vol=.12, delay=.1), s.T(type='sine', f=100, f2=50, dur=.1, vol=.5, delay=.45)),
    'chest_close': lambda s: (s.T(type='sawtooth', f=240, f2=90, dur=.3, vol=.2, lp=700), s.T(type='sine', f=130, f2=45, dur=.12, vol=.7, delay=.28),
                              s.N(f=900, dur=.08, vol=.3, delay=.28)),
    'armor_equip': lambda s: (s.N(type='highpass', f=3000, dur=.1, vol=.3), s.T(type='square', f=1200, f2=900, dur=.07, vol=.12),
                              s.T(type='triangle', f=600, f2=400, dur=.1, vol=.2, delay=.04)),
    'totem': lambda s: ([s.T(type='sine', f=s.rnd(900, 3000), dur=.4, vol=.08, delay=i * .05) for i in range(14)],
                        [s.T(type='triangle', f=f, dur=.9, vol=.2, delay=.2 + i * .04) for i, f in enumerate((392, 494, 587, 784))]),
    'ui_click': lambda s: (s.T(type='square', f=900, f2=600, dur=.04, vol=.18), s.N(type='highpass', f=4000, dur=.02, vol=.2)),
    'door_open': lambda s: (s.T(type='sawtooth', f=110, f2=200, dur=.25, vol=.2, lp=600, vib=20, vibDepth=20),
                            s.T(type='triangle', f=180, f2=90, dur=.08, vol=.3, delay=.22)),
    'door_close': lambda s: (s.T(type='sine', f=160, f2=60, dur=.1, vol=.7), s.N(f=900, f2=200, dur=.1, vol=.45),
                             s.T(type='triangle', f=300, f2=150, dur=.05, vol=.2, delay=.04)),
    'bucket_fill': lambda s: (s.N(type='bandpass', f=600, f2=1800, dur=.45, vol=.4, q=1), s.T(type='sine', f=300, f2=700, dur=.4, vol=.15, vib=12, vibDepth=30)),
    'bell': lambda s: [s.T(type='sine', f=f, dur=2.2 - i * .5, vol=.28 / (i + 1)) for i, f in enumerate((880, 1760, 2637))],
    'ender_pearl': lambda s: (s.T(type='sine', f=300, f2=1400, dur=.3, vol=.3), s.N(type='bandpass', f=2000, f2=800, dur=.25, vol=.25, delay=.15, q=2),
                              s.T(type='triangle', f=1400, f2=400, dur=.2, vol=.2, delay=.25)),
    # world and weapons
    'explosion': lambda s: (s.N(f=2000, f2=60, dur=1.6, vol=.9), s.T(type='sine', f=90, f2=25, dur=1.2, vol=.9), s.N(f=300, f2=40, dur=2, vol=.5, delay=.1)),
    'thunder': lambda s: (s.N(f=500, f2=80, dur=3, vol=1, a=.05), s.N(f=200, f2=40, dur=3, vol=.6, a=.3, delay=.2)),
    'lava_pop': lambda s: (s.T(type='sine', f=150, f2=550, dur=.1, vol=.45), s.N(type='bandpass', f=900, dur=.1, vol=.3, q=2),
                           s.T(type='sine', f=200, f2=650, dur=.08, vol=.3, delay=.15)),
    'bow_shot': lambda s: (s.T(type='triangle', f=260, f2=90, dur=.12, vol=.5), s.N(type='bandpass', f=2500, f2=600, dur=.22, vol=.3, q=1.5),
                           s.T(type='sine', f=1200, f2=2200, dur=.2, vol=.05, delay=.05)),
    'arrow_hit': lambda s: (s.T(type='square', f=420, f2=160, dur=.06, vol=.3), s.T(type='triangle', f=240, f2=120, dur=.1, vol=.4),
                            s.N(type='highpass', f=3000, dur=.04, vol=.2)),
    # the universal block hit
    'block_hit': lambda s: (s.T(type='sine', f=150, f2=55, dur=.14, vol=.6), s.N(type='bandpass', f=1400, f2=500, dur=.09, vol=.45, q=.9),
                            s.N(f=2200, f2=300, dur=.07, vol=.25), s.T(type='triangle', f=620, f2=320, dur=.05, vol=.12)),
}
# Sounds made by mixing others, or the high part of one.
SFX_RECIPES['axe_swing'] = lambda s: (s.N(type='bandpass', f=2500, f2=600, dur=.22, vol=.42, q=1.5),
                                      s.T(type='sine', f=1200, f2=2200, dur=.2, vol=.07, delay=.05))
SFX_RECIPES['gun_shot'] = lambda s: (s.N(type='highpass', f=1800, f2=500, dur=.09, vol=.5),
                                     s.T(type='square', f=260, f2=70, dur=.08, vol=.3),
                                     s.N(type='bandpass', f=700, f2=200, dur=.16, vol=.25, q=.8, delay=.01))
SFX_RECIPES['collapse'] = lambda s: (s.layer('explosion', 1.0), s.layer('anvil', 0.6, delay=0.12), s.layer('thunder', 0.9, delay=0.08))
SFX_RECIPES['body_land'] = lambda s: (s.layer('fall_damage', 1.0), s.layer('break_stone', 0.8, delay=0.02))
for _i, _d in enumerate(PLING_SCALE):
    SFX_RECIPES['pling_%d' % _i] = _pling(_d)

SFX_LOOPS = ('laser',)      # sounds rendered as seamless loops (see SoundFX._render_loop)


class SoundFX:
    """Plays the game's sounds by name. All methods are safe to call with no audio: they do nothing."""
    GAP = {'step_grass': 0.1, 'step_sand': 0.1, 'step_stone': 0.07, 'break_gravel': 0.05, 'pickaxe_tink': 0.05,
           'break_stone': 0.06, 'break_wood': 0.06, 'glass_break': 0.08, 'body_land': 0.12, 'collapse': 1.2,
           'lava_pop': 0.0, 'ui_click': 0.02}
    VARIANTS = 4            # how many renders of a sound that uses random numbers

    def __init__(self):
        self.ok = False
        self.error = None
        self.bank = {}
        self.last = {}
        self.pending = []
        self.loops = {}
        self.eye = None
        self.yaw = 0.0
        self.sr = 44100
        self.ch = 2

    # ---- set-up ---------------------------------------------------------------------------------------
    def init(self, progress=None):
        """Open the mixer and render every sound. progress(text) is called now and then (the loading screen)."""
        self.ok = False
        self.error = None
        self.bank.clear()
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(44100, -16, 2, 512)
            self.sr, fmt, self.ch = pygame.mixer.get_init()
            if fmt != -16 or self.ch not in (1, 2):
                pygame.mixer.quit()
                pygame.mixer.init(44100, -16, 2, 512, allowedchanges=0)
                self.sr, fmt, self.ch = pygame.mixer.get_init()
            if fmt != -16:
                raise RuntimeError("mixer format %s is not 16-bit" % fmt)
            pygame.mixer.set_num_channels(32)
        except Exception as ex:
            self.error = "audio mixer unavailable: %s: %s" % (type(ex).__name__, ex)
            print("Sound: off (%s)" % self.error)
            return
        rng = _random.Random(1234)
        names = list(SFX_RECIPES)
        try:
            for k, name in enumerate(names):
                if progress and k % 10 == 0:
                    progress("%d of %d" % (k, len(names)))
                self.bank[name] = self._render(name, rng)
            for name in SFX_LOOPS:
                self.bank[name] = [self._render_loop(name, rng)]
            self.ok = True
            print("Sound: on (%d effects, %d Hz, %d channel%s)" %
                  (len(self.bank), self.sr, self.ch, "s" if self.ch != 1 else ""))
        except Exception as ex:
            self.bank.clear()
            self.error = "sound rendering failed: %s: %s" % (type(ex).__name__, ex)
            print("Sound: off (%s)" % self.error)

    def _synth(self, rng):
        s = _Synth(self.sr, rng)
        s.np_rng = np.random.default_rng(rng.randrange(1 << 30))
        return s

    def _sound(self, buf):
        y = buf * SFX_VOLUME
        pk = float(np.abs(y).max())
        if 1e-6 < pk < 0.8:
            y = y * (0.8 / pk) ** 0.7                        # quiet recipes (a footstep, thunder) are lifted part of the way
        y = np.tanh(y)
        a = (np.clip(y, -1.0, 1.0) * 32767).astype(np.int16)
        if self.ch == 2:
            a = np.ascontiguousarray(np.column_stack([a, a]))
        return pygame.sndarray.make_sound(a)

    def _render(self, name, rng):
        out = []
        for v in range(self.VARIANTS):
            s = self._synth(rng)
            SFX_RECIPES[name](s)
            out.append(self._sound(s.mix()))
            if not s.random:
                break                                        # nothing random in it: one render is enough
        return out

    def _render_loop(self, name, rng):
        """The laser: a Nether-portal style hum (steady tones with a slow wobble) and a bed of fire crackle. Every
        part repeats exactly over the loop, and the ends are crossfaded, so it can run for as long as the beam does."""
        sr = self.sr
        L = int(2.0 * sr)
        X = int(0.25 * sr)
        t = np.arange(L + X) / sr
        s = self._synth(rng)
        hum = np.zeros(L + X)
        for f, vol, vib, depth in ((110.0, .30, 3.0, 25.0), (222.0, .15, 4.0, 30.0)):
            ph = 2 * math.pi * (f * t - depth / (2 * math.pi * vib) * np.cos(2 * math.pi * vib * t))
            hum += vol * np.sin(ph)
        bed = _filtered(s.noise(L + X), 'bandpass', 700.0, None, 1.0, 2.0, sr) * (0.5 + 0.5 * np.sin(2 * math.pi * 0.5 * t)) * 0.5
        s.layers.append((0, hum + bed))
        for _ in range(26):
            s.N(type='highpass', f=rng.uniform(2000, 5000), dur=.03, vol=.28, delay=rng.uniform(0, 2.0))
        buf = s.mix()[:L + X]
        buf = np.pad(buf, (0, max(0, L + X - len(buf))))
        w = np.linspace(0.0, 1.0, X)
        out = buf[:L].copy()
        out[:X] = buf[:X] * w + buf[L:L + X] * (1.0 - w)
        return self._sound(out * 0.55)

    # ---- playing --------------------------------------------------------------------------------------

    def play(self, name, vol=1.0, pos=None, gap=None, delay=0.0):
        """Play a sound. pos = where it happens in the world (None = on the player). gap = least seconds since the
        last play of this same sound. delay = seconds from now."""
        if not self.ok:
            return None
        now = time.perf_counter()
        if delay > 0.0:
            self.pending.append((now + delay, name, vol, pos, gap))
            return None
        g = self.GAP.get(name, 0.03) if gap is None else gap
        if now - self.last.get(name, -9.0) < g:
            return None
        variants = self.bank.get(name)
        if not variants:
            if name not in self.bank and self.error is None:
                logging.warning("SFX name %r is missing from the sound bank", name)
            return None
        left = right = 1.0
        if pos is not None and self.eye is not None:
            d = np.asarray(pos, np.float64) - self.eye
            dist = float(np.linalg.norm(d))
            if dist > SFX_HEARD:
                return None
            vol *= 1.0 / (1.0 + (dist / SFX_FALLOFF) ** 2)
            flat = math.hypot(d[0], d[2])
            pan = 0.0 if flat < 0.5 else (d[0] * math.cos(self.yaw) + d[2] * math.sin(self.yaw)) / flat
            ang = (pan + 1.0) * math.pi / 4.0
            left, right = math.cos(ang) * 1.414, math.sin(ang) * 1.414
        vol = min(vol, 1.5)
        if vol < 0.01:
            return None
        self.last[name] = now
        ch = _random.choice(variants).play()
        if ch is not None:
            ch.set_volume(min(1.0, vol * left), min(1.0, vol * right))
        return ch

    def tick(self):
        """Start the sounds that were asked for with a delay. Call once a frame."""
        if not self.pending:
            return
        now = time.perf_counter()
        due = [p for p in self.pending if p[0] <= now]
        if due:
            self.pending = [p for p in self.pending if p[0] > now]
            for _, name, vol, pos, gap in due:
                self.play(name, vol, pos, gap)

    # ---- things that happen in the game ---------------------------------------------------------------------
    def step(self, sprint=False):
        self.play(_random.choice(('step_grass', 'step_grass', 'step_sand')), 0.55 if not sprint else 0.65)

    def land(self, speed):
        """The player came down at this speed (blocks per second)."""
        if speed > 14.0:
            self.play('fall_damage', min(1.0, 0.5 + (speed - 14.0) * 0.04), gap=0.15)
        elif speed > 5.0:
            self.play('place_block', min(0.9, 0.3 + (speed - 5.0) * 0.07), gap=0.15)


    def crack(self, pos):
        """A bond in a structure gave way."""
        self.play(_random.choice(('pickaxe_tink', 'arrow_hit')), 0.35, pos, gap=0.09)

    def collapse(self, pos, volume):
        """A piece of a structure broke away; volume = how many blocks of it."""
        if volume >= 1.5:
            self.play('collapse', min(1.0, 0.35 + 0.06 * volume), pos)

    def body_land(self, pos, speed, volume):
        self.play('body_land', min(1.0, (0.15 + 0.07 * speed) * (0.5 + min(volume, 4.0) * 0.15)), pos)


    def settle(self, pos, count):
        """Dirt cubes came to rest. Quiet, and only some of them are heard."""
        if _random.random() < 0.45:
            self.play(_random.choice(('step_sand', 'break_gravel')), min(0.3, 0.1 + 0.01 * count), pos, gap=0.12)

    def bounce(self, pos, speed):
        self.play('step_stone', min(1.0, 0.2 + speed * 0.05), pos, gap=0.05)


SFX = SoundFX()





# ═══════════════════════════════════════════════
#  MAIN LOOP (WASD + mouse, Space jump, F pause, V fly, 2-5 hotbar, LMB break, RMB place, Tab menu)
# ═══════════════════════════════════════════════



# ═══════════════════════════════════════════════
#  DEBRIS SETTINGS
# ═══════════════════════════════════════════════
CONFIG = {'debris_on': True, 'debris_amount': DEBRIS_AMOUNT / 100.0, 'debris_detail': DEBRIS_DETAIL_DEFAULT, 'debris_size': DEBRIS_SIZE_DEFAULT, 'debris_limit': False}


def debris_cell_size():
    """Physical cube side length before the spawn effect applies its own scale."""
    return CONFIG['debris_size'] / CONFIG['debris_detail']

_NEIGH_OFFS = np.array([-1099512676353, -1099512676352, -1099512676351, -1099511627777, -1099511627776, -1099511627775, -1099510579201, -1099510579200, -1099510579199, -1048577, -1048576, -1048575, -1, 0, 1, 1048575, 1048576, 1048577, 1099510579199, 1099510579200, 1099510579201, 1099511627775, 1099511627776, 1099511627777, 1099512676351, 1099512676352, 1099512676353], np.int64)   # the 27 cells around a cube's cell, as key offsets
_rng = np.random.default_rng()


# ═══════════════════════════════════════════════
#  DUG DIRT: each dug block splits into mini cubes that fly out and land
# ═══════════════════════════════════════════════
WASH_DELAY     = 2.0                 # seconds a cube lies under water before it starts to wash away
WASH_FADE      = 1.5                 # seconds it then takes to shrink away
BODY_MAX       = 12000               # cap on cubes alive at once (oldest go first); only applies when CONFIG['debris_limit'] is on, which is off by default
MAX_AWAKE_CUBES = 500               # cubes simulated per frame; the slowest beyond this are put to sleep
HARD_AWAKE_CUBES = 700              # most cubes simulated in one frame even in flight; beyond this they take turns (see update)
BODY_GRAVITY   = 14.0                # blocks per second squared
BODY_MAX_FALL  = 9.0                 # terminal speed, blocks per second
BODY_FRICTION  = 6.0                 # sideways slow-down
SUBSTEP_MAX    = 0.05                # longest single debris step in seconds; a longer step (a time-sliced group) is split
SEP_WAKE_DEPTH  = 0.06                # blocks: overlap with a neighbour deeper than this keeps a cube awake (0.02 left packed crater piles awake for good)
JAM_MOVE       = 0.10                # blocks per second: a cube that is flagged as perched off-centre, or pushed hard, but moves less than this is wedged by its neighbours, not toppling or sliding
PROGRESS_R     = 0.05                # blocks: a cube that stays within this distance of one spot...
PROGRESS_TIME  = 1.0                 # ...for this many seconds is at rest, however much it shakes (0 switches the rule off). A pile in a narrow hole can vibrate for ever: each cube travels about 0.9 blocks a second and gets nowhere (0.005 blocks)
JAM_TIME_MUL   = 3.0                 # a wedged cube must stay put this many times longer than the usual sleep time before it sleeps (0 for JAM_MOVE switches the rule off)

def _sample_many(world, X, Y, Z):
    """Ground cubes at integer cube indices, for arrays: +1 solid, -1 air. Below the world is solid, above it is air,
    and unloaded chunks are air."""
    vals = np.full(len(X), -1.0, np.float64)
    vals[Y < 0] = 1.0
    inside = (Y >= 0) & (Y < NH)
    cx = np.floor_divide(X, NC)
    cz = np.floor_divide(Z, NC)
    ckey = (cx + 100000) * 200000 + (cz + 100000)                # 1-D keys: much faster than unique(axis=0)
    keys = ckey[:1] if len(ckey) and (ckey == ckey[0]).all() else np.unique(ckey)   # most batches sit in one chunk
    for kk in keys.tolist():
        kx, kz = kk // 200000 - 100000, kk % 200000 - 100000
        d = world.dens.get((kx, kz))
        if d is None:
            continue
        m = inside & (cx == kx) & (cz == kz)
        if not m.any():
            continue
        vals[m] = d.sample(X[m] - kx * NC, Y[m], Z[m] - kz * NC)
    return vals

def _density_many(world, P):
    """Solid (+1) or air (-1) at many world points: the ground cube each point is inside."""
    if len(P) == 0:
        return np.zeros(0, np.float64)
    c = np.floor(np.asarray(P, np.float64) / CELL).astype(np.int64)
    return _sample_many(world, c[:, 0], c[:, 1], c[:, 2])

def _cell_contact(world, Q, reach=0.06):
    """Where points sit against the ground cubes. For a point inside a cube: how far it is from the nearest face that opens
    to air, and the direction out. For a point just outside: the (negative) gap to the nearest solid face within `reach`.
    Returns (depth (m,), normal (m, 3), ok (m,)); ok is False for points that are neither inside nor within reach."""
    Q = np.asarray(Q, np.float64)
    m = len(Q)
    c = np.floor(Q / CELL).astype(np.int64)
    dirs = np.array([(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)], np.int64)
    here = _sample_many(world, c[:, 0], c[:, 1], c[:, 2]) > 0
    nb = np.stack([_sample_many(world, c[:, 0] + d[0], c[:, 1] + d[1], c[:, 2] + d[2]) > 0 for d in dirs], axis=1)   # (m, 6)
    lo = c * CELL
    hi = lo + CELL
    # distance from the point to each of the six faces of its own cube, and to the face it would meet in each neighbour
    face = np.stack([hi[:, 0] - Q[:, 0], Q[:, 0] - lo[:, 0], hi[:, 1] - Q[:, 1], Q[:, 1] - lo[:, 1],
                     hi[:, 2] - Q[:, 2], Q[:, 2] - lo[:, 2]], axis=1)                       # (m, 6)
    inside_d = np.where(~nb, face, np.inf)                                                  # leaving through a face that is open
    k_in = np.argmin(inside_d, axis=1)
    d_in = inside_d[np.arange(m), k_in]
    out_d = np.where(nb, face, np.inf)                                                      # a solid neighbour: the gap to its face
    k_out = np.argmin(out_d, axis=1)
    d_out = out_d[np.arange(m), k_out]
    deep = here & ~np.isfinite(d_in)                                                        # boxed in on every side: push up
    k_in = np.where(deep, 2, k_in)
    d_in = np.where(deep, face[:, 2] + CELL, d_in)
    depth = np.where(here, d_in, -d_out)
    k = np.where(here, k_in, k_out)
    n = dirs[k].astype(np.float64)
    n = np.where(here[:, None], n, -n)                                                      # inside: out through the open face; outside: away from the solid
    ok = here | (d_out <= reach)
    return depth, n, ok

def _density_batch(world, point_sets):
    """Several _density_many calls in one batched sample. Returns one array per point set.
    Each density value is independent of the others, so the results are the same as separate calls."""
    sizes = [len(p) for p in point_sets]
    if sum(sizes) == 0:
        return [np.zeros(0, np.float64) for _ in point_sets]
    out = _density_many(world, np.concatenate(point_sets))
    return np.split(out, np.cumsum(sizes)[:-1])

def _corners_touching(world, P, size):
    """(m, 4) bool: which of each cube's four bottom corners sit inside terrain."""
    m = len(P)
    pts = np.repeat(P, 4, axis=0)
    off = np.array([[0.4, 0.4], [0.4, -0.4], [-0.4, 0.4], [-0.4, -0.4]])
    s_rep = np.repeat(size, 4)
    pts[:, 0] += np.tile(off[:, 0], m) * s_rep
    pts[:, 2] += np.tile(off[:, 1], m) * s_rep
    pts[:, 1] -= np.repeat(size, 4) * 0.5
    return (_density_many(world, pts) > 0.0).reshape(m, 4)

def _struct_corners(P, size):
    """(m, 4) bool: which bottom corners sit inside a fixed structure or a loose rigid body."""
    m = len(P)
    out = np.zeros((m, 4), bool)
    objs = STRUCTS.objects()
    if m == 0 or not objs:
        return out
    pts = np.repeat(P, 4, axis=0)
    off = np.array([[0.4, 0.4], [0.4, -0.4], [-0.4, 0.4], [-0.4, -0.4]])
    s_rep = np.repeat(size, 4)
    pts[:, 0] += np.tile(off[:, 0], m) * s_rep
    pts[:, 2] += np.tile(off[:, 1], m) * s_rep
    pts[:, 1] -= s_rep * 0.5
    flat = out.reshape(-1)                     # view: writes land in out
    for O in objs:
        lo, hi = O.aabb()
        near = np.nonzero(((pts >= lo - 0.05) & (pts <= hi + 0.05)).all(axis=1))[0]
        if not len(near):
            continue
        sel, _, _ = O.probe(pts[near])
        flat[near[sel]] = True
    return out

def _support(world, P, size):
    """(m, 4) bool: which bottom corners are on the ground, counting a corner that is within 0.05 above it."""
    Q = P.copy()
    Q[:, 1] -= 0.05
    return _corners_touching(world, Q, size) | _struct_corners(Q, size)

def _downhill(world, P, size):
    """Unit horizontal direction pointing down the slope under each cube (zero on flat ground)."""
    e = 0.3 * size
    yb = P[:, 1] - size * 0.5 - 0.05
    def at(dx, dz):
        return np.stack([P[:, 0] + dx, yb, P[:, 2] + dz], axis=1)
    d = _density_batch(world, [at(e, 0.0), at(-e, 0.0), at(0.0, e), at(0.0, -e)])
    gx = d[0] - d[1]
    gz = d[2] - d[3]
    g = np.stack([gx, gz], axis=1)
    n = np.linalg.norm(g, axis=1, keepdims=True)
    return np.where(n > 1e-9, -g / np.maximum(n, 1e-9), 0.0)


def _struct_push(P, size):
    """For each cube whose bottom corners are inside a structure or loose body: the shortest move that takes it
    out (along the nearest exposed face's normal), and which cubes needed one. Returns (push (m,3), hit (m,))."""
    m = len(P)
    push = np.zeros((m, 3))
    hit = np.zeros(m, bool)
    objs = STRUCTS.objects()
    if m == 0 or not objs:
        return push, hit
    pts = np.repeat(P, 4, axis=0)
    off = np.array([[0.4, 0.4], [0.4, -0.4], [-0.4, 0.4], [-0.4, -0.4]])
    s_rep = np.repeat(size, 4)
    pts[:, 0] += np.tile(off[:, 0], m) * s_rep
    pts[:, 2] += np.tile(off[:, 1], m) * s_rep
    pts[:, 1] -= s_rep * 0.5
    best = np.zeros(m)
    for O in objs:
        lo, hi = O.aabb()
        near = np.nonzero(((pts >= lo - 0.05) & (pts <= hi + 0.05)).all(axis=1))[0]
        if not len(near):
            continue
        sel, depth, normal = O.probe(pts[near])
        if not len(sel):
            continue
        cube = near[sel] // 4
        for c, dp, nm in zip(cube.tolist(), depth.tolist(), normal):
            if dp > best[c]:
                best[c] = dp
                push[c] = nm * (dp + 0.01)
                hit[c] = True
    return push, hit

def _terrain_push(world, P, size):
    """For cubes with the underside middle or any bottom corner inside the ground: a move out of the cube that holds the deepest
    of those points. Catches cubes wedged against a wall by one corner. Returns (push (m,3), hit (m,))."""
    m = len(P)
    off = np.array([[0.0, 0.0], [0.4, 0.4], [0.4, -0.4], [-0.4, 0.4], [-0.4, -0.4]])
    pts = np.repeat(P, 5, axis=0)
    s5 = np.repeat(size, 5)
    pts[:, 0] += np.tile(off[:, 0], m) * s5
    pts[:, 2] += np.tile(off[:, 1], m) * s5
    pts[:, 1] -= s5 * 0.5
    inside = (_density_many(world, pts) > 0.0).reshape(m, 5)
    hit = inside.any(axis=1)
    push = np.zeros_like(P)
    if not hit.any():
        return push, hit
    depth, nrm, _ = _cell_contact(world, pts)
    depth = np.where(inside.reshape(-1), depth, -1.0).reshape(m, 5)
    k = np.argmax(depth, axis=1)
    sel = np.nonzero(hit)[0]
    kk = k[sel]
    d = depth[sel, kk]
    n = nrm.reshape(m, 5, 3)[sel, kk]
    push[sel] = n * (d + 0.005)[:, None]
    return push, hit

def _extra_debris(positions, sizes, amount):
    """Return extra cube positions and their source indices for amounts above 100%."""
    source = np.flatnonzero(_rng.random(len(positions)) < amount - 1.0)
    offset = _rng.uniform(-0.25, 0.25, (len(source), 3))
    offset[:, 1] += 0.55
    return positions[source] + offset * sizes[source, None], source


class DirtCubes:
    """Mini dirt cubes. Simulated as numpy arrays: gravity, collision with the ground cubes, and sleep
    for cubes at rest. Cubes do not collide with each other, so they can overlap."""
    def __init__(self):
        self.clear()

    def clear(self):
        self.pos = np.zeros((0, 3), np.float64)
        self.vel = np.zeros((0, 3), np.float64)
        self.size = np.zeros(0, np.float64)
        self.shade = np.zeros(0, np.float64)
        self.awake = np.zeros(0, bool)
        self.still = np.zeros(0, np.float64)            # seconds each cube has been at rest
        self.wet = np.zeros(0, np.float64)              # seconds each cube has been under water: it washes away
        self.anc = np.zeros((0, 4), np.float64)         # progress anchor: x, y, z of the spot it was last somewhere new, then seconds it has stayed near that spot
        self.flight = np.zeros(0, np.float64)  # seconds of straight flight remaining for aimed shots
        self._wet_acc = 0.0
        self.col = np.zeros((0, 3), np.float64)         # colour of each cube
        self.tile = np.empty(0, np.float32)             # terrain texture layer, or -1 for plain colour

    @property
    def n(self):
        return len(self.pos)

    def remove(self, mask):
        """Delete the cubes where `mask` is True."""
        keep = ~np.asarray(mask, bool)
        self.pos, self.vel = self.pos[keep], self.vel[keep]
        self.size, self.shade, self.awake = self.size[keep], self.shade[keep], self.awake[keep]
        self.still, self.wet, self.col = self.still[keep], self.wet[keep], self.col[keep]
        self.anc = self.anc[keep]
        self.flight = self.flight[keep]
        self.tile = self.tile[keep]

    def wake_all(self):
        """Wake every cube so it re-checks what it rests on (called when the ground or a structure changes)."""
        self.awake[:] = True
        self.still[:] = 0.0

    def wake_sphere(self, centre, radius, column_up=0.0):
        """Wake only the cubes near `centre`: those whose centre lies within radius (plus their own size) of it.
        column_up > 0 also wakes cubes stacked above the centre in the same column, since a pile resting on a
        dug-out spot loses its support from below. Everything else stays asleep."""
        if self.n == 0:
            return
        c = np.asarray(centre, np.float64)
        d = self.pos - c
        reach2 = (radius + self.size) ** 2
        hit = (d * d).sum(axis=1) <= reach2
        if column_up > 0.0:
            column = ((d[:, 0] ** 2 + d[:, 2] ** 2) <= reach2) & (self.pos[:, 1] >= c[1] - radius - 1.0) \
                     & (self.pos[:, 1] <= c[1] + column_up)
            hit |= column
        self.awake[hit] = True
        self.still[hit] = 0.0

    def spawn(self, world, cell_groups, per_block, size_scale=1.0, rgb=None, cell=None, keep_all=False, material=None):
        """Split each dug ground cube (`cell` wide, given by its centre) into level x level x level smaller cubes (level 1 = one
        cube per ground cube, level 10 = 1,000). The debris amount setting can remove cubes or add extra ones.
        Nothing is thrown: the cubes start at rest in the dug space and fall. Cubes whose slot overlaps the
        ground are skipped, so none starts inside it. size_scale shrinks each cube inside its slot."""
        cell = CELL if cell is None else cell
        groups = [np.asarray(g, np.float64).reshape(-1, 3) for g in cell_groups if len(g)]
        level = int(max(1, min(10, round(per_block))))
        if not CONFIG['debris_on'] and not keep_all:
            return
        if not groups:
            return
        m = level
        slots = np.stack(np.meshgrid(np.arange(m), np.arange(m), np.arange(m), indexing='ij'), -1).reshape(-1, 3)
        amount = 1.0 if keep_all else CONFIG['debris_amount']
        want = m ** 3 * min(1.0, amount)                       # a whole number of slots plus a chance of one more
        blocks = np.concatenate(groups)
        keep = int(want) + (_rng.random(len(blocks)) < want - int(want)).astype(int)
        slot_c = (slots + 0.5) / m - 0.5                        # slot centres inside one ground cube
        P = []
        for block, k in zip(blocks, keep):
            if k > 0:
                pick = _rng.permutation(len(slots))[:k]        # which slots get a cube
                P.append(block + slot_c[pick] * cell)
        if not P:
            return
        P = np.concatenate(P)
        side = float(np.clip(size_scale, 0.1, 1.0)) * cell / m
        sizes = np.full(len(P), side)
        if amount > 1.0:
            extra, source = _extra_debris(P, sizes, amount)
            P = np.concatenate([P, extra])
            sizes = np.concatenate([sizes, sizes[source]])
        Pt = P + np.array([0.0, 0.02 * cell, 0.0])                # tested a hair higher: a cube sitting right on the floor is free
        free = ((_density_many(world, Pt) <= 0.0) & ~_corners_touching(world, Pt, sizes).any(axis=1)
                & ~_struct_corners(P, sizes).any(axis=1))
        if keep_all and not free.all():                           # none may be lost: a cube that starts inside a wall or the ground is lifted clear
            for _ in range(60):
                bad = ~free
                if not bad.any():
                    break
                P[bad] += np.array([0.0, cell, 0.0])
                Pt = P + np.array([0.0, 0.02 * cell, 0.0])
                free = ((_density_many(world, Pt) <= 0.0) & ~_corners_touching(world, Pt, sizes).any(axis=1)
                        & ~_struct_corners(P, sizes).any(axis=1))
        P, sizes = P[free], sizes[free]
        if len(P) == 0:
            return
        self.pos = np.concatenate([self.pos, P])
        self.vel = np.concatenate([self.vel, np.zeros((len(P), 3))])
        self.size = np.concatenate([self.size, sizes])
        self.shade = np.concatenate([self.shade, _rng.uniform(0.9, 1.1, len(P))])
        self.awake = np.concatenate([self.awake, np.ones(len(P), bool)])
        self.still = np.concatenate([self.still, np.zeros(len(P))])
        self.wet = np.concatenate([self.wet, np.zeros(len(P))])
        self.anc = np.concatenate([self.anc, np.zeros((len(P), 4))])
        self.flight = np.concatenate([self.flight, np.zeros(len(P))])
        self.col = np.concatenate([self.col, np.tile(np.array(_S_RGB[DIRT] if rgb is None else rgb, np.float64), (len(P), 1))])
        layer = _S_TEXLAYER[material] if material is not None else (_S_TEXLAYER[DIRT] if rgb is None else -1.0)
        self.tile = np.concatenate([self.tile, np.full(len(P), layer, np.float32)])
        if CONFIG['debris_limit'] and self.n > BODY_MAX:
            cut = self.n - BODY_MAX
            self.pos, self.vel = self.pos[cut:], self.vel[cut:]
            self.size, self.shade, self.awake = self.size[cut:], self.shade[cut:], self.awake[cut:]
            self.still = self.still[cut:]
            self.wet = self.wet[cut:]
            self.anc = self.anc[cut:]
            self.flight = self.flight[cut:]
            self.col = self.col[cut:]
            self.tile = self.tile[cut:]

    def spawn_chunks(self, P, V, sizes, rgb, world=None, escape_normal=None, material=None, straight_time=0.0):
        """Chunks thrown from a broken structure: positions P, velocities V, sizes (disc diameters) and colours."""
        self.last_spawn_count = 0
        if not CONFIG['debris_on']:
            return
        P = np.asarray(P, np.float64).reshape(-1, 3)
        V = np.asarray(V, np.float64).reshape(-1, 3)
        sizes = np.broadcast_to(np.asarray(sizes, np.float64), (len(P),))
        rgb = np.broadcast_to(np.asarray(rgb, np.float64), (len(P), 3))
        tile = np.full(len(P), -1.0, np.float32) if material is None else np.broadcast_to(_S_TEXLAYER[material], (len(P),))
        amount = CONFIG['debris_amount']
        if amount < 1.0:
            sel = _rng.random(len(P)) < amount
            P, V, sizes, rgb, tile = P[sel], V[sel], sizes[sel], rgb[sel], tile[sel]
        elif amount > 1.0:
            extra, source = _extra_debris(P, sizes, amount)
            P = np.concatenate([P, extra])
            V = np.concatenate([V, V[source]])
            sizes = np.concatenate([sizes, sizes[source]])
            rgb = np.concatenate([rgb, rgb[source]])
            tile = np.concatenate([tile, tile[source]])
        if world is not None and len(P):
            def clear(Q, S):
                return (_density_many(world, Q) <= 0.0) & ~_corners_touching(world, Q, S).any(axis=1) \
                       & ~_struct_corners(Q, S).any(axis=1)
            ok = clear(P, sizes)
            if not ok.all():
                P = P.copy()
                if escape_normal is None:
                    P[~ok, 1] += 0.15
                    ok = clear(P, sizes)
                else:
                    # Take short steps toward the wall face until the whole cube fits.
                    step = max(0.025, float(sizes.min()) * 0.5)
                    steps = math.ceil(1.0 / step)
                    for i in range(1, steps + 1):
                        distance = i / steps
                        blocked = np.flatnonzero(~ok)
                        if not len(blocked):
                            break
                        Q = P[blocked] + distance * escape_normal
                        free = clear(Q, sizes[blocked])
                        P[blocked[free]] = Q[free]
                        ok[blocked[free]] = True
            P, V, sizes, rgb, tile = P[ok], V[ok], sizes[ok], rgb[ok], tile[ok]
        k = len(P)
        if k == 0:
            return
        self.last_spawn_count = k
        self.pos = np.concatenate([self.pos, P])
        self.vel = np.concatenate([self.vel, np.asarray(V, np.float64).reshape(-1, 3)])
        self.size = np.concatenate([self.size, np.broadcast_to(np.asarray(sizes, np.float64), (k,))])
        self.shade = np.concatenate([self.shade, np.ones(k)])
        self.awake = np.concatenate([self.awake, np.ones(k, bool)])
        self.still = np.concatenate([self.still, np.zeros(k)])
        self.wet = np.concatenate([self.wet, np.zeros(k)])
        self.anc = np.concatenate([self.anc, np.zeros((k, 4))])
        self.flight = np.concatenate([self.flight, np.full(k, straight_time)])
        self.col = np.concatenate([self.col, np.broadcast_to(np.asarray(rgb, np.float64), (k, 3))])
        self.tile = np.concatenate([self.tile, tile])
        if CONFIG['debris_limit'] and self.n > BODY_MAX:
            cut = self.n - BODY_MAX
            self.pos, self.vel = self.pos[cut:], self.vel[cut:]
            self.size, self.shade, self.awake = self.size[cut:], self.shade[cut:], self.awake[cut:]
            self.still = self.still[cut:]
            self.wet = self.wet[cut:]
            self.anc = self.anc[cut:]
            self.flight = self.flight[cut:]
            self.col = self.col[cut:]
            self.tile = self.tile[cut:]

    def _sleeper_index(self, cell, OFF, M):
        """Sorted neighbour keys and ids of the sleeping cubes. Cached: a sleeping cube does not move, so the index
        is rebuilt only when the awake set, the cube count, the cell size or a sleeping cube's position changes."""
        sl = np.nonzero(~self.awake)[0]
        pos_sl = self.pos[sl]
        c = getattr(self, '_sleep_cache', None)
        if (c is not None and c['cell'] == cell and np.array_equal(c['awake'], self.awake)
                and np.array_equal(c['pos'], pos_sl)):
            return c['keys'], c['ids']
        ci = np.floor(pos_sl / cell).astype(np.int64) + OFF
        keys = (ci[:, 0] * M + ci[:, 1]) * M + ci[:, 2]
        o = np.argsort(keys, kind='stable')
        keys, ids = keys[o], sl[o]
        self._sleep_cache = dict(cell=cell, awake=self.awake.copy(), pos=pos_sl.copy(), keys=keys, ids=ids)
        return keys, ids

    def _separate(self, passes=3, dt=1.0 / 60.0, grounded=None, only=None):
        """Round cube against round cube. Each cube is treated as a sphere with radius half its size.
        Overlapping pairs are pushed apart along the line between their centres. Sleeping cubes never
        move; when one of a pair is asleep, the awake one takes the whole correction. Motion that drives
        the pair into each other is removed, so piles settle instead of jittering."""
        self._contact = np.zeros(self.n, bool)                    # cubes that touched another cube this frame
        self._on_sleeper = np.zeros(self.n, bool)                 # cubes resting on a cube that is already asleep
        self._unstable = np.zeros(self.n, bool)                   # cubes perched off-centre on another cube: they slide off, never freeze or sleep
        if self.n < 2:
            return
        if grounded is None:
            grounded = np.zeros(self.n, bool)
        M = 1 << 20
        OFF = 1 << 19
        SEP_SLOP = 0.003
        k = max(1.0, dt * 60.0)          # slow frames fall further, so they are allowed to correct further
        FRICT_KEEP = 0.85 ** (dt * 60.0)  # sideways speed kept per pass: 0.85 at 60 steps a second, scaled to this step's length
        SEP_SOFT = min(1.0, 0.35 * k)    # share of an overlap fixed per pass
        SEP_MAX_STEP = 0.02 * k          # most a pair is moved per pass, in blocks
        SEP_CUBE_CAP = 0.03 * k          # most one cube is moved per pass, however many neighbours push it
        # Only a pair with at least one awake cube can change anything, so the search starts from the awake
        # cubes alone and looks up their neighbours in the full index. Sleeping cubes are still indexed, so an
        # awake cube finds the sleeping ones it touches. The work now scales with the awake count, not self.n.
        aw_all = np.nonzero(self.awake)[0]
        if len(aw_all) == 0:
            return
        # `only`: when a big burst is time-sliced, just the cubes stepped this frame are searched for neighbours. Every awake cube
        # is still in the index, so a stepped cube still meets the awake cubes that sit out this frame.
        q_all = aw_all if only is None else np.asarray(only)
        inq = None
        if only is not None:
            inq = np.zeros(self.n, bool)
            inq[q_all] = True
        cell = float(self.size.max())                             # the same for every pass, so it is worked out once
        sleep_keys, sleep_ids = self._sleeper_index(cell, OFF, M)  # sleepers: cached, only re-sorted when they change
        for _ in range(passes):
            ci = np.floor(self.pos[aw_all] / cell).astype(np.int64) + OFF   # only the awake cubes are sorted each pass
            ak_unsorted = (ci[:, 0] * M + ci[:, 1]) * M + ci[:, 2]
            ord_a = np.argsort(ak_unsorted, kind='stable')
            ak = ak_unsorted[ord_a]
            aid = aw_all[ord_a]
            if only is None:
                qk = ak_unsorted
            else:
                cq = np.floor(self.pos[q_all] / cell).astype(np.int64) + OFF
                qk = (cq[:, 0] * M + cq[:, 1]) * M + cq[:, 2]
            # all 27 neighbouring cells in one batch per index, instead of 27 separate passes of small numpy calls
            nk = (qk[:, None] + _NEIGH_OFFS[None, :]).ravel()
            i_all = np.repeat(q_all, len(_NEIGH_OFFS))
            I, J = [], []
            for idx_keys, idx_ids, awake_only in ((ak, aid, True), (sleep_keys, sleep_ids, False)):
                lo = np.searchsorted(idx_keys, nk, 'left')
                hi = np.searchsorted(idx_keys, nk, 'right')
                cnt = hi - lo
                total = int(cnt.sum())
                if DEBUG_ENABLED:
                    DEBUG_STATS['pairs_raw'] = DEBUG_STATS.get('pairs_raw', 0) + total
                if total == 0:
                    continue
                i = np.repeat(i_all, cnt)
                starts = np.repeat(lo, cnt)
                within = np.arange(total) - np.repeat(np.cumsum(cnt) - cnt, cnt)
                j = idx_ids[starts + within]
                # awake-awake pairs are found from both ends: keep them once; awake-sleeping pairs are kept
                if awake_only:
                    keep = (i < j) if inq is None else ((i < j) | ~inq[j])
                else:
                    keep = np.ones(total, bool)
                I.append(i[keep])
                J.append(j[keep])
            if not I:
                return
            I = np.concatenate(I)
            J = np.concatenate(J)
            if DEBUG_ENABLED:
                DEBUG_STATS['pairs_tested'] = DEBUG_STATS.get('pairs_tested', 0) + len(I)

            d = self.pos[J] - self.pos[I]
            # Debris cubes are axis-aligned boxes, so they are tested as boxes: a pair overlaps only when it overlaps
            # on all three axes, and it is pushed apart along the one axis with the least overlap. (A sphere test
            # missed corner-to-corner overlaps, which is what showed as cubes sunk into each other.)
            half = ((self.size[I] + self.size[J]) * 0.5)[:, None]              # sum of half-widths, one per pair
            ov = half - np.abs(d) - SEP_SLOP                                    # overlap on each axis, per pair
            # The axis with the least overlap, but vertical is favoured: a sideways shove pushes a cube into a wall,
            # and piles separate upward far more often than they should slide sideways.
            ax = np.argmin(ov * np.array([1.0, 0.7, 1.0]), axis=1)
            rows = np.arange(len(ov))
            depth = ov[rows, ax]
            aI = self.awake[I]
            aJ = self.awake[J]
            hit = (ov > 0.0).all(axis=1) & (aI | aJ)
            hit &= ~((self.flight[I] > 0.0) & (self.flight[J] > 0.0))
            if DEBUG_ENABLED:
                DEBUG_STATS['pairs_hit'] = DEBUG_STATS.get('pairs_hit', 0) + int(np.count_nonzero(hit))
            if not hit.any():
                return
            I, J, d, ax, depth = I[hit], J[hit], d[hit], ax[hit], depth[hit]
            aI, aJ = aI[hit], aJ[hit]

            n = np.zeros_like(d)                                    # unit normal from I towards J, on the chosen axis
            sd = d[np.arange(len(d)), ax]
            n[np.arange(len(d)), ax] = np.where(sd >= 0.0, 1.0, -1.0)
            wI = np.where(aI & aJ, 0.5, np.where(aI, 1.0, 0.0))     # share of the push each cube takes
            wJ = 1.0 - wI

            # Correct only part of the overlap, capped per pass. Fixing it all at once shoved a landing cube
            # up and sideways in one frame, which is what looked like a bounce.
            push = np.minimum(depth * SEP_SOFT, SEP_MAX_STEP)
            corr = np.zeros_like(self.pos)
            np.add.at(corr, J, n * (push * wJ)[:, None])
            np.add.at(corr, I, -n * (push * wI)[:, None])
            mag = np.linalg.norm(corr, axis=1)
            corr *= np.minimum(1.0, SEP_CUBE_CAP / np.maximum(mag, 1e-9))[:, None]    # a cube in a crowd moves at most this much
            self.pos += corr

            strong = depth > SEP_WAKE_DEPTH                      # a cube squeezed in deeper than this is still being shoved about; a shallow squeeze in a packed crater is just a pile at rest
            self.still[np.concatenate([I[strong], J[strong]])] = 0.0
            touched = np.unique(np.concatenate([I[aI], J[aJ]]))
            self._contact[touched] = True
            self.flight[touched] = 0.0
            # Resting on a sleeping cube below it counts as held. Touching an awake cube, or a cube above, does not,
            # so a loose clump floating in mid-air keeps falling instead of freezing where it bumped.
            self._on_sleeper[I[aI & ~aJ & (n[:, 1] < -0.5)]] = True
            self._on_sleeper[J[aJ & ~aI & (n[:, 1] > 0.5)]] = True
            # Toppling. A cube resting on another cube with its centre past TOPPLE_MIN of a cube width off the lower
            # cube's centre is not balanced: it is pushed sideways, away from the lower cube's centre, harder the
            # further off it is. A cube sitting between two others is pushed both ways and stays put. Cubes that are
            # being toppled are flagged so static friction and sleep leave them alone until they have slid off.
            vert = (ax == 1)
            if vert.any():
                up_is_J = d[:, 1] > 0.0
                off = np.where(up_is_J[:, None], d[:, [0, 2]], -d[:, [0, 2]])        # upper cube's offset from the lower one, x and z
                avg = (self.size[I] + self.size[J]) * 0.5
                mag_off = np.max(np.abs(off), axis=1) / avg                          # in cube widths; 0 = dead centre
                tip = vert & (mag_off > TOPPLE_MIN)
                upper = np.where(up_is_J, J, I)
                tip &= self.awake[upper]
                if tip.any():
                    o = off[tip]
                    dirn = o / np.maximum(np.linalg.norm(o, axis=1, keepdims=True), 1e-9)
                    strength = np.clip(mag_off[tip] / TOPPLE_FULL, 0.0, 1.0)
                    u = upper[tip]
                    np.add.at(self.vel, (u, 0), dirn[:, 0] * strength * TOPPLE_ACCEL * dt / passes)
                    np.add.at(self.vel, (u, 2), dirn[:, 1] * strength * TOPPLE_ACCEL * dt / passes)
                    self._unstable[u] = True
            # contact friction: bleeds off sideways energy only. Slowing the fall too made debris drift down in slow motion.
            friction = touched[grounded[touched] | self._on_sleeper[touched]]
            self.vel[friction, 0] *= FRICT_KEEP
            self.vel[friction, 2] *= FRICT_KEEP

            # Remove only the velocity that drives the pair into each other.
            vI = np.einsum('ij,ij->i', self.vel[I], n)
            vJ = np.einsum('ij,ij->i', self.vel[J], n)
            # Every contact used the same pre-correction velocity, so a cube resting on two cubes had its fall
            # cancelled twice and came out moving UP. Each contact now takes only its share (1 / contacts), which
            # can never remove more than the approach speed.
            deg = (np.bincount(I, minlength=self.n) + np.bincount(J, minlength=self.n)).astype(np.float64)
            # Two unsupported cubes can share the same falling velocity. Cancel
            # only their closing speed, so contact cannot hold up the whole cloud.
            airborne = aI & aJ & ~grounded[I] & ~grounded[J]
            closing = airborne & (vI > vJ)
            impulse = (0.5 * (vI[closing] - vJ[closing])
                       / np.maximum(deg[I[closing]], deg[J[closing]]))
            delta = impulse[:, None] * n[closing]
            np.add.at(self.vel, I[closing], -delta)
            np.add.at(self.vel, J[closing], delta)
            kill_I = aI & ~airborne & (vI > 0)
            kill_J = aJ & ~airborne & (vJ < 0)
            np.add.at(self.vel, I[kill_I], -(vI[kill_I] / deg[I[kill_I]])[:, None] * n[kill_I])
            np.add.at(self.vel, J[kill_J], -(vJ[kill_J] / deg[J[kill_J]])[:, None] * n[kill_J])

    def update(self, world, dt, sleep_time=1.0):
        cap = None
        if not CONFIG['debris_on']:
            cap = 0
        elif CONFIG['debris_limit']:
            cap = int(BODY_MAX * min(1.0, CONFIG['debris_amount']))
        if cap is not None and self.n > cap:
            cut = self.n - cap
            self.pos, self.vel = self.pos[cut:], self.vel[cut:]
            self.size, self.shade, self.awake = self.size[cut:], self.shade[cut:], self.awake[cut:]
            self.still = self.still[cut:]
            self.wet = self.wet[cut:]
            self.anc = self.anc[cut:]
            self.flight = self.flight[cut:]
            self.col = self.col[cut:]
            self.tile = self.tile[cut:]
        if self.n == 0:
            return
        dt = min(dt, 0.05)
        aw = np.nonzero(self.awake)[0]
        if len(aw) > MAX_AWAKE_CUBES:
            # Too many moving cubes for one frame: the slowest RESTING cubes settle now. A cube in mid-air is never
            # frozen (slow at the top of its arc is not the same as resting), so it keeps falling.
            excess = len(aw) - MAX_AWAKE_CUBES
            speed = np.linalg.norm(self.vel[aw], axis=1)
            cand = aw[np.argsort(speed)[:excess * 4]]
            rest = _support(world, self.pos[cand], self.size[cand]).any(axis=1)
            drop = cand[rest][:excess]
            self.awake[drop] = False
            self.still[drop] = 0.0
            self.vel[drop] = 0.0
            self.flight[drop] = 0.0
            aw = np.nonzero(self.awake)[0]
        if len(aw) > HARD_AWAKE_CUBES:
            # A big burst is all in mid-air, so nothing can be put to sleep. Rather than simulate every cube every
            # frame, split the airborne cubes into k groups and step one group per frame, with a k times longer step
            # (capped at 0.05 s), so the cloud keeps moving at nearly full speed while the frame cost stays flat.
            k = -(-len(aw) // HARD_AWAKE_CUBES)
            self._turn = getattr(self, '_turn', 0) + 1
            aw = aw[(np.arange(len(aw)) % k) == (self._turn % k)]
            dt = dt * k                                        # this group is owed the time of all k frames it stands in for
        dt_group = dt
        n_sub = max(1, int(math.ceil(dt / SUBSTEP_MAX - 1e-9)))
        dt_sub = dt / n_sub
        grounded_frame = np.zeros(self.n, bool)           # kept for the whole frame, so a cube moved in an early substep keeps its flag
        for _sub in range(n_sub):
            aw = aw[self.awake[aw]]
            if not len(aw):
                break
            dt = dt_sub
            V = self.vel[aw]
            P = self.pos[aw]
            P_start = P.copy()
            straight = self.flight[aw] > 0.0
            ballistic = ~straight
            V[ballistic, 1] = np.maximum(V[ballistic, 1] - BODY_GRAVITY * dt, -BODY_MAX_FALL)
            shot_velocity = V[straight].copy()
            # Substeps are worked out per cube, not from the fastest cube in the whole batch: one fast fragment used to make every
            # slow cube repeat its terrain and structure checks up to six times. Cubes that need the same count move together.
            steps_i = np.clip(np.ceil(np.abs(V).max(axis=1) * dt * 16), 1, 6).astype(np.int64)
            size = self.size[aw]
            _tm = {}
            def _mark(key, t0):
                _tm[key] = _tm.get(key, 0.0) + (time.perf_counter() - t0)
            _t0 = time.perf_counter()
            # A cube that ended up inside a structure (a blast throws pieces out of one) is lifted out,
            # otherwise every move is blocked and it hangs there.
            for _ in range(4):
                push, stuck = _struct_push(P, size)
                if not stuck.any():
                    break
                L = np.linalg.norm(push[stuck], axis=1)
                step = push[stuck] * (np.minimum(L, 0.1) / np.maximum(L, 1e-9))[:, None]   # out the nearest face, not always up
                P[stuck] += step
                nrm = step / np.maximum(np.linalg.norm(step, axis=1, keepdims=True), 1e-9)
                into = np.minimum(np.einsum('ij,ij->i', V[stuck], nrm), 0.0)
                V[stuck] -= into[:, None] * nrm                                           # stop only the motion into the surface
            stuck = _struct_corners(P, size).any(axis=1)
            if stuck.any():
                P[stuck, 1] += 0.1 * size[stuck]                                          # last resort if the normals fail
            _mark('struct_push', _t0)
            # A cube whose centre is inside the ground (a push from a neighbour, or a blast that moved the surface)
            # is moved back out along the density gradient. It used to stay stuck there for good.
            _t_tp1 = time.perf_counter()
            for _ in range(2):
                tpush, tin = _terrain_push(world, P, size)
                if not tin.any():
                    break
                L = np.linalg.norm(tpush[tin], axis=1)
                P[tin] += tpush[tin] * (np.minimum(L, 0.08) / np.maximum(L, 1e-9))[:, None]
                V[tin, 1] = np.maximum(V[tin, 1], 0.0)                                   # stop it sinking back in
            _mark('terrain_push', _t_tp1)
            _t_move = time.perf_counter()
            for n_steps in np.unique(steps_i).tolist():
                gi = np.nonzero(steps_i == n_steps)[0]
                whole = len(gi) == len(steps_i)
                Pg, Vg, sizeg = (P, V, size) if whole else (P[gi], V[gi], size[gi])
                sdt = dt / n_steps
                for _ in range(n_steps):
                    for axis in (1, 0, 2):
                        new = Pg.copy()
                        new[:, axis] += Vg[:, axis] * sdt
                        if axis == 1:
                            under = new.copy()
                            under[:, 1] -= sizeg * 0.5
                            _t0 = time.perf_counter()
                            corners = _corners_touching(world, new, sizeg)
                            _mark('debris.move.terrain', _t0)
                            _t0 = time.perf_counter()
                            sc = _struct_corners(new, sizeg)
                            _mark('debris.move.struct', _t0)
                            _t0 = time.perf_counter()
                            blocked = (corners | sc).any(axis=1)                      # any bottom corner in terrain or a structure
                            blocked |= _density_many(world, under) > 0.0            # ...or the middle of its underside (a bump between the corners)
                            _mark('debris.move.terrain', _t0)
                        else:
                            _t0 = time.perf_counter()
                            dens = _density_many(world, new) > 0.0
                            _mark('debris.move.terrain', _t0)
                            _t0 = time.perf_counter()
                            sc = _struct_corners(new, sizeg).any(axis=1)
                            _mark('debris.move.struct', _t0)
                            blocked = dens | sc
                        go = ~blocked
                        Pg[go] = new[go]
                        Vg[blocked, axis] = 0.0
                if not whole:
                    P[gi] = Pg
                    V[gi] = Vg
            _mark('debris.move', _t_move)
            _t_sup = time.perf_counter()
            # A cube stops on its highest bottom corner, so its low side sinks slightly into the ground.
            # Where only some corners are supported, the cube slides downhill until its base is level.
            hits = _support(world, P, size)
            # Sideways drag (BODY_FRICTION) acts only on cubes on the ground, using this substep's real dt. A cube in the air
            # keeps its sideways speed, so a thrown cube follows a parabola. Grouped cubes now get the same result as ungrouped ones.
            kf = math.exp(-BODY_FRICTION * dt)
            on_ground = ballistic & hits.any(axis=1)
            V[on_ground, 0] *= kf
            V[on_ground, 2] *= kf
            shot_ids = aw[straight]
            remaining = np.maximum(0.0, self.flight[shot_ids] - dt)
            remaining[hits[straight].any(axis=1) | (V[straight] != shot_velocity).any(axis=1)] = 0.0
            self.flight[shot_ids] = remaining
            partial = ~straight & ~hits.all(axis=1) & (V[:, 1] > -0.5)     # not fully on the ground, and not falling
            if partial.any():
                down = _downhill(world, P[partial], size[partial])
                V[partial, 0] += down[:, 0] * BODY_GRAVITY * 0.6 * dt
                V[partial, 2] += down[:, 1] * BODY_GRAVITY * 0.6 * dt
            _mark('debris.support', _t_sup)
            # Hard sleep timer: a cube that stays still for sleep_time seconds goes to sleep for good.
            self.pos[aw] = P
            self.vel[aw] = V
            _t_sep = time.perf_counter()
            grounded = grounded_frame
            grounded[aw] = hits.any(axis=1)
            self.grounded_last = grounded                      # which cubes touched ground this step, so the game can reuse it
            only = aw if len(aw) < int(self.awake.sum()) else None
            pre_sep = self.pos.copy() if only is not None else None
            self._separate(dt=dt, grounded=grounded, only=only)
            # A contact can push a cube that was not stepped this substep. Give those cubes their ground state and repair too.
            fix = aw
            if pre_sep is not None:
                in_aw = np.zeros(self.n, bool)
                in_aw[aw] = True
                moved = np.nonzero((self.pos != pre_sep).any(axis=1) & ~in_aw)[0]
                if len(moved):
                    fix = np.concatenate([aw, moved])
            _mark('debris.separate', _t_sep)
            _t_fix = time.perf_counter()
            # Separation knows nothing about the ground, so a pile pressing down can push its bottom cubes into it.
            # Bring any cube whose underside went into the surface back out.
            for _ in range(2):
                tp, tin = _terrain_push(world, self.pos[fix], self.size[fix])
                if not tin.any():
                    break
                L = np.linalg.norm(tp[tin], axis=1)
                self.pos[fix[tin]] += tp[tin] * (np.minimum(L, 0.1) / np.maximum(L, 1e-9))[:, None]
                self.vel[fix[tin], 1] = np.maximum(self.vel[fix[tin], 1], 0.0)
            _mark('debris.terrain_fix', _t_fix)
            if pre_sep is not None:
                # Any cube a contact or the repair moved this substep gets a ground flag that matches where it ended up (audit 06).
                moved_now = np.nonzero((self.pos != pre_sep).any(axis=1))[0]
                if len(moved_now):
                    grounded[moved_now] = _support(world, self.pos[moved_now], self.size[moved_now]).any(axis=1)
            # Static friction: a cube that is touching others and already moving slowly stops sliding sideways, so a
            # pile of round-ish cubes stops creeping and can go to sleep.
            ct = self._contact[aw]
            crawl = np.linalg.norm(self.vel[aw], axis=1) < 0.35
            held_contact = grounded[aw] | self._on_sleeper[aw]
            stick = aw[ct & crawl & held_contact & ~self._unstable[aw]]
            self.vel[stick, 0] = 0.0
            self.vel[stick, 2] = 0.0
            moved_speed = np.linalg.norm(self.pos[aw] - P_start, axis=1) / max(dt, 1e-6)   # real movement this frame, pushes included                                       # pushes cubes apart, stops motion into each other
            Vn = self.vel[aw]
            calm = (np.abs(Vn).max(axis=1) < 0.12) & (moved_speed < 0.25)         # crawling AND not being shoved around
            unstable_aw = self._unstable[aw]
            # A cube flagged as perched off-centre, or pushed hard (a slope pulling it down) against a neighbour that holds it, can be
            # busy without going anywhere. If it really has not moved, it is wedged in place: at rest, once it has stayed that way a while.
            busy = unstable_aw | ~calm
            wedged = busy & (moved_speed < JAM_MOVE)
            still_now = (calm & ~unstable_aw) | wedged                             # a cube that is still toppling or sliding is not at rest
            # A slow cube only counts as at rest if something is under it. Without this, a cube at the top of its arc passes the
            # "slow" test, has its velocity zeroed, and at high frame rates (gravity per frame below 0.12) gravity never builds
            # up again, so it hangs in mid-air. Airborne cubes keep their velocity and keep falling.
            # Progress test: judged over a second, not a frame. Cubes jammed in a pit shake in place (a long path, no progress), so the
            # one-frame speed tests above never call them at rest. Staying within PROGRESS_R of one spot for PROGRESS_TIME does.
            if PROGRESS_TIME > 0:
                self.anc[~self.awake, 3] = 0.0                                       # a cube that slept starts its count again when it wakes
                A = self.anc[aw]
                far = np.linalg.norm(self.pos[aw] - A[:, :3], axis=1) > PROGRESS_R
                A[far, :3] = self.pos[aw][far]
                A[:, 3] = np.where(far, 0.0, A[:, 3] + dt)
                self.anc[aw] = A
                prog = A[:, 3] >= PROGRESS_TIME
                still_now |= prog
            else:
                prog = np.zeros(len(aw), bool)
            cand = np.nonzero(still_now)[0]
            if len(cand):
                held_now = _support(world, self.pos[aw[cand]], size[cand]).any(axis=1) | self._on_sleeper[aw[cand]]
                still_now[cand[~held_now]] = False
            self.vel[aw[still_now]] = 0.0
            self.still[aw] = np.where(still_now, self.still[aw] + dt, 0.0)
            need = np.where(busy, sleep_time * JAM_TIME_MUL, sleep_time) if JAM_MOVE > 0 else sleep_time   # wedged cubes wait longer
            if PROGRESS_TIME > 0:
                need = np.where(prog, dt * 0.5, need)                              # it has already stayed put for a second: no further wait
            ready = np.nonzero(still_now & (self.still[aw] >= need))[0]                # about to fall asleep
            if len(ready):
                held = _support(world, self.pos[aw[ready]], size[ready]).any(axis=1) | self._on_sleeper[aw[ready]]
                lost = ready[~held]                                                    # nothing under it: keep it awake
                self.still[aw[lost]] = 0.0
            asleep = self.still[aw] >= need
            if asleep.any():
                SFX.settle(self.pos[aw[asleep]][0], int(asleep.sum()))
            self.awake[aw[asleep]] = False
            for k_, v_ in _tm.items():
                PROF.add(k_ if k_.startswith('debris.') else 'debris.' + k_, v_ * 1000.0)
        dt = dt_group
        fading = self.wet > WASH_DELAY
        if fading.any():
            self.size[fading] *= math.exp(-3.0 * dt)
        keep = (self.pos[:, 1] > -4.0) & (self.wet < WASH_DELAY + WASH_FADE)     # also drops cubes that fell out of the world
        if not keep.all():
            self.pos, self.vel = self.pos[keep], self.vel[keep]
            self.size, self.shade, self.awake = self.size[keep], self.shade[keep], self.awake[keep]
            self.still = self.still[keep]
            self.wet = self.wet[keep]
            self.anc = self.anc[keep]
            self.flight = self.flight[keep]
            self.col = self.col[keep]
            self.tile = self.tile[keep]

    def instances(self, textured=False):
        """Per cube: position, colour, side length, and optional texture layer."""
        out = np.empty((self.n, 8 if textured else 7), np.float32)
        out[:, :3] = self.pos
        out[:, 3:6] = self.col.astype(np.float32) * self.shade[:, None].astype(np.float32)
        out[:, 6] = self.size
        if textured:
            out[:, 7] = self.tile
        return out

BODIES = DirtCubes()

TOPPLE_MIN     = 0.18                # a cube resting on another slides off once its centre is this many cube widths off-centre
TOPPLE_FULL    = 0.5                 # ...and is pushed at full strength by this offset (the edge of the cube below)
TOPPLE_ACCEL   = BODY_GRAVITY * 1.2  # sideways acceleration at full strength, blocks per second squared


_DISC_VERT = """
#version 330 core
layout(location = 1) in vec3 aInstPos;    // cube centre
layout(location = 2) in vec3 aInstCol;    // cube colour
layout(location = 3) in float aInstSize;  // cube side length
layout(location = 5) in float aTile;
uniform mat4 uVP;
uniform float uLight;
uniform bool uBlastFX;
out vec3 vCol;
out vec2 vRayNdc;
flat out vec3 vCentre;
BOUNDS_PLACEHOLDER
flat out vec3 vSeed;
flat out float vTile;
flat out float vSize;
float smoothBand(float lo, float hi, float t) {
    float x = clamp((t - lo) / (hi - lo), 0.0, 1.0);
    return x * x * (3.0 - 2.0 * x);
}
void main() {
    float side = aInstSize;
    vec3 colour = aInstCol;
    if (uBlastFX) {
        float age = aInstCol.x, life = max(aInstCol.y, 0.000001);
        float glow = aInstCol.z, kind = aTile;
        float t = clamp(age / life, 0.0, 1.0);
        float factor;
        if (kind < 0.5) {
            colour = t < 0.18 ? vec3(3.2, 3.0, 2.0) : t < 0.40 ? vec3(3.2, 2.0, 0.55) :
                     t < 0.65 ? vec3(2.6, 0.85, 0.18) : t < 0.85 ? vec3(0.9, 0.28, 0.12) : vec3(0.30, 0.20, 0.18);
            factor = (0.6 + 0.4 * clamp(t * 6.0, 0.0, 1.0)) * (1.0 - 0.85 * smoothBand(0.35, 1.0, t));
        } else if (kind < 1.5) {
            float u = clamp(age / max(glow, 0.000001), 0.0, 1.5);
            colour = glow > 0.0 && u < 1.0 ? (u < 0.30 ? vec3(3.2, 2.4, 0.9) : u < 0.65 ? vec3(2.6, 1.0, 0.22) : vec3(1.2, 0.32, 0.10)) :
                     (t < 0.25 ? vec3(0.17, 0.16, 0.15) : t < 0.60 ? vec3(0.26, 0.25, 0.24) : vec3(0.36, 0.35, 0.34));
            factor = (0.45 + 0.7 * clamp(t * 2.2, 0.0, 1.0)) * (1.0 - smoothBand(0.75, 1.0, t));
        } else if (kind < 2.5) {
            colour = t < 0.30 ? vec3(3.2, 2.8, 1.4) : t < 0.65 ? vec3(2.8, 1.2, 0.30) : vec3(1.6, 0.30, 0.08);
            factor = 1.0 - 0.75 * t;
        } else if (kind < 3.5) {
            colour = t < 0.5 ? vec3(0.62, 0.46, 0.30) : vec3(0.50, 0.36, 0.24);
            factor = (0.5 + 0.5 * clamp(t * 5.0, 0.0, 1.0)) * (1.0 - smoothBand(0.5, 1.0, t));
        } else {
            vec3 hue = clamp(abs(fract(vec3(glow) + vec3(1.0, 0.66667, 0.33333)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);   // firework colour: glow carries the hue (0..1)
            hue = mix(vec3(1.0), hue, 0.9);
            if (kind < 4.5) {
                colour = mix(vec3(3.2), hue * 3.2, 0.6);                         // a rocket's bright head
                factor = 1.0;
            } else {
                colour = t < 0.12 ? vec3(3.2, 3.1, 2.8) : hue * (t < 0.55 ? 3.2 : 3.2 - 2.4 * (t - 0.55) / 0.45);     // a star: white-hot, then its colour, fading out
                factor = 1.0 - 0.85 * smoothBand(0.45, 1.0, t);
            }
        }
        side *= factor;
    }
    vCol = colour * uLight * 1.3;     // lifted to sit with the lit tiles
    vCentre = aInstPos;
    vSeed = colour * 127.0 + vec3(13.0, 17.0, 31.0);
    vTile = uBlastFX ? -1.0 : aTile;
    vSize = side;
    gl_Position = rayBounds(uVP, aInstPos - side * 0.5, aInstPos + side * 0.5, vRayNdc);
}
""".replace("BOUNDS_PLACEHOLDER", _RAY_BOUNDS_GLSL)

_DISC_FRAG = """
#version 330 core
in vec3 vCol;
in vec2 vRayNdc;
flat in vec3 vCentre;
uniform mat4 uVP;
SEGMENT_PLACEHOLDER
flat in vec3 vSeed;
flat in float vTile;
flat in float vSize;
uniform sampler2DArray uTiles;
uniform bool uTextured;
out vec4 fragColor;
LIGHT_GLSL_PLACEHOLDER
float hash3d(vec3 p) {
    return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453);
}
// Signed distance to a unit cube in instance-local space.
float cubeDistance(vec3 p) {
    vec3 q = abs(p) - 0.5;
    return length(max(q, vec3(0.0))) + min(max(q.x, max(q.y, q.z)), 0.0);
}

bool marchCube(vec3 origin, vec3 direction, out vec3 hit) {
    const float padding = 0.015625;
    const float epsilon = 0.0001;
    vec3 invD = 1.0 / mix(direction, vec3(1e-8), lessThan(abs(direction), vec3(1e-8)));
    vec3 a = (-vec3(0.5 + padding) - origin) * invD;
    vec3 b = ( vec3(0.5 + padding) - origin) * invD;
    vec3 nearT = min(a, b), farT = max(a, b);
    float t = max(0.0, max(nearT.x, max(nearT.y, nearT.z)));
    float limit = min(farT.x, min(farT.y, farT.z));
    if (t > limit) return false;

    // The absolute distance also lets rays starting inside a cube march to its exit.
    bool inside = cubeDistance(origin) < 0.0;
    vec3 p = origin + direction * t;
    for (int step = 0; step < 24; ++step) {
        float distance = abs(cubeDistance(p));
        if (distance <= epsilon) {
            // Near an edge, verify the hit with the exact interval below.
            vec3 edge = abs(p);
            int nearFaces = int(edge.x > 0.5 - epsilon * 4.0)
                          + int(edge.y > 0.5 - epsilon * 4.0)
                          + int(edge.z > 0.5 - epsilon * 4.0);
            if (nearFaces == 1) {
                int axis = edge.x >= max(edge.y, edge.z) ? 0 : (edge.y >= edge.z ? 1 : 2);
                float face = sign(p[axis]);
                float slope = direction[axis];
                if (face * slope * (inside ? 1.0 : -1.0) > epsilon) {
                    float correction = (face * 0.5 - p[axis]) / slope;
                    vec3 surface = p + direction * correction;
                    if (t + correction >= 0.0 && all(lessThanEqual(abs(surface), vec3(0.5 + epsilon * 0.01)))) {
                        hit = surface;
                        return true;
                    }
                }
            }
            break;
        }
        t += distance;
        if (t > limit) return false;
        p += direction * distance;
    }

    // Grazing rays can converge too slowly for the step budget.
    a = (-vec3(0.5) - origin) * invD;
    b = ( vec3(0.5) - origin) * invD;
    nearT = min(a, b);
    farT = max(a, b);
    float entry = max(nearT.x, max(nearT.y, nearT.z));
    float leave = min(farT.x, min(farT.y, farT.z));
    if (leave < max(entry, 0.0)) return false;
    hit = origin + direction * (entry >= 0.0 ? entry : leave);
    return true;
}

void main() {
    if (vSize <= 0.0) discard;
    vec3 origin, direction, vLocal;
    pixelRay(vRayNdc, origin, direction);
    if (!marchCube((origin - vCentre) / vSize, direction, vLocal)) discard;
    vec3 q = abs(vLocal);
    int axis = q.x >= max(q.y, q.z) ? 0 : (q.y >= q.z ? 1 : 2);
    vec3 n = vec3(0.0);
    n[axis] = sign(vLocal[axis]);
    vec4 clip = uVP * vec4(vCentre + vLocal * vSize, 1.0);
    float z = clip.z / clip.w;
    if (z < -1.0 || z > 1.0) discard;
    gl_FragDepth = z * 0.5 + 0.5;
    vec3 light = dayLight(n, 1.0);
    // Edge wear: distance from this point to the nearest cube edge. Edges chip to a lighter, dustier tone.
    vec3 d = 0.5 - abs(vLocal);
    float edge = min(d.x + abs(n.x) * 9.0, min(d.y + abs(n.y) * 9.0, d.z + abs(n.z) * 9.0));
    float wear = 1.0 - smoothstep(0.0, 0.07, edge);
    // Fine speckle per face cell, so flat faces are not perfectly uniform.
    float speck = 0.96 + 0.08 * hash3d(floor((vLocal + 0.5) * 4.0) + n * 3.0);
    vec3 base = vCol * speck;
    if (uTextured && vTile >= 0.0) {
        vec2 faceUV = abs(n.y) > 0.5 ? vLocal.xz : (abs(n.x) > 0.5 ? vLocal.zy : vLocal.xy);
        vec2 patch = vec2(hash3d(vSeed), hash3d(vSeed.zxy));
        vec3 texel = texture(uTiles, vec3(patch + faceUV * vSize, vTile)).rgb;
        if (vTile == 0.0) texel *= vec3(1.02, 0.86, 0.70);
        base = mix(base, texel, 0.72);
        light *= 0.82 + 0.18 * smoothstep(-0.5, 0.3, vLocal.y);
    }
    vec3 col = base * light;
    col = mix(col, col * 1.18 + vec3(0.02), wear * (uTextured ? 0.23 : 0.6));
    fragColor = vec4(col, 1.0);
}
"""
_DISC_FRAG = _DISC_FRAG.replace("SEGMENT_PLACEHOLDER", _RAY_SEGMENT_GLSL).replace("LIGHT_GLSL_PLACEHOLDER", _LIGHT_GLSL)


class DirtBodyRenderer:
    """Raymarches loose cubes and blast particles inside instanced screen bounds."""
    def __init__(self):
        vs = _compile_shader(_DISC_VERT, gl.GL_VERTEX_SHADER)
        fs = _compile_shader(_DISC_FRAG, gl.GL_FRAGMENT_SHADER)
        self.program = _link_program(vs, fs)
        self.u_inv_vp = gl.glGetUniformLocation(self.program, "uInvVP")
        self.u_vp = gl.glGetUniformLocation(self.program, "uVP")
        self.u_tiles = gl.glGetUniformLocation(self.program, "uTiles")
        self.u_textured = gl.glGetUniformLocation(self.program, "uTextured")
        self.u_light = gl.glGetUniformLocation(self.program, "uLight")
        self.u_blast_fx = gl.glGetUniformLocation(self.program, "uBlastFX")
        self.vao = gl.glGenVertexArrays(1)
        self.vbo_i = gl.glGenBuffers(1)
        self._textured_layout = None
        gl.glBindVertexArray(self.vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo_i)
        gl.glEnableVertexAttribArray(1)
        gl.glBindVertexArray(0)

    def render(self, vp, ambient, yaw, pitch, bodies=None):
        src = BODIES if bodies is None else bodies          # another set of cubes with .n and .instances() can be drawn the same way
        n = src.n
        if n == 0:
            return 0
        textured = src is BODIES
        blast = getattr(src, "gpu_colour_size", False)
        inst = BODIES.instances(textured=True) if textured else src.gpu_instances() if blast else src.instances()
        gl.glUseProgram(self.program)
        gl.glUniformMatrix4fv(self.u_vp, 1, gl.GL_TRUE, vp.astype(np.float32))
        gl.glUniformMatrix4fv(self.u_inv_vp, 1, gl.GL_TRUE, np.linalg.inv(vp).astype(np.float32))
        gl.glUniform1i(self.u_textured, int(textured))
        gl.glUniform1i(self.u_blast_fx, int(blast))
        if textured:
            gl.glActiveTexture(gl.GL_TEXTURE0)
            gl.glBindTexture(gl.GL_TEXTURE_2D_ARRAY, tile_texture())
            gl.glUniform1i(self.u_tiles, 0)
        gl.glUniform1f(self.u_light, max(float(ambient), GFX['ambient_floor']))
        gl.glBindVertexArray(self.vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo_i)
        if self._textured_layout != (textured, blast):
            stride = inst.shape[1] * inst.itemsize
            if blast:
                for loc, count, offset in ((1, 3, 0), (2, 3, 12), (3, 1, 28), (5, 1, 24)):
                    gl.glEnableVertexAttribArray(loc)
                    gl.glVertexAttribPointer(loc, count, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(offset))
                    gl.glVertexAttribDivisor(loc, 1)
            else:
                for loc, count, offset in ((1, 3, 0), (2, 3, 12), (3, 1, 24)):
                    gl.glEnableVertexAttribArray(loc)
                    gl.glVertexAttribPointer(loc, count, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(offset))
                    gl.glVertexAttribDivisor(loc, 1)
                if textured:
                    gl.glEnableVertexAttribArray(5)
                    gl.glVertexAttribPointer(5, 1, gl.GL_FLOAT, gl.GL_FALSE, stride, ctypes.c_void_p(28))
                    gl.glVertexAttribDivisor(5, 1)
                else:
                    gl.glDisableVertexAttribArray(5)
            self._textured_layout = (textured, blast)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, inst.nbytes, inst, gl.GL_STREAM_DRAW)
        gl.glDrawArraysInstanced(gl.GL_TRIANGLES, 0, 6, n)
        gl.glBindVertexArray(0)
        return n


# ═══════════════════════════════════════════════
#  STRUCTURES: breakable supports, rigid bodies, solid rotating geometry
# ═══════════════════════════════════════════════
# A structure is a box-shaped grid of solid cells (a pillar, a wall). Each cell has a material, and
# neighbouring cells are joined by bonds. Blasts destroy and crack cells. After each change the
# structure is checked: every bond across a cut plane carries its share of the weight above it, and
# a bond that is stretched or crushed past its strength breaks. A group of cells with no bond path to
# the ground becomes a RigidBody: a solid with a position, a rotation, mass and an inertia tensor.
# Bodies collide with the terrain, with structures and with each other, so a pillar that loses its
# footing tips over its remaining support instead of just dropping.

STRUCT_GRAVITY      = 24.0     # blocks per second squared
STRUCT_SUBSTEPS     = 3        # physics steps per frame for each awake body
STRUCT_SOLVER_ITERS = 8        # contact solver passes per step
STRUCT_FRICTION     = 0.7
STRUCT_RESTITUTION  = 0.0
STRUCT_SLOP         = 0.03    # penetration the solver leaves alone, in blocks
STRUCT_MAX_CONTACTS = 10       # contacts kept per body per step
# The Wobble setting (0-100%) drives these live. 50% is the original behaviour. Lower: loose pieces lose spin and
# rocking faster, grip harder, push more firmly out of overlaps and go to sleep sooner. Higher: they stay lively.
WOBBLE = dict(ang_damp=0.25, lin_damp=0.0, friction=STRUCT_FRICTION, iters=STRUCT_SOLVER_ITERS, sleep_k=1.0)



STRUCT_SLEEP_LIN    = 0.15
STRUCT_SLEEP_ANG    = 0.20
STRUCT_SLEEP_TIME   = 0.6
STRUCT_SHATTER      = 0.25     # blast strength (after falloff) that destroys a cell of hardness 1
STRUCT_BLAST_IMPULSE = 140.0   # converts blast pressure on a body's surface to momentum
STRUCT_CRACK_STEP   = 0.05     # seconds between rounds of bond failures, so cracks spread visibly
STRUCT_BUDGET_S     = 0.0025   # most time per frame spent on the support checks
STRUCT_LOCAL_R      = 2.0      # blocks: a cut only re-checks the cells this close to it (cells past the edge count as held)
MESH_BRICK          = 16       # structure meshes are kept in bricks of this many cells a side; a cut rebuilds only the bricks it touches
STRUCT_MIN_BODY_CELLS = 6    # a loose group smaller than this crumbles into chunks instead of becoming a body

# ---- impact bonds -------------------------------------------------------------------------------------------------
# Cells hold together with bonds (see GridObject / Structure / RigidBody). A hard contact on a cell gives it damage in
# proportion to R = contact force / the force its bonds hold. A cell with R >= 1 (or enough damage) lets go: every bond of
# the cell breaks, its neighbours are cracked, and whatever is no longer joined to the rest is released and flies on with
# the speed it had. At most BOND_PER_STEP cells let go per pass, worst first. The 'Bond strength' setting (0..100) sets
# Shared gun/blast strength: 0 = attack damage off, 1..99 = exponentially stronger, 100 = attack-proof.
BOND = dict(strength=60)               # live value of the Bond strength setting
BOND_T_MIN = 1500.0                    # contact force a cell of reference material holds at strength 1 ...
BOND_T_RANGE = 28.0                    # ... and the factor between strength 1 and strength 99
BOND_REF_SHEAR = 200.0                 # shear strength of the reference material (brick); harder materials hold more
BOND_DMG_PER_R = 0.6                   # damage a cell takes per unit of R
BOND_NEIGHBOUR_DMG = 0.25              # a cell that lets go damages each bonded neighbour by this x its R ...
BOND_NEIGHBOUR_MAX = 0.85              # ... at most this much
BOND_PER_STEP = 8                      # most cells that let go in one pass
BOND_MIN_R = 0.3                       # contacts below this share of a cell's threshold do nothing
BOND_GRACE = 0.25                      # seconds a new body ignores impacts (it can start touching its neighbours)
FRACTURE_MIN_CELLS = 24                # a loose body this big breaks along flat planes into a few solid chunks
FRACTURE_COOLDOWN = 0.10               # seconds between two fractures of the same body
FRACTURE_MAX_CUTS = 4                  # cross-sections that can let go in one step
BOND_STRENGTH_K = 0.5                  # force one bond holds, as a share of the cell threshold (lower = breaks more easily)
FRACTURE_PUSH = 0.0                    # speed (m/s) the new chunks are pushed apart
FRACTURE_JAGGED = 0.25                 # how ragged a break is: the crack wanders up to this share of the body's length (0 = flat planes)
FRACTURE_JAGGED_MAX = 4                # ...but never more than this many cells off the flat plane
FRACTURE_PATCH = 6                     # the crack wanders with a wavelength of about this many cells (smaller = more zig-zag)
FRACTURE_SIBLING_DEEP = 0.3             # pieces broken off the same body touch along the crack; a contact with a sibling deeper than this share of a cell is a lattice artefact and is ignored
CANNON_SPEED = 45.0                    # blocks per second
CANNON_CELLS = 3                       # the cannon fires a steel cube this many cells a side


def bond_threshold(strength=None):
    """Live attack resistance: gun force threshold and blast scaling (0/100 disable attack fracture)."""
    v = BOND['strength'] if strength is None else strength
    if v <= 0:
        return 0.0
    if v >= 100:
        return math.inf
    return BOND_T_MIN * BOND_T_RANGE ** ((v - 1.0) / 98.0)


def blast_bond_scale():
    """Use the gun's live bond threshold for blast resistance too.
    Strength 1 preserves the original blast tuning; 1..99 follows the same
    28x resistance curve as gun impacts. Both endpoints disable attack damage.
    This controls fracture, not blast impulse or the separate self-weight checks.
    """
    threshold = bond_threshold()
    return threshold / BOND_T_MIN if 0.0 < threshold < math.inf else math.inf


AXE_CUT_HALF_W = 0.45     # the axe's cut: a slot this many blocks either side of the swing line...
AXE_CUT_DEPTH = 0.75      # ...and this deep into the surface
AXE_BLUNT_FRAC = 0.5      # the middle of the axe is blunt: cells within this fraction of the cut's half-width are only cracked...
AXE_BLUNT_CRACK = 0.5     # ...by this much crack damage per swing (0.85 is the most a cell takes, so about three swings); only the outer edges cut cubes out
AXE_CUT_POWER = 0.2       # what the blade can cut: a cell is cut away if hardness * STRUCT_SHATTER is at most this (wood, planks, dirt, brick); harder cells only crack
AXE_MIN_PIECE_CELLS = 8     # the smallest piece an axe cut leaves as a loose log: anything smaller crumbles into cubes
AXE_IMPULSE = 0.05        # momentum of a swing (mass units x blocks/s: a 2 kg head at 8 m/s is about 0.016), pushed into a loose piece at the hit point
STRUCT_UNBREAKABLE_CELLS = 40000  # a fixed structure with more live cells than this never cracks or collapses under load (it can still be cut in two). Was 2000, which left anything over 16 blocks of cubes unable to collapse

# id: mass per block of volume, compressive, tensile and shear strength (force per face area), blast hardness.
# The numbers are tuned so a 2 x 2 pillar stands whole but cracks and topples once about a third of its
# section is gone. Blocks that are not listed behave like stone.
STRUCT_MATERIALS = {
    DIRT:   dict(rho=2.0, comp=1200.0,  tens=25.0,    shear=60.0,   hard=0.5),    # crumbly: weak in tension and shear
    STONE:  dict(rho=3.0, comp=3000.0,  tens=300.0,   shear=450.0,  hard=1.0),
    BRICK:  dict(rho=1.9, comp=1500.0,  tens=120.0,   shear=200.0,  hard=0.7),
    # Glass values are gameplay tuning, not calibrated engineering constants.
    GLASS:  dict(rho=2.5, comp=1800.0, tens=25.0, shear=60.0, hard=0.35, mu=0.4),
    PLANKS: dict(rho=0.6, comp=500.0,   tens=400.0,   shear=100.0,  hard=0.4),
    STEEL:  dict(rho=7.8, comp=20000.0, tens=20000.0, shear=12000.0, hard=3.0, mu=0.5),
    CONCRETE_WHITE: dict(rho=2.3, comp=1600.0, tens=60.0, shear=350.0, hard=1.0, mu=0.75),   # heavy, strong squeezed, weak pulled
    WOOD:   dict(rho=0.7, comp=90000.0, tens=80000.0, shear=40000.0, hard=0.5),    # tree bark and branches: light, tough along its length
}
# Friction between a block and whatever it rests on (used for the sideways thrust of arches).
_S_MU = np.full(256, 0.6)
for _b, _m in STRUCT_MATERIALS.items():
    _S_MU[_b] = _m.get('mu', 0.6)
STRENGTH = {'k': 1.0}                 # global strength scale from the settings slider (1.0 = as tuned)
ARCH_JOINT_SHEAR = 0.25               # share of a material's shear strength a loose joint can use
ARCH_CONTACT = 0.5                    # share of an arch joint that actually carries the thrust
_S_RHO   = np.full(256, STRUCT_MATERIALS[STONE]['rho'])
_S_COMP  = np.full(256, STRUCT_MATERIALS[STONE]['comp'])
_S_TENS  = np.full(256, STRUCT_MATERIALS[STONE]['tens'])
_S_SHEAR = np.full(256, STRUCT_MATERIALS[STONE]['shear'])
_S_HARD  = np.full(256, STRUCT_MATERIALS[STONE]['hard'])
for _b, _m in STRUCT_MATERIALS.items():
    _S_RHO[_b], _S_COMP[_b], _S_TENS[_b] = _m['rho'], _m['comp'], _m['tens']
    _S_SHEAR[_b], _S_HARD[_b] = _m['shear'], _m['hard']
_S_RGB = np.full((256, 3), 0.6, np.float32)
for _b, _c in COLORS.items():
    _S_RGB[_b] = _c
_S_RGB[CONCRETE_WHITE] = (0.80, 0.80, 0.77)
_S_BONDK = np.clip(np.sqrt(_S_SHEAR / BOND_REF_SHEAR), 0.3, 12.0)      # how much more (or less) force than brick a material's bonds hold

# ═══════════════════════════════════════════════
#  MATERIAL TEXTURES
# ═══════════════════════════════════════════════
# One 256 x 256 seamless tile per structure material (JPEG, embedded here so the game stays a
# single file. Layer k of the GL texture array is TILE_MATS[k]. A face is mapped one tile per block, in the
# object's own frame, so a toppled wall carries its pattern with it. Materials not listed stay plain colour.
TILE_SIZE = 256
TILE_MATS = [DIRT, BRICK, PLANKS, STEEL, CONCRETE_WHITE, WOOD, GLASS]
_TILE_PNG = {
    'dirt': (
        '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/'
        '2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADAREAAhEBAxEB/8QA'
        'GgAAAwEBAQEAAAAAAAAAAAAABAUGAwIBB//EADgQAAICAgEDAwMCBQMDBAMBAAECAwQFESEAEjEGE0EUIlEyYRUjQnGBBzNSYpGhFiRDwXKx0eH/xAAaAQAD'
        'AQEBAQAAAAAAAAAAAAACAwQBAAUG/8QALxEAAgIBAwEHAwQDAQEAAAAAAQIAESEDEjFBIlFhcYGR8BOhsTLB4fEEI9FCM//aAAwDAQACEQMRAD8A+B5W5Vyc'
        'tfHxwVb1xJnewsDlqrwFB7ULtxuVWBPeONHR6+MAIXdx+fPyn3BO5toz+P7gjUa3pDMZKpYq1ktx1/dSPHRdxeQrtBvymtknf46YGOooa8eMDaNNiKowOhn8'
        'hfvSWmrVdxA1JIoYhGGmC727gbLaPcP231rKAKgIxJJqJGxUSoyWWhHeC7T+88fO/wBZbW9DZUn8HphY32YIQf8AqP4s7LUlwnp3BxRZB8W8sy5eSd5qzA6k'
        'WJEYa7IyCdj9RPSCoO7V1MX06+frHByu3T08116eUqMPk85ku+SFHsreL2pr1pBViMzf0onPwPOgNA66SWXT65GK5j1V9TAGPaSf0WdtZb6fMmpKiyFkruW0'
        'snwQx5Y68fA31U2qrJaXI10WD08Jy2AOKxUkWOiSBgPckn7v9pgeNtyAd8kfPnpKuWa2zKGRVWlnN82sPmWnjspFkJ4CJrFNVJlLDWypBXTc68Hz1i0y1WB3'
        'wntWvqRGsWXmimg7bF2vDJDGlXcACT2F893H2Af0qdjoNoKnA8fL94YZlYZnPq1VcSXbVOmuRsL7E89Qe2j7/q7ddnf+/HWaZJO0HA+e03UA/URmB5LE0pqF'
        'Wc0IUt0IvYeaKQo051sFl3vv14I44PTEdgTRwYpkUgGsiL4K/qOxehpYYS3Ya1dpTj8d2q0dfRMjiPY79D7iSeR556f9TTVb1DV9T3+cnOnqE1p58B3SKTPr'
        'lrs9WsskcLbHv2a/ZKYvyI/gH5A+erCm0An56yFX3ttH3lrXrC+JpO1qUjKhaQOEBQD7O1T4Ox4Hjn89eeTtxzPSq88RjXhnFVGMnuPDK0zoFCiR30r9x/Ud'
        'AaA8DZPQsw7oYXg3cJy9ypk5oMfFBVvXEmd7CwOWqvAUHtQu3G5VYE9440dHrgCF3HH58/KYTubaM/j+4G1Gt6QzGSqWKtZLcdf3Ujx0XcXkK7Qb8prZJ3+O'
        'mBjqKGvHjA2jTYiqMDoZ/IX70lpq1XcQNSSKGIRhpgu9u4Gy2j3D9t9aygCoCMSSaiRsVEqMlloR3gu0/vPHzv8AWW1vQ2VJ/B6YWN9mCEH/AKj+LOy1JcJ6'
        'dwcUWQfFvLMuXkneaswOpFiRGGuyMgnY/UT0gqDu1dTF9Ovn6xwcrt09PNdenlKjD5POZLvkhR7K3i9qa9aQVYjM39KJz8DzoDQOukll0+uRiuY9VfUwBj2k'
        'n9FnbWW+nzJqSoshZK7ltLJ8EMeWOvHwN9VNqqyWlyNdFg9PCctgDisVJFjokgYD3JJ+7/aYHjbcgHfJHz56SrlmtsyhkVVpZzfNrD5lp47KRZCeAiaxTVSZ'
        'Sw1sqQV03OvB89YtMtVgd8J7Vr6kRrFl5opoO2xdrwyQxpV3AAk9hfPdx9gH9KnY6DaCpwPHy/eGGZWGZz6tVXEl21TprkbC+xPPUHto+/6u3XZ3/vx1mmST'
        'tBwPntN1AP1EZgeSxNKahVnNCFLdCL2HmikKNOdbBZd779eCOOD0xHYE0cGKZFIBrIi+Cv6jsXoaWGEt2GtXaU4/HdqtHX0TI4j2O/Q+4knkeeen/U01W9Q1'
        'fU9/nJzp6hNaefAd0ikz65a7PVrLJHC2x79mv2SmL8iP4B+QPnqwptAJ+eshV97bR95a16wviaTtalIyoWkDhAUA+ztU+DseB45/PXnk7ccz0qvPEZVoZhWR'
        'jJ3vDK0zoFCiR30r9x/UdAaA8DZ6FiO6EBwbuM/UWTkpT18TUlitW7K6SKOJWMg3r21B15I5b9ugVRW8igPlwyc7RyYrxWNf0/nshL6ix0mUq5Ibmu1pdWqw'
        'OiZYm/S4HA0fPaB0bONVQNM0R06HwMBUbSc/VF316iKKVhq0dlkmswxxyCRnsRCT3EUlY2kQeGUE7/APTyLofPGTqSLowmBbVDN3qmQSravIyyrNtZ4GXt3s'
        'qTypXwP+/QMFZQVsD2MatqSHq5tUXHGwDVaKkL1ky++0gjhWTX2oin9AJP2jx0BDnBzXz1hjYuRi4/q+vf8A0rI+Ns4i3fyGSPsw+2AYO9SWJ+7kDQ7tjyRx'
        '0of4/wBTtAgAe8Y3+SNLsMDmYxeq4Mtllmjhq+/HE0cf2OYwpP5Pkk73+Os+nsWjcL6m9rHM69ZY+eX0sPo471Wft+pswQqWjlj2AokU8J+QfkDo9J1D01QN'
        'bTZkxj951m/TGVq+mjdyFismKjmRlkKLMjyMQVRACGk8DfwOhRwzYGfY/wATdRSP1GT5yV6W4K0FKGrjgw+qgjtuUdiNkgN+jnnW/jjo9qgWTnpiBva6AxGH'
        '0gjgmixN5/qrsTJFCkiTRzOCCrHuPDf9PyOs3Ue2OIW0kWpmFehNhsl/ELUc0UEg924kEZsCJlH3lQeW/YDj7uisONo9OkCmQ7mE2z7pkcY8eMrAR2a3cWde'
        'yYR7DCDtHII+RvkdDp9lu0eD6ecY/aFr1mmWwGQo3qFiGtGjSVgI5rBRURyN790nSqP/ABz1iMrBgT1+YmMpDAiYyUJkswe5FWzteAn3pqEwVJGP6vb7uSV8'
        'FtaPkdMUqBjHnAYE1efKPhUgSO28eVoz1nQVZYQh1VO+4NED+orwC4JB2fx0osSa2m/z5xgAA/ViB+o8nJRnr4mpLFat2F0kUcSkyDevbUHXkjlutVRW8igP'
        'lzCe1tHMV4rGv6fz2Ql9RY6TKVckNzXa0urVYHRMsTfpcDgaPntA6NnGqoGmaI6dD4GAqNpOfqi769RFFKw1aOyyTWYY45BIz2IhJ7iKSsbSIPDKCd/gHp5F'
        '0PnjJ1JF0YTAtqhm71TIJVtXkZZVm2s8DL272VJ5Ur4H/foGCsoK2B7GNW1JD1c2qLjjYBqtFSF6yZffaQRwrJr7URT+gEn7R46Ahzg5r56wxsXIxcf1fXv/'
        'AKVkfG2cRbv5DJH2YfbAMHepLE/dyBod2x5I46UP8f6naBAA94xv8kaXYYHMxi9VwZbLLNHDV9+OJo4/scxhSfyfJJ3v8dZ9PYtG4X1N7WOZ16yx88vpYfRx'
        '3qs/b9TZghUtHLHsBRIp4T8g/IHR6TqHpqga2mzJjH7zrN+mMrV9NG7kLFZMVHMjLIUWZHkYgqiAENJ4G/gdCjhmwM+x/ibqKR+oyfOSvS3BWgpQ1ccGH1UE'
        'dtyjsRskBv0c8638cdHtUCyc9MQN7XQGIw+kEcE0WJvP9VdiZIoUkSaOZwQVY9x4b/p+R1m6j2xxC2ki1Mwr0JsNkv4hajmigkHu3EgjNgRMo+8qDy37Acfd'
        '0VhxtHp0gUyHcwm2fdMjjHjxlYCOzW7izr2TCPYYQdo5BHyN8jodPst2jwfTzjH7Qtes0y2AyFG9QsQ1o0aSsBHNYKKiORvfuk6VR/456xGVgwJ6/MTGUhgR'
        'MZKEyWYPcirZ2vAT701CYKkjH9Xt93JK+C2tHyOmKVAxjzgMCavPlHwqQIlt4spRnrOgqywhDqqd9waIH9RXgFgSDs/jpRazRU3+YxQAP1YkzkfUFW7nUt+/'
        'PUp0WhhqtjolM0Cu3AYtztiQSf6enbGK1Vk83xj56xP1AGsGq7oxj9yzcatnrsVq/wDVyK093ZEa7BVSBrsPwPg+ekmlF6QoV0+Zjlyf9hvMZYiW9BayFqx6'
        'VvT4jGOkvsUgQbyd+mVJCCQwGnO/I0NdAVUhf9gtu/pD3spbsYXu6xBas3rVj28jVS9TnVpGtTQrFIjliwViBojX+P36eCgHZNHu59oi3JphY9obiK1W/NAm'
        'Vx1etUEU030soJjZBrZ7m/UdnWx+nx0DEgEobhAA9lhOKGP9M+pbGMnvQy0MzUkZbFl0LUoQD9jI+9kEH9PgH+x6Is+mKQ4PvM2I5thkRHbz7421MuKkqyXI'
        '+4VbIb7AobRKfGz+/wD99MGkCLa66xZ1SppeY4w3qaIrLfmyJv2PqtTi0rs5UR63tTrWzwPjoH0yTtqsRialC7ivIYm7FLKkWXia7M5nEFXuksVeQSeeFJHg'
        'DpiupolcfYxTIwwrTqvDkMbjZKEby34shJt7N6IyTpr/AKh9pB8Hfj+/WMQ5s4ru4nKpQUDcrcF6VvNBbkNeaW7bC22ZaqqkSAdvf262uvkD46i1NQWB0HjL'
        'tLTIBJ6zY56FMbcxmWdpcakZHZibTRsH8ozSa7mG+dDQ/PHRAGwyjPiILURtY+0F9PK1jAe5J7V6Svoz2oIizf8A5OPz8E+D1rXuwKmLQXm4jGJ/iGWrtNDV'
        'pmCaSVKLh2SwiqP9xTxpt7BH40OnF9qmjd9e7yidpZhiq+8cDEyWI1ltYnHYCkUlItwsSu0XuUEkkuDrWl/Oj0AYdGJhlSf/ACBC5P8AUP0ZewdawmOeBpYU'
        '7Yqtfv8Abc8sp3rsYHZ18+OsGhrB2BMM62iUBAkvkfUFa9nVtmeepUotFDVfHRKZoFduAxbnbEgk/wBPT9jFdtWT38Y+esm3gNYNV3RjH7lm41bPXYrV/wCr'
        'kVp7uyI12CqkDXYfgfB89JNKL0hQrp8zHLk/7DeYyxEt6C1kLVj0renxGMdJfYpAg3k79MqSEEhgNOd+Roa6AqpC/wCwW3f0h72Ut2ML3dYgtWb1qx7eRqpe'
        'pzq0jWpoVikRyxYKxA0Rr/H79PBQDsmj3c+0Rbk0wse0NxFarfmgTK46vWqCKab6WUExsg1s9zfqOzrY/T46BiQCUNwgAeywnFDH+mfUtjGT3oZaGZqSMtiy'
        '6FqUIB+xkfeyCD+nwD/Y9EWfTFIcH3mbEc2wyIjt598bamXFSVZLkfcKtkN9gUNolPjZ/f8A++mDSBFtddYs6pU0vMcYb1NEVlvzZE37H1WpxaV2cqI9b2p1'
        'rZ4Hx0D6ZJ21WIxNShdxXkMTdillSLLxNdmcziCr3SWKvIJPPCkjwB0xXU0SuPsYpkYYVp1XhyGNxslCN5b8WQk29m9EZJ01/wBQ+0g+Dvx/frGIc2cV3cTl'
        'UoKBuVuC9K3mgtyGvNLdthbbMtVVSJAO3v7dbXXyB8dRamoLA6Dxl2lpkAk9Zsc9CmNuYzLO0uNSMjsxNpo2D+UZpNdzDfOhofnjogDYZRnxEFqI2sfaC+nl'
        'axgPck9q9JX0Z7UERZv/AMnH5+CfB61r3YFTFoLzcRjE/wAQy1dpoatMwTSSpRcOyWEVR/uKeNNvYI/Gh04vtU0bvr3eUTtLMMVX3jgYmSxGstrE47AUikpF'
        'uFiV2i9ygkklwda0v50egDDoxMMqT/5Ahb/6h+jL2DqzpjngaWFO2GrX7/bc8sp3rsYHZ18+OsGhrB2BP3hnW0SgoQb1P6Lu4XE1cDLXikyYX3YIMQUmisAj'
        'TStMeTxwe4bA+PHTgwDlyceP4qSlbTaBmIY6dvHpMuXqQ4ugiiWKGVmZSQNNuVuWbev23z1pKsQUNn50mLuSw4oSnxWan9WYGu38Xpha8jR1w1qRHpNsbdkQ'
        'fe5HhmPb+ep3UaLUVPtz/wAErRvqrYP3jz0VhsPBmZIcpareoVrRlqFW/MXSf4+/s/3Ah2e1eDvXx0zRp33ba7/OJ17Rdu7P7RJ69TGHIY2nJXr1nsTPE4iB'
        'iheBgCzhGOo+1gNeBzs9U6mnsXcoqTaWoWfYxkL6kyArwGGnh5aEwm921br25LYuqp7QO0gIqcE8eT3Dx0vTAPLX6VX8xmqawBUzSGe1kYbkUaWBMQK9eWER'
        'ro/GhzvjZ/sB1pOChmgZ3id01lyVp2SSyZK6vrsgAjLA6ZiPn5Ub8dEV2DPWADvPlHPoOS/kZc1jKcUcK2mB96aIiSNf2bkjZ/H4/HStQAbSYzT7RIn0Gr6Q'
        'yS11q16sT34UU162MsM4dTvvnMZG98a0T556SKc0Ovf+LjySgs9JG+qslZ9KT3rBaS5AwX2mnZ1sK58xSDY3+6j8jo00g9Dr9vOLbWOnnp0iWLLeo3vWGepQ'
        'xdPJ1UkSOyQ8zKnAUL5Tu3rn46M6ekFAskg+kWNTVLEkAAiV2SyV+wlVMVQpY+p9C8NhEmNYTrMvZ7RGu4p/je/nqXTGwncTd+ct1e0AFUVEl3KXa3t1zkXn'
        'tPCjvjAVYQqi9q9zjlD8aPPzx1RsU5I9fnMmLkGgfSELg8V6mv0L2EklTHtVaOOWz/KFewG+9VkY9o53s6GwAOlHVbT3I/N+ePKNGkNQB0OK+8k8d6CzXqj1'
        'bWkqZJcvBPM9eRWIhiJXZ90SqNBf+s8+evQ+qiptqj8xPN+kxbddiWnqf0Xdw2Jq4GSvDJkwvuwQYgpNFYBGmlaY8njg9w4Hx46mDAOWJx4/ipSRaBQMxDHT'
        't49Jly9SHF0EUSxQyszKSBptytyzb1+2+etJViChs/OkxdyWHFCU+KzU/qzA12/i9MLXkaOuGtSI9JtjbsiD73I8Mx7fz1O6jRaip9uf+CVo31VsH7x56Kw2'
        'HgzMkOUtVvUK1oy1CrfmLpP8ff2f7gQ7PavB3r46Zo077ttd/nE69ou3dn9ok9epjDkMbTkr16z2JnicRAxQvAwBZwjHUfawGvA52eqdTT2LuUVJtLULPsYy'
        'F9SZAV4DDTw8tCYTe7at17clsXVU9oHaQEVOCePJ7h46XpgHlr9Kr+YzVNYAqZpDPayMNyKNLAmIFevLCI10fjQ53xs/2A60nBQzQM7xO6ay5K07JJZMldX1'
        '2QARlgdMxHz8qN+OiK7BnrAB3nyjn0HJfyMuaxlOKOFbTA+9NERJGv7NyRs/j8fjpWoANpMZp9okT6DV9IZJa61a9WJ78KKa9bGWGcOp33zmMje+NaJ889JF'
        'OaHXv/Fx5JQWekjfVWSs+lJ71gtJcgYL7TTs62Fc+YpBsb/dR+R0aaQeh1+3nFtrHTz06RLFlvUb3rDPUoYunk6qSJHZIeZlTgKF8p3b1z8dGdPSCgWSQfSL'
        'GpqliSAARK7JZK/YSqmKoUsfU+heGwiTGsJ1mXs9ojXcU/xvfz1LpjYTuJu/OW6vaACqKiS7lLtb265yLz2nhR3xgKsIVRe1e5xyh+NHn546o2KckevzmTFy'
        'DQPpCFweK9TX6F7CSSpj2qtHHLZ/lCvYDfeqyMe0c72dDYAHSjqtp7kfm/PHlGjSGoA6HFfeSeN9BZr1R6uqy1MkuXgnmevIGIhiJXZ90SqNBf8ArPPnr0Pq'
        'qqFao/MTzfpMW3XYntjPZC/kIxVWcTd5ea3Kpj9t2XtWNe4bYjRJB+fz0eptayYOmWSgLlxF6mv/AOpF3H443cJZgx6iGa3ZLVY5pQP1s0g0utaGvJH79Q/T'
        'GnbURfr+JcHOpiwaiH1RdtYxq01KAWatjfa9GRWZtNoxsygf3HGhx1qIHBBOR3/mY7/Toge0ZLdOYeiTQ9iSeykNEQQmOWJQvlpd6ZiePt1sgjrUvRJIPHMF'
        '9uqoDDyhIrem7FfMGxOJcmrMljI5mUlZQDysangDel1o+d+B12pqargEnHQCbpaelpmgM95iLI3LkaRLDgYh2yLMcTJYaU2IgfiXhWUee0AdpA156EBbst61'
        'x6TWLDAXIhUOeyOFuS5Blp9lpy0s99FZq4PKhV3pe79PHyPz0xUV7Tu7usF9Rkpunj0iDIZoVIcgBaNaL6cmKaoChjn8qGj8EMNj+w6qVAase/dJW1aujKX0'
        'ZmruTuJHiI48nnLKDS1U+nRFK6bbnhVA5389S6iKv6sL4yrTdnArJhmR9QS+nsjGLGUlwjyvGk89GVrjfywVLJJxptFvtB8dCq7l4uvSGzlGzi/WSeU9UySe'
        'oMXkMXkKtjDQ22nhiyEX1LzrohhIDo7I5G/B+enKtKQwz7Sdm7SlWxcMmxUF/CZW9bn+hyvdGalNa7zS2VILBzIDqGNB8nZJ41rpamiAMj57xjDcCSKivGeo'
        'fUUuQa1BCM3nmURP7tc3HkiGgFCfH7EfPTGXTUVdL7Zi1fUY2BZmeTo5abO3LNqtJHLE4/iETxfTGE65WX5Rtf8AjoVZQgX26+0JgxfcR5zjCenqmcs5SlDW'
        'aSEdh+iszNFGQ3iT/iAf/wCdE2o2mA1+sFNNXJWpeYrL5j0pjbUONxlY2YEFZP54kerGTyYUHBL/APL50ek6b6e/c55+ZjtRH2bV6SKnzuQvX4hUWcS95ea3'
        'Kpj9t2XtWNe4bYjRJB+fz1ZqbWsmR6e5KAuXEXqa/wD6kXcfjjdwlmDHqIZrdktVjmlA/WzSDS61oa8kfv1D9MadtRF+v4lwc6mLBqIfVF21jGrTUoBZq2N9'
        'r0ZFZm02jGzKB/ccaHHWogcEE5Hf+Zjv9OiB7Rkt05h6JND2JJ7KQ0RBCY5YlC+Wl3pmJ4+3WyCOtS9Ekg8cwX26qgMPKEit6bsV8wbE4lyasyWMjmZSVlAP'
        'KxqeAN6XWj534HXampquAScdAJulp6WmaAz3mIsjcuRpEsOBiHbIsxxMlhpTYiB+JeFZR57QB2kDXnoQFuy3rXHpNYsMBciFQ57I4W5LkGWn2WnLSz30Vmrg'
        '8qFXel7v08fI/PTFRXtO7u6wX1GSm6ePSIMhmhUhyAFo1ovpyYpqgKGOfyoaPwQw2P7DqpUBqx790lbVq6MpfRmau5O4keIjjyecsoNLVT6dEUrptueFUDnf'
        'z1LqIq/qwvjKtN2cCsmGZH1BL6eyMYsZSXCPK8aTz0ZWuN/LBUsknGm0W+0Hx0KruXi69IbOUbOL9ZJ5T1TJJ6gxeQxeQq2MNDbaeGLIRfUvOuiGEgOjsjkb'
        '8H56cq0pDDPtJ2btKVbFwybFQX8Jlb1uf6HK90ZqU1rvNLZUgsHMgOoY0HydknjWulqaIAyPnvGMNwJIqK8Z6h9RS5BrUEIzeeZRE/u1zceSIaAUJ8fsR89M'
        'ZdNRV0vtmLV9RjYFmZ5Ojlps7cs2q0kcsTj+IRPF9MYTrlZflG1/46FWUIF9uvtCYMX3Eec4wnp6pnLOUpQ1mkhHYforMzRRkN4k/wCIB/8A50TajaYDX6wU'
        '01clal3i8tmPSmMtw47GVjZgQVkPviR6sZPJhQcEv/y+dHpOm+nv3P1+ZjtRH2bV6RRloCaskslxJLk6kqK9n3mbjQdG8BQOBvnjrE5wITCxmeWsHSw+FaJ5'
        'RJVue21wMCRIQPs8jXA51531Ug3G+o4kjWo8DEmGhvU7V2WlBVrMrhBNYqGWwB8ANvtTY8Dk+Pz1jlSADmagYZUSkvGraetYvKZMRPXBEVkmNEI3t9nR7hrn'
        'Q3zx1OLGF5lRq7biL7WdxGVQmjiVt3q8HuVUO5YpXIChe99FCoO+4+db+Oh2On6moH56zi6NhVsxbeyGRuQJXnxn8QnhkHuGeYKqAfCjezr+o/Pnz0ahVJIN'
        'XMJZgAVuoyr0sTkshDVgrCq85+onqmT3kkdf093uaVN74XZ4G/nrN2oFsn56TSumWoD95kuDeLISizasYlYY5JZxYgDiADX3MAddnPB3oeOd9HvscX6/MwPp'
        'gNzUGuetavod43XEzvMzFYGisdsdvnQl0ORvfAHAB6NFfV4YV5ceEBmTR5U3+fGLfrUz5MPbLjUaN5VjKyNGX3oIhAJLnez8aHR7inj8/EDaNRqGJmcRFRW1'
        'JUowzQ1x3STmu3uErru7lJ/P589BvLUGM36YTKiUtz1DYx1VLUNnHXo7UWxBjIGWRGIG+/Z/WOdBuD0sIGwQRXfGl9ovBHhGPo36St33YMgZa8JUNVqzGtKW'
        'P6YZA3Mbb/qB0fxrpeqL7JHrz6+PlD0epUxNaxz5bKMXKUZmue9YpS3DYcADZV2P+4QOe5v7dMDbVxkVg1X9QK3tce5qpJDilsYrKw0I5kaGOCOswDMxHbqT'
        'fczE/wCBvpCEE0636x+oDXYappengxlQx2bFeOWNY0Zn3FF3Eff2spJY73tT+nrACx7I+fOs4mv1HMW5eufppZZLiSXJ1JUV7PvM3Gg6N4CgcDfPHTU5wIth'
        'YzPLWDpYfCtE8okq3Pba4GBIkIH2eRrgc6876qQbjfUcSRrUeBiTDQ3qdq7LSgq1mVwgmsVDLYA+AG32pseByfH56xypABzNQMMqJSXjVtPWsXlMmInrgiKy'
        'TGiEb2+zo9w1zob546nFjC8yo1dtxF9rO4jKoTRxK271eD3KqHcsUrkBQve+ihUHfcfOt/HQ7HT9TUD89ZxdGwq2YtvZDI3IErz4z+ITwyD3DPMFVAPhRvZ1'
        '/Ufnz56NQqkkGrmEswAK3UZV6WJyWQhqwVhVec/UT1TJ7ySOv6e73NKm98Ls8Dfz1m7UC2T89JpXTLUB+8yXBvFkJRZtWMSsMcks4sQBxABr7mAOuzng70PH'
        'O+j32OL9fmYH0wG5qDXPWtX0O8briZ3mZisDRWO2O3zoS6HI3vgDgA9Givq8MK8uPCAzJo8qb/PjFv1qZ8mHtlxqNG8qxlZGjL70EQgElzvZ+NDo9xTx+fiB'
        'tGo1DEzOIiorakqUYZoa47pJzXb3CV13dyk/n8+eg3lqDGb9MJlRKW56hsY6qlqGzjr0dqLYgxkDLIjEDffs/rHOg3B6WEDYIIrvjS+0XgjwjH0b9JW77sGQ'
        'MteEqGq1ZjWlLH9MMgbmNt/1A6P410vVF9kj159fHyh6PUqYmtY58tlGLlKMzXPesUpbhsOABsq7H/cIHPc39umBtq4yKwar+oFb2uPc1UkhxS2MVlYaEcyN'
        'DHBHWYBmYjt1JvuZif8AA30hCCadb9Y/UBrsNU0vTwYyqY7FivHLGsaMz7ii7iPv7WUksd72p/T1gBY9kfPnWcTX6jmEYDGSJTiqUSltKg9we9GYUk4+xmBG'
        'wATy3jxx1zGyS2LmhdoAEWZLH5OStJTnyMstWUNLfxleUTwhxws4IGw2udf99dPVwOB5H9pOylrJPmJg+Kho4rFsIppqn3vTdJC/ujf+5oEDzxvnga6zeWY2'
        'c9YewKooTXCxY8YmpbknWVZ7TQM8k3fPXUAk7gP3Sfk9pHwOiKkmjj53wQRVjMWZO2mTmmw4sg1IiJrMsMfaTH8NIf1DnwvkDY6wLt7fXp/HzmcW3nZ7zTH+'
        'm8fjKlivHco2Up8h3kIBG9kxg8yDkaX/AL76AuzsGo5+ekaqBFoHieVaNHMVYak92pj8o7SB5IZO5LGztQxY6VlA0FXXB10w2uQMSfDcnMt09P4u96Ynlkzk'
        'dL1BjKhuXpJ1IUQgDtT2n2rbbtCoPGwT1MzMupQHZP58x+ZaoVtPdfaXmTXquX05cxmIeynsZvHh8gYqaliAQAI5P+G2IJAHJ/bpmkNUbgMg4+d8TqnSbaTy'
        'MxNSifL4+C7LXsQZ1gYbtetKRGqqftMCqON//vfx0Z7J2j9PQn94CncNxwY1pVTegtyNWv3zXZY7UdYNxKT9nd/jjnfPS6N0MRtgi4sWmZ/VdWPGRRVGhf3L'
        'FRJwZnUjbKkbDlwAdE/p302z9M7/AHiDnUH051PbpjNWXP1+Fv3pfcnhesks8qE6jBPlifnsH79EFagKDAeMAsoJ6Ez6Hj/9L4PTGCzmZnuKLFmD21xsEYsy'
        'RheZFLMdB31vQ3rxvo9XS1NSgBVZ7vlQdLV0ktibvEmHq4/Kw+7FTsU44fvR57S944+ztG+CT8AbPUnaU1d+ksG0jiD5GNsves27VgZAtHHWhScrUEetl5Ej'
        'UfeRojZ5PPRKdoAGPvMYbibjTA4ySOpFUosltKn8we9GYUk4+xmBGwATy3jxx0DGyS2LhhQoAEWZLH5OStJTnyMstWUNLfxleUTwhxws4IGw2udf99dPVwOB'
        '5H9pMylrJPmJg+Kho4rFsIppqn3vTdJC/ujf+5oEDzxvnga6zeWY2c9YewKooTXCxY8YmpbknWVZ7TQM8k3fPXUAk7gP3Sfk9pHwOiKkmjj53wQRVjMWZO2m'
        'Tmmw4sg1IiJrMsMfaTH8NIf1DnwvkDY6wLt7fXp/HzmcW3nZ7zTH+m8fjKlivHco2Up8h3kIBG9kxg8yDkaX/vvoC7Owajn56RqoEWgeJ5Vo0cxVhqT3amPy'
        'jtIHkhk7ksbO1DFjpWUDQVdcHXTDa5AxJ8Nycy3T0/i73pieWTOR0vUGMqG5eknUhRCAO1Pafattu0Kg8bBPUzMy6lAdk/nzH5lqhW0919peZNeq5fTlzGYh'
        '7Kexm8eHyBipqWIBAAjk/wCG2IJAHJ/bpmkNUbgMg4+d8TqnSbaTyMxNSifL4+C7LXsQZ1gYbtetKRGqqftMCqON/wD738dGeydo/T0J/eAp3DccGNaVU3oL'
        'cjVr9812WO1HWDcSk/Z3f4453z0ujdDEbYIuLFpmf1XVjxkUVRoX9yxUScGZ1I2ypGw5cAHRP6d9Ns/TO/3iDnUH051PbpjNWXP1+Fv3pfcnhesks8qE6jBP'
        'lifnsH79EFagKDAeMAsoJ6Ez6Hj/APS+D0xgs5mZ7iixZg9tcbBGLMkYXmRSzHQd9b0N68b6PV0tTUoAVWe75UHS1dJLYm7xJh6uPysPuxU7FOOH70ee0veO'
        'Ps7Rvgk/AGz1J2lNXfpLBtI4g+QjbL3rNu1YF8tHHWhScrUEWtl5EjA+8jRGzz56JTsAAx9/SYw3E3me0LKesrlyzNLaEckYdYJ5GDlQdIvYCANH+n9+uP8A'
        'pAUCYv8AtN3KvIw0ViNeKLuWNDDZljnIDbA32qmiF8Aa2SfPSRfNx2BiRt+pPUlhqtAlSERu42XMiqH0I+1fD/OgNdULTWwN/PxJmtcVEnqehcx2KtZJWSSY'
        'sv8A7ey4SdO7gSDXIBB1xz8kdP0zbBP68onVBVSwjp6svpLDPX9hVs2ojCYW/wDiBUF3kf52OB8/HU+NVrvj5iU//NKrmeXPTk2Dj/hJrpPKup66uywvUPaH'
        '7WZuOVIHZ+Nfnrg+477rv8fnfMZNo2VfdF+MxcsUH1eSxEFb30LxNPCWgEYBIcdvDMSDxv446J36KSa94OmhGWWoZlPUtGavSjei8sdKEvNNGzCWyNd22fgo'
        'Cee07/T8dLVCCc8/b/sYzg1jj7xdjLmHzkSSQU56VmPusR/xBv5lkEfeWIGinjzyfjjpz70FE2OMSdQjZAz4xpFXhlr1Wyb0v4c7qxsQRNDKNg6QsjbCeB0s'
        'sbpbv3+GPCg/q4lsfU2H9OenViihhrXFmWP36hZ0lIH2kNv8fLfPPSQHclQee+PJRaJEirGYjr+pBTtww1ck/bLjGrFWMRJ5DMw7gTvnZ/t56pKHZuBsdbkq'
        'upejg9ITTzMnp3M0MhkSmSuRSaiulGUwkEgdrMNLwSNHgdHpMt0ood0XrBq7RsmUOf8A9UcGwlENhJ5a4WQ15ZlDqnhvbaP7XYkj99bHXoBzg8fOs88qMjmK'
        'aUlTPYO39YlA5CCLtfIT1zEXdnARo2BBJ5AJI+3R114/aV8XR6X+fmZ7ACsmeQIH6nh7b1DF2poZ8lSg7bCwyLJ3N38JGV4KmNe/ZO97B89GtKNy8H5+YD5a'
        'myROqNpPWl27amltCORBIsE8jByoOkXsBAGj/T+/Qn/SAoEJf9xsmVWRhorEa8UXcsaGGzLHOQG2BvtVNEL4A1sk+eki+bjsDEjb9SepLDVaBKkIjdxsuZFU'
        'PoR9q+H+dAa6oWmtgb+fiTNa4qJPU9C5jsVaySskkxZf/b2XCTp3cCQa5AIOuOfkjp+mbYJ/XlE6oKqWEdPVl9JYZ6/sKtm1EYTC3/xAqC7yP87HA+fjqfGq'
        '13x8xKf/AJpVczy56cmwcf8ACTXSeVdT11dlheoe0P2szccqQOz8a/PXB9x33Xf4/O+YybRsq+6L8Zi5YoPq8liIK3voXiaeEtAIwCQ47eGYkHjfxx0Tv0Uk'
        '17wdNCMstQzKepaM1elG9F5Y6UJeaaNmEtka7ts/BQE89p3+n46WqEE55+3/AGMZwaxx94uxlzD5yJJIKc9KzH3WI/4g38yyCPvLEDRTx55Pxx0596CibHGJ'
        'OoRsgZ8Y0irwy16rZN6X8Od1Y2IImhlGwdIWRthPA6WWN0t37/DHhQf1cS2PqbD+nPTqxRQw1rizLH79Qs6SkD7SG3+PlvnnpIDuSoPPfHkotEiRVjMR1/Ug'
        'p24YauSftlxjVirGIk8hmYdwJ3zs/wBvPVJQ7NwNjrclV1L0cHpCaeZk9O5mhkMiUyVyKTUV0oymEgkDtZhpeCRo8Do9JlulFDui9YNXaNkyhz/+qODYSiGw'
        'k8tcLIa8syh1Tw3ttH9rsSR++tjr0A5wePnWeeVGRzFNKSpnsHb+sSgchBF2vkJ65iLuzgI0bAgk8gEkfbo668ftK+Lo9L/PzM9gBWTPIEE9TR+3fx+MtTQz'
        '5KjBqwkMiydzd/CRleCpjXv2TvewfPTFoDcvB+fmA5tu1kiF42OhUktZWL3I3rL7hnEw7apYdpDINli2/HJ6V2idh/uN7IG8CAYSni8rlPo6Nk+yR3VZbB2z'
        'S/8AyHjlAfI/fk+Om6hZRZ9YnTAY7RO1yb4WxZlo2fqBSmMKFg4nsEnTn3edtvjQ+AD89ZtD0D19h6Td2y66RVmpLl3KYSnLiIoLUzrJCk/32m5PHf4XZ5AP'
        'JH7dEtBWIbH2gtudlBXP3md/O5uvebGfw1YoAXjvWS3cLik9uinKgL42vnx1oTTK7r8vCcz6m6tvn4yyxd6x6kvwrJPPl5cdL7bPLVVZNKgXudD9rsAABzwo'
        '+epNTsZ4vxlel28c1BTUv5jKQxSZ2bG46vMTHFC6qEJ32qTyo7vOz46y1RSdtmbRdgpahJmt6YjS9cDVDPUln9izN77GauNbBHaf0MfnXO/wOn/UJAN5iDpq'
        'CbGIbk8PicQkFy1Y74e54atQSE93x2o/zoeCeTyB0KO7dkes1tPTXtNPIs9FUwqy4auuRjrllmrxqrIhJ/SCP1No7JH/AI6PZbU5q4O+l/1i5wWzCVrt4VGu'
        'vFGZXp+4tdfbB8Bx9xH4Gtk9EPp2FuvHmA31K3V6RZRmzPqG0LmbZ7Ve3cWWGQJ3TxJsARl9DvVfk/GujfYorTwft/ETp7nNvkdI9t4xEkuJ9fJJUbuh7sjK'
        'JYofyygfJHHzrpKkkChnwxKGULdme+l/TteOn9e0S26bSGWMwKvcY1XQHcRpdMN9p1+eh1WYnacGHpKtWMxzlfT+UxGbuxxZOvkrbVRDIvcssLIAHIYcdvt7'
        '7QRsknfPQqyBcigD887hFWJteoiuerjsDahhSus0H0iSvDEWEsZ7uPtYb2T8kfpHnpgZtS89fnzvgsFQioVjI6FSS1lYvcR6y+4bAmHbVLDtIZBssW345PQ9'
        'onYf7m9kDeBxAMJTxeVyn0dGyfZI7qstg7Zpf/kPHKA+R+/J8dN1Cyiz6xOmAx2idrk3wtizLRs/UClMYULBxPYJOnPu87bfGh8AH56zaHoHr7D0m7tl10ir'
        'NSXLuUwlOXERQWpnWSFJ/vtNyeO/wuzyAeSP26JaCsQ2PtBbc7KCufvM7+dzde82M/hqxQAvHeslu4XFJ7dFOVAXxtfPjrQmmV3X5eE5n1N1bfPxlli71j1J'
        'fhWSefLy46X22eWqqyaVAvc6H7XYAADnhR89SanYzxfjK9Lt45qCmpfzGUhikzs2Nx1eYmOKF1UITvtUnlR3ednx1lqik7bM2i7BS1CTNb0xGl64GqGepLP7'
        'Fmb32M1ca2CO0/oY/Oud/gdP+oSAbzEHTUE2MQ3J4fE4hILlqx3w9zw1agkJ7vjtR/nQ8E8nkDoUd27I9ZraemvaaeRZ6KphVlw1dcjHXLLNXjVWRCT+kEfq'
        'bR2SP/HR7LanNXB30v8ArFzgtmErXbwqNdeKMyvT9xa6+2D4Dj7iPwNbJ6IfTsLdePMBvqVur0iyjNmfUNoXM2z2q9u4ssMgTuniTYAjL6Heq/J+NdG+xRWn'
        'g/b+InT3ObfI6R7bxiJJcT6+SSo3dD3ZGUSxQ/llA+SOPnXSVJIFDPhiUMoW7M99L+na8dP69olt02kMsZgVe4xqugO4jS6Yb7Tr89DqsxO04MPSVasZjnK+'
        'n8piM3djiydfJW2qiGRe5ZYWQAOQw47fb32gjZJO+ehVkC5FAH553CKsTa9RFc9XHYK1DCtdZoPpEleGMsJYz3cbVhvZPyR+keemBm1Lz1+fO+CwVCIszX+n'
        '03pW5lcVcnXEmGszEhHee0hJKGJdeWJBJ57Tvnoxrb6arz6Dz+ZijpbbW6nvp+H/ANO0sTIs1eNpOyuuoi1mWRuTtz8a0Dr/ADrrNQ/UZh/U3TH01U/3KXP5'
        'PEH1FPbnoLgrChTHhY5T9PDoa7gQe5STyzfvodBbkYyO+HSDnmIk9RLk4554WRPpFWRacKdsMDr5JJPcdk7D718eejKGxfXrAGoM5jmp6JjnNmWTJwVoBEs8'
        'UXvN7SuxG9Jyyg8j50TvpJ1CDQF1HKgI3E8zvJ+kJcbDJSvXH96U/VCrj52dLba4MnwCB2jewNa6BdQN2gOMWekJ9IiwTCMVgKMeMrxXJ5ZMuUWxbhxdONoY'
        'vwrAn7zrQOhrrGcliQMdLMIIAtMc+E7+kieI53LrHiqnePZMZCu532oZCOCeOFHj9utArsJmCT/7Y1MfW/qDF3npRXcri2qiJ4JIAVedUI7kftZe3vL8bHOv'
        '26doJ1o3Fa7isEVF2T9V4bNY6uK8VlrdVRHE9WipZWP2l5imhx8HXjpraRB/n8RS6yt09hFFfGS4u1IamQr5+1NLqSRmJUMo5HjXcB4HQFtwsjaIQG00Ddwm'
        'PN5LDxqHmWOSN2NZniCtGW/VpfPjfHz0O1WOIwOU5M9xYj9Q91mtJGECokzlgYfbB/S3H287Pd5J4HWsx0+yf5nBRqdoSv8ATP8AC/TlOqkV6hDVOQklOR+9'
        '440Mf2xe235OySdnkdKLM54zUYFCCgcXElrFW8hYeWK/cglkBX2YGIFUa33ALrTMOe748eejD1gj+Ys6diwYc+CtyNjMxkr+RzMp9uq2XlutPPCnIUPv9K7O'
        'gp2Rrzz1h1C5KjHhU0aYQBj7yQzP+nc/pK5lcRcnXEtXrMSex3ntISSjRDXljok89p3z04a31Karz6Dz+ZiDo7bW6nXp+H/07SxMizV42k7K66iLWZZG5O3P'
        'xrQOv866zUP1GYf1C0x9NVP9ylz+TxB9RT256C4KwoUx4WOU/Tw6Gu4EHuUk8s376HQW5GMjvh0g55iJPUS5OOeeFkT6RVkWnCnbDA6+SST3HZOw+9fHnoyh'
        'sX16wBqDOY5qeiY5zZlkycFaARLPFF7ze0rsRvScsoPI+dE76SdQg0BdRyoCNxPM7yfpCXGwyUr1x/elP1Qq4+dnS22uDJ8Agdo3sDWugXUDdoDjFnpCfSIs'
        'EwjFYCjHjK8VyeWTLlFsW4cXTjaGL8KwJ+860Doa6xnJYkDHSzCCALTHPhO/pIniOdy6x4qp3j2TGQrud9qGQjgnjhR4/brQK7CZgk/+2NTH1v6gxd56UV3K'
        '4tqoieCSAFXnVCO5H7WXt7y/Gxzr9unaCdaNxWu4rBFRdk/VeGzWOrivFZa3VURxPVoqWVj9peYpocfB146a2kQf5/EUusrdPYRRXxkuLtSGpkK+ftTS6kkZ'
        'iVDKOR413AeB0BbcLI2iEBtNA3cJjzeSw8ah5ljkjdjWZ4grRlv1aXz43x89DtVjiMDlOTPcWI/UPdZrSRhAqJM5YGH2wf0tx9vOz3eSeB1rMdPsn+ZwUana'
        'Er/TP8L9OU6qRXqENU5CSU5H73jjQx/bF7bfk7JJ2eR0osznjNRgUIKBxcSWsVbyFh5Yr9yCWQFfZgYgVRrfcAutMw57vjx56MPWCP5izp2LBh0np+3O2Ny2'
        'SvZHNSt7dU5ea6088KchQ+/0rs6CnZGvPWHULkgY8KmjSCAE+8kMdFL6ikwOWzqX8madQ46NJLEiRQ1x9wCkbP2n8nZPTmb6e9EIFm/X+YlEGoV1HFkYhh9A'
        '5DKmzLjsVbzLQNtpUuCRK2xsd3b+k68ePHJ6V9ZRW4gekadC/wBIv1meNp4vDeoMYj5eGtkoVa1ZW2hKRSA6WL3mJBYg7PGhx89GxZlJAsfOkABFcAmjGuMu'
        '+nczkZK8WAFi1adppMrXVoohFo/czjhgNHjx/npJ+qi2WqukaRpM2F56yswP+psOHhnweBxENdbtJZ7dqCATpP2/aQrMCwUDWx889VrpBhZ58eZI2sUYjp0k'
        'nF61ef1BkaVPFqUigE1yuZiK9gqf0nf+2hOif3AHx0Orohaa/LvH/Yej/kF7FcTyKjfzeK92TKwV2thmaWNlWBN7JT3gNqx4H40OkWqt+nj5xHkFl/VV/OZH'
        'WfQc1zLJQx1mWnBHH9U0ENgyQqANBmRiSqkn42SeqhrUu58yQ6FttU1BZvQ/0UbCxNM1eQlgxlWQgg8tH3bK7I4Px+3TF1Q7ACKfSKqTHV7P4axl5WwlpcO9'
        'qnFDeWKwEjHaNaKk/cx/bnZPXammwWmF0cTtLVUmwaJ5hdWe5Q9M42azGtDG5F5oKlsMjtKIz9xSIEsNEgBm1s9RsluSMkdP5lq6lIAeJn6Z771pJI3i94d0'
        'MqWV+o7Qw0Gl2SrOx4ULynO+i1aRSP49v3752mdzTzFGOlRsK1iSKrSs901WGuqs6d3YNcbPYeWH48daRu9RzfzmYCR14m9qanUqs1nESXhFZIS0JvcjdtbD'
        'outb8HXJHG+sUMeDU1io5FwwPNmsg9nT2a86gSvZ3AjEDjs7T/Sfz+eegJCDPPvDFtkcST9aXGe3SijryLUruZHqRzuizuRrubXPZ/8A71Vo4BPWR69mh0jn'
        'Hxzeo5cFl88t/JmnUOOjSSxIkMVcfcApGz9p/J2T0pm+nvRCBZv1jlT6hXUcWRiFn0DkMqbMuOxVvMtA22lS4JErbGx3dv6Trx48cnpX1lFbiB6Rp0L/AEi/'
        'WZ42ni8N6gxiPl4a2ShVrVlbaEpFIDpYveYkFiDs8aHHz0bFmUkCx86QAEVwCaMa4y76dzORkrxYAWLVp2mkytdWiiEWj9zOOGA0ePH+ekn6qLZaq6RpGkzY'
        'XnrKzA/6mw4eGfB4HEQ11u0lnt2oIBOk/b9pCswLBQNbHzz1WukGFnnx5kjaxRiOnSScXrV5/UGRpU8WpSKATXK5mIr2Cp/Sd/7aE6J/cAfHQ6uiFpr8u8f9'
        'h6P+QXsVxPIqN/N4r3ZMrBXa2GZpY2VYE3slPeA2rHgfjQ6Raq36ePnEeQWX9VX85kdZ9BzXMslDHWZacEcf1TQQ2DJCoA0GZGJKqSfjZJ6qGtS7nzJDoW21'
        'TUFm9D/RRsLE0zV5CWDGVZCCDy0fdsrsjg/H7dMXVDsAIp9IqpMdXs/hrGXlbCWlw72qcUN5YrASMdo1oqT9zH9udk9dqabBaYXRxO0tVSbBonmF1Z7lD0zj'
        'ZrMa0MbkXmgqWwyO0ojP3FIgSw0SAGbWz1GyW5IyR0/mWrqUgB4mfpnvvWkkjeL3h3QypZX6jtDDQaXZKs7HhQvKc76LVpFI/j2/fvnaZ3NPMUY6VGwrWJIq'
        'tKz3TVYa6qzp3dg1xs9h5Yfjx1pG71HN/OZgJHXib2pqdSqzWcRJeEVkhLQm9yN21sOi61vwdckcb6xQx4NTWKjkXDA82ayD2dPZrzqBK9ncCMQOOztP9J/P'
        '556AkIM8+8MW2RxJT1ldc3KUUVeRaldzI9SOd0WeQ8dza57P/wDeqtHAJ6yPXskd0prNfK46GulaSK7XgYOtMzewng9o7hscHnt8+d9T0hJ3Y8eZVbgdnIiS'
        'lHZI9se4kllG+sWu7oDo/cWCkbUeQPkdMavbiLBNefMGuYSGeokk5tTYF42EqTyLEZ2DfYyKNlVB8qdnno1facfqiWTdk8R16Izlf07PJJ3RlKVYyNUR1ZLE'
        'P434JZtcj8eOlaumXNnr9jKNJwgqc5mlDYpS5iBjhQkRl3WnMcUKkDSq2x3knQ0PB61HZX28wNREZNxxJnC4vvwsnvSTV5LkEshtRWiTKxTuSIxeCpOh5J2T'
        '0937Xke773EaemQtjFiHYStkruFGMlq2bVyWNpXr0aoZlYeHfZ0vjhR+P36DUKK24EADvPz3jNMMybSLPhG2OjsrgaXqIRU4Llnu9tFdfciRD2v3KD/V+Dzv'
        'xroGFMdMk1CVrUagGZ6zx5WPUqoVXseUQIEEK9240JP6R8nyehYlTiGtMMzGPDUXyuQs14YI4ioJkuAOJB8up0NvvZA/A6Le20KT7QRpqGJAnLyYetXpNiKc'
        'ORiBLPdzSmp735ACnhB+R50Ot2uSd5ryzMDIANgvzxMcGLkkv0NTFQAxq0v8gkmxs77u5tEaOgf+XA63UA/Ux/idpluFEbUbGXo0it61PJaedGlWJV1WYE6C'
        'oPO96XfxvfSmVCRQrHvDVnF7j1i3OWz6d9RriLQglo1p1URRRssUDONugYcd2+WIJ/bpiKdRN45gO2zU2HiVNz05R9MQxHM5evZx08igPiW+oSFWO+4A6450'
        'Fbn56SjfUcAD3jmX6akk3AfT+Gb1Bgp8zkL8sVky+3i8JJEupa4YgyyTH9BGh9utt1QyItheRyZKHc0W4MzsV8rjoa6VZI7teBg61DN7CeD2juGxwee3z530'
        'ikJO7HjzKu2B2ciJKUdkj2x7iSWUb6xa7ugOj9xYKRtR5A+R0xq9uIsE158wa5hIZ6iSTm1NgXjYSpPIsRnYN9jIo2VUHyp2eejV9px+qJZN2TxHXojOV/Ts'
        '8kndGUpVjI1RHVksQ/jfglm1yPx46Vq6Zc2ev2Mo0nCCpzmaUNilLmIGOFCRGXdacxxQqQNKrbHeSdDQ8HrUdlfbzA1ERk3HEmcLi+/Cye9JNXkuQSyG1FaJ'
        'MrFO5IjF4Kk6HknZPT3fteR7vvcRp6ZC2MWIdhK2Su4UYyWrZtXJY2levRqhmVh4d9nS+OFH4/foNQorbgQAO8/PeM0wzJtIs+EbY6OyuBpeohFTguWe720V'
        '19yJEPa/coP9X4PO/GugYUx0yTUJWtRqAZnrPHlY9SqhVex5RAgQQr3bjQk/pHyfJ6FiVOIa0wzMY8NRfK5CzXhgjiKgmS4A4kHy6nQ2+9kD8Dot7bQpPtBG'
        'moYkCcvJh61ek2Ipw5GIEs93NKanvfkAKeEH5HnQ63a5J3mvLMwMgA2C/PExwYuSS/Q1MVADGrS/yCSbGzvu7m0Ro6B/5cDrdQD9TH+J2mW4URtRsZejSK3r'
        'U8lp50aVYlXVZgToKg873pd/G99KZUJFCse8NWcXuPWLc5bPp31GuItCCWjWnVRFFGyxQM426Bhx3b5Ygn9umIp1E3jmA7bNTYeJU3PTlH0xDEczl69nHTyK'
        'A+Jb6hIVY77gDrjnQVufnpKN9RwAPeOZfpqSTcBwOHOfwM+ZyF+WGyZfbxeEkiXtlrhiDLJMf0EaH2623VDIi2F5HMlDuaL8GNMJLi6sawS1VeOVCXpUVViB'
        '/U5Hgc/08kjpT7m6+plKUkUQ5eUZTLHCY+zcqz3XYex29orhVC7PnfcpIA3vXWtpihvNGvvAXVOSgsX9ogyOKmew7wWInntTs7ySRyPIB5KoB4U87HxrpquO'
        'COIplPQxRcW5dnd6s0r0YtRtHLUWIRya8nX6QPx/noqCjIz5wLLHBx5RpicDWzWQbFPUjzUioJfpWkDAcfeUJIHG99vSGdlG8Go9UVjtIuWk3pqDDTtTmtxM'
        'MescklT319uoHOwHmYAI3g7GzroSrXkcxgZQMHiKUjrZf1RLjoczbxOCMf8A7q3gNzi3wSImmbRJB/4/2HT9qou9lBPcenkJOS2o+xWIXwjrP4/D4OFPT2Jg'
        'FvCA1La2ooGqTwu+y4lc7J7da1/VvrS99q8n1gqhFLRqSWejqwSSXsXRspVtZRopMn7haYzp9yIVY67D4AP+ehSz2XPA46V/2E1LnTGCefGMJsk12lXkW3JZ'
        'msWGOQkmUB4QdDajXkEj+4BPSQtGq8o/da2OvMCb0PZjyWPhksSWq1OfvVGj2y6+Sp/WOQR+R8cdMGtgmqJijoGwLsCH0RksQc5HiJGiRozWmv209w1e5v5j'
        'RHY33eN+B/jrNwwW57h1m7TZCcd8JzUNnIJTib+JZHMe1Cta3M3d7UaN9hOh/MJ+ABrXP56WrZJJAHd84jmWgFF33zLI5WKs9ipWtGSWYEyRtDGfZkPLIR/W'
        '2/6x4B6ELwSP5+d0JmuwDI+0Ll+7LFCYqAkfdlrdgSFnOhx28BR8HyfAPVi7QBee6hIm3E4x33Po2AuwYb0HYpU5YrfqhJjF/EpI2ljhqnx7a64Otqd88/t1'
        '29e6rg/TYnJup1hJMVViWCSqrxSoS9KiAx1/U5Hgc/08k/nqd9zdfUyxCEiiHLyjKZY4TH2blWe67D2O3tFcKoXZ877lJAG9661tMUN5o194C6pyUFi/tEGR'
        'xUz2HeCxE89qdneSSOR5APJVAPCnnY+NdNVxwRxFMp6GKLi3Ls7vVmlejFqNo5aixCOTXk6/SB+P89FQUZGfOBZY4OPKNMTga2ayDYp6keakVBL9K0gYDj7y'
        'hJA43vt6Qzso3g1HqisdpFy0m9NQYadqc1uJhj1jkkqe+vt1A52A8zABG8HY2ddCVa8jmMDKBg8RSkdbL+qJcdDmbeJwRj/91bwG5xb4JETTNokg/wDH+w6f'
        'tVF3soJ7j08hJyW1H2KxC+EdZ/H4fBwp6exMAt4QGpbW1FA1SeF32XErnZPbrWv6t9aXvtXk+sFUIpaNSSz0dWCSS9i6NlKtrKNFJk/cLTGdPuRCrHXYfAB/'
        'z0KWey54HHSv+wmpc6YwTz4xhNkmu0q8i25LM1iwxyEkygPCDobUa8gkf3AJ6SFo1XlH7rWx15gTeh7MeSx8MliS1Wpz96o0e2XXyVP6xyCPyPjjpg1sE1RM'
        'UdA2BdgQ+iMliDnI8RI0SNGa01+2nuGr3N/MaI7G+7xvwP8AHWbhgtz3DrN2myE474TmobOQSnE38SyOY9qFa1uZu72o0b7CdD+YT8ADWufz0tWySSAO75xH'
        'MtAKLvvmWRysVZ7FStaMkswJkjaGM+zIeWQj+tt/1jwD0IXgkfz87oTNdgGR9oXL92WKExUBI+7LW7AkLOdDjt4Cj4Pk+AerF2gC891CRNuJxjvufRsBcr4f'
        '0JYo1JYrnqdJjCclJG0scNU+PbXXB1tTvZ5/brt691XB+m15N1JJfUeTsYLIxYmY171pvabtgX21iCkArKfuV9fAHyfz1gVFcF+B847ppfUZCNM5meFtW8VH'
        '7VH20YVXqyxtLqVNgH7VPHcpGwf3I67UIa777+fvN01KgAd3EaT2rfv07UtOxBXmjRUmZWhCyd33rz8+PHB5156SqjIB/f5+0ezE0xE+mj096QselzYu/UZG'
        '1LqQWJu6IRsOO4QjgoD57iSf7dNTTJFjEQ+rRoz5fl6K5r15LNPAqGECuiQJ2RllA+4MvBPI1rxofjqcXp6W0GU7Rqau6b5jD5W1l45M1G2Wjr2vrGjcrIkp'
        '129zIPJA1+rwB1qagC0hq5jpbbmF1PJ/SD5T1fXten4cvmsfRc5GXH0EaKGBWBCush1tRySP26crEaZD0CRVn9xEMoOoCt0DxGcdK21nK5mve+ix1OFZLN5o'
        '3bsA4WEhtq77O+OddT32VQiz8z5SkjtFwamk8LZ6rSjt42GD3Ef2LOmjHvgdw9weO5wQFPx46EHbdH585jCNwG4UIGsb4S7axjvTybRqPfgmhIZUZfIZeQ6h'
        'm0o8656PssA9EQe0pK2DNbleS/6xy0NJJPpcksGrE7Ms6LFoRsPhXKjtIJ8HrN1aYJ6X9+ZpUnUNdamfp+bIUMfYxcqxqJJXcLcQdsCSLuQrI3AV2A+08jnX'
        'PXalE7h/dcY8O+Zp2oKmYJZwdi3UvSzWMZ7UgjM8UrM7AjtBjQnb7Hdo7HGvx0SjUorzfzMBm0ydxNTu7DUwmOlgwVestQXpbL0sivfaY9o07zAb0o/pX7ef'
        'z0NnUN6hPmOPaHtGn/8AMDxuT2TwjVadOvcqwSWsrKyiaO1qE871Kf6SB4+OqEeySpwvhn0kzoQArD9U89PXJqmJmqQiQYoSkS5IZFoY4UU+DwQy/gDk76Jw'
        'C1nnuqAhKrQ477myepMnZwWRixMxr3bTe03bAvtrEFIBWU/cr6+APk/nrgiK4L8D5x3TC+oyEaZozjC2reKj9qj7aMKr1ZY2l1KmwD9qnjuUjYP7kddqENd9'
        '9/P3m6alQAO7iNJ7Vv36dqWnYgrzRoqTMrQhZO7715+fHjg8689JVRkA/v8AP2j2YmmIn00envSFj0ubF36jI2pdSCxN3RCNhx3CEcFAfPcST/bpqaZIsYiH'
        '1aNGfL8vRXNevJZp4FQwgV0SBOyMsoH3Bl4J5GteND8dTi9PS2gynaNTV3TfMYfK2svHJmo2y0de19Y0blZElOu3uZB5IGv1eAOtTUAWkNXMdLbcwup5P6Qf'
        'Ker69r0/Dl81j6LnIy4+gjRQwKwIV1kOtqOSR+3TlYjTIegSKs/uIhlB1AVugeIzjpW2s5XM1730WOpwrJZvNG7dgHCwkNtXfZ3xzrqe+yqEWfmfKUkdouDU'
        '0nhbPVaUdvGwwe4j+xZ00Y98DuHuDx3OCAp+PHQg7bo/PnMYRuA3ChA1jfCXbWMd6eTaNR78E0JDKjL5DLyHUM2lHnXPR9lgHoiD2lJWwZrcryX/AFjloaSS'
        'fS5JYNWJ2ZZ0WLQjYfCuVHaQT4PWbq0wT0v78zSpOoa61M/T82QoY+xi5VjUSSu4W4g7YEkXchWRuArsB9p5HOueu1KJ3D+64x4d8zTtQVMwSzg7FupelmsY'
        'z2pBGZ4pWZ2BHaDGhO32O7R2ONfjolGpRXm/mYDNpk7iand2GphMdLBgq9ZagvS2XpZFe+0x7Rp3mA3pR/Sv28/nobOob1CfMce0PaNP/wCYHjcnsnhGq06d'
        'e5VgktZWVlE0drUJ53qU/wBJA8fHVCPZJU4Xwz6SZ0IAVh+qeen7s1PETVYRIMUJT7uSGRaGOFFPg8EMv4A5O+icAtZ57quAhKrQ477mfuV8X9VcaSBMWD2W'
        'LET9xXZ4c7PcpPA1+B1wDPS9ZpK6dseIRlsdWtNWmriWaqqFpbfZqLt40wPnQ+T5HXKSLB57prqDTDiMLPuqUhgn+rZBGkV2CSSxUj5/Qy6JP2nYIHgknpIo'
        'ZIrwwD5xuTQHvyI9v4uPKZD2KDZGGsmjJUV2WF21zYSJv0qBoaJ10sarquSPnSGdBGa+sVeobEkfp3EU2W/LJWuNN7dWXtEXwpJ5AHjn8bPW6VF2bHHWdrAh'
        'FHdAc9JDlsVKYjPjZkRz9Q0nutKNEFWKaJjPj9z0emSjVyPn3gatOL4M+iYuer6i9KSXMO6Wo1rrC7xmRdkIP5ckQIKqdHfxwP36woyE7py6gcCpEQOfWM91'
        'Pq78GMgiEP0zZELFGi/aOyLWixbxvegvnrnY6dVV+UJEGrfQT6nivSfpbB4BYfUN2x6vvLF31TkS6U4D5SOJEIJIPPefIHUf1GZrRdvlzKxpBV7R3efEnMxW'
        'qlpIsbBe+oZ/fsR45BB7b9v3tEzfdpgAp7jvXI10wEA2arxglT0+0RxReo7k9eazaix8O/YTEmUnugH3aiYbLuNbYn8EdEx0xgZ8fHx7otRqnJx4fOsm6cFv'
        'M2K8oyMU9GL3HEs9M+y6sdsXViD7h8DjQGtdU4WwRnzz/Um7TEEHE3xoo+pxkE9rsgrI8kYpxDvmPgBA39ZOtj4HgdGQdOs8/M+EAVqWAOIFcgynp6oqWq8Y'
        'n7A61p5hK/A43r9K/wB/PQ0rnE22QQbG5ipLhrkmQvCCewvavdEZXOj+hY/C6PjfkdayMHG0YHzmamopQlzkzWPK37uOrfxCOOxMrxvVcIqkhT924v0sO3wT'
        'z56wqqsdvr/c7czp2pkZK2LNq40kCYsHsnsRP3Fdnhzs9yk8DX4HRgM9L16QCV07bpCMtjq1pq01cSzVVQtLb7NRdvGmB86HyfI65SRYPPdNdQaYcRhZ91Sk'
        'ME/1bII0iuwSSWKkfP6GXRJ+07BA8Ek9JFDJFeGAfONyaA9+RHt/Fx5TIexQbIw1k0ZKiuywu2ubCRN+lQNDROuljVdVyR86QzoIzX1ir1DYkj9O4imy35ZK'
        '1xpvbqy9oi+FJPIA8c/jZ63SouzY46ztYEIo7oDnpIctipTEZ8bMiOfqGk91pRogqxTRMZ8fuej0yUauR8+8DVpxfBn0TFz1fUXpSS5h3S1GtdYXeMyLshB/'
        'LkiBBVTo7+OB+/WFGQndOXUDgVIiBz6xnup9XfgxkEQh+mbIhYo0X7R2Ra0WLeN70F89c7HTqqvyhIg1b6CfU8V6T9LYPALD6hu2PV95Yu+qciXSnAfKRxIh'
        'BJB57z5A6j+ozNaLt8uZWNIKvaO7z4k5mK1UtJFjYL31DP79iPHIIPbft+9omb7tMAFPcd65GumAgGzVeMEqen2iOKL1HcnrzWbUWPh37CYkyk90A+7UTDZd'
        'xrbE/gjomOmMDPj4+PdFqNU5OPD51k3Tgt5mxXlGRinoxe44lnpn2XVjti6sQfcPgcaA1rqnC2CM+ef6k3aYgg4m+NFH1OMgntdkFZHkjFOId8x8AIG/rJ1s'
        'fA8DoyDp1nn5nwgCtSwBxArkGU9PVFS1XjE/YHWtPMJX4HG9fpX+/noaVzibbIINjcxUlw1yTIXhBPYXtXuiMrnR/QsfhdHxvyOtZGDjaMD5zNTUUoS5yZrH'
        'lL93HVv4hHHPMrxtVcIoJCn7txfpYdvgnnz1hVVY7fX+5wZnUbp3nfT0kcE8MUFMJGNtZWIFpEH5PjX7eT1um+bNzNRDVShxuBggpJDfy9lr1qm0z0I5IZYy'
        'Br2oxpvOtHXyOPjoGJuwMDrn1hooqibPdFNSzNC8n0ARbUkYVYakgQRyg8d4P6dNzvwfHjrGUH9XHjOViP0faMMZk6yBZMnddJvbYX6sjd1uMLywUeH2daP+'
        'Ncdbto9kY6d07fY7RzD19Rx5rDx0q5fEel8mfq5K0MRJ/lntD7b9bE8doPapP7dCxZLB5EYoXU2kcEQjHYOe7HKtdMdC84IiZpC0ceyRqQj+r9hxs9AMkDMI'
        'rSyR9ZemrfoqjUxuUyRx+K2Hkkw+w99j/TJJvuUj4Q/HVy2WJC58eBPONBQC2PDrJr0xjLSKk0tWPFVvedlyHve5JaDa7UcEnQHHgeeOu1WXIuz3d0LSV8Gq'
        'Hf3ysb1RnMLZhmrSzUfpu4ub8ayiRieNBSQuhyAeT/jqYIjCub7pQzaiEEYrvjnFHLyXnrTWzHaNVsnPetxd6KT+kELwO7wCfPP46S2yt1Y4qUaZcHbeT1mN'
        'b1LYwNWWXIvFfyM8izQskqtLSVdbWJxwhY+ed9p646avhcD8+c5XZMtk/iLDYzU0l7Px3Lb2cjJ7U7RyI81Qb+0rGeOwDz865HVCjTAGnih9/WSsXN6nf9p1'
        'ibdnP0ffxv09+57jF74rMi9sbcsEXhSflzx0xl2ttYUPnyotX3LuBzF+TydB7ssyyGlDNqT3e0HsYAhhvyV86J+eetCtVc1OZ1vMA9NYOrBHVtPO4eaEysn9'
        'Uis32lx+4HBH/wB9DquxJWoWjpqAGJlLNhqGRyakK9OO3JpzEQI4h2/anb5XZAO/3P46nDuF8pUyIW84szvp6SKCeGOCmEj/AFWViBaRR+T41+3k9P03zZuT'
        '6iGqlDjcDBBSSG/l7LXrVNpnoRyQyxkDXtRjTedaOvkcfHS2JuwMDrn1hooqibPdFNSzNC8n0ARbUkYVYakgQRyg8d4P6dNzvwfHjrGUH9XHjOViP0faMMZk'
        '6yBZMnddJvbYX6sjd1uMLywUeH2daP8AjXHW7aPZGOndO32O0cw9fUceaw8dKuXxHpfJn6uStDESf5Z7Q+2/WxPHaD2qT+3QsWSweRGKF1NpHBEIx2Dnuxyr'
        'XTHQvOCImaQtHHskakI/q/YcbPQDJAzCK0skfWXpq36Ko1MblMkcfith5JMPsPfY/wBMkm+5SPhD8dXLZYkLnx4E840FALY8OsmvTGMtIqTS1Y8VW952XIe9'
        '7kloNrtRwSdAceB5467VZci7Pd3QtJXwaod/fKxvVGcwtmGatLNR+m7i5vxrKJGJ40FJC6HIB5P+OpgiMK5vulDNqIQRiu+OcUcvJeetNbMdo1Wyc963F3op'
        'P6QQvA7vAJ88/jpLbK3VjipRplwdt5PWY1vUtjA1ZZci8V/IzyLNCySq0tJV1tYnHCFj5532nrjpq+FwPz5zldky2T+IsNjNTSXs/HctvZyMntTtHIjzVBv7'
        'SsZ47APPzrkdUKNMAaeKH39ZKxc3qd/2nWJt2c/R9/G/T37nuMXvisyL2xtywReFJ+XPHTGXa21hQ+fKi1fcu4HMX5PJ0HuyzLIaUM2pPd7QexgCGG/JXzon'
        '5560K1VzU5nW8wD01g6sEdW087h5oTKyf1SKzfaXH7gcEf8A30Oq7ElahaOmoAYmUs2Go5DJqVV6aWpdOYiBHEO37U7fK7IB3+5/HU4dwvlKmRCfOE5a5Uyk'
        'lfHxwVb9xJnewsLlqrwFB7ULtxuVWBPeONHR60Ahd3Hj18/KASGbaM/j+4H/AA6p6OzGSqT06sdtK/upHjou4vIV2g7vKa2Sd/jpgY6ihrNePzMXtGmxFUYL'
        'Q9QZC/ektNWq/wAoGpJDDEIw0wXu27gbLaPcP231rKAKgoxJJiNsTCEZLJgHeC5n9549Hf6y+t6GypP4PTC5vswQg/8AUfxZ6WpLhPTuDjivti3lmXLyTvNW'
        'YHUixIjDXZGQTsfqJ6nKA7tXUxfTr5+scHKldPTzXXp5SoxGTzmT75Ikeyt4tamu20FWIzN/SiaPwPOgNA66UWTT8xjvj1V9TFY9pJrRzljLfT5j6SVFkLJX'
        'ctoSfBBPLHWtfA31U+qrJaXJF0XD08Jy2AOJxcsWOiSBgPckn7v9pgeNtyAQeSPnz0lXLNbZj2RVWlnN5reGzTTxWUhyE8BE9ikqkylhrZU7XTc68Hz1i061'
        'WB3wntWvqRG0WYnimg7bF6vDJDGlX+QAk9hfPdxpAP6VOx89L2gg4Hj5fvDDMrDM49XKriS9ap01yNhfYnnqL7SPv+rt12d/78ddp2eyDgfPabqAfqIzAslh'
        '6E9GrYOPhS5Qi9h5onKtOdcFl3vv0eCONA9NR2BIBwYpkVgDWRAYYPUlm9BSw/u3oatcynH44qrR19EyP7ex36H3HZ5Hnnp31NNV3amL6nv85OdPUJrTz4Du'
        'kSnqBcrdnq1Vkjhba+/Zr9kpi/Ij+AfkD56sKbQCfnrIVfe20feWtesL4ml7WpSMqM8gcKCgH2dqnwdjwPHP568+9uOZ6VXniMa8Mwqoxk9x4ZWmdAoUSO+l'
        'fuP6joDQHxsnoWYd0ILwbhOYuVMpNBj44Kt+4kzvYWBy1V4Cg9qF243KrAnvHGjo9cAVXccePXz8pxO5toz+P7gX8Oqejsxkqk9OrHbSv7qR46LuLyFdoO7y'
        'mtknf46YGOooazXj8zF7RpsRVGC0PUGQv3pLTVqv8oGpJDDEIw0wXu27gbLaPcP231rKAKgoxJJiNsTCEZLJgHeC5n9549Hf6y+t6GypP4PTC5vswQg/9R/F'
        'npakuE9O4OOK+2LeWZcvJO81ZgdSLEiMNdkZBOx+onqcoDu1dTF9Ovn6xwcqV09PNdenlKjEZPOZPvkiR7K3i1qa7bQVYjM39KJo/A86A0DrpRZNPzGO+PVX'
        '1MVj2kmtHOWMt9PmPpJUWQsldy2hJ8EE8sda18DfVT6qslpckXRcPTwnLYA4nFyxY6JIGA9ySfu/2mB423IBB5I+fPSVcs1tmPZFVaWc3mt4bNNPFZSHITwE'
        'T2KSqTKWGtlTtdNzrwfPWLTrVYHfCe1a+pEbRZieKaDtsXq8MkMaVf5ACT2F893GkA/pU7Hz0vaCDgePl+8MMysMzj1cquJL1qnTXI2F9ieeovtI+/6u3XZ3'
        '/vx12nZ7IOB89puoB+ojMCyWHoT0atg4+FLlCL2Hmicq051wWXe+/R4I40D01HYEgHBimRWANZEBhg9SWb0FLD+7ehq1zKcfjiqtHX0TI/t7Hfofcdnkeeen'
        'fU01XdqYvqe/zk509QmtPPgO6RKeoFyt2erVWSOFtr79mv2SmL8iP4B+QPnqwptAJ+eshV97bR95a16wviaXtalIyozyBwoKAfZ2qfB2PA8c/nrz7245npVe'
        'eIyrQzCsjGT3HhlaZ1ChRI76V+4/qOgNAeBsnoWI7oQXg3cZ+osnJSnr4mpLFat2V0kUcSsZBvXtqDryRy37dAqit5FAfLhk52jkxXisa/p/PZCX1FjpMpVy'
        'Q3NdrS6tVgdEyxN+lwOBo+e0Do2caqgaZojp0PgYCo2k5+qLvr1EUUrDVo7LJNZhjjkEjPYiEnuIpKxtIg8MoJ3+AenkXQ+eMnUkXRhMC2qGbvVMglW1eRll'
        'WbazwMvbvZUnlSvgf9+gYKygrYHsY1bUkPVzaouONgGq0VIXrJl99pBHCsmvtRFP6ASftHjoCHODmvnrDGxcjFx/V9e/+lZHxtnEW7+QyR9mH2wDB3qSxP3c'
        'gaHdseSOOlD/AB/qdoEAD3jG/wAkaXYYHMxi9VwZbLLNHDV9+OJo4/scxhSfyfJJ3v8AHWfT2LRuF9Te1jmdessfPL6WH0cd6rP2/U2YIVLRyx7AUSKeE/IP'
        'yB0ek6h6aoGtpsyYx+86zfpjK1fTRu5CxWTFRzIyyFFmR5GIKogBDSeBv4HQo4ZsDPsf4m6ikfqMnzkr0twVoKUNXHBh9VBHbco7EbJAb9HPOt/HHR7VAsnP'
        'TEDe10BiMPpBHBNFibz/AFV2JkihSRJo5nBBVj3Hhv8Ap+R1m6j2xxC2ki1Mwr0JsNkv4hajmigkHu3EgjNgRMo+8qDy37Acfd0VhxtHp0gUyHcwm2fdMjjH'
        'jxlYCOzW7izr2TCPYYQdo5BHyN8jodPst2jwfTzjH7Qtes0y2AyFG9QsQ1o0aSsBHNYKKiORvfuk6VR/456xGVgwJ6/MTGUhgRMZKEyWYPcirZ2vAT701CYK'
        'kjH9Xt93JK+C2tHyOmKVAxjzgMCavPlHwqQJHbePK0Z6zoKssIQ6qnfcGiB/UV4BcEg7P46UWJNbTf584wAAfqxA/UeTkoz18TUlitW7C6SKOJSZBvXtqDry'
        'Ry3WqoreRQHy5hPa2jmK8VjX9P57IS+osdJlKuSG5rtaXVqsDomWJv0uBwNHz2gdGzjVUDTNEdOh8DAVG0nP1Rd9eoiilYatHZZJrMMccgkZ7EQk9xFJWNpE'
        'HhlBO/wD08i6Hzxk6ki6MJgW1Qzd6pkEq2ryMsqzbWeBl7d7Kk8qV8D/AL9AwVlBWwPYxq2pIerm1RccbANVoqQvWTL77SCOFZNfaiKf0Ak/aPHQEOcHNfPW'
        'GNi5GLj+r69/9KyPjbOIt38hkj7MPtgGDvUlifu5A0O7Y8kcdKH+P9TtAgAe8Y3+SNLsMDmYxeq4Mtllmjhq+/HE0cf2OYwpP5Pkk73+Os+nsWjcL6m9rHM6'
        '9ZY+eX0sPo471Wft+pswQqWjlj2AokU8J+QfkDo9J1D01QNbTZkxj951m/TGVq+mjdyFismKjmRlkKLMjyMQVRACGk8DfwOhRwzYGfY/xN1FI/UZPnJXpbgr'
        'QUoauODD6qCO25R2I2SA36Oedb+OOj2qBZOemIG9roDEYfSCOCaLE3n+quxMkUKSJNHM4IKse48N/wBPyOs3Ue2OIW0kWpmFehNhsl/ELUc0UEg924kEZsCJ'
        'lH3lQeW/YDj7uisONo9OkCmQ7mE2z7pkcY8eMrAR2a3cWdeyYR7DCDtHII+RvkdDp9lu0eD6ecY/aFr1mmWwGQo3qFiGtGjSVgI5rBRURyN790nSqP8Axz1i'
        'MrBgT1+YmMpDAiYyUJkswe5FWzteAn3pqEwVJGP6vb7uSV8FtaPkdMUqBjHnAYE1efKPhUgRLbxZSjPWdBVlhCHVU77g0QP6ivALAkHZ/HSi1mipv8xigAfq'
        'xJnI+oKt3Opb9+epTotDDVbHRKZoFduAxbnbEgk/09O2MVqrJ5vjHz1ifqANYNV3RjH7lm41bPXYrV/6uRWnu7IjXYKqQNdh+B8Hz0k0ovSFCunzMcuT/sN5'
        'jLES3oLWQtWPSt6fEYx0l9ikCDeTv0ypIQSGA0535GhroCqkL/sFt39Ie9lLdjC93WILVm9ase3kaqXqc6tI1qaFYpEcsWCsQNEa/wAfv08FAOyaPdz7RFuT'
        'TCx7Q3EVqt+aBMrjq9aoIppvpZQTGyDWz3N+o7Otj9PjoGJAJQ3CAB7LCcUMf6Z9S2MZPehloZmpIy2LLoWpQgH7GR97IIP6fAP9j0RZ9MUhwfeZsRzbDIiO'
        '3n3xtqZcVJVkuR9wq2Q32BQ2iU+Nn9//AL6YNIEW111izqlTS8xxhvU0RWW/NkTfsfVanFpXZyoj1vanWtngfHQPpknbVYjE1KF3FeQxN2KWVIsvE12ZzOIK'
        'vdJYq8gk88KSPAHTFdTRK4+ximRhhWnVeHIY3GyUI3lvxZCTb2b0RknTX/UPtIPg78f36xiHNnFd3E5VKCgblbgvSt5oLchrzS3bYW2zLVVUiQDt7+3W118g'
        'fHUWpqCwOg8ZdpaZAJPWbHPQpjbmMyztLjUjI7MTaaNg/lGaTXcw3zoaH546IA2GUZ8RBaiNrH2gvp5WsYD3JPavSV9Ge1BEWb/8nH5+CfB61r3YFTFoLzcR'
        'jE/xDLV2mhq0zBNJKlFw7JYRVH+4p4029gj8aHTi+1TRu+vd5RO0swxVfeOBiZLEay2sTjsBSKSkW4WJXaL3KCSSXB1rS/nR6AMOjEwypP8A5Ahcn+ofoy9g'
        '61hMc8DSwp2xVa/f7bnllO9djA7Ovnx1g0NYOwJhnW0SgIEl8j6grXs6tszz1KlFooar46JTNArtwGLc7YkEn+np+xiu2rJ7+MfPWTbwGsGq7oxj9yzcatnr'
        'sVq/9XIrT3dkRrsFVIGuw/A+D56SaUXpChXT5mOXJ/2G8xliJb0FrIWrHpW9PiMY6S+xSBBvJ36ZUkIJDAac78jQ10BVSF/2C27+kPeyluxhe7rEFqzetWPb'
        'yNVL1OdWka1NCsUiOWLBWIGiNf4/fp4KAdk0e7n2iLcmmFj2huIrVb80CZXHV61QRTTfSygmNkGtnub9R2dbH6fHQMSAShuEAD2WE4oY/wBM+pbGMnvQy0Mz'
        'UkZbFl0LUoQD9jI+9kEH9PgH+x6Is+mKQ4PvM2I5thkRHbz7421MuKkqyXI+4VbIb7AobRKfGz+//wB9MGkCLa66xZ1SppeY4w3qaIrLfmyJv2PqtTi0rs5U'
        'R63tTrWzwPjoH0yTtqsRialC7ivIYm7FLKkWXia7M5nEFXuksVeQSeeFJHgDpiupolcfYxTIwwrTqvDkMbjZKEby34shJt7N6IyTpr/qH2kHwd+P79YxDmzi'
        'u7icqlBQNytwXpW80FuQ15pbtsLbZlqqqRIB29/bra6+QPjqLU1BYHQeMu0tMgEnrNjnoUxtzGZZ2lxqRkdmJtNGwfyjNJruYb50ND88dEAbDKM+IgtRG1j7'
        'QX08rWMB7kntXpK+jPagiLN/+Tj8/BPg9a17sCpi0F5uIxif4hlq7TQ1aZgmklSi4dksIqj/AHFPGm3sEfjQ6cX2qaN317vKJ2lmGKr7xwMTJYjWW1icdgKR'
        'SUi3CxK7Re5QSSS4OtaX86PQBh0YmGVJ/wDIELf/AFD9GXsHVnTHPA0sKdsNWv3+255ZTvXYwOzr58dYNDWDsCfvDOtolBQg3qf0XdwuJq4GWvFJkwvuwQYg'
        'pNFYBGmlaY8njg9w2B8eOnBgHLk48fxUlK2m0DMQx07ePSZcvUhxdBFEsUMrMykgabcrcs29ftvnrSVYgobPzpMXclhxQlPis1P6swNdv4vTC15GjrhrUiPS'
        'bY27Ig+9yPDMe389Tuo0Woqfbn/glaN9VbB+8eeisNh4MzJDlLVb1CtaMtQq35i6T/H39n+4EOz2rwd6+OmaNO+7bXf5xOvaLt3Z/aJPXqYw5DG05K9es9iZ'
        '4nEQMULwMAWcIx1H2sBrwOdnqnU09i7lFSbS1Cz7GMhfUmQFeAw08PLQmE3u2rde3JbF1VPaB2kBFTgnjye4eOl6YB5a/Sq/mM1TWAKmaQz2sjDcijSwJiBX'
        'rywiNdH40Od8bP8AYDrScFDNAzvE7prLkrTsklkyV1fXZABGWB0zEfPyo346IrsGesAHefKOfQcl/Iy5rGU4o4VtMD700REka/s3JGz+Px+OlagA2kxmn2iR'
        'PoNX0hklrrVr1Ynvwopr1sZYZw6nffOYyN741onzz0kU5ode/wDFx5JQWekjfVWSs+lJ71gtJcgYL7TTs62Fc+YpBsb/AHUfkdGmkHodft5xbax089OkSxZb'
        '1G96wz1KGLp5OqkiR2SHmZU4ChfKd29c/HRnT0goFkkH0ixqapYkgAESuyWSv2EqpiqFLH1PoXhsIkxrCdZl7PaI13FP8b389S6Y2E7ibvzlur2gAqioku5S'
        '7W9uuci89p4Ud8YCrCFUXtXuccofjR5+eOqNinJHr85kxcg0D6QhcHivU1+hewkkqY9qrRxy2f5Qr2A33qsjHtHO9nQ2AB0o6rae5H5vzx5Ro0hqAOhxX3kn'
        'jvQWa9Uera0lTJLl4J5nryKxEMRK7PuiVRoL/wBZ589eh9VFTbVH5ieb9Ji267EtPU/ou7hsTVwMleGTJhfdggxBSaKwCNNK0x5PHB7hwPjx1MGAcsTjx/FS'
        'ki0CgZiGOnbx6TLl6kOLoIolihlZmUkDTblblm3r9t89aSrEFDZ+dJi7ksOKEp8Vmp/VmBrt/F6YWvI0dcNakR6TbG3ZEH3uR4Zj2/nqd1Gi1FT7c/8ABK0b'
        '6q2D9489FYbDwZmSHKWq3qFa0ZahVvzF0n+Pv7P9wIdntXg718dM0ad922u/zide0Xbuz+0SevUxhyGNpyV69Z7EzxOIgYoXgYAs4RjqPtYDXgc7PVOpp7F3'
        'KKk2lqFn2MZC+pMgK8Bhp4eWhMJvdtW69uS2Lqqe0DtICKnBPHk9w8dL0wDy1+lV/MZqmsAVM0hntZGG5FGlgTECvXlhEa6Pxoc742f7AdaTgoZoGd4ndNZc'
        'ladkksmSur67IAIywOmYj5+VG/HRFdgz1gA7z5Rz6Dkv5GXNYynFHCtpgfemiIkjX9m5I2fx+Px0rUAG0mM0+0SJ9Bq+kMktdaterE9+FFNetjLDOHU775zG'
        'RvfGtE+eekinNDr3/i48koLPSRvqrJWfSk96wWkuQMF9pp2dbCufMUg2N/uo/I6NNIPQ6/bzi21jp56dIliy3qN71hnqUMXTydVJEjskPMypwFC+U7t65+Oj'
        'OnpBQLJIPpFjU1SxJAAIldkslfsJVTFUKWPqfQvDYRJjWE6zL2e0RruKf43v56l0xsJ3E3fnLdXtABVFRJdyl2t7dc5F57Two74wFWEKovavc45Q/Gjz88dU'
        'bFOSPX5zJi5BoH0hC4PFepr9C9hJJUx7VWjjls/yhXsBvvVZGPaOd7OhsADpR1W09yPzfnjyjRpDUAdDivvJPG+gs16o9XVZamSXLwTzPXkDEQxErs+6JVGg'
        'v/WefPXofVVUK1R+Ynm/SYtuuxPbGeyF/IRiqs4m7y81uVTH7bsvasa9w2xGiSD8/no9Ta1kwdMslAXLiL1Nf/1Iu4/HG7hLMGPUQzW7JarHNKB+tmkGl1rQ'
        '15I/fqH6Y07aiL9fxLg51MWDUQ+qLtrGNWmpQCzVsb7XoyKzNptGNmUD+440OOtRA4IJyO/8zHf6dED2jJbpzD0SaHsST2UhoiCExyxKF8tLvTMTx9utkEda'
        'l6JJB45gvt1VAYeUJFb03Yr5g2JxLk1ZksZHMykrKAeVjU8Ab0utHzvwOu1NTVcAk46ATdLT0tM0BnvMRZG5cjSJYcDEO2RZjiZLDSmxED8S8Kyjz2gDtIGv'
        'PQgLdlvWuPSaxYYC5EKhz2RwtyXIMtPstOWlnvorNXB5UKu9L3fp4+R+emKivad3d1gvqMlN08ekQZDNCpDkALRrRfTkxTVAUMc/lQ0fghhsf2HVSoDVj37p'
        'K2rV0ZS+jM1dydxI8RHHk85ZQaWqn06IpXTbc8KoHO/nqXURV/VhfGVabs4FZMMyPqCX09kYxYykuEeV40nnoytcb+WCpZJONNot9oPjoVXcvF16Q2co2cX6'
        'yTynqmST1Bi8hi8hVsYaG208MWQi+peddEMJAdHZHI34Pz05VpSGGfaTs3aUq2Lhk2Kgv4TK3rc/0OV7ozUprXeaWypBYOZAdQxoPk7JPGtdLU0QBkfPeMYb'
        'gSRUV4z1D6ilyDWoIRm88yiJ/drm48kQ0AoT4/Yj56Yy6airpfbMWr6jGwLMzydHLTZ25ZtVpI5YnH8QieL6YwnXKy/KNr/x0KsoQL7dfaEwYvuI85xhPT1T'
        'OWcpShrNJCOw/RWZmijIbxJ/xAP/APOibUbTAa/WCmmrkrUvMVl8x6UxtqHG4ysbMCCsn88SPVjJ5MKDgl/+Xzo9J0309+5zz8zHaiPs2r0kVPnchevxCos4'
        'l7y81uVTH7bsvasa9w2xGiSD8/nqzU2tZMj09yUBcuIvU1//AFIu4/HG7hLMGPUQzW7JarHNKB+tmkGl1rQ15I/fqH6Y07aiL9fxLg51MWDUQ+qLtrGNWmpQ'
        'CzVsb7XoyKzNptGNmUD+440OOtRA4IJyO/8AMx3+nRA9oyW6cw9Emh7Ek9lIaIghMcsShfLS70zE8fbrZBHWpeiSQeOYL7dVQGHlCRW9N2K+YNicS5NWZLGR'
        'zMpKygHlY1PAG9LrR878DrtTU1XAJOOgE3S09LTNAZ7zEWRuXI0iWHAxDtkWY4mSw0psRA/EvCso89oA7SBrz0IC3Zb1rj0msWGAuRCoc9kcLclyDLT7LTlp'
        'Z76KzVweVCrvS936ePkfnpior2nd3dYL6jJTdPHpEGQzQqQ5AC0a0X05MU1QFDHP5UNH4IYbH9h1UqA1Y9+6Stq1dGUvozNXcncSPERx5POWUGlqp9OiKV02'
        '3PCqBzv56l1EVf1YXxlWm7OBWTDMj6gl9PZGMWMpLhHleNJ56MrXG/lgqWSTjTaLfaD46FV3LxdekNnKNnF+sk8p6pkk9QYvIYvIVbGGhttPDFkIvqXnXRDC'
        'QHR2RyN+D89OVaUhhn2k7N2lKti4ZNioL+Eyt63P9Dle6M1Ka13mlsqQWDmQHUMaD5OyTxrXS1NEAZHz3jGG4EkVFeM9Q+opcg1qCEZvPMoif3a5uPJENAKE'
        '+P2I+emMumoq6X2zFq+oxsCzM8nRy02duWbVaSOWJx/EIni+mMJ1ysvyja/8dCrKEC+3X2hMGL7iPOcYT09UzlnKUoazSQjsP0VmZooyG8Sf8QD/APzom1G0'
        'wGv1gppq5K1LvF5bMelMZbhx2MrGzAgrIffEj1YyeTCg4Jf/AJfOj0nTfT37n6/Mx2oj7Nq9Ioy0BNWSWS4klydSVFez7zNxoOjeAoHA3zx1ic4EJhYzPLWD'
        'pYfCtE8okq3Pba4GBIkIH2eRrgc6876qQbjfUcSRrUeBiTDQ3qdq7LSgq1mVwgmsVDLYA+AG32pseByfH56xypABzNQMMqJSXjVtPWsXlMmInrgiKyTGiEb2'
        '+zo9w1zob546nFjC8yo1dtxF9rO4jKoTRxK271eD3KqHcsUrkBQve+ihUHfcfOt/HQ7HT9TUD89ZxdGwq2YtvZDI3IErz4z+ITwyD3DPMFVAPhRvZ1/Ufnz5'
        '6NQqkkGrmEswAK3UZV6WJyWQhqwVhVec/UT1TJ7ySOv6e73NKm98Ls8Dfz1m7UC2T89JpXTLUB+8yXBvFkJRZtWMSsMcks4sQBxABr7mAOuzng70PHO+j32O'
        'L9fmYH0wG5qDXPWtX0O8briZ3mZisDRWO2O3zoS6HI3vgDgA9Givq8MK8uPCAzJo8qb/AD4xb9amfJh7ZcajRvKsZWRoy+9BEIBJc72fjQ6PcU8fn4gbRqNQ'
        'xMziIqK2pKlGGaGuO6Sc129wldd3cpP5/PnoN5agxm/TCZUSlueobGOqpahs469Hai2IMZAyyIxA337P6xzoNwelhA2CCK740vtF4I8Ix9G/SVu+7BkDLXhK'
        'hqtWY1pSx/TDIG5jbf8AUDo/jXS9UX2SPXn18fKHo9Spia1jny2UYuUozNc96xSluGw4AGyrsf8AcIHPc39umBtq4yKwar+oFb2uPc1UkhxS2MVlYaEcyNDH'
        'BHWYBmYjt1JvuZif8DfSEIJp1v1j9QGuw1TS9PBjKhjs2K8csaxozPuKLuI+/tZSSx3van9PWAFj2R8+dZxNfqOYty9c/TSyyXEkuTqSor2feZuNB0bwFA4G'
        '+eOmpzgRbCxmeWsHSw+FaJ5RJVue21wMCRIQPs8jXA51531Ug3G+o4kjWo8DEmGhvU7V2WlBVrMrhBNYqGWwB8ANvtTY8Dk+Pz1jlSADmagYZUSkvGraetYv'
        'KZMRPXBEVkmNEI3t9nR7hrnQ3zx1OLGF5lRq7biL7WdxGVQmjiVt3q8HuVUO5YpXIChe99FCoO+4+db+Oh2On6moH56zi6NhVsxbeyGRuQJXnxn8QnhkHuGe'
        'YKqAfCjezr+o/Pnz0ahVJINXMJZgAVuoyr0sTkshDVgrCq85+onqmT3kkdf093uaVN74XZ4G/nrN2oFsn56TSumWoD95kuDeLISizasYlYY5JZxYgDiADX3M'
        'AddnPB3oeOd9HvscX6/MwPpgNzUGuetavod43XEzvMzFYGisdsdvnQl0ORvfAHAB6NFfV4YV5ceEBmTR5U3+fGLfrUz5MPbLjUaN5VjKyNGX3oIhAJLnez8a'
        'HR7inj8/EDaNRqGJmcRFRW1JUowzQ1x3STmu3uErru7lJ/P589BvLUGM36YTKiUtz1DYx1VLUNnHXo7UWxBjIGWRGIG+/Z/WOdBuD0sIGwQRXfGl9ovBHhGP'
        'o36St33YMgZa8JUNVqzGtKWP6YZA3Mbb/qB0fxrpeqL7JHrz6+PlD0epUxNaxz5bKMXKUZmue9YpS3DYcADZV2P+4QOe5v7dMDbVxkVg1X9QK3tce5qpJDil'
        'sYrKw0I5kaGOCOswDMxHbqTfczE/4G+kIQTTrfrH6gNdhqml6eDGVTHYsV45Y1jRmfcUXcR9/aykljve1P6esALHsj586zia/UcwjAYyRKcVSiUtpUHuD3oz'
        'CknH2MwI2ACeW8eOOuY2SWxc0LtAAizJY/JyVpKc+Rllqyhpb+MryieEOOFnBA2G1zr/AL66ergcDyP7SdlLWSfMTB8VDRxWLYRTTVPvem6SF/dG/wDc0CB5'
        '43zwNdZvLMbOesPYFUUJrhYseMTUtyTrKs9poGeSbvnrqASdwH7pPye0j4HRFSTRx874IIqxmLMnbTJzTYcWQakRE1mWGPtJj+GkP6hz4XyBsdYF29vr0/j5'
        'zOLbzs95pj/TePxlSxXjuUbKU+Q7yEAjeyYweZByNL/330BdnYNRz89I1UCLQPE8q0aOYqw1J7tTH5R2kDyQydyWNnahix0rKBoKuuDrphtcgYk+G5OZbp6f'
        'xd70xPLJnI6XqDGVDcvSTqQohAHantPtW23aFQeNgnqZmZdSgOyfz5j8y1Qrae6+0vMmvVcvpy5jMQ9lPYzePD5AxU1LEAgARyf8NsQSAOT+3TNIao3AZBx8'
        '74nVOk20nkZialE+Xx8F2WvYgzrAw3a9aUiNVU/aYFUcb/8A3v46M9k7R+noT+8BTuG44Ma0qpvQW5GrX75rssdqOsG4lJ+zu/xxzvnpdG6GI2wRcWLTM/qu'
        'rHjIoqjQv7liok4MzqRtlSNhy4AOif076bZ+md/vEHOoPpzqe3TGasufr8LfvS+5PC9ZJZ5UJ1GCfLE/PYP36IK1AUGA8YBZQT0Jn0PH/wCl8HpjBZzMz3FF'
        'izB7a42CMWZIwvMilmOg763ob1430erpampQAqs93yoOlq6SWxN3iTD1cflYfdip2KccP3o89pe8cfZ2jfBJ+ANnqTtKau/SWDaRxB8jG2XvWbdqwMgWjjrQ'
        'pOVqCPWy8iRqPvI0Rs8nnolO0ADH3mMNxNxpgcZJHUiqUWS2lT+YPejMKScfYzAjYAJ5bx446BjZJbFwwoUACLMlj8nJWkpz5GWWrKGlv4yvKJ4Q44WcEDYb'
        'XOv++unq4HA8j+0mZS1knzEwfFQ0cVi2EU01T73pukhf3Rv/AHNAgeeN88DXWbyzGznrD2BVFCa4WLHjE1Lck6yrPaaBnkm7566gEncB+6T8ntI+B0RUk0cf'
        'O+CCKsZizJ20yc02HFkGpERNZlhj7SY/hpD+oc+F8gbHWBdvb69P4+czi287PeaY/wBN4/GVLFeO5RspT5DvIQCN7JjB5kHI0v8A330BdnYNRz89I1UCLQPE'
        '8q0aOYqw1J7tTH5R2kDyQydyWNnahix0rKBoKuuDrphtcgYk+G5OZbp6fxd70xPLJnI6XqDGVDcvSTqQohAHantPtW23aFQeNgnqZmZdSgOyfz5j8y1Qrae6'
        '+0vMmvVcvpy5jMQ9lPYzePD5AxU1LEAgARyf8NsQSAOT+3TNIao3AZBx874nVOk20nkZialE+Xx8F2WvYgzrAw3a9aUiNVU/aYFUcb//AHv46M9k7R+noT+8'
        'BTuG44Ma0qpvQW5GrX75rssdqOsG4lJ+zu/xxzvnpdG6GI2wRcWLTM/qurHjIoqjQv7liok4MzqRtlSNhy4AOif076bZ+md/vEHOoPpzqe3TGasufr8LfvS+'
        '5PC9ZJZ5UJ1GCfLE/PYP36IK1AUGA8YBZQT0Jn0PH/6XwemMFnMzPcUWLMHtrjYIxZkjC8yKWY6DvrehvXjfR6ulqalACqz3fKg6WrpJbE3eJMPVx+Vh92Kn'
        'Ypxw/ejz2l7xx9naN8En4A2epO0pq79JYNpHEHyEbZe9Zt2rAvlo460KTlagi1svIkYH3kaI2efPRKdgAGPv6TGG4m8z2hZT1lcuWZpbQjkjDrBPIwcqDpF7'
        'AQBo/wBP79cf9ICgTF/2m7lXkYaKxGvFF3LGhhsyxzkBtgb7VTRC+ANbJPnpIvm47AxI2/UnqSw1WgSpCI3cbLmRVD6Efavh/nQGuqFprYG/n4kzWuKiT1PQ'
        'uY7FWskrJJMWX/29lwk6d3AkGuQCDrjn5I6fpm2Cf15ROqCqlhHT1ZfSWGev7CrZtRGEwt/8QKgu8j/OxwPn46nxqtd8fMSn/wCaVXM8uenJsHH/AAk10nlX'
        'U9dXZYXqHtD9rM3HKkDs/Gvz1wfcd913+PzvmMm0bKvui/GYuWKD6vJYiCt76F4mnhLQCMAkOO3hmJB438cdE79FJNe8HTQjLLUMynqWjNXpRvReWOlCXmmj'
        'ZhLZGu7bPwUBPPad/p+OlqhBOeft/wBjGcGscfeLsZcw+ciSSCnPSsx91iP+IN/Msgj7yxA0U8eeT8cdOfegomxxiTqEbIGfGNIq8Mteq2Tel/DndWNiCJoZ'
        'RsHSFkbYTwOlljdLd+/wx4UH9XEtj6mw/pz06sUUMNa4syx+/ULOkpA+0ht/j5b556SA7kqDz3x5KLRIkVYzEdf1IKduGGrkn7ZcY1YqxiJPIZmHcCd87P8A'
        'bz1SUOzcDY63JVdS9HB6QmnmZPTuZoZDIlMlcik1FdKMphIJA7WYaXgkaPA6PSZbpRQ7ovWDV2jZMoc//qjg2EohsJPLXCyGvLModU8N7bR/a7EkfvrY69AO'
        'cHj51nnlRkcxTSkqZ7B2/rEoHIQRdr5CeuYi7s4CNGwIJPIBJH26OuvH7Svi6PS/z8zPYAVkzyBA/U8PbeoYu1NDPkqUHbYWGRZO5u/hIyvBUxr37J3vYPno'
        '1pRuXg/PzAfLU2SJ1RtJ60u3bU0toRyIJFgnkYOVB0i9gIA0f6f36E/6QFAhL/uNkyqyMNFYjXii7ljQw2ZY5yA2wN9qpohfAGtknz0kXzcdgYkbfqT1JYar'
        'QJUhEbuNlzIqh9CPtXw/zoDXVC01sDfz8SZrXFRJ6noXMdirWSVkkmLL/wC3suEnTu4Eg1yAQdcc/JHT9M2wT+vKJ1QVUsI6erL6Swz1/YVbNqIwmFv/AIgV'
        'Bd5H+djgfPx1PjVa74+YlP8A80quZ5c9OTYOP+Emuk8q6nrq7LC9Q9oftZm45Ugdn41+euD7jvuu/wAfnfMZNo2VfdF+MxcsUH1eSxEFb30LxNPCWgEYBIcd'
        'vDMSDxv446J36KSa94OmhGWWoZlPUtGavSjei8sdKEvNNGzCWyNd22fgoCee07/T8dLVCCc8/b/sYzg1jj7xdjLmHzkSSQU56VmPusR/xBv5lkEfeWIGinjz'
        'yfjjpz70FE2OMSdQjZAz4xpFXhlr1Wyb0v4c7qxsQRNDKNg6QsjbCeB0ssbpbv3+GPCg/q4lsfU2H9OenViihhrXFmWP36hZ0lIH2kNv8fLfPPSQHclQee+P'
        'JRaJEirGYjr+pBTtww1ck/bLjGrFWMRJ5DMw7gTvnZ/t56pKHZuBsdbkqupejg9ITTzMnp3M0MhkSmSuRSaiulGUwkEgdrMNLwSNHgdHpMt0ood0XrBq7Rsm'
        'UOf/ANUcGwlENhJ5a4WQ15ZlDqnhvbaP7XYkj99bHXoBzg8fOs88qMjmKaUlTPYO39YlA5CCLtfIT1zEXdnARo2BBJ5AJI+3R114/aV8XR6X+fmZ7ACsmeQI'
        'J6mj9u/j8ZamhnyVGDVhIZFk7m7+EjK8FTGvfsne9g+emLQG5eD8/MBzbdrJELxsdCpJaysXuRvWX3DOJh21Sw7SGQbLFt+OT0rtE7D/AHG9kDeBAMJTxeVy'
        'n0dGyfZI7qstg7Zpf/kPHKA+R+/J8dN1Cyiz6xOmAx2idrk3wtizLRs/UClMYULBxPYJOnPu87bfGh8AH56zaHoHr7D0m7tl10irNSXLuUwlOXERQWpnWSFJ'
        '/vtNyeO/wuzyAeSP26JaCsQ2PtBbc7KCufvM7+dzde82M/hqxQAvHeslu4XFJ7dFOVAXxtfPjrQmmV3X5eE5n1N1bfPxlli71j1JfhWSefLy46X22eWqqyaV'
        'Avc6H7XYAADnhR89SanYzxfjK9Lt45qCmpfzGUhikzs2Nx1eYmOKF1UITvtUnlR3ednx1lqik7bM2i7BS1CTNb0xGl64GqGepLP7Fmb32M1ca2CO0/oY/Oud'
        '/gdP+oSAbzEHTUE2MQ3J4fE4hILlqx3w9zw1agkJ7vjtR/nQ8E8nkDoUd27I9ZraemvaaeRZ6KphVlw1dcjHXLLNXjVWRCT+kEfqbR2SP/HR7LanNXB30v8A'
        'rFzgtmErXbwqNdeKMyvT9xa6+2D4Dj7iPwNbJ6IfTsLdePMBvqVur0iyjNmfUNoXM2z2q9u4ssMgTuniTYAjL6Heq/J+NdG+xRWng/b+InT3ObfI6R7bxiJJ'
        'cT6+SSo3dD3ZGUSxQ/llA+SOPnXSVJIFDPhiUMoW7M99L+na8dP69olt02kMsZgVe4xqugO4jS6Yb7Tr89DqsxO04MPSVasZjnK+n8piM3djiydfJW2qiGRe'
        '5ZYWQAOQw47fb32gjZJO+ehVkC5FAH553CKsTa9RFc9XHYG1DCldZoPpEleGIsJYz3cfaw3sn5I/SPPTAzal56/PnfBYKhFQrGR0KklrKxe4j1l9w2BMO2qW'
        'HaQyDZYtvxyeh7ROw/3N7IG8DiAYSni8rlPo6Nk+yR3VZbB2zS//ACHjlAfI/fk+Om6hZRZ9YnTAY7RO1yb4WxZlo2fqBSmMKFg4nsEnTn3edtvjQ+AD89Zt'
        'D0D19h6Td2y66RVmpLl3KYSnLiIoLUzrJCk/32m5PHf4XZ5APJH7dEtBWIbH2gtudlBXP3md/O5uvebGfw1YoAXjvWS3cLik9uinKgL42vnx1oTTK7r8vCcz'
        '6m6tvn4yyxd6x6kvwrJPPl5cdL7bPLVVZNKgXudD9rsAABzwo+epNTsZ4vxlel28c1BTUv5jKQxSZ2bG46vMTHFC6qEJ32qTyo7vOz46y1RSdtmbRdgpahJm'
        't6YjS9cDVDPUln9izN77GauNbBHaf0MfnXO/wOn/AFCQDeYg6agmxiG5PD4nEJBctWO+HueGrUEhPd8dqP8AOh4J5PIHQo7t2R6zW09Ne008iz0VTCrLhq65'
        'GOuWWavGqsiEn9II/U2jskf+Oj2W1OauDvpf9YucFswla7eFRrrxRmV6fuLXX2wfAcfcR+BrZPRD6dhbrx5gN9St1ekWUZsz6htC5m2e1Xt3FlhkCd08SbAE'
        'ZfQ71X5Pxro32KK08H7fxE6e5zb5HSPbeMRJLifXySVG7oe7IyiWKH8soHyRx866SpJAoZ8MShlC3Znvpf07Xjp/XtEtum0hljMCr3GNV0B3EaXTDfadfnod'
        'VmJ2nBh6SrVjMc5X0/lMRm7scWTr5K21UQyL3LLCyAByGHHb7e+0EbJJ3z0KsgXIoA/PO4RVibXqIrnq47BWoYVrrNB9IkrwxlhLGe7jasN7J+SP0jz0wM2p'
        'eevz53wWCoRFma/0+m9K3Mrirk64kw1mYkI7z2kJJQxLryxIJPPad89GNbfTVefQefzMUdLba3U99Pw/+naWJkWavG0nZXXURazLI3J25+NaB1/nXWah+ozD'
        '+pumPpqp/uUufyeIPqKe3PQXBWFCmPCxyn6eHQ13Ag9yknlm/fQ6C3Ixkd8OkHPMRJ6iXJxzzwsifSKsi04U7YYHXySSe47J2H3r489GUNi+vWANQZzHNT0T'
        'HObMsmTgrQCJZ4oveb2ldiN6TllB5HzonfSTqEGgLqOVARuJ5neT9IS42GSleuP70p+qFXHzs6W21wZPgEDtG9ga10C6gbtAcYs9IT6RFgmEYrAUY8ZXiuTy'
        'yZcoti3Di6cbQxfhWBP3nWgdDXWM5LEgY6WYQQBaY58J39JE8RzuXWPFVO8eyYyFdzvtQyEcE8cKPH7daBXYTMEn/wBsamPrf1Bi7z0oruVxbVRE8EkAKvOq'
        'EdyP2svb3l+NjnX7dO0E60bitdxWCKi7J+q8NmsdXFeKy1uqojierRUsrH7S8xTQ4+Drx01tIg/z+IpdZW6ewiivjJcXakNTIV8/aml1JIzEqGUcjxruA8Do'
        'C24WRtEIDaaBu4THm8lh41DzLHJG7GszxBWjLfq0vnxvj56HarHEYHKcme4sR+oe6zWkjCBUSZywMPtg/pbj7ednu8k8DrWY6fZP8zgo1O0JX+mf4X6cp1Ui'
        'vUIapyEkpyP3vHGhj+2L22/J2STs8jpRZnPGajAoQUDi4ktYq3kLDyxX7kEsgK+zAxAqjW+4BdaZhz3fHjz0YesEfzFnTsWDDnwVuRsZmMlfyOZlPt1Wy8t1'
        'p54U5Ch9/pXZ0FOyNeeesOoXJUY8KmjTCAMfeSGZ/wBO5/SVzK4i5OuJavWYk9jvPaQklGiGvLHRJ57Tvnpw1vqU1Xn0Hn8zEHR22t1OvT8P/p2liZFmrxtJ'
        '2V11EWsyyNydufjWgdf511mofqMw/qFpj6aqf7lLn8niD6intz0FwVhQpjwscp+nh0NdwIPcpJ5Zv30OgtyMZHfDpBzzESeolycc88LIn0irItOFO2GB18kk'
        'nuOydh96+PPRlDYvr1gDUGcxzU9ExzmzLJk4K0AiWeKL3m9pXYjek5ZQeR86J30k6hBoC6jlQEbieZ3k/SEuNhkpXrj+9KfqhVx87OlttcGT4BA7RvYGtdAu'
        'oG7QHGLPSE+kRYJhGKwFGPGV4rk8smXKLYtw4unG0MX4VgT951oHQ11jOSxIGOlmEEAWmOfCd/SRPEc7l1jxVTvHsmMhXc77UMhHBPHCjx+3WgV2EzBJ/wDb'
        'Gpj639QYu89KK7lcW1URPBJACrzqhHcj9rL295fjY51+3TtBOtG4rXcVgiouyfqvDZrHVxXistbqqI4nq0VLKx+0vMU0OPg68dNbSIP8/iKXWVunsIor4yXF'
        '2pDUyFfP2ppdSSMxKhlHI8a7gPA6AtuFkbRCA2mgbuEx5vJYeNQ8yxyRuxrM8QVoy36tL58b4+eh2qxxGBynJnuLEfqHus1pIwgVEmcsDD7YP6W4+3nZ7vJP'
        'A61mOn2T/M4KNTtCV/pn+F+nKdVIr1CGqchJKcj97xxoY/ti9tvydkk7PI6UWZzxmowKEFA4uJLWKt5Cw8sV+5BLICvswMQKo1vuAXWmYc93x489GHrBH8xZ'
        '07Fgw6T0/bnbG5bJXsjmpW9uqcvNdaeeFOQoff6V2dBTsjXnrDqFyQMeFTRpBACfeSGOil9RSYHLZ1L+TNOocdGkliRIoa4+4BSNn7T+TsnpzN9PeiECzfr/'
        'ADEog1Cuo4sjEMPoHIZU2ZcdireZaBttKlwSJW2Nju7f0nXjx45PSvrKK3ED0jToX+kX6zPG08XhvUGMR8vDWyUKtasrbQlIpAdLF7zEgsQdnjQ4+ejYsykg'
        'WPnSAAiuATRjXGXfTuZyMleLACxatO00mVrq0UQi0fuZxwwGjx4/z0k/VRbLVXSNI0mbC89ZWYH/AFNhw8M+DwOIhrrdpLPbtQQCdJ+37SFZgWCga2Pnnqtd'
        'IMLPPjzJG1ijEdOkk4vWrz+oMjSp4tSkUAmuVzMRXsFT+k7/ANtCdE/uAPjodXRC01+XeP8AsPR/yC9iuJ5FRv5vFe7JlYK7WwzNLGyrAm9kp7wG1Y8D8aHS'
        'LVW/Tx84jyCy/qq/nMjrPoOa5lkoY6zLTgjj+qaCGwZIVAGgzIxJVST8bJPVQ1qXc+ZIdC22qags3of6KNhYmmavISwYyrIQQeWj7tldkcH4/bpi6odgBFPp'
        'FVJjq9n8NYy8rYS0uHe1TihvLFYCRjtGtFSfuY/tzsnrtTTYLTC6OJ2lqqTYNE8wurPcoemcbNZjWhjci80FS2GR2lEZ+4pECWGiQAza2eo2S3JGSOn8y1dS'
        'kAPEz9M9960kkbxe8O6GVLK/UdoYaDS7JVnY8KF5TnfRatIpH8e37987TO5p5ijHSo2FaxJFVpWe6arDXVWdO7sGuNnsPLD8eOtI3eo5v5zMBI68Te1NTqVW'
        'aziJLwiskJaE3uRu2th0XWt+DrkjjfWKGPBqaxUci4YHmzWQezp7NedQJXs7gRiBx2dp/pP5/PPQEhBnn3hi2yOJJ+tLjPbpRR15FqV3Mj1I53RZ3I13Nrns'
        '/wD96q0cAnrI9ezQ6Rzj45vUcuCy+eW/kzTqHHRpJYkSGKuPuAUjZ+0/k7J6UzfT3ohAs36xyp9QrqOLIxCz6ByGVNmXHYq3mWgbbSpcEiVtjY7u39J148eO'
        'T0r6yitxA9I06F/pF+szxtPF4b1BjEfLw1slCrWrK20JSKQHSxe8xILEHZ40OPno2LMpIFj50gAIrgE0Y1xl307mcjJXiwAsWrTtNJla6tFEItH7mccMBo8e'
        'P89JP1UWy1V0jSNJmwvPWVmB/wBTYcPDPg8DiIa63aSz27UEAnSft+0hWYFgoGtj556rXSDCzz48yRtYoxHTpJOL1q8/qDI0qeLUpFAJrlczEV7BU/pO/wDb'
        'QnRP7gD46HV0QtNfl3j/ALD0f8gvYrieRUb+bxXuyZWCu1sMzSxsqwJvZKe8BtWPA/Gh0i1Vv08fOI8gsv6qv5zI6z6DmuZZKGOsy04I4/qmghsGSFQBoMyM'
        'SVUk/GyT1UNal3PmSHQttqmoLN6H+ijYWJpmryEsGMqyEEHlo+7ZXZHB+P26YuqHYART6RVSY6vZ/DWMvK2EtLh3tU4obyxWAkY7RrRUn7mP7c7J67U02C0w'
        'ujidpaqk2DRPMLqz3KHpnGzWY1oY3IvNBUthkdpRGfuKRAlhokAM2tnqNktyRkjp/MtXUpADxM/TPfetJJG8XvDuhlSyv1HaGGg0uyVZ2PCheU530WrSKR/H'
        't+/fO0zuaeYox0qNhWsSRVaVnumqw11VnTu7BrjZ7Dyw/HjrSN3qOb+czASOvE3tTU6lVms4iS8IrJCWhN7kbtrYdF1rfg65I431ihjwamsVHIuGB5s1kHs6'
        'ezXnUCV7O4EYgcdnaf6T+fzz0BIQZ594YtsjiSnrK65uUooq8i1K7mR6kc7os8h47m1z2f8A+9VaOAT1kevZI7pTWa+Vx0NdK0kV2vAwdaZm9hPB7R3DY4PP'
        'b5876npCTux48yq3A7ORElKOyR7Y9xJLKN9Ytd3QHR+4sFI2o8gfI6Y1e3EWCa8+YNcwkM9RJJzamwLxsJUnkWIzsG+xkUbKqD5U7PPRq+04/VEsm7J4jr0R'
        'nK/p2eSTujKUqxkaojqyWIfxvwSza5H48dK1dMubPX7GUaThBU5zNKGxSlzEDHChIjLutOY4oVIGlVtjvJOhoeD1qOyvt5gaiIybjiTOFxffhZPekmryXIJZ'
        'DaitEmVinckRi8FSdDyTsnp7v2vI933uI09MhbGLEOwlbJXcKMZLVs2rksbSvXo1QzKw8O+zpfHCj8fv0GoUVtwIAHefnvGaYZk2kWfCNsdHZXA0vUQipwXL'
        'Pd7aK6+5EiHtfuUH+r8HnfjXQMKY6ZJqErWo1AMz1njysepVQqvY8ogQIIV7txoSf0j5Pk9CxKnENaYZmMeGovlchZrwwRxFQTJcAcSD5dTobfeyB+B0W9to'
        'Un2gjTUMSBOXkw9avSbEU4cjECWe7mlNT3vyAFPCD8jzodbtck7zXlmYGQAbBfniY4MXJJfoamKgBjVpf5BJNjZ33dzaI0dA/wDLgdbqAfqY/wATtMtwojaj'
        'Yy9GkVvWp5LTzo0qxKuqzAnQVB53vS7+N76UyoSKFY94as4vcesW5y2fTvqNcRaEEtGtOqiKKNligZxt0DDju3yxBP7dMRTqJvHMB22amw8SpuenKPpiGI5n'
        'L17OOnkUB8S31CQqx33AHXHOgrc/PSUb6jgAe8cy/TUkm4D6fwzeoMFPmchflismX28XhJIl1LXDEGWSY/oI0Pt1tuqGRFsLyOTJQ7mi3BmdivlcdDXSrJHd'
        'rwMHWoZvYTwe0dw2ODz2+fO+kUhJ3Y8eZV2wOzkRJSjske2PcSSyjfWLXd0B0fuLBSNqPIHyOmNXtxFgmvPmDXMJDPUSSc2psC8bCVJ5FiM7BvsZFGyqg+VO'
        'zz0avtOP1RLJuyeI69EZyv6dnkk7oylKsZGqI6sliH8b8Es2uR+PHStXTLmz1+xlGk4QVOczShsUpcxAxwoSIy7rTmOKFSBpVbY7yToaHg9ajsr7eYGoiMm4'
        '4kzhcX34WT3pJq8lyCWQ2orRJlYp3JEYvBUnQ8k7J6e79ryPd97iNPTIWxixDsJWyV3CjGS1bNq5LG0r16NUMysPDvs6Xxwo/H79BqFFbcCAB3n57xmmGZNp'
        'FnwjbHR2VwNL1EIqcFyz3e2iuvuRIh7X7lB/q/B53410DCmOmSahK1qNQDM9Z48rHqVUKr2PKIECCFe7caEn9I+T5PQsSpxDWmGZjHhqL5XIWa8MEcRUEyXA'
        'HEg+XU6G33sgfgdFvbaFJ9oI01DEgTl5MPWr0mxFOHIxAlnu5pTU978gBTwg/I86HW7XJO815ZmBkAGwX54mODFySX6GpioAY1aX+QSTY2d93c2iNHQP/Lgd'
        'bqAfqY/xO0y3CiNqNjL0aRW9anktPOjSrEq6rMCdBUHne9Lv43vpTKhIoVj3hqzi9x6xbnLZ9O+o1xFoQS0a06qIoo2WKBnG3QMOO7fLEE/t0xFOom8cwHbZ'
        'qbDxKm56co+mIYjmcvXs46eRQHxLfUJCrHfcAdcc6Ctz89JRvqOAB7xzL9NSSbgOBw5z+BnzOQvyw2TL7eLwkkS9stcMQZZJj+gjQ+3W26oZEWwvI5kodzRf'
        'gxphJcXVjWCWqrxyoS9KiqsQP6nI8Dn+nkkdKfc3X1MpSkiiHLyjKZY4TH2blWe67D2O3tFcKoXZ877lJAG9661tMUN5o194C6pyUFi/tEGRxUz2HeCxE89q'
        'dneSSOR5APJVAPCnnY+NdNVxwRxFMp6GKLi3Ls7vVmlejFqNo5aixCOTXk6/SB+P89FQUZGfOBZY4OPKNMTga2ayDYp6keakVBL9K0gYDj7yhJA43vt6Qzso'
        '3g1HqisdpFy0m9NQYadqc1uJhj1jkkqe+vt1A52A8zABG8HY2ddCVa8jmMDKBg8RSkdbL+qJcdDmbeJwRj/91bwG5xb4JETTNokg/wDH+w6ftVF3soJ7j08h'
        'JyW1H2KxC+EdZ/H4fBwp6exMAt4QGpbW1FA1SeF32XErnZPbrWv6t9aXvtXk+sFUIpaNSSz0dWCSS9i6NlKtrKNFJk/cLTGdPuRCrHXYfAB/z0KWey54HHSv'
        '+wmpc6YwTz4xhNkmu0q8i25LM1iwxyEkygPCDobUa8gkf3AJ6SFo1XlH7rWx15gTeh7MeSx8MliS1Wpz96o0e2XXyVP6xyCPyPjjpg1sE1RMUdA2BdgQ+iMl'
        'iDnI8RI0SNGa01+2nuGr3N/MaI7G+7xvwP8AHWbhgtz3DrN2myE474TmobOQSnE38SyOY9qFa1uZu72o0b7CdD+YT8ADWufz0tWySSAO75xHMtAKLvvmWRys'
        'VZ7FStaMkswJkjaGM+zIeWQj+tt/1jwD0IXgkfz87oTNdgGR9oXL92WKExUBI+7LW7AkLOdDjt4Cj4Pk+AerF2gC891CRNuJxjvufRsBdgw3oOxSpyxW/VCT'
        'GL+JSRtLHDVPj211wdbU755/brt691XB+mxOTdTrCSYqrEsElVXilQl6VEBjr+pyPA5/p5J/PU77m6+pliEJFEOXlGUyxwmPs3Ks912HsdvaK4VQuz533KSA'
        'N711raYobzRr7wF1TkoLF/aIMjipnsO8FiJ57U7O8kkcjyAeSqAeFPOx8a6arjgjiKZT0MUXFuXZ3erNK9GLUbRy1FiEcmvJ1+kD8f56KgoyM+cCyxwceUaY'
        'nA1s1kGxT1I81IqCX6VpAwHH3lCSBxvfb0hnZRvBqPVFY7SLlpN6agw07U5rcTDHrHJJU99fbqBzsB5mACN4Oxs66Eq15HMYGUDB4ilI62X9US46HM28TgjH'
        '/wC6t4Dc4t8EiJpm0SQf+P8AYdP2qi72UE9x6eQk5Laj7FYhfCOs/j8Pg4U9PYmAW8IDUtraigapPC77LiVzsnt1rX9W+tL32ryfWCqEUtGpJZ6OrBJJexdG'
        'ylW1lGikyfuFpjOn3IhVjrsPgA/56FLPZc8DjpX/AGE1LnTGCefGMJsk12lXkW3JZmsWGOQkmUB4QdDajXkEj+4BPSQtGq8o/da2OvMCb0PZjyWPhksSWq1O'
        'fvVGj2y6+Sp/WOQR+R8cdMGtgmqJijoGwLsCH0RksQc5HiJGiRozWmv209w1e5v5jRHY33eN+B/jrNwwW57h1m7TZCcd8JzUNnIJTib+JZHMe1Cta3M3d7Ua'
        'N9hOh/MJ+ABrXP56WrZJJAHd84jmWgFF33zLI5WKs9ipWtGSWYEyRtDGfZkPLIR/W2/6x4B6ELwSP5+d0JmuwDI+0Ll+7LFCYqAkfdlrdgSFnOhx28BR8Hyf'
        'APVi7QBee6hIm3E4x33Po2AuV8P6EsUaksVz1OkxhOSkjaWOGqfHtrrg62p3s8/t129e6rg/Ta8m6kkvqPJ2MFkYsTMa9603tN2wL7axBSAVlP3K+vgD5P56'
        'wKiuC/A+cd00vqMhGmczPC2reKj9qj7aMKr1ZY2l1KmwD9qnjuUjYP7kddqENd99/P3m6alQAO7iNJ7Vv36dqWnYgrzRoqTMrQhZO7715+fHjg8689JVRkA/'
        'v8/aPZiaYifTR6e9IWPS5sXfqMjal1ILE3dEI2HHcIRwUB89xJP9umppkixiIfVo0Z8vy9Fc168lmngVDCBXRIE7IyygfcGXgnka140Px1OL09LaDKdo1NXd'
        'N8xh8ray8cmajbLR17X1jRuVkSU67e5kHkga/V4A61NQBaQ1cx0ttzC6nk/pB8p6vr2vT8OXzWPoucjLj6CNFDArAhXWQ62o5JH7dOViNMh6BIqz+4iGUHUB'
        'W6B4jOOlbazlczXvfRY6nCslm80bt2AcLCQ21d9nfHOup77KoRZ+Z8pSR2i4NTSeFs9VpR28bDB7iP7FnTRj3wO4e4PHc4ICn48dCDtuj8+cxhG4DcKEDWN8'
        'JdtYx3p5No1HvwTQkMqMvkMvIdQzaUedc9H2WAeiIPaUlbBmtyvJf9Y5aGkkn0uSWDVidmWdFi0I2HwrlR2kE+D1m6tME9L+/M0qTqGutTP0/NkKGPsYuVY1'
        'EkruFuIO2BJF3IVkbgK7AfaeRzrnrtSidw/uuMeHfM07UFTMEs4OxbqXpZrGM9qQRmeKVmdgR2gxoTt9ju0djjX46JRqUV5v5mAzaZO4mp3dhqYTHSwYKvWW'
        'oL0tl6WRXvtMe0ad5gN6Uf0r9vP56GzqG9QnzHHtD2jT/wDmB43J7J4RqtOnXuVYJLWVlZRNHa1Ced6lP9JA8fHVCPZJU4Xwz6SZ0IAVh+qeenrk1TEzVIRI'
        'MUJSJckMi0McKKfB4IZfwByd9E4Bazz3VAQlVocd9zZPUmTs4LIxYmY17tpvabtgX21iCkArKfuV9fAHyfz1wRFcF+B847phfUZCNM0ZxhbVvFR+1R9tGFV6'
        'ssbS6lTYB+1Tx3KRsH9yOu1CGu++/n7zdNSoAHdxGk9q379O1LTsQV5o0VJmVoQsnd968/PjxwedeekqoyAf3+ftHsxNMRPpo9PekLHpc2Lv1GRtS6kFibui'
        'EbDjuEI4KA+e4kn+3TU0yRYxEPq0aM+X5eiua9eSzTwKhhArokCdkZZQPuDLwTyNa8aH46nF6eltBlO0amrum+Yw+VtZeOTNRtlo69r6xo3KyJKddvcyDyQN'
        'fq8AdamoAtIauY6W25hdTyf0g+U9X17Xp+HL5rH0XORlx9BGihgVgQrrIdbUckj9unKxGmQ9AkVZ/cRDKDqArdA8RnHSttZyuZr3vosdThWSzeaN27AOFhIb'
        'au+zvjnXU99lUIs/M+UpI7RcGppPC2eq0o7eNhg9xH9izpox74HcPcHjucEBT8eOhB23R+fOYwjcBuFCBrG+Eu2sY708m0aj34JoSGVGXyGXkOoZtKPOuej7'
        'LAPREHtKStgzW5Xkv+sctDSST6XJLBqxOzLOixaEbD4Vyo7SCfB6zdWmCel/fmaVJ1DXWpn6fmyFDH2MXKsaiSV3C3EHbAki7kKyNwFdgPtPI51z12pRO4f3'
        'XGPDvmadqCpmCWcHYt1L0s1jGe1IIzPFKzOwI7QY0J2+x3aOxxr8dEo1KK838zAZtMncTU7uw1MJjpYMFXrLUF6Wy9LIr32mPaNO8wG9KP6V+3n89DZ1DeoT'
        '5jj2h7Rp/wDzA8bk9k8I1WnTr3KsElrKysomjtahPO9Sn+kgePjqhHskqcL4Z9JM6EAKw/VPPT92aniJqsIkGKEp93JDItDHCinweCGX8AcnfROAWs891XAQ'
        'lVocd9zP3K+L+quNJAmLB7LFiJ+4rs8OdnuUnga/A64Bnpes0ldO2PEIy2OrWmrTVxLNVVC0tvs1F28aYHzofJ8jrlJFg89011BphxGFn3VKQwT/AFbII0iu'
        'wSSWKkfP6GXRJ+07BA8Ek9JFDJFeGAfONyaA9+RHt/Fx5TIexQbIw1k0ZKiuywu2ubCRN+lQNDROuljVdVyR86QzoIzX1ir1DYkj9O4imy35ZK1xpvbqy9oi'
        '+FJPIA8c/jZ63SouzY46ztYEIo7oDnpIctipTEZ8bMiOfqGk91pRogqxTRMZ8fuej0yUauR8+8DVpxfBn0TFz1fUXpSS5h3S1GtdYXeMyLshB/LkiBBVTo7+'
        'OB+/WFGQndOXUDgVIiBz6xnup9XfgxkEQh+mbIhYo0X7R2Ra0WLeN70F89c7HTqqvyhIg1b6CfU8V6T9LYPALD6hu2PV95Yu+qciXSnAfKRxIhBJB57z5A6j'
        '+ozNaLt8uZWNIKvaO7z4k5mK1UtJFjYL31DP79iPHIIPbft+9omb7tMAFPcd65GumAgGzVeMEqen2iOKL1HcnrzWbUWPh37CYkyk90A+7UTDZdxrbE/gjomO'
        'mMDPj4+PdFqNU5OPD51k3Tgt5mxXlGRinoxe44lnpn2XVjti6sQfcPgcaA1rqnC2CM+ef6k3aYgg4m+NFH1OMgntdkFZHkjFOId8x8AIG/rJ1sfA8DoyDp1n'
        'n5nwgCtSwBxArkGU9PVFS1XjE/YHWtPMJX4HG9fpX+/noaVzibbIINjcxUlw1yTIXhBPYXtXuiMrnR/QsfhdHxvyOtZGDjaMD5zNTUUoS5yZrHlb93HVv4hH'
        'HYmV43quEVSQp+7cX6WHb4J589YVVWO31/uduZ07UyMlbFm1caSBMWD2T2In7iuzw52e5SeBr8DowGel69IBK6dt0hGWx1a01aauJZqqoWlt9mou3jTA+dD5'
        'PkdcpIsHnumuoNMOIws+6pSGCf6tkEaRXYJJLFSPn9DLok/adggeCSekihkivDAPnG5NAe/Ij2/i48pkPYoNkYayaMlRXZYXbXNhIm/SoGhonXSxquq5I+dI'
        'Z0EZr6xV6hsSR+ncRTZb8sla403t1Ze0RfCknkAeOfxs9bpUXZscdZ2sCEUd0Bz0kOWxUpiM+NmRHP1DSe60o0QVYpomM+P3PR6ZKNXI+feBq04vgz6Ji56v'
        'qL0pJcw7pajWusLvGZF2Qg/lyRAgqp0d/HA/frCjITunLqBwKkRA59Yz3U+rvwYyCIQ/TNkQsUaL9o7ItaLFvG96C+eudjp1VX5QkQat9BPqeK9J+lsHgFh9'
        'Q3bHq+8sXfVORLpTgPlI4kQgkg8958gdR/UZmtF2+XMrGkFXtHd58SczFaqWkixsF76hn9+xHjkEHtv2/e0TN92mACnuO9cjXTAQDZqvGCVPT7RHFF6juT15'
        'rNqLHw79hMSZSe6AfdqJhsu41tifwR0THTGBnx8fHui1GqcnHh86ybpwW8zYryjIxT0YvccSz0z7Lqx2xdWIPuHwONAa11ThbBGfPP8AUm7TEEHE3xoo+pxk'
        'E9rsgrI8kYpxDvmPgBA39ZOtj4HgdGQdOs8/M+EAVqWAOIFcgynp6oqWq8Yn7A61p5hK/A43r9K/389DSucTbZBBsbmKkuGuSZC8IJ7C9q90Rlc6P6Fj8Lo+'
        'N+R1rIwcbRgfOZqailCXOTNY8pfu46t/EI455leNqrhFBIU/duL9LDt8E8+esKqrHb6/3ODM6jdO896fkignhjhphIxtrIiBaRB52fGh+PJ63TfqbmaiGqlB'
        'jMHXhpLDey9l71qm0slCOSGSMga9qMabzrR18jj46FybsLgdc+sNANtE2T0iupYngeT6BUS1LGFWGpIEEcoPHfv9Om534Pjx0LKG/Vx4zlYj9H2h2MytVAr5'
        'O86TGNhfqyN3W4wOWCjw+zrR/wAa46LbR7Ix07pwex2jmMF9Qx5rDxUqxfE+mMofq5K0ERY/yz2h9t+tieO0HtUn9ugYstjqIxVVwpHBEIx+DnuRypXTHQPO'
        'CImaQtHHskakI/q/YcbPQDJAzCIpe6SHrD03a9GUamNyeSNHFbDSSYYEPfY72skm+5SPhD8dXCyxIXPjwJ55oKAWx4dZNel8ZaRUmlqx4qt77suQ973JLQbX'
        'ajgk6A48Dzx12qymwDZ7u6bpK/NV498rv/VGcw9qKWtLNRNXuL/XxrKJGJ40FJC6GiAeT/jqUIjCjm+6UM2opBGK745xX8XkvPWmttHaNZslPetxd6Kx/SCF'
        '4Hd4BPnn8dKbZW7pxUoQuDtvJzcwrepLGArSy5F4r+RndZ4WSRTLSVdbWJxwhY+Tvej1x01fC4H585y6jJlsn8RWbWZllvZ6O5ae1kpPanMciPNUG/tKxnjs'
        'A8/OuR1So0wBp9B9/XvkrFyTqd/2neKt2c7RE+P+nvXPcYtf+mZF7YzywReFJ+XPHRlQrbWFD58qLVty7gcwDJZKhJdlmVzShm1J7vaD2No9w35K+dE/PPWh'
        'WrvqczreYv8ATWDqwR1rTzuHlhMrJ/VIrH7S4/cDgj/76HVdiStQtHTUAMTKWfDUMhk1IV6cduTTtEQI4h2/anb5XZAO/wBz+OpwzhfKVMiFvOLM76fkignh'
        'jhphIxtrKxAtIg87PjQ/7np2m+bNyfUQ1UoMZg68NJYb2XsvetU2lkoRyQyRkDXtRjTedaOvkcfHQuTdhcDrn1hoBtomyekV1LE8DyfQKiWpYwqw1JAgjlB4'
        '79/p03O/B8eOhZQ36uPGcrEfo+0OxmVqoFfJ3nSYxsL9WRu63GBywUeH2daP+NcdFto9kY6d04PY7RzGC+oY81h4qVYvifTGUP1claCIsf5Z7Q+2/WxPHaD2'
        'qT+3QMWWx1EYqq4UjgiEY/Bz3I5UrpjoHnBETNIWjj2SNSEf1fsONnoBkgZhEUvdJD1h6btejKNTG5PJGjithpJMMCHvsd7WSTfcpHwh+OrhZYkLnx4E880F'
        'ALY8OsmvS+MtIqTS1Y8VW992XIe97kloNrtRwSdAceB5467VZTYBs93dN0lfmq8e+V3/AKozmHtRS1pZqJq9xf6+NZRIxPGgpIXQ0QDyf8dShEYUc33Shm1F'
        'IIxXfHOK/i8l5601to7RrNkp71uLvRWP6QQvA7vAJ88/jpTbK3dOKlCFwdt5ObmFb1JYwFaWXIvFfyM7rPCySKZaSrraxOOELHyd70euOmr4XA/PnOXUZMtk'
        '/iKzazMst7PR3LT2slJ7U5jkR5qg39pWM8dgHn51yOqVGmANPoPv698lYuSdTv8AtO8Vbs52iJ8f9Peue4xa/wDTMi9sZ5YIvCk/LnjoyoVtrCh8+VFq25dw'
        'OYBkslQkuyzK5pQzak93tB7G0e4b8lfOifnnrQrV31OZ1vMX+msHVgjrWnncPLCZWT+qRWP2lx+4HBH/AN9DquxJWoWjpqAGJlLPhqOQyalVenHbk07RECOI'
        'dv2p2+V2QDv9z+OpwzhfKVMiFvOf/9k='
    ),
    'brick': (
        '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/'
        '2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADAREAAhEBAxEB/8QA'
        'HAAAAwADAQEBAAAAAAAAAAAAAwQFAQIGAAcI/8QAQBAAAgECBQMCBAQEBQMDBAMAAQIDBBEABRIhMQYTQSJRBxQyYQhCcYEVI1KRJDNiobEXQ8EWcoIlU9Hw'
        'Y7Lx/8QAGgEAAwEBAQEAAAAAAAAAAAAAAQIDAAQFBv/EADkRAAEDAgMFBgUEAQUBAQEAAAEAAhEDIQQSMUFRkaHwBRMiYXGBFBUysdFCksHh8SMzUnKCU0Ni'
        '/9oADAMBAAIRAxEAPwCVLlnTWRST02YCSasmgScJPSp/hVJIWQtrupJvZRsw3tj56rXZRjMNdy+pw2DrYye7IAGslTamr6ROYQU1PJBNDEn86mzSSKMu547R'
        'sdIHuSf2xD4xgE5TwXeOx65sKjOMIuT5T0tLFX/LqqZvI4aMa4pacre7K5WxuPc7e3vhD2hSGrTwVG9h4k6PZxUiXpzp6nyypqMvqaSJI5tPajmgJueXUahr'
        'vvuF/wCMP8wpTBBn0KT5HithbH/ZL5lVdH0ImpKtqIxzLoUsFcRkrtr0qbi+/P3GKjGU3fS1x9lF3Y+IZ9T2j/0kMs6X6JpWo5pc0pJsphAEjCWNGR/9Oonz'
        'vv8AsML8ZTmIM+iI7IxBE5mR/wBkeSHotK+doq/K54w6tEYWVhHF5XXsNR5Nv2tgfFsH6TwTfKqv/Ns/9lVoM16Sy5DSrX0cVY0oYMKiEAQ34tr+sDYG/njD'
        'fGUiJh3ApPlWJBjMz9wXQydZfDJKGen+eMs08ixfLT1tOJF9naTVuo99v0wRiqeuV3BTPZlcGC9n7lzfUOV9KR5jCVpqGlMKmzSvGVl24IUH0+Qf3BIxP4+k'
        'bhp4K47HxAF3t4rMWUdLioWKKtpo4ZItcdNJURrLFLflhwyDezWF774U9oUonKeCZvYmJJjO39yznuU5AlRTU0FNl08bKWaNq9FZkG5ES6PUdixv7focEdoU'
        'zJyngs7sTENiXtv5rnqHL/hjTVFVVy5jQoqWEEKGO73G/pY3Nzte1vO2LfFN0yO4Ln+V1f8A6M/d/SoN0b0fmz/N5XL26QQ3l7c8EJ7l/wDua+F/YC/HtiRx'
        '1IGC0z6K7exsURLXtP8A6TFFlHTcF6eWTLCKxQr65ofTvZbPYBTffa1/GN8bT1APBA9j1x+pv7koKHpDJs4qhUVOXPTxARS0EtUFYNe+q44YeCARY74YYxhE'
        '5TwSnsqsDGdvFPNQdG51ndKKaqy2OnmBiiy+KqDsW51XPLHySALDbCnGsAnKeCcdk1pgVG8U3W5P0zPanikyu1GhVNE0Pr3s13IIY333vbzgfG09S08E3ybE'
        'HRzf3Jdeiujcob5zNpe7RtDqh7lRBMe5/wDx6OV/a1+fbAbj6TjAaZ9EXdi4oCXPaB/2U6vy34W1VTS1kWZUDh9QngcxEoQNvSrXFjte1vO+K/Ft/wCDuC5/'
        'lVb/AOjP3f0ujyHKOn3qKqmqKbLaeNVDLGuYRsyodwJV0XU2IYW9/wB8RPaNIAHKeC6G9hYl0xUbbzWJsn6V+ZaKWtpZIY4dclNHUxtLLLflRwqEWu1ja22A'
        'O0KRE5XcET2HihbOz9y16dyrpKTMpy9Nl9UZlF2heNVh24AYD0+Sf3JAwTj6QuWu4JT2LiYs9vFdNH1p8LnoKen+faKaCVovloK6mMre8iyahZT77/pixxdM'
        'fpd+1QHZeIJgPZ+5c7mGbdIZigpWr6KatWUsXNTAQYb8W1/WRsTe23GF+MogTDv2lP8AKcSTGZn7gpEcPRD18DS5hlVPGXZpWnZVEkXhde41DkX2974X4xh/'
        'S7gqfKawsXsn/sgZn0r0NVNWTw5pSQZRMCImMsbtI/8Aq0kc/b98EY2mTEGfRIex8QBOZkf9lQyyq6MrxDR0jUKxwL22KhUEhC76NSiwvvz9zhnY2m0S5rh7'
        'IN7GxL5yvYf/AF/SZi6b6cqcrpqnMamklSScL2ZJ6cEkcOw1HRbbcr/yMS+Y0pgAz6FX+RYs6lsf9lXznKOlIosv+YVXziKQtINcUVOFvdVQtc3PuNvf3wg7'
        'QpGIaY9E7uwsUNXs4oVNV9H/AMRnpaiWCGGZP5NNlUkUhRxyJTYagfcEfvfDjGsInI7gpnsbECxqM4yqkWV9MZ7JBTZaJYa2GnecpT0if4tQQryhtd2INgVI'
        'so3tjoo4inXnKNN68/E4Ktg47wgg6QV8Zzw1LdfV9T35nmhhhhMtJNpeTSSO5a1yhO3Fr32xLGQA0Eb9ft6ru7KBzPIO7RIxU9NmbzrVmnhpijlpJWKqhBP1'
        'EXsW33G98cMloGXVe+GB5OfRFFRl2metrJ6uT5wrO9RFUgSSkCybrxYDgfvzhZeTlA0TgU2gvJ1VWoqIqmShzR3ip3nuKcutmjf8yhbE3PnYDfxiNxLQug5S'
        'A/fopVPmcM1YaWkqaahIBlZVeUrKBuVRXA0g8ne97WxYsIGZwJXN3gc7I0gLQUdPE00gpqM9+Xuzl1YEG9wTa29uORfnffFM5NpKj3TReAma4wR0jB6R+2hX'
        'vKjKylCdrWN9V+dW18SbJNirOaA3RLy0dPSzQSzhqWOrmNLAFYRp3ALtGwAuDb9Bc2vgy4gxsSwxhE2nRJZ5RZfm4VYoXg7UgLyIVkEgA9UQUXJ35J4+98NT'
        'c5lz15qVamyoABZUMvpYKbLFrKaeURoQivTRDYk2VfqBXnyN/tiTi5zspF10NaGszNPJFlzJa6rqaaCmL1ultc1OC7Mqmx7ZNxseQD6d8HKQATp1r1dJnD3Z'
        'W6qfX0NCtb/DZ709SY7Qwyt3FjB/oPAbzze322xQOdGcaJHMZmyu1WKerSCCelWWlqJIAAhqv8xTb3IBNvcbj74xBJzQbrZmtGWRZM1vT5zeJamlkmEqKlpo'
        'JN1Y7kceoH2sRY3GAH5LFZ1LPBC2zHJv/p0jSUUccUgMQimZG2IvpsCbi97A+9zbCh17FM5hDbhFyFstiEUbUFHRxxRFA0SKLyDkESXK7eR5NzjOJm5KLA2I'
        'ACc6hbLJe9EuX0dbFLEELzIp0yNwAI7FtvJ8i4wrc2oJCrUDYIICDluTD+GxNHQxyQxARGKFkXYC+mzEWW9rgA8XF8Yu8VylbTJaIC1oenjk8TVNXJOZHVyZ'
        'p5N2YC4HHpAHiwFhc4Ln57BBtHu5ceaWqKtKingpWlpaeScEOaX/ADGNvcAkX9zufsMMARe9kC5rhlkX3arNBQUL1v8ADYL1FUI/50MLdpZAB+c8FvPN7fbb'
        'ALnRmOizWMDsrblUIszWgrKalnpilboXRPUgo6qxsvcIsN/ALerbnCZMwJBt1p1ZOXhjsrrFCzCkgqssasqZ5jG5ZGepiG5vZkPqJY7e233wrS4OygX8inew'
        'OZmceSnZFQ5fk6ss0D1AlkJSRysYjBHpiKmxG/BHP2ti1Rzn3FutVCjTZTBBvPUJ6Kipqqaolpw1XHRzilnDMJF7hF1jQEXJt+ouLXOFktAzWm6rDHkxeNUz'
        'Qmnko1CUcnbfV2VkZVUIDvqub6r3tp2vfCukHVFrQRolTR08rQSfLUQ+Xl7sBRWLMb3JF77254F+N98WzkWkqPdNN4CJUZnDDWikq6mmriQJVVnlAiDbhXVA'
        'dQHI3ve98TDCRmaCOtiv3jWuyOIKq09RFTSV+apJFUvBZagol2kc/SpWwII8bEC3nELmGLpGUS/dqpJqst/kV1HNWRfJl50qJaoGSIkWcXbnUDwf24xaX/SQ'
        'LrnLabmh4OnJClpqbK3p0ozTzUoRNMkR1K5JG6k2uV23NzfDglwObVTLAwjJon8iNUvxBy6p78yTzQzQiWsm1PGGIHcta4QHY7WvbbHdg4yuA8tPt6r5/tcH'
        'Mwk79UvmsFP1F1h1PFKVJRoU+fiGqpi9J1CJhuFbgncX/vg415p5I87bPdDsikKoqz5X2qcOnMqo1jjWrkC07K8cUxupc7i4bZvex58Y4O8e68ar3hQptMTo'
        'ka3MI1lmqUoEmamPc+Wpqcxpcfmk/pvcXHtirWEgNza7SfspvqAXDZjYB91S6nz2Glz5I6sUuqGEIJqNe3EXYBrLfgb6dX2xOlSLmS2bnb1yVcRXDKmV2oGz'
        'eubE0LZpSmalK9pLyTFgVaQG6bDba+5v+ox1EEMMH/C4cwNQGNPunjm7xamqkp6h2ezpHH/KdQb3UJwF52vf74TKCfDb781Q1HAeK6t5XmdJXpFVUcscVNys'
        'lGDKHceGZdPH/wBsgffEHsLZDtfPrmrsqCoAW6eSs1MdFn9JEaP5WqnNpLO/qQDYs+2pSbmy2JF99rYldh8UjrgrmKkQAV6s6QpY1aGkZ0ilgSRaSmIkkdSP'
        'oKKQAb3F2sSPfCtqOJzOTvpNAyjgo+b1VHlkVIy0VWaruJBHSCeOlqRIdlKqbMbc3GwtycVYxzyZIjaYkLlqVWMAgGdgkAqVJm75i2uWuebMtT0d2L0wRDu7'
        'MGHqViLFlJ1H2xYMDRYQNd/X8LmNRzzMy7Td16qOJtNJPK9LMy0wNmVwBKvJIut9iPH7YrEkCdVMOOUujRW4KeorKOKlrmkQzKhjWpQgd5hqSMX3UcG9rG3g'
        '457Ndmby3LqE1GBr9u/eqnTWQ5nO82WV8sRdI/XLTVHZeUHkWtdW23AI42thalRg8bOYVaNKrBp1OSZOZUGS5QlHUVFUcxDyhDVxd2aCHVZdT8Ec2uST5vgF'
        'rqjswAjy0lFr2UWBjiZ89YSdXmuXJTUM0QhhUh9Uoj7omW4/KN9juRub8bbYwY64KJeyxCcpc3y16avmmEM6gR6JTH2hCtz+U77ncC4N+dtsKabrAKoey5Kc'
        'GZ5dneTyUVPU1QzIvErmki7U88OqzaZOAOLkEEeMANfTdmIEeekoOeyuwsaTPlYwlup+n80geHK8vlhEjxeiWqqO88IHAta7NvsCTzvfBp1KZ8bxwEJa1KrH'
        'd0+ZUqop6miopqWhaSQwK5lWmQkd9RqeM23Ycm9rD7nDiHOzO2793XupGabC1h01jeofe1UkEqUsqpUgXZnBESncXst9yfP746IgkE6LlLiGhwGqsR5xJlrB'
        '4q54cz1JR3UvVB0G6MgUelVJsGYjSffEsgcIItru6/lUFRzDMw7Tf16lVsnq6LNIqxmoawVXdeCWjaeOrqTKNmLKCXAPNzsb8gYi9jmRBEagwQI+y6qdZrwZ'
        'aZ2iQSrNF0dSyKsNWzvFFA8rUlTaKRFA+gIxIJvYXW5A32xF1Rw8TV1MpNcMp4FZpo6Lp6kmNb8rSTi8tkf1ODsGQ6dTEWF1sCbbbb4a9T6ZPXBIIpAyAFFz'
        'bNKPL1lqq2WOam5aSsBiCOTwrNq5/wDtgH7YqxhdZmvl1zXPUqNYCXG3n1yUIZxJMFalSnpnV7IkkX8pFJvdg/Ibne1vtjoyAHxX+6gKriPDbrzSLTQrmtUY'
        'aRm7qXjmDAKshN32OwvbY3/QYYAlgk/4U8wFRxA1+66XpbPoarP3jpPldc0JQzVi9yEOoLWa3I206vc45qtItZLpsdmvXku/D12vqZW6kbdJCmUWYRtLDUvQ'
        'RwvUnufLVNOZEufzRjzbew9sUcwiW5tNoP3UWVAYcWxOwj7J89N5VWLJG1XIVqGZ5IoDZQ43Nguy+9hx5xLvHtvGioaFNxidVTyinp+nOsulooSoLvMn8QlG'
        'mqm9I0iVjuVXgHYXP7478E81O8nyts9l4HbNIUhSI87nX3XI11Mmc9aZzmKOtHmBRHhWLVEYSt7qhAsL7bH6sWxbyMoOl1DsqkHB7pvaExBBR9mViZ6Ze23e'
        'lCiRifzW3uWPvba9scEukbV72VsGTCjU9fQ5k9NTwyZlQQdmWKOV1U62Nrd0A307G/JHvjocxzAXEA9bPNcVOrTquDGktF+itqijq0oZo4ayjSliTcu3qJPC'
        'xBhqN/Yf3xg5pNwZ61TvpvaLOEDqyfyjL6aWoEbxa6KcoZ0o1SWrkKi57cbkKsgO1zYAc3tib3EXm/LjtCoymIgCRz9lbpsqjoYxKYqJRCjVUWWU1QDVxHf/'
        'ADA4VXlAsTY2HIGOdzsxsTe0nT2jYutrcglwFtg1/wAqhDmtKlJDUw11FmdI9P25aMoY5QxNyz6fpcH842OJ5TMEEHrl5KrXtiQQRuRKDN1aknp6XLZ3tJ3p'
        'wSXjgDD/ADHdfqU8C9h77YDm3kn+/IIMeAMoF9vl6p2SuokqBmEVOryVyosnbQszhRYrIwF/TtZbbj++AA4jKTp1ZOS1rswGqidWZ61ZmVTl2XRTGupUjKTz'
        'xroaJt3MZI1qu1jvv+2LUqYDA95ser7Fy1qmaoabB4h1ZKLUmCpEtNTS004Knt1SnsxLfcBgfUp3twRfBgHXTy1WkjQX80aem+fneIujUcbd4wh3hcKovqL3'
        'Fwu9g1wbffAnKJGp90+XOYJsL7k4k1dV5hFJl8tRmYjTuSTK3qeJxddBcXQEc+5xOGgQ+3W1OS4uBZdQ5c8zkdUigNLmVLkYLGWWqBjJltwTbgG225x1NpUu'
        '6zyC7yXnmvX+I7uCGea1qap66rhSolpo1klMXzLp3qeMg/WwGqw8ekWv5BxmtDRYH7FUe8ucJj7hM0BybKVrqhflZmnkV9VQ8kt3GwZVT1C58X9XnAOd8AjT'
        '2RY2jTkiLpzMWyXNxQ1DCkgankL6qZ5YQHbYs6v6msfF/T4wre8ZIA191R7aNSCYslaWqkoKyeOnmpXWOVYfmUTsU8tz/mICFuPHqFr+ScFzQQJB+5QY8tcY'
        'j10C2iz3O26rOXikzOqyElTFNSgyES24BtwTfbY4zqVLus8gO81MYiv8QaZBLNhCuvNmFLmMsmYzVOVdxO5HM7epIUF27hQXcAcexxyw0thl/wA+W5eiHPa4'
        'l9utqTgphQTpEHRKOVu+IC7zOUYagwfewba4UgD9rYpOYSdR7JMuQwDY33oLVJnqTLVU0tVOSxEdKp7Mq32UsT6VG1+SbY0AWGnnqkknUX8k30j1A1HmVNlu'
        'ZRTCuqo5DJPBEvbWJd0MhA1su9hvt++BVpgsL2aD7+WxahVy1BTePE7y+6uR19C9S2YS06xyUIdY+4hVkDCwWNiL+rytth/fESHBuUHXq66pY52YjRJZhnCr'
        'SU9PVZZOn8zvwAExx1AA/wAxHf6VHBtcW42wWtvIPr5eRSPeCILb7PNCmzakkpJqmevosrpEp+3FRCMySlgbhk1fU5P5zsMHIZgAk9cvJM57YkkAbtSp9VlE'
        'dfE03ZoWE0a1UuV1NQPm5SbD+WEDKkpF2FzY8kYo12U6m1pGnvOxRczOJaBfUE3/AMqFnGXU0VS0aRaKGAuYErVSKrjLDbuRoSrSE7XFwRxa+OljjE7eXHYF'
        'xvYIgiBz9xtSFNR1bUEEc1ZRSUsqbGNvUCOVmCjULex/vipc2bAz1opspPcLuEHq6xUZhQ5a1TTzSZnXwdiKKSVFUdthe/aBN9O4twT74DWPeA4AC56PmkqV'
        'adElhJcIHQVmeGjMULKZ6pe2vZlK9tgfy33uGHvbe1sc4LpOxduVsBL0NKmS9b5JmLutbmISR51l1TNMWtZXLDSbG+w+nHfg3k5hFrLwO1qQaKbpveVSzCtX'
        'LOq86g+YlSSaSBpFLglUANivF9jttuOd8SxjS5zSRpKv2U4NY9oOsJKklzE17w94TZcRdWWXUYyDdSotqBPDb23uMchLA2dvXQXsNFQvjYlMwzSN8zrJ/nY0'
        'rFbRLJIset2A5Lncj787YdoOUAi3uleWZnEOAPso9HmaTxCtWOGogUmJ59Ym0Sf6mUEqD+n6HF3NI8OnL/K5BUafFqOK3oeqKLLqtV7y0lSpIFSysqo54XuF'
        'R/8AjAfSe4TqOtiNPFUmugmDy4oBrMvmnC1MkLCSULF3AdUjk3N3JIRP9Vt8aH7NnXv6Il1MnxHXmuwo8tvVCPLckSOuZNAZqpVRx7atiy/744y8R4nW9F3N'
        'owfAy/qp5yjKZ5GFQKeaJkYSmBnAEqt6gzq12AO1trc2xTvHt0N/ZS7ik+xE+kpylSfJ46VJKozwmUinqBWM+n2VwTZttr3t4OJuIfJAvtsqsYWQ06bLpbL+'
        'qFgqJrVE3ySqRFK6lIl9V20DhEJ9uTgupkgWug2s0EnZvVbJM5pZT/EKOnhqTB/NlrKdZXYk7AXv6r+yi374R7XfQ4xOyyam5hl7RPndP5jBWw5oWc5VUwmP'
        'WYaYCLQh32DE8exv/wCMSDmltpVi14dcAhLx1joXrJ54hKkouiGxQ8AXDX3G5NrbYP8A/IRbBklTM3zdMqlqKpKmm+ZcfRT1T1EbDwSrEjb2JuTzirAXw0gx'
        '6QoVCynLwRPrK0yrqGhlkLJWirlkibXDPDpdiN2uu2lh/puOMVex20Qo0qlM6GSlJMmqpszpaiqoxl8kgMlI6zLEqkb3LKdm3BsdsUFRsQ0zvUTRcXBzmxuT'
        'aZLVQ5rV1FLRDMZIwJax2nWVWPNwzHdhYmw2wpqNLQCY3KvcODy5rZ3pvN+o6CKRWetFJLFEuiGCHU6Em6kLvqY/6rDE2MdulWq1KY1MFEyjOVzaWnq3qqX5'
        'lB9FRVSU8ajyQqkD9gbg8e+JPBZLQDHpKtSLKkPJE+sKpLWvJorIJ4mleY2jc3Lng3Ja+wFwbW3xIf8AErodAhzUxlkFbNmoKHKaWER6xDUr3daLvay259hb'
        '9+MAuaG3koZXl1gAFPzzOqWIjMayngpjUfzYqypWVGBGxF9Xpt7MLcecVY130NMxssoVHMEPeI87hScw6qWeohJqZ/kmUCWVFZ4n9V11jh0B9+Dxh204tF0j'
        '6zSQZtvTFUk+cx1ccVUYIRIBUVBrWTV7qgBsotte9vAwGkMgkX2WTPZ3ktGm26TGT5TTyKtOKaGJUURGodyDKzekK7NdVJ8b3O9sU7x7he59lLuKTNAAPMn8'
        'qjW5ZaqMeZ5GkteqaCy1asiD21blV/3xMPEeF1vRVdRk+Nl/VcaK3LoZylNLCBHKVl7YOqOQG4s4IDp/rttjsh+3r8ei8/NTnwnTkj1/VVFmVWyd5ayqYhTU'
        'hWZXccr3Ap//AB7YzKL2idBu/papiqLnRMnlxQ6zNI4ITXNHDT07kRJPrEOuT/SzAFwP0t7nBDSfDrz/AMIGo1vi0HBWsvzWNM0o5/no3rCxSKWJY9aMRsQ4'
        '3A8X532xFwOUgC3uuthZnaS4E+ybq5cyGYRwmYQ5cou7NLoMhJuxYW1Ejhd7bXOJgsLZ29dFO8VBUjYnsurRmvVuSU/zEryQS1DRqHClkIFy3NthvtsON8de'
        'Dblc4gawvF7WeHMY0nSV0/XvwMfquuFZmWUNAA5iTNFlZXqb7jVGQAovc6QSf0x6/iAXyeZp2r55U/h3osuqmifMXpW9RvJqjb0rq0katyeF97740zsQBjQ/'
        'dSYfghS1UVE8stGpnL6Yp2FzpAuCC33sBxcHDSULO811WU/hgyuurT8vMZG0gjslbNbZgQG3AvxfG8R2oy1vkl5PwvJEJaSmihq6hJgjRqraQu5D7yWC7j9L'
        'b4Mum6EthR8x/D1DlU06zTUlO2tYYgitoqCTYCMFt7m977C19rjGBJQiEYfhhrpK2ihkhZXkkCaFjkVk2O+rVYXA2N7cY0nT8LTtk80jU/h9qcorZ6LMA1IQ'
        '/wDJaCV0jnX77izAXuTgE70wOwE8U3B8C8nMkAqJ5qOFvHfLafNrX8gf742vmmkjbzTkv4c6GGRDWmRsvmY6DUzGOONLXu2p7cbahcE4wtcWQOY2meKkVv4c'
        '5aUUE/yCUWXVTWpqqaqcCZSLqQNQsp9/72wQZ2/ZKczbXHFMR/hmGYJO8McPbppVjkqaicRgsTe13fey7kja1sGY1IQ8TjYE8VrB8BMpFM1XA6SUqSsgnhqf'
        'QwDW+osLe+9tsLM6oxGw81rmPwUoqMNPTo/y7gRrKZRoZvLi0l//AI+OTtgWNimBI0/lL1PwKpBTQTBAzgm7SzBQ1/Ny1iR9vG2+CDFgUJJuR91Q6e/DHT52'
        'ZHp6GedjIqR2nVUK/mdhqJ038De3ODnO9AtgzB5rpKn8I+X1ZVaLJc0jmZyO9XVKxoiA7ERg+Te1zttxgNdO1Y2vH3S1V+Euop4ao0tL36lShuko0gA3YAht'
        'iw2uf0wxANiUMzhs+6JW/hoiEFS9PQvUzx03eVZql1WEkm2sXvqNjZTxbfkYlYbfsqS5+z7qFH+HRKx4VNJJVSVETSIkbMG0ruzG7ekAA3B324w2YbCgWnaD'
        'zU1fgPl8MtNDJTy08kzaTO6SImsnZQ5IHG9/PjBzSgAR6+6InwLyqeFKhozHTyM8bLJO7m6khgRqve9jb2OBmGn4T5XEXnmq1H+HukmjqY6aKQfLsFkggnKK'
        'nH1KWHjYG1r3wsg6rAOAtMe6WzL4BwZb8ys0FeyoFVSVftOW2vrvYKD774IIQJOkpWm+BkNYqJDNUVyxh/mSdZjgYbC9ztYjnzcW98HfAW1sXc0eH8Oax5bH'
        'Vy11PB3NPdedWILE2tYPc282vg5nbkJAP1cyqz/hXrSZHkpIVCPoiWZWYOn9RCtsBz7bjnG8QU8zDtW8/wCFaugqflZMuhmgEYlWaBWCFzzERr2t4PH3wJds'
        'ThzVpl34X6isiqayuolUIRoWzfSTYhVNzwL6fPHJxgTFlpE3ujRfhi+crpaXLKVXl7hTQkUiIgFvUWawAN9lFyDz5xpc5LLGiTZSqz8Muf0sknzVKTICxhjJ'
        'dmkt7NqsCPN/2vgQRsRzh36uZX0L4Y/BKo6WCVyUD02Z1MLGnqJ4m0hkIOlGJsbH1aTbUPvtgkHbosKjd6+aUvV2eVFRUymtNMsfEckUboCfADAgXPNseUWN'
        'AH5K+vFR7nHQew/CNXdW5vURJ/iU1qbl1pIlH/tLaPfe4xgwD/Kznk7uA/CM2Y5pBHElRVzBaktPGSkStsAun0AmxNyNrj98JAOmz1TRH1bfIJV8wzqvn+XG'
        'ZVTOrK/+Y0LaQPoLADnz5sMOABdIb2VGLMKqnp43avnijCdswjt/SeQSUuf/AHE3xPKOpVfPTggVZr6ZYp3zWsdz6Vu8YAB+xUgjb9Tb7YIINoSuaQJn7JP+'
        'O5xFFHEc8M0i3Mi6e3cf6lsP9r8A4fK3WEhc4bZ9k70T1XV5p1DUUE9WzUTUuox0tl7jrKouuxszAldgLg7nHdRZDSvDxj8zxouz686lzLIcyApmp6aeFama'
        'HLJYw4MaqoEiHSQxVmsWv9rWGJ4poNMXOo0VuzXRWdYHwmxXF1PWud5nTiCrzWN2jGqWGk0R6B/qYeph9gQPttjzsjZm/vJXvtqPIgkegACXpM7zd1q5Ycym'
        'i7F5JLSWum21zsb+1ube+AWMBEjVXbUqFpvojZrnVXOI/nhKsjw+iCCYQmL2LO19O/8AvtjNY3Z+UX1HkeLbustczzfPYunqan/ij0bQBNIE0bd429SuFWzu'
        'NiCR9jjNawvNp49QmcaraQ8UEel0nlnVHUFXOZGzNSIIisca06kyE8i2m1/LE+MM6nTaNOfXspMq1Xn6tPJGpM4zWtnjpP42cvWG6mpqJdRgHOyot2X2tv7W'
        'GAWNb4olO19R3hDoTGTdSZ7W/Loeo5wsLPLFMsIDMyta92FwL8g7nyDgPYxs+HmmpOfVjx8kau6rzqjgPymdVCxSuzkmMTXKn1FEtex/NYWGFbTafqHNNVqF'
        't2u5JXM+oM4qqOVKnPJJlqFVwgACqBxdAu2/F9x9sFtNgNmpHVakSXaqfRZ1mlSpeslepLEjVsSGta5A+qwH6gjFSxosFzMqVDdxTM1dVCWaFc7aVXH8tZVL'
        'LqAtqDED0je4GAGjXKiXumA9Zh6mzdGpHp82rpp5FayzwGUx28Rl7gk+4FwONsMWtE/lIHuJEHkmqTqrNGr5Xq8xrPlmVEikWcK0R/r2A1I3tbYb4m5gjw6q'
        'jXku8ensmJOoa+nhDxSvMQpW9WUqA++9yw4839rYnkBN1cvc36Vp0n1lU0nVtNPWzGroKmnkpGp09KqSysrKo2LAjc+2oY9PDgNDmhfP9pEuyPPmu36t6zqO'
        'nK2CLL4yFnM+uqYoiM4C3JUqy2C/SCLgG4tfD1xLI81x9ngGtpNlzGYdf5wtWrT12hBEwjpoUUq5tsGYIAu+97b2tjhyyLE8V9DZsWHALnouuupKhaiKhn/n'
        'LcsyqEC/rvYeQB/zhyxojMTxKAqPM5GifQJyjzHM6x5pKCqllnhi7sz1KmQIvBL3GwBPPAOJGG/V911glw8H2CXnzLqmjDMc5SCneXRO4nRrORvpAPJH2xQZ'
        'CIg81yvbVaZJEeyl1WeVElZpgrZQsdhGVcm/vc+b7/bDBlrqbqpzWK3iznNdS/44h5H9MkkessoPHpubD9N8KWN8+KcVXeXAKpT/ABIzGKNYWWCumZikXeAa'
        'w87XsN9gPO98DudsmPVH4iBGUT6BbNTwQFXSEqQvdiLQai1+CFsLjGk7SjDdiVmldoHMenWFMncmcpcj3IFwbn7D9sbakMxZeyqvq4IkmXMBdlV417CRPBq2'
        'sgB1HUQd+TbxhnATEf2kpkxmLp9ohU6KmqqmIyTHux1KuEmmBY7fXvy17Hje4sD4wjiGmFRgLpJW1LUQyZZEtSwZJQERDohle3BJsST+o425wSL2WBBZdBra'
        'FUpDHKqx2l1NLoKn0bFbNyVYHURjDWymbtuudqzUx5mEkqHqURFkEpCsQDe1tjceNr4qIjRcxzZtV03w6y6oi6ugnqoX1vRkFasgNYSLYW2A+w24/v10iIIC'
        '8nGAhzSVY+K0ndzXL69o57M9TDDNS1TETSBIyzzFh6Y9NwFX23wK/wDtkeY6HmqYAAYgEnYVwTGojrRGlEn8xAYtUFlkB3B1gWbm9vvjhgESTzXuy4OgDXy/'
        'lMU+X06d1qlFStBEDoQ0kJKm/wCW4829/bE3OOzTmuhlNpJJs7kjZtPQrRnXBBSyvqWKKpOlrx21hb/UCCAGP384DM+bWfTzVKndFlwAdgPluW2YUYomMtOy'
        'zUsAWOK7pTzBGFwpV+BqJ3BvYXxmnNrqff7IvaWDw3A9jzRo63NJ4FeaapimgYfLSdxGDX4AA5tYX23BxsrQbAX1RFSo5t5EaaKbVVNTmdV8zLA0VY9/mKqJ'
        'SacuDYFX9/fxfFQ3IIGnPguZzzUIJEHadiOmVPMBLPUCJamRppa6CRisYUAXeNDdBt7Xtf3wsjQbNn97U/dnU7doP8Jz+HzUtJYBZppQW+ZZQHKWuFZhyDcW'
        'JO198TzAn+FbI5g3k7UrHR1E6xSSq5SoDB4u3JrA43K7Hiw08ix2w5yiw2eigMzrkWPqmlikirUgSodJjHxK3dJX+kWGoOADsPVbE9RMW65KkZTlnjdbNQ1C'
        'QxutMZo3VSjQz6JGA4GlwCA1rEXuRzvhgRMSpuBiYn0KYiny2rqUkqRLTVUF5HpbiI07WJsWBIAtuW+3thYc2wuDt1lNnY+5sRs3KOnUEtfIMweZawSBVV5Y'
        'Q5k2/KG4Hj2tv5xXJHhiPdRFXMO8BWwhqcygWonlpaapuXWSTUhe/AXSpAP+ki3/ADgWaYGibxPEmxRukMrMvWmXT1cjxMIpdbVsutSgsToAAAt7KLnbHbQO'
        'oHJeJ2g36Debrr/inNUpPkdRSUj00OueOKCH1Gd9EZO52VQtgBuRc33w1cAsgqPZ5IqkjcuJlpKWohklqa1BPNMEaKZO6HuNyrcFh7HxjkEjQL3C1p1KXWju'
        'GhjgqYXjbUrdzWCvgBNx/bGJ2yiwTZoNkGa1RQ1LyvPJUNGY4u0zRrGlxc6Qdx7g3v5GNo4QqnxMJJMpfTQ1kSMskFTLHdAiWGs+Q1vpH355xQFzTuXOQx4E'
        'EFNRwzGKZqdI9AW4dD6Ijf1aRvtbi9rHAMHVANcAcqPGy0JkkYSdtXBMiRlTGDySRyPP23OEImyIOW5W82WpR1skU1OkQXTLHThbM4uPtuADqufFrXw0yJBQ'
        'jK6CEfMWhq3WGML3XXTKV1F7cD1k+fFsAWEpXQ45Qn0ozU/JRRiKKKMFNQvI4AH1Nze3tsSRiZMSSrNBIACpVeWQ5bEJlqKQpL2i0t7vF6SFWRRsnnke+3OF'
        'bLrQUzsrATKsqEEbUEvYeV4RMEMYZ1QcEEkXFyWG217/AHwhEHMFZrpGUr5/Hk1DP3TA1VTrUSSXkjFoYWFiroW39Z1Cw2FiecdTnOETeOPQXnta1xIEweAT'
        'MGWQ0BqxDXyQ5hMNby1L6qeIDcyNbYMeTfnbm+CHZokW5pSzJmym54JJK1qeJxHWvUODdCpBjcf1iwBX9rX22w5AOoUmlwuCq3QyQV/xDiqKvMZ445KQkyVR'
        '7EIIcERJfgk7X8tsOcdNKzSF5eLkuDpJXefEjU9Jl01PBUxxv81LHBUwBwZLRDW8qnYgECwsPB84jiYye66uzT/rH0XCw1CQiKkdXCKx1mAGztuVUqTcW32H'
        'F/tjzje4X0jTAAK3p8to51nqp4q/L4Y1hEVZJJohEttUjIqXJYEiw35N8DMRDRB1ttj3QNMEuJBERB0E7UKuo6SsoK6eGc1FbFZ4KyuBeeOQH6Leb72Fhfk8'
        'YoJaQCIB2DRSIDmlwMkbTqFzVKalJMumanqYY6qI1Uc+xMsYfS3N7i4IswF/AxQgCROluv6Stfny2NxKqS5PXaC0dPJ35b1DJE+p5dZ2VrmwOkbAW9hhc7dC'
        'nNJ7RmASUq5kalaeWrrIYGFis0fopgPEmm4H23NvOKeEDQflQ/1CQJIB5L38SW0cksUjKQwmmVAFgjA3eS3AY2AHk4GXUA/36JzWDYkevkN5R8oho2lk+aja'
        'sJkDQVUpkRadSPoNtih9/wBDjPzD6bbxa/8AaWnlLvHfcdypARaamplyqrqZpNcARa7taRaztqU6jb8oQXJOJ6eEOA9p9P7lVMEl5YTs1hO9P0s9NPCa2aPK'
        'aGb+XHm6xtJILJ6I3J9cbNYLq/ckYm+HTFzu6sVRmZsB1hoHfmdENaGGZIWfNXmRfS3bYdre9wCBqJvt53v74IdH6YSlmb9UqHLOtGESGifvPeM0cEZLuD9Q'
        'IYbrwSePfFgC7U+65yQzRt9ycm79bRVL1DU1G8sqMY5FErXCgWUqLgkWvb2G+AAARF093NM2QnziajkWU1HajQ6AIrs0je9vDf7C+BkBEQgXkGSVa6Y6gly/'
        'rHIpa4KsE6VMKyTovo1IoB0qL6QwH3PIx04cCXR5Ly+0iS2nO8rpfi1DUmAUQqJDFEk88skQUQ20x+kMNlU3vYfbck4tWix81y4CSXDyXzSOlr/4bE0kUIF9'
        'MAKuA5J3ksBfceePGOaRK9drXlkkeiytQ1LUzKrSPWKykJSKWcH+q+wQDYXvsdsYtkDd59XTNqZHHf5JeV6R5R/EUkqI5nIlQSBGfff1m9iT5scMAdmxK54J'
        '8W1UiKdl7tOkaGFQnYWLXdRx6tNm0jknfE76HaugFsS3YmGjnpIyjgSyhA6yxtGFct6gUIX1C1/q9IO2FEFYlzbarSkJq6yWolhqXRriNXckobbGQJyPsvG3'
        'vhjYQFBpLjJBVd8vq5zDNLVCno4kdEnkm2SU/UsZfewFvQAbHzhC4Cw161/KqGOcZJgKZl8NKhEdRUQ/4mZn70z6V0lbds7c3Pi17m2/DOLiLDRSZlBOc6le'
        'oY6XpiV6b58QZcZHR6btOmp7ehmW9yB4J4uPvjGagmLpWZcOYDrJvL8/rad6qeB5E/kiGeRkCiW5uCSfbax5/bALGwAmbUMko4rGhEiCGSd2BIkMZk0kjywu'
        'STvx4vhTcpw6ApK5mPl4ahkCTEmMQJIriCxtdgo2vtYckefGKluzoqDX2zEKZURQ1CzRyo0EL2Z3VyQxBuLgcWO/nDSRcJHAOkELeCmiptMcQCwKotoHqvfc'
        '28/pe+NM3KWMogaKt0OJKnr2iioyzK9I3oKiVmXuC90I9J2vbwPN8ddMWK8rFmSF1nxOmM5miroII4HklaKoWnYdxQEIiKFrFfSGFrn1C/OJ1ycojeujs+O9'
        'IO5cLS5qk8YeCeV2BKyshYKhI3TbYc3su4GODuyLEL6AVWH6Sn8tjkgizBYqaJRGmtUmqWQSm9i7Io2sNwoIJJFzjEgZSTy/lABzswaI99UzkdJDepqpjLHI'
        'xF2lBuEFgq3HB2/c7e+A9xs3Ynpsa2XbSgrlSRCpqAUyiadmmllZ1YySjez6iPsNI4vt5wS7NA1A66KVjAyS2xN/VL1uWJllFIISJZqnVPPHHEXMbONxqJAA'
        'HseN7YLX5jfYg+mKYMbbqdl9BWTsghg0yxxExrCO0HX3uCAfuD/vh3OaNTZTYx5014JamoKeNKieONO9M9qq9TqV1B2VlOwOoar3PGww5cZAOmyymym27xqd'
        'bpqir6mVap4omCRqV1Sn1LcfmsPNr8bYVzRaU9NxIMbFSy3MFdwzRzqzt3ZpNAldHA2F0tz/AFML/bEXtPX9/ZXpvAMnbrt+33R6WScUrT3mo5mmaEzBzMQh'
        'BOna5GrcG37YDokDXks2S0k25pDJ8xJplo0ymojqNLCJVgdomYHb1arIAOQf+cUe0k5i63XFQp1QBkDDPJNUWUzZnXUtUY5560MFilEpSzX+kbGw542t98IX'
        'hgLRorNpGoQ86odGmaZadS5olLWUrSJ8xFUJIXBN+VN/cbA8AeMMXMdoJBQYyo2xcAQd4K2nyshJkkg0U9gmthYtfc3323PHOAHed1nU94RemZ0o+sMmCU/f'
        'mImQr2tbh/SQVvbWwsbb+98dlCfEfReL2hEUx6rp/iHSmgnhZ3WgnzCOpAjkpwk0kR0EML7gah5HN7eMUrfT7qGC+s32LipInSmRBPLNJIT3hJKTqFudzv8A'
        't4++OTavZNhYpVGq0mDRy9uQRmMFWBAHnUByPsRb/fDWiFPM4GQVmryr+I1PzdTCXaaPR3GftopA207af2HnBDsogImmKhzOWI3JjQR0sMaUrdtZKViQ4Fry'
        'b8sfJ88DAIvc6pw60ARG5O1VRAalkM0XdkTtxSRw9sAXuQX978D35woBhM9wmCVQoHYVaI1OWsA+v5oBgRv99x/5whuJnkmaYOnNJwoPmZKlHhmiRZGRiTKi'
        'Xa/b1G17Hfb3tucOd3Xqoi11Npcu64q0kp0r6V+4NV56EGwJvcaSP1AO3tjvNKkIMc18/wDF1zIkH2R4vhd1NncNTUU+ZUUz6bzyrSka9X5iWY3v7jDZWi0a'
        'eaU16jrki/kiUHwl+IFNWRU1MaSeocdtIKhCY1HuwfZCPc/tgFlN2qzcRWYPCR90XM+jfiLlbCPu5VRzsfl3pqZSJZATYnT4A918H9sJ3VImCCrfF4iJbA9l'
        'Hz7orq/Ku8ahaGm+ViKs0CXK6gRo+rZrE7Ebc84cNZpdSOIrEzZLTdCdYZYUkr216FDR2Ur6SBYsAw34Fz7HfBLGEQAgMVWFyQm8u6R62rKxUozQXGy6oClj'
        'fj1E/rhe6p+fFP8AF1nbuC7DoroDO8s6hq67qaop83MbR0oWhcuIzfWNAIUsQ3Pi/nfDtDWiGhc73vqHM83Vf4zZ3B1b0jFRUDZpSVuXVHdjmkp/5TxuumRC'
        'NZ0DUAV07k3B4wSGusUWVH0zmYvlOW5H1/IsNBlMtC4AHbpVpbLYi9yCeTYm53xPuKRMmeK6R2hiGDK2IHkn4qbrqEy9xsuaLWiLTxwHTf6huGu17E+ePGJn'
        'C0tL8VZvamJEnw8E/W5917WxQ96DL1omYN2YY3jjL2sG55twPY7DExg6TRYlUd2riHHxNbwKmCl6zr6xaKTLMulVNTNTuJFKC352Jvb29hxbFfh6YuHHkpHt'
        'Gs6xY2PdPQ9H9bn5VIxkkc8sq08FKzy3N9hYWIKrsbsfbB7mnvPJD4+vFmjmgVnQfX8dRLStBlizxM4bvO7GRx9ZDG4JtuTwR9sHuaY1JQ+PrxADea0ouguv'
        'al6cRU2SPDIzJGqJbUwHI2uduCMY0mHaeKwxtcbG8FLEvV9JBLMJkWnb0mnNMAjEcWUHkc8/fG7imdnul+YYhtwRG6EI9R9YtAZVio4JgwFxTaSQOQd9wfI8'
        'jCnC0ydqcdqV40HBOVOd9Y5pPLWSZXltFTue1LHS0r6ZSOA1m3t4G2FGFptAGYlO7tSu5xdlaEu+c9aZmsiCKmpY4xpQxUDKdXtct9X33www9IbSUp7TxBtA'
        'A9FpLH1LSRo1TNqj02MK0zhW/UB7/wC+2AaDEox9Yardcwz5o43pcroqZIfU0oy76rj8xLcWFx4843wzby4n3R+Y1QQWsaI8lmTPuo51Kw5bRONY1O0Dq5c7'
        'i5Lkgnn74wwrJ+orHtOrpkbz/K6nofJc/wA16goc0z96daamBEFLSq8ZjGoF3ktuo2AuL7kX2OKspspTk1K5a2Jq4gt7yBGkeav/ABsoqGpqErKOrahrUk7o'
        'ghQVIeNhsJRr58gg2t4GGyk6ixU21chBabhfKMyzfqSaWNmlRXZB2phQgHSOCBqsB/8A7hBRYBb7q7sbWdqRwVETdVV0lOBSUzo9hqWlYSFrcsNQsftsMDuW'
        'AJjjas3A4JiJeuIKJkelp6GBmKx1YpGkaMnxuxCk/cY3w9Mun+UfmFcNyiB7Latynr2mZewtPK0OnXEcv+r2DXYhr82/XzhxRpbuaQ47EbxwQqodcGkip5IK'
        'dhUL80k38PsxQnYAh7EXFrcjCCjSBn+U5xuIIykjglRTdX01MsJrRGiky2NAPpvuC9ySotxxh+7paxzSfFVwIzclrT1nUcNSlSmYI50artl5kQhtgSC2/wBj'
        '/bANKmRBCAxdYGQ7kvqkHxCjkoIKD+EqKONiVWWoJkNwLqraTtextx7Wxx95VG0cF6wwuFOx3FPZX8Us1mo6imqsjp5O1J83pBWd7gW1I2n1Gx3Fhh87x9Lh'
        'whJ8Ph9XUyP/AF/SuZT8bMy+XdKDL6hmhK/MxvDCBD/SAz31E+PHvY4XvardSERhMK4+EO4oeZfGjqKCrOYtR/Ow0oV43iigWSMsLAuQL6PBHjnjGFV7jEjg'
        'icHh2iSwn3Ulfi5PS0c0Z6VyqNXGoPT0kepCTckN+bfzckecY1Kp/UOCww2Fb+g/uKBmvxTzCuzR562hp6iaRtcwQAF2sAG06NJIABIB3xu8qn9XJY4bCjRh'
        '/cVpR/G7qOmkeqpskpPlnAo5G0xzRhCbFmj0325O/wDtg5nA/VyW7ih/8zH/AGVOu+Pub5wopMziWGNIzRmaBI0gli1bLsoaM+Q29vtgF9TUO5IjDYTQ0yPP'
        'MVH/AOodK0McKQS1giZljo1KkH3YNp8e9ve/N8L3lbeB7KnwuDA+kk+q1pevqmjokpaPLFhMTGRPmaqMSLfchJSvHnSbEfphe9qD9fJUGEwuymZ83Iv/AFUq'
        'c1qqVTlsUbIGLOJdLEG2pmAj3J2Fztv++GL6gBkjh/aQYXDGwYR/6/pFqPi5JVRw0EmVa8vgHc+XgjRUifglgyks445+42wc9SNRwS/C4UH6XcUxSfEirMnz'
        'dLllK9RCflxBUxqWAYW9Z0er3Hj3wpq1AbkcE3wmGcLNP7v6Waf405tTwSUZymm0x/yjMIoS8g8gMyjYb72H2w/eVIs4cFL4XCzJY79yyfjZV1hp6pMuqUeA'
        'aYyhjSYFeLqo3AF7X5Hvxhc1aYLhwR+HwkSGOHuu6oM6XrqmkzaWCOiemqRTVBpaZ+zEnaEqyMUuI3Y3JUfVvbyMdVJznU5frK8rFUmUK+SmbQDfVcVnedZf'
        'RzzUD09LRzQRwzRzxl3VmcXMXZuVsEsbg3u3Nr4SrVdTIAEyr4TCNr5nOdljylIN1VlFbmKGDIyYka08FQqlXJ8dsHZAd7ltXt7Y5/iXtuY6/ldY7PpukZjw'
        'TuV51S06w065PFTtT2VpKcoY2vfV3FJJc+Nj7EW3wDjHi8DmrDsqkbFzhwV6l6np4C0VLSERa2XXFTxyLPYbhizerkcGwPGIfG1dcreJVvlOHuO8dyUGq64y'
        'SZ3M8Mk1RG4Ec0qev07WZL6W/cecV+JrEfQOJUj2bhgf913AJGo6qpZcwMMWVy1Uda3e7SSRxCpceplA+lQvtcW4wwxDyJgCPM2Su7PotOXM4+wSC/ETK8lq'
        'pmhy2py/v7yxoFnKAcAvtfz4244w4q1SNBxUTg6DTBc7gF0HTPxUy7Mq+N5coph8m20YpgXlU8O5D8j7cHm+FqYio0fSOJT0uz6FSQHu4Ba9RdZZYpooXyCM'
        'UKlwIIuyqsjNcXHKsL7MG88c4UYqq6SAOao7sygww5zuAWsOdZfk2mpNIYu0JDaWCN2pWP50Vtgw23IIPgYUYuodGg+5Rd2XQAnvHcAvZfn2R5XQ0+VjJHq6'
        'kQs61tc93Jvq1lgwGq5uAQQeOMY4mtcgDiUo7Ow8jxOPsFRh+KVO2S0tBJlFbWJSSlw7H/PJbWFFmF7EXBO+1r2wRXe39I4lB2BpG+Z3AKx/1IpJe00mWLC0'
        '796eoPcZyG5V17oFydudrHbyR8XUH6BbzKY9l0nD63cAo2afEfp7MoKvL6bJOwsyajLCtmja/wBSF3Okm1uNxhviqmuQD3KUdnUZjvXH2CTg6q6cluZ8keJa'
        'o2mh1M0cibei/cBCEi/j+22McVUH6Rbz/pL8tpad4f2hXcvyrp3rKvqaLLony6shKyxoW0pIrKSLI5uSCpsUJH2Ax10KprMzFse8rzsZhm4R4a12a26F8eqJ'
        '6iXL+/LHM0mssz6QWZbDkC1yOffzjmgTAXtXiSiZfJVpWvDDM9QWKuKqGEntMRt+YFiR43tjGIk8N6UE5i0FUMvSOh+WqKrL5qqgWQhjHOiTS87Dm1jvpI38'
        '4Ukk63TtAAuLL1RlNVVVSVkYSmV42Vq2WZtlt9BAstrcji+BmAGXXyWNNxMhIx0qrR07xtEiMO5ojkdgT42NwL2ufIw8mTKXLYIVZXhXR/UsLpeZW0tqe++l'
        'vHjfYnBA4pSRKAtbH8xCUCXWzRzvYMGvxf8AKP74EGE4IlY1aHkaSS8Skq6kjTvcmxHH7HfGudE0ak6LaloKV44miiJJYshjk0qo9zfcEew98KS7amaxuoC1'
        '+akMkMZSMlpZDMl2YIij63HPNv1ONHX4WzmwhZjmqczqKmoXMTV1it6542Jt/wDI7bDxxgkBoAIgLAl8nNKfhEsFK7QTyJPFpeON1BEqBgGIVhuSL+xFhhDB'
        'N1S4bY3Vys+VemZIamkkpNRQCJmDMlyNxYD9QOTiYDpk6qzssWIhQcxVqSZkUrUiH0MkMwLabelSCLAW35xZom+i5n2MaqbVQR1YL9yohm+kJDKBp9vV9vc/'
        'pijTlsoFs3X1r4GinTNswoa6lm7rpC5iA0swWJvWWZgEa4vYAmzEjnHTSPg9yvGxoirHkF8+z/Kcyg+IObrU0utiI2tHK6BCU9DKCCTqHKm1jfEMSWgAErt7'
        'Oa90kCQtKfLklSOaadlZSweMACK/gfcDYgbHHnFxBgD8r3hSm5KoZbrFI6JpiaNrntpqDe4sd7ng239uMB0TKdosQt/4itQ0kKrSCnhJLU9QWbkbnVsT+o2u'
        'eL42TLBvKUPzGNgU8UaZg0TyN2Io4RKkzIZPSSdKtY3LDcLf9DvikwI663pS3MZ0hGhcw5P266CRVmN5ogodJG4DFfYi3pJFj74WAXeA9dbVSTk/1AUklDVT'
        'wBJaEpSj/JkanvpF91DePta5GwxQluw39VztDzqIHosR5XJS19F8vUUUcEt5EkYPJpVT6hsdJJPj3/TAJBaZlbK9r2hsQU9V9P1KvO9Gz5nd+9LFUeltJ5EZ'
        'A3Qew39sKHg626+6o6m5pkHNfb/CWr4JhTSJP26dHIkABdF9I+ksxNz9x58YDCJkX68lnglsGyt5fFRyUolWopKQ6VMQnVpY5d909Pq449ucJfMQU8DLLSt4'
        'p4GqX7aFI2cqXAE0if0kqwAA2/25wI0ladYTWSRLm1E0ryOkaO8M0c6duoVgd1ZeVvsbg2I4OC5uQwf6Ssqd4JE7r6pbramo5ZJJsvqA9TsZIzAAqcAsSvpB'
        'sNhvfDMtY6IPki2qj0EEKzTM4maKWwjeaFkuv31EgA+1zxhnJGiZJXW/BzK1gzSpqKVamrqaArDEjvdFjKvZha7X3K/6R9selhTmaSvnu0hlc1s2hcMezHR9'
        'uljSGeQ2kSS/cU2uDYfVe2zD73GOeDtXrAjYo0VNXUckdSI4mkjqNUTlLGAWuBcXuVO/g4tLSI6K5Ye0yqXdVou8UhMoJWWVIdLm++piPzHfa+/+2JQZ66hX'
        'kRK0SVqqNFSUIwBEsLCRfmBflNyoW3JvcHDRFyhObQ2TWmKnStqIe/lylwqrKDKpN7BS62J32vbbCTNjdPEXFkFYEoaiWqWkMShg0skcV2WRfzMtuL+wv73w'
        'ZmBKAblOaEUxfxB51DtHV7nXKq3duTswspt7/a2ATlg7FQNzzFihZeZ6enEM2YSq8kjRw60R0dbf9yIiwsfzAi4tYYzgCZA68iswuDcrnX2acwsLFVZcQGqY'
        'lqomv3GiKav6RpBsD9r7g3xjDtBZKMzdSJTpr5zVQTyBYC0ZB0PZQOWB3udxsCdvGEyiICsXeKXJdqQvBQkRrAsbM0caMsitcbMyqLbe33w8wTtSRIEWRUZa'
        'pZzEIWaM6xURIyxhwN7Aki9vO3tbCm0SnEOmEzS5iqvSwErHDAradLEMyk3Ubghbb8c398AtMEoteJA3JuHMYXhkNYIy8i27mj1aydrv59txbAIM2WBbfMoj'
        'SRGOVJ+9LGoPrLKVXxpII4PA3xUA7FGRtX1H4R0c2ZQ1bRM9a0NbT1ggSZTOscMBVNJf6kux+kXFt7jHXRHgjzXiY4/6szqAuP61zOjHxKz+op3p5oZYqUuU'
        'BenU6D6diS1lsb3uCd+McuLBOX3XpdkEBr58lOXKYaXM2WnCOsYLrAb2k23W4202I3BvY44MxIuvb7sB1knFXx5WHTMJKrLnmIjp6qlVaqNZLg6GUgNZrDSy'
        '+oHffFsuf6RPlp15rne8U7PkSdl0XN55OonMdA709VqaQwvCrSAD6iBYA73HGr3vbGYAz6hbrrcg+X2pmD6LTIqHMoJ4PncyppaQzN/iZItEapbdZAvgEbEb'
        '3++GfkP0tgpKQrN/3HSOCcWI1VVSzUFTFTXvoFTO6aXPANtgrDy1yMRFgQ77LpccxBYY9SvTz01HTESRwAyEMZnkDmMg+rfh7cb28XwwDnHXr+Erixo0HGV0'
        'eQZlRVUBphHHLKR8y6zOspZR6WIIsoA50jxvY4i9hF1WnUaQBqUvnNMknzEdJUVFHokEUcGq6CS30MoNlY3BIuLAi2MDBBIRdDpDXaJCipK2h/w9CkLZjVSi'
        'N4nXUjc8O50qCdv1++GLgTLtB1sSNaWiGi5S2W1ktfV1sfZaCrp9LVFPK0cctGSSAWB5uQRq9rfu5blAOw81Jr85Ii41GkJydv58MyRSUxpqhXEsbCZliCnW'
        'siC1j7Bbqb7jzhBYRv8AbgnfMzER7rNPmFHV0McjGY1EwV2FPpkkTWpKgEADZQPTyP74Ygg+XmkDgWztKYWOnNNJSfMTFmlEqysQrNt9Ja1tJ+9r733wpN80'
        'KjRbLK1ohQ1k6zmqloxAS0aRQM0UjW3dSWIB/wBJFvbAdmAiNUW5SQZsE70BmtUc/qq2qWmjilpRINMkcMZhKtqPIGsMFJtcm9rWx6uFAa2Avm+0yXVBPsuY'
        'rk1wSwxLWUc06lEy9jpYtYFiG5YbfYjEPXivRJkEBZokSpg0RUUtLUDTGGp5ZNQUC90S1wb+/Fzcb4JMalFrSRACVzOOhzDt1MnepKymLSQVpMkkAm06b6ED'
        'Hf6dRXY8jDMzN8Ow6jyUqrWPhx1Gh/pLRXjWVYadnMYQtEDoVXI83H03/wBzgG9yUwEWAS9dkkhBlWD+KUxP8yWSQxmIi2or9h7H9BfDNeNCYKm6m4XiQqcu'
        'WVFBLI8bitpFHb+aVyEseN+NgfP6XxOQ5dIBGl1usJjjahmqI6mbtqoiqHDSJHf60HI+wY2GF18Q69UwMDJqU3RZYMqeHMaISUtVM7CKooZtLkG6sp5HB3B8'
        'nxjFxNjzRDGtOZuqE2T11OHEESNE4XtTGMyJG48Pa5F+PVt5GNnadSsWPGgRqamqaRJ4ZJYaiC0a1kUUKlZWXdVdT6bqdwt/bCkgwR7f16owQIdB3rNLTd+n'
        '78UUbl7ukMOrtsDsBptyDyF5332xnGDBWaDGYKPoEjaCziV1Mk4hZkVtJ3kKX0lvYEbW3xa6hb3Rpcxip0jdnj+YnJ1xGP8AmAqbaiLWGrYi2BlLrbkS4Nvv'
        'QhVyuZRHGYyGDEu2rQDy11OrcbW8HGLQNSjnJ0CdWdYpSktNT1NO/qs2sL9juSd/PP3wsbQU87CF9A6IngmrM1NM0cNTNKIafVLIYkkWAAEMFGom5st1O3sM'
        'dVARTuvEx7ga5jcFyvVdPT5d15mc7vPNDNT0sqpPSpGrBlcEAKbcAm687/pjmxdy2F6PZMAPneFmDKKfJZ5618xkmpFiBjliXQFBOxVvJ3+kb3/THBmzDKBd'
        'e9kDCXF1kl1ZH2FpJsuqnqqmGRy8iSg9xTwkmoDdfpGn3uT7VpEXDhC5sQ1wAc0ypNPWmoVpv4ej1EZ1rMSwqIiONLg/2vcYqWgCJ/C5g8k5oujDqpp6aMus'
        'lRSJdiY21ktINJQL5e+/N/fm+F7uD5p+/wAzJIsjZDnEVVAlMyw6yHDFqf8Amqp/rvax/ufbjBqNLTP89dapqD2uEbfRFliM1RT0cfykblFji12j7bC4/m+3'
        'uDvhQYGYz1uRezxZBHW9Z6VlSKWrOYwxwaalKeMCNe1UXBX0Mtrm91vsLHGqiYynZKWgTJziIt6qujSwTdiliWerldneEUMrsStwWLBd2UWFzuQLcb4hE3Og'
        '811B2WzdT5JOlrZKDXSdQu1XXVMbMUmbSB7RWA2jtbne/nDEA3piAOp9UjXOaIqmSVrUZlHE9MJqs1iyxC7yMB2EBIBEwGq99gp1W3uBgx5R1uQJh0TP8e6d'
        'qqOKvoZZEzKSZJFBQ1U4UdsizaNRseLXvc+2FDgCLJ3NzNJBlaxijqUWSqmMawp3I2RSwlkJssaqBdSQDe9xbfGvcBIQNuxLR6Vy8SNStVykNG3ykzCBvO6n'
        '0Bh9hzhibwDHrqkaDqRPpoo09RFl9JLUPLEzKtoo5RpjU3+lmuSB+nj7XxQS4wFP6QSVf6SzCv6Z6qo4a6gSGSqpI/ljHMk6sWYlSptYI5vva43x34YtcDlO'
        '3cvF7TDg5mYRbeuEq+v+lc3nhq1/i8U8N+yAPTe1wD4v778c3we4qgRZMcXh3GZMhPZb17lsXYYU1VN2hqemEblSf/ehB53De+xwhoPMqzcfRbEykYOoUqqm'
        'eWOlzVKbUXjk+Uclm+2nhr7DweThzScBFlEYumSTJ4JfLurXTMKefNOn8wFOLraONu97XAb0lvcDzgmicsNN0rMazPmqNMK1N11ksaOTl2ePrI/wxoWjRgOG'
        'dgSSf0xEYeoN3FdZx+GjbwWkXxSy7KqORKbL82ikAIvBQOqupO6sGuNP2/fB+FqOMmOKDe0sOxsCeCEfihk8EdXRRU+aLRykSPNJRmISNb6Dp3FvubYPw1Qw'
        'bcUg7RoAkAHgg0HxFyKakkkqMuzqCrvcGnpQyufFz425xjh6swCI9Vm9oYci4cD6Jl+ustlijlkps2lqUkWT0RPFGQN1Vlv6rHffY4XuXiwhMcbRdBJPBYb4'
        'tU9NRVAAzP5l3cxdyj1IQ3I4NiOfv9sAYYkiYj1THtCmGmCZPkvT/FWmqaeBTlldU9qMRFJ6YmNlHn02Iv8A3F9sOMM4HVK7tCmREHgmP+ouUMEWDLMyj/lM'
        'FUUjMInPvYXI8X5H3xvh36k80px1HZI9lz1T1rBUV8Uc9DmTU8f1JTUp1yseCdZ2H2H64qKJgxC5zjKZImY8gjt1jkkhdqimzilMYARkoHLORySL2v8A7Hzg'
        'dzUGkcU/xlAm8j2Wn/UKkipVTLqTMWcnVIaujNj+gHF/cG+B8O4k5o4rfHU8sMn3C/QfwPfNa7pXOKrMXmo6LM5iY6SrCh2EaBTPocqFIvZSTdrb2sDirGZG'
        '5QvPxFXvaucBfE+oOqqfpbrOv+bSpihkSFoIHgL05VdXFxcrcmxFrb24xKvRfVjKPyu3A4ulh83eHWNiXzf4j9OVFEqmZqxpvXJqgZe23uPAPt7c3vjiZhq4'
        'JtC9ep2hhS0eKfZTpfifSV0lQvarGUhSneRSqsBY6TGoYAi173/XFhhHtA6+6g7tOk4m58p/pbwfEKlVwZJAGZVQzx05ZYxfc6WTkeANr74HwzlvmNLeqNL8'
        'Q+l5xJTTZvMRrDRmpomZBY8rYDf39/tgHD1hcN5qjcdhpgv4hMVnxT6WhDzSZgZ5Vt/IggkMb24srbg/v6eBthBha2gaqO7Qwjb559AVqvxb6RrNE1JK1LK0'
        'YVkmpXMiPfcsSbMLcAWwThK4sRPuk+ZYR3ia6Pa6Sqviv0+rxKlNXtJrHd+WI7ZHuobcn7fthhhKt5hSf2nhxAAPstqvrrKKqm7wmqkIn1RllkWREt4kUixv'
        '76rXIGFGHqgxl+32TnHYZwzZr+hQh8X6HvsrTilkPp+Yn1oLf0swW4/t98Y4R8TEpfmVEmM0eZR2+KWQCI9yeR4479tKcFoSTzsV/ub38jA+Fqk2Cb5hhtrk'
        'SDrnozt6o8ziRVQkwMJ2ZG9gAuk+wJ8bHA7jEf8AH7IjHYOPr+69D8S+mUgip3r6zsXDSiSJjUalBCkSAcC52wThq+uUfxwSjHYWAM/5Wtf8TsjnSSOOsqay'
        'kexTWrKR7qb8r5vzfAbhqo1bBTux+G2PkJSp+IHSuZOnehqyCp0COPaNr8lNrgjbY7Yo3DV2zCk7H4RwEk8F2/wr/wDr2Z1OY5BloSDLyhSYQBdL2JKIZjYt'
        'bfiwG2O2kx1MePrgvIxlWnXd/paBfSup8j6cqJqylzDMpZFmmBgiNPpSqe25Zi9g3uW5sDsMRbiqJE5uSd3Z2KFizmFxGYfDjpaoqqfRPT5bTjUJZK6VQuo7'
        'g6vsNlFv18HB+Lp6z91vluIH6OY/K2p/hz0nmdVSU7/KyNGCZ3pJUZ5U/rQEgX42J3ueMA4qmLl1vdN8sxJsKcn1H5VjLPhZ09SwrHIkVX3gQtOjAOu22ot6'
        'R+gJv4Iwnx2H/wCfIpx2Tjf/AJHiPyma74PdHVDxdunkglViEE4QmZfc6CNPvpN//dfG+Ow5/XyKX5TjR/8AlzCjZp8Pul0oiq1VNRyI4MCtGJpXANiHCtdL'
        'Ak2F/Avc4sMVRJs7kUh7OxQF2ge4Qqb4V9OVdTPSNXQSJSk7sFWSRQdnWIm5vxpBJF97YBxVPUGyn8vr2GWSn8t+HuQ1NJBTSSx087L31pJIpGnjh1aA7LYA'
        'Lq/1alvc+xq2q18lpmFGrhqtA5ajSJ3rbM+icgp6+OhmgpJZY6ZZ5aZwyAxtsrdxiObbEb+4wX4hlKM518lqODq4ie7bMecLydGdDQSws1RAIkjdZMvkqIi4'
        'cj0lXVrc2Nhsbb2xL4ykbieBVx2biBYgfuCmQdG5KIqRWFJUq5IM7VKo6X2ugvZrG1wR+mAcZSE68CnHZmIdpH7gt4Onuh6BqqKtrVarSoChqeVSpG1rgbix'
        'F7g/rbDDFUyNDwQPZlcGJb+5V66PoqFYop56ZytReWRUQySI1yxY6zuTb/xgDFUydvBH5ZXA/T+4KfPlHR0VIYDNTU2YKptEzIiG52J9Vxtv7+wwRiabhIB4'
        'IHs6s06t/cmMu6S6DESStmIrA4AKyKqlZLjUtlJDLa5uCPGAcTTO/gs3s2v/APyf/SYocp6Oyqsp+xUQUbByHeegMsLm5tywuNNjdiCDe+D8TTO/gh8vxA/4'
        '8VUkh6WraaWil6jln+WGuCKCkCgtq3LIWBKL+W/G+xGB8TSF78Fvl+IdF2/uXOVmQ9DVOYColkjkQ2jeBBupt6mBOwubEDce+G+KZGh4LfLK03LeK0kpfhtl'
        'dO9GMxjeqMYk2gUGNtVipYmzgjfbdfbBGIpuGaHcEDgKzTllv7kVsh6InpqKaOGBVikK1AYBlkTwTZvSw2vc2N/thPiqcxfgn+XVo/T+5PZdkHQ1Qiq1TBHm'
        'MMgvSwCN0ABurBi+4A5U7n743xNLLJngh8BXzQMv7lapMt6Rqa9Waavo6lf5gpqaCNUVSDuDr3Dceri/jCHFUQJvwTjs/EExbiufrOlOh6lJZq+elyyvkkYf'
        'Lo6Sw6b7DUG29iCRYna+KfF09hPBL8tr7QP3BWMm6B6AkirY4XSaST/IgUo7AW4Uqx3J+2wwBjaEXJ4FKezMUDZoj1Ci5d8BIZoY0rJafKZJlIDMS0oUbmTQ'
        'NwFP5m2PtuDij6tOkAajgFz0sNWxM9ywutNkeX4WZJRWlnqcuiRU0SySxN63AJ1pfezm3pO4viAxdA2zjmur5diwP9o8vyrGUfCPpGroUEs+XwVc9OoqkamM'
        'nZF7mONlJB8evm1xgDGUP/p9/wAIns7GXikeI/Kqw/D/AKJp5Y3lWniMUhiloXhlVivuTay+6nfb774xxlC8P5FYdmYvbT5j8qRJ0F0XR9LyMI6OuzQTqNfd'
        'ZTMhJLOdQ320gAH3vscY4ylNn/dEdmYjbT5j8rns5+FuR/waSfLqrL8znkZHNCtqXuAt60DObAgceLj2OAMbQJu6PYofK8WJhk+4SFX8IenIaiqipJNULOv8'
        '+qMYanB5GzWNiRdwbW8bjB+No65/v+OSI7Kxh/8AyPEfldZ0LkGUZVHUUFN1GKd2kSEMvZkSQEjW/bLXXSLhXJv5tfDfGUNZ5H8JfleLH6OY/K+R5pTfx2uZ'
        'dEsRh1polpnRY99wxKkAk+b/AKY4GFzBK+hfkrugfYr1FlFJlhVVDrUz2A70ClLfcG4e/gG17YYvc70SCnTYY2+avZhTxUFNLOyoJpHCyhNI13AURRR2/l3P'
        'Ki422IxAOc8gDrzO9dxYykC53XolaWlnpZ9FW8qyowaGOcFFAuQXYDfSLEbbttbDEyJCmxkGCuiizGBm0xSJT1AcOKo05hXTaxFtyAfuLbg845i123RdAcJj'
        'ak66qMCRTpF8tPq0aWgVmb7ED+9zxtfDtkyNiV0WdoVDqqWVGMlRSItJBJ6WiClbk/Vp8G/gfrigcDZpuVzmmQZcLKj0Zn0ydfUdA1UKmCSnlgkMZeYprtpi'
        'Hp3YkX+1r849LDtgF0RyXg9o1JLW6wue6izOfPOuM9qJ6gfMxtCIjENgI006VHuOSPO+DXsW7ro4CHMeDvCbjmWlyyTLOwZ6YDXJPJpIkcm4X7mx+rgXtjig'
        'l2eV6ocACyJW2SyijzCH5Wlp4YbNG9OkIVXBFrg+CPB84z7g5iVmWcMogIlBVAIUim0wJMyvGLLNISPqAPg+Tex4xi07f6RDhsWFj+Wp6rMqfOSl2WJVhGqS'
        'SQfnsVYqLbXBOMdjS1CIl4cpmYXrmZIYJavvf9yKS+5HJ121H7jj2xRtrkwpv8VgJU80sCRRovbjenHYfS+osfc+L/cbHFBMqUCABsQY6GKgrm7Ts0skRuXu'
        'VYe33P3FsNMi6TKGugaoTU+h3LrE42YyJENm8b+f/GDMoEQtoYqeOmWFyDMzHUHUhQOb8Wsfy783wDOvXW9ERoi09LHBMzalBXYMhB0Hybj3H74UmbJwALlV'
        'aWmijeOqJAkR9KuwuwFthtc2O/384mSTZUAGpR4srjr6tTDNECdQkRb6UTwLNvpvbf39sCSBdHKHGxTdPT/KxzRNXrK9SRHJUQNpJAP0lyP9/bbzhTfZombY'
        'ESp/U1SKmvqIhpDOV+YeKYsZeB9IsotYbjfnD0wQ0Hgp1XAugLyxmrqoXNRLPIKqJ2iLqlhrUGw02HHPnfBFotCVwJBIN19U+Ndfms/W9RV07QVFNO8kNExY'
        'KIiXUspjABYhACC17g72ti2MAtmNlwdklwDsgvAXE1WXzRVccUMHzDzBmBCXYEb3BHuBxjzmutJOi98tg6Kh0n0u/UUq5iIZo4NBZZY0WLUV4Avb6W5t48YV'
        '7i3wpmta7x6J6ooRDDNTS0hmeVQk0IVbS3O+5G4Pi9uLYnJF5VnBhsQkX6foRXwQiOClqENgsqqjx/YaQdgPyjx+uH7x0EypikyQAFpW5c0K1FaQaZ6uHZ62'
        'AxsyC4VtJ3H2FuN7YOcyGnYh3Yc0uASFDmZjy6njmVNBVi3cheRCBsrNo4B33PPNsFwOYkHr3RYRkhw+6FkElUF0ZfTCtpjJpqpQqLpA/Otx6m/0+P1w1SP1'
        'GDsSUpB/02yNq6rM8oiy6lmmirJJJqh7TNK4jZ1UWUJqGm+9iNrg7HEWuJgEaLqeA2XA3OqgTwUXyvdb5Fm3eod4yjRqNrM+qwO24AJ4tioLpi/l/hRLWkZj'
        'CHlgWuMtJHTxRwelkWdXLKrfTyB6jsRo3scZ0tgnX264pqUPlsCPOVNzvPfl5ZIFoKyrnk/w5eKP1mNbEyOWtpsQAPNgeMVZTkTIC5qmIFOwYXHSyp5FUtnP'
        'Zq675mExOfRK6Ri9jcHwWNhwC3FhibwGSGwqU5rQ4gr2dTyZc1FHXxx5VI8Sv8vUSIZYUJI9aJcgb3Cn1EbnCtEzluqlxEB9ihyR11ZWiFGXQG1iaSK+pL7E'
        '35v4A33GEGUCeuuSfxF0BdR8OI4qj4q0GgIKZcuqS8rwtqQlkCkqDqXfYW4v7Xx6WDmHSvn+2ABkjzU34g9MJUdZZ3M6xTSL8stRMrD0N29V0C8sLgk3vze4'
        'wcQ/K5onf0VHs5gex58wuarpIUqpRUztIrIVniLIVcEW1LsrBreN8QbpYL0XRME2VGjy+koaDUVjPyn+JgUO6yS6SP5Ybg3uPqG2FMuJ81Roa1ogaI3VtLRS'
        '5VmNVVSWSIk1LSPEDAx37em9lsdgRzhaRdmAb7apqwbkc550XPHqemyOqRZYDTVUVMplp0XuGBXUFG9F/SRZg33ti5pueLafdc4rMp2O5K5dVw59USZflslR'
        'WSyKX/lxt3Tf6msQLH/Ye+GcCwZnCErXtqHIwyUekdXaSWKGZeyexqVL3I5uBvb9fOFdIsT5qrQDoDZeq6WNQlTLUxUsCAmWQMQQeBe+674wOyJWewA5iYC1'
        'zChGiyM8NaLK8bRgeNnB+kKRbY777YLTv0QcyR4dUmI2pqSddK6g6sztJc6h+YHYX8fbBnMRCTLkaVQhoou7F/OWIGMM8c8e5Pm3uPN9jbCE2VcokXRaWukj'
        'WoL1EVbT93ud2EduQLawtxf7W9tjgECRaErSbyZCLU1RqpBLTv8ANSSntR1IZS6r+YMSQdvAsP8AzgAACDZFxm7bp6kz+GYwCYyxOYg8LCHVFcAjcgG24/vz'
        'ibmm8f2qtc0wEKpijzNQ1dIahkXQHnUOxa9+QLFhew84IcW/SgWh31J2gookrIqqEEiOQRszqbBw4uOLHb7834xpNgUMrbkbj9l1/wAUM3y6r69pY5/RTxrI'
        'kDUSr6pNS6/qJspJADHgi3GOvHSWy3YvJ7Hyg5XbVCrOmpg04zChemidyYqiRHZnH9KgEKzD34tffHmB+mU/ZfRmmSYI90xTQVdDS0700QFRISJaZJwY2QfS'
        '5vsT+g87YHhJ1ssczWy0XRc4jbMaOjXNjG9HDUIz07SKI9f0pc6v5hVjst7XsbXwzHEE5NY69FOpTa8DOLAqdFp7jJLKmXF6ibs0ckwic6DuzbjfkXaw32vg'
        'ESJF9Lp2kT4jCHW5iJ1KVWYTPDpJknNQrtAOdJck29x5PGMGwbD+0xfIgmyXqJYflI6yjWWSlYskz1sZZ3I2spQ2O3jkfrggXLTr5f2gT4Q5unn/AEr2WwVG'
        'bfLI1JFlo0EQsH+hefo2UX5uSb+d8ScQCYMqzJgWhQ+talqGsWSpqZYI51aFNKR6DoAJAVuOSxaxuW52x00QXCw09VxYgtY7xGJQctd40ZIayb5vt92E6A5N'
        'iPq9h/zbGcBqRZGm46NddM5/KCkgasrJaqaZT2pEAu5Fy2oHYg8WG3m2BTAmQBZUrEgXJMr1RmtG3zS1EnzFWagSyzGezy2X1lzbySRcb824Jxods0WLmAHM'
        'bqTVfKS1QqZquKVSQfk4onjgp1HAD3ux4uQN9t8OAQ2APdRLmkkk23I/ROURyU1RU0VMSpq7RiWpDSy3BJdpAPSF4s29mFr4Fc3Acdm5NhWwCQLTrKqVlFma'
        'ZwFpKaQo6ALLEwdISbggX2BAvyOd/tjnGUtuV3HOHwBZG6Hyasj+I1J8gtYUTLqotVxsint6kBLayRpJPJ9QvceMelg3SHey+a7YEOpz5qRJSQ19d1JBNXRU'
        'tbNUhU7ktkde2OD+Zbj9eMHEkte21lPs5manUveQpkOWz5gJpIYxUNTsI5mkj1dp7bbi9xYfUP8AfEcwGq9HKXkwJhEr6nNKWgiiyp6XLaph8pJU10hc06Ec'
        'xC3JB+x3t98ZoYTL5I1t/KFTvcsU4B0JOz0WmX5WtCzUFW8ec5bJTGKo70Cq09xuq2IIbggk2PBN8HvJh4sZW7owWOOYRdGmkq6TKssoisi0rRJHRyQRAaUU'
        'elWdfUdO3pLXX7jG8JcSmEsAbCBmTNmMlS9TM9YkMSvK1Q/cdQBv6Cx9F/Kki/gYAMRHXumcJJJvCJHUQSlWpaq/ej0uWDROB7fce1sLcahVBafpKXF0gSGW'
        'nglhWR40aIklVcWPcts4H3uV5GK66KBERmCVqHSF4wEUG4Qm/cjYcAg+VA874IlAkCIS7vBC9QJ5dy9+3MnbHsApNwQR5/4wRJiFOQCQ5NGnRSJY6mnqBIoL'
        'GaRhID4AUXZrfsv3ws7x117py2DbasVGUxVsbTRqryxWXtxxIdZ/rI1BbnyAbYwfBgoOpZhmC1gyiMvR5mtDDUxwEfMPJGpRCDvF22uBceDf9cHNYtmOtZS9'
        '2CQ6J3/4TdOlBlcsjUsEMFG5dkpqcleyDwovcg+99j+mEdL/AKtU7Q2n9IgbgiVOZw/w5BFGyCYljCXVpiPsF3O+/A3xgw5lnVRlVzIM0hyynjWoLTMx1Xd2'
        'HZjdhqJF9v3ucIRLrJ2uytg+f2VD4n51QU3U1fFLXRoDRoGeoEYkC9wHlFCszABr2uecduJaXERdeR2W5rA4kxYKTU1EtW8dSoaQShXirFjJCC/PJIB/pNvN'
        '8ea2BbkvoHOJIdzVKslMMPzUtXA9O5UK8Ts7Ox2NlsEUAX3BFhwMI0TYC/Xui90HxXC0rcilpqespKoPSLLGyLTxErqiksVspBut1Bv4vtjB8kOHULGmS0tK'
        'Zy2GqaBGhoo5I5AzShJtChlUXLgAgi9tyfbCujaevJVZmgEBLVEEFdW09ZPAMyWlQx6XISi7usNqkWweVl/+IIHBFxhwcoLQYnj7bkhYHuDiJjh770xm1fD0'
        '/UpVSwjMe6wef5U6RHrO0ojtYg3HoAuBiTWl/hBj1+39qz6gpQ4iRN4+8JiPTemkpzOYo5XBeop/5b6tgpJ3Co3q9FiSN9sCdQYk9c/NMbwWk2UaGOCd4K2W'
        'sppJ6GduzOKhZ5lfVfQgG9ibbWt443xYuP07D7BQytd4pEj3Kow5aaiesqWrHjhdRUTrUpaJzf8AMw21jnTiZcIyxfRXax2YuBjbdT6vpmGvL/NLUSUk2xSL'
        'Uwmb8t4l5v4ud+Tijapb9OvW1Sfhw+cwMFJTdLtBQU0ApKpiw7ZYMIiU1EiIgg3Xxfx74cVPFMjraouoQ0AAqdmFVljaTLqEYS/aKgsrA29SgG1vIO1uL4YZ'
        'xolcKJ1VPK8+iy6JIYKpYBPEzu0dTHApG4VSrWaQEm5sNgPsMSe0mSdnv/QXTTe0ANbt9P8AKq5PVVC5TETUNOYouzPUwJplVPK3va4B55I83xF+UugbVdmY'
        'MvdLdMVi0HXNNBSwRGOWjliFbUorGMdxSCI1+km1gDf6t/t6mEuHX3L5ntb6me6g5utZUdc9SJTFfmTKJGp5j6nRlGmQBbFgCOVP7WxTEw0tzaKPZ0lrgzXc'
        'nKfpuFZ6xZwaSd4ir1MhO9xckC/I5APi2OI1NIuvYbSiZ13pEUtLS0/8PoKdEWRO3JNLIVWVgPrLgEknn1foNsUzEnM49dblEtDW5GBI5TmBaieljaSZIacz'
        'dh1RZHUHcpqPrTz6Tt7DDPbcO8+vdJTeQ0tGwe6v08ks2VxMaAs7gMr0umUOxG1yDcX/AKuPBxJwAJuuprnZQY/lAy9MxhzAfOU2YfMqQXhqwsaKvnYLpH2I'
        'OC6CLQtTLs0kH3WKyiqaqoqIo0WMyOWWeqawUHjfYX9tueMYQLlZ8kkALR8qrZ6oRy02qtpTofSCh1W32vcFha9tvY4bMAPIqZa5xE6hM0vSq06QmauSOolJ'
        'aWHShjvfbt76ma32HGFdUmYCo2jkuXXSM2S0tC0six1DVjSallDm6+N0sdIA3tY4bMXWmyQ0g0kwZWrUBhq1kkpxIZk0B9ZRpPcg+3n2t4GMDaJRy3khLS06'
        'UU4pZ2p0ZY+5p1Bt78EH07+B/vhgZGYKZGU5XIQoMu70EkvaieGXWjOnqcf/ABJBAvwbfrjZnQYSljCROxV5MpWTWUoqisZ2sEaEbr7ghiCPBA9t9sTzRthX'
        'yg6tlBoMqyqWurKFI447EN8otoSRbfUy/Ub8qTYY2Z4AdKUU6ReWx7JoZVLDLQ1E9ADRQ1Cf4RnX0LrBvcEAEHwbjf8AXDsO4qdRkAyNitZ1CuWdUZz/AAyp'
        'SnNes2lqukWd6dTJe6MpIDb2DDbkcDHRjIMF2/evP7JzQ5rdSNylUGUT0kTQV1bC7KoYt3Fd15ssgO1xzY+D+mPMc9pMtC99lN7QQ8qrl8pqI46ekhj+acGS'
        'R6WUoungFrX2J202/tibiBcm3mqNaTZoW0y1i0jRqDJV05MUjST6YwuoMqpKbltO+335wczSZm3WxLldEASQvVz5xVQPFJWIixIG+YeF0MCjkr6AoPi4548Y'
        'ALNRt5qhzxG5KKIsvFSXqWikqQmqfvh3kRd7MoHP+rcgc4ac0Dd10FKzSSdVrR5zltLUS1Ac1PfWxpquQuur3vYFfbx4tvglriACix7ASQUXL6yR5lqmggh+'
        'ansIo3mWmXSBdQXkOq/FxYH8xxnEaTp6Ss0H6iNfVI5T+GildKaanrswmkklETGjVrpc+1hvbexO45x9ESTaF8E2GGZg+quVv4MMzmmqY6uuzOajUnRaobSS'
        'OHIPIt72t98OGltw0cEhq5xBeeKnZH+GmrqYr0vUNe0DMUppoql+2SDYq2+17WB8+bYQtDrlo4KorVKZyioRHmlKr8N9ZplllzXNXzATCGJpp2X1nhRc8++9'
        'vvjBoFgBHoh31QnNnJPqk80+BVRlZaMS1cdUCsciGqezN/XqBHoHm+/tjZRoRyS967UOPFS5PgnB25Xkmcz7dqcSHSN7HVe+3kb+MGdiEuN5urqfhyq8ulip'
        'JczrJo5UvPNTTNpUDgsoO4J4t43tgFg1ICLaz4yhx4rqvh58AqvJs5arpEM+Zdju061RfUYtW8kbXtsdjudj+uDc2CGcauPNdzn/AOFym+JslNnVSk5zV1MJ'
        'ghr9DwlNihcA6iOb8W2xhMQEhc0GZXy3OvwvdQ5GMwgWuMsVNNonpFzPW6HxcX832PnzbAyAn6RPoqCs4WzmD5lP5f8AhiSuihWs6iq0ikXStPSStJJCTyZF'
        'vewOxA/YnGDRrA4LGq4CC48UtD+DuphU1EkldLDqvHpLudP2N+Tzb253w/i3clPM2fq5oFR+EWbL6io0rm81LIU+SkhjlQS3+rUPykH38YBzHZyQFRo0dHuo'
        '0/4b63LaipgeozBJYEZ2W8g4F7c8kcD2++2BrbLyT5zqHnig03wGhqqWnOaVNfl8Lxdx2Ez1IuT+ZDYqP0vvgaaDknzOIguPFVqH8M+WZllq1eVdR1dXKJTF'
        'NRdxkljNudzZlItuOPbDAF2xKXZdp4rYfhUpxOsqtV14jI76JUMXa4Fu2+nkXDXO1ttrYXNNkYGpW+ZfhUWCsFM2ZzMJx24WSv0yRH8rOgY+k8H2wZiNFgCZ'
        '14lSKT8MxizUUFRV1zGF2jqnim1dplFyLauRtzbn32w2a0wEoBmATxK6d/wlU8OXvVzT5hPRqndkUVV2ZOSVBO5A3t5tYHCZxNoT5SN/NPD8HNP1A4renM6q'
        '66min+Xkmqqko5AsdkYXIIO1ri4PgYAcIgws7MDt5qR1J+GaDI6eozCkr8zq6Ok2iliqXgZ5NWkogNiCL8+QCdhvgHLGg5JgahNieJW1J+FT+JzxfLZvW1EL'
        'hZWDVmlwWtcEeDfz+5wZGoAWJeNSeat5X+F7orMDEI8xzVqnvsA1XmywRHtOAbaxZ7kWtt9r3xg47gsZ2k81X+L/AMNI+uc0+WmSKHOaOGSVDlrxx/y7/RIy'
        'OFPuEXcDGBIW8xZfN4vw3U+aRzpl9XXQvGFaWOWoWyMRufZlBHN/IxpBuQjDmixPNXZ/wuR0sQabM8xp0kphUIy1yhWfhgHU+rg7Dc3+xwsN3BPnqR9R5rz/'
        'AIacjnNLDF1DmsNdNSNOMuq61R61O6o97Ei+wPPOCI3BKTU2uPEqo34YaOCjy7+LdYZnUGp2aky7ODUPAbGzNGL6gLWsDe5thcrBcAcAmz1zYudHqVOm/CbU'
        'ZZUUEUecVsKy+p5Ya65pweA334O3vfgYJyO1AKAfVbo4j3Qo/wAJVRU9Q5jRtm9XPXU6rIsstbqM6twAbi5HkX9vfB8IEACEmZ5OYuM+6nZt+HaXJolpc3et'
        'pppQzrG0jkOo5LMdlA8nfGgAyAiXvcIc48Vv1v8AE7Oc7+ItWaaSWnpstpIaeGnLNKslwXeVhf1sx88+2IVhLWyvQwJhziBuUyXqLNK6mdZcwrIGk3dIXVUC'
        '+2k+P33xxw0H/K9rM52v2C8md5hKRC+c1biJfSYl9Y8AAFgt/F8GBGnNAPcDY39AtXzKrmp4FNfUwTxsxbtSrIXHg7gqreDosMYNAOn3TFznCSY9giS5nmsT'
        'xmLOKyNJ9RjNRC8yystrqHAI1D7gAe+CANo5pCXTAPJCOb1EaMtR1HUS1Ez7wtES1/sCCP13xiAdG80ucssXclSy/qPNYK6nNBWLXknTHTzqQ7ycEenTq283'
        'vhSBF7Js7pkQ71CWrOv+oKmqesmMFBA3/YpKYKpANvQAx3vz7+cNkGkk+6UVnuuWgD0Cl1PW2aUVHJFStNUKGEqxGYUxW/JuFBPPB4J2OMKYJufui6u4CzQf'
        'YLYdRZpmNOENRFSoE1BYY1WRv6tTkG9uT74wYGnf7p+9e/cPYIi59nFHK9RT5sYCy6CCANa34C6bEX3tfbGytjRYPqDbyCpUfU2dS1X8Pqc0emkCGXVoUOoA'
        'vuwXYn3xI02gZgOZVm1ahdlcRwH4VCXrfqPLzQS02e6CztCXmiGmZDw6gfS3uQACLE4VrGmQZ4lVdVcMsR+0fhIVfWdbJUhK2SKV1Ys0iiO6tblhaxv/AHG1'
        '8EU9onmgaxmCBwCSret807kQiq5YIgC1ou19d+DdLg+/98UFMRf+VJ1V0wI4D8IkXW2e5TBrCxys7/SYYtQP2utre9/1wAxp0J4lDvHtglo4Bdn1h1jnUXX+'
        'fpFUSZOtC0FNDTtKqNSnQSxUb6A7E3sCCQBxi+IDXZZXkdnOc1r4O0KRP1XmvzIavzKZJ9RBp6aYF5dt2uiLa33845Mrf0r2M7p8R+yBJ1ZLTWpo81raql7n'
        'cZpZnAJOwNm8355+2GyTchHvC2wcpVdmubSK3czKZpUbUH9Ngf6Rbx4vz55wwaydErqlSPqPJGgfMXpTTQ53UZRM1njnZhURqSeCrWIvvYg7nnGlsyWzyQio'
        'RDXlp4prK5uoqKoqqTMOop63RZ1TR8oO9bYuWUlv1HO29jhH92YLWxzT0+/BLX1J9oTTy581cCamWlkeMSPUQQRDu7bWNiLkXvvvbxhfBH+VT/VnX7IEnVfU'
        'eXVi0q1809NOhnCJRwl00EBvyebjnk84IYxwJjmUj61VjgCZ9gmKXrvN4bCWtlhDfzSrlRJTFdrMALMeD7jgEjDd2Dp/lL3ztv8ACWlzvOJZJJYuoS9UTqjW'
        'qUCJvOjVbYkbg7W9jjBrdoWzvuWuRmzrPoqFZKfNJJJ6cMYIm0RoXJBIIC2Ww3NudiLYAayYiyLqlUN1k+y2q87zPN8lrGhzZmp2YwFJtDOsosdha6fa3I3v'
        '4xgxrXCQkNR72mHLSKqzIUMKVGfSVZkGo1EEypGP6QNK6mN7eo2+4wxDZsFmmpF3Sl//AFpn0PzMEtdUJG/pcKQqyvtuBay3+1r8YbKNiQPM3QZur82NQImr'
        'qiOJAO3/ADQ4VuTpBFrge/8A4GAGNiU3eOBgFfT/AIYdWZpncGa0lZFT5isIgl707tAsbNCS6LEpPJVCbW3JvttjtotGQR5+a8LHPPfQdw2L4ZmPTEz9R5pX'
        'I6CKOeCGohjYGH6C1tK2I/0tsNrYaq+IbCGCplxc4HchhJ0qQIJJZnuAvaDKY/8A3X2Fh+t8c1okr1gDMA3TDNVKmiOQTq8ihowWRSF4Ym29ubWwsA62VPEN'
        'LoMtW3z3Zmq3aeom0qwkDK7W2UsfSlxwCcMGmJiwSOeAcpNyqFNT1QptBDaXUqO1G8ciIG3VixKkXv8ATbfCHLKeXgIiUy1uW0svy8vzETyK1S+ghkHG2wVv'
        '/d+2NJaSNiOXOwGL+yw0aKrtU1NTGkzXjk+U7vcH9JKtt+wtjTOkcUIjUngl5aNqJUeJBHTa7mPToRWP9IJ2v9thbBBDtdUhbku3RC0RvY6oTPKgdNG8qx3s'
        'HW+2/ABG5wUZB9SlpsuaDssZ1jVogyzTi/csxBtbYG+x4tg5vJAsiLrzQSsyiKVo0YXkhuCZB4sp8/8A6cYHegWmbFHSQwJRzCQP3ohKZKedZGQm40y29SOA'
        'LFDuAcYt1669UwJsd61hnSN1LMrsG4UaTb+gN5v7EYBFkwN5Ko1ueU1Ll1ExhWOCRmWnnMigqRyGBW62N/tfbjE20ySb3Gqs+s1oBix0P5QhSCpyqXtSH5tX'
        'MrG6EuLbsL8MBsdyCD9sAmHX0ThmZljdSHnZo2igVKiJdIX1jnkr5P8Aexvxti2XeoB0mBovovWGSxU/UfUGZTLC8s7RRpKsis7AhpDsL22ZQWOxOww1cklr'
        'ZXlYFvhe8jcFycEsSRXlqQhkICrN6AD4UMbm367YkQTovRDg0XK9IzSyRwTUtRP2u8f5f850st9SqL+lACT4HN9sMBtH46lK54BAcEwtIJ6cT6bTVF3WSFVB'
        'LHlmtYfcnn7YSbxuVYETtKLTUdPZWmCmnYCN/XcFj6QzHwL835HGBJ0CYAC5Vfp+mlzOszGgzaupVzimtqAqFV2AH8uRA3+YgFht+h3xJ8ABzBbrmr0ZcSyq'
        'fEOuCxU5dSRLTwQ1JVWbthCAFW5ux1ni532HvxtgBxNyEzmtFgUWOpoalMxp5Z56SupDC4hqpdbVKE2Yxk/5mnyOedrYIBsdh5fhAubdtwRzSVFFFS5q3z7V'
        'GSSzKpoKsaJIZVv6mJUna/j9RsbYofE3w33rmbZxzjLuOqFk+RSOrGaJRKXleNexplqVB9Ju7WjvvYadXBwziNAf6/KWm0xmcPyVtPluY0lFNUU1PPLNG5mq'
        'IYnAJjtYMkguD9wRvbCgtJgpyHhsgJGtzuO1JGY45SDpNPqEUhXix2Nmudr7H3uRhgzUpXVNAt5srnpsxqqIU38wsdEayhCXG3qVhcEj8p3GMCIBlDKRMBKS'
        '0v8AhUFfTGSJvqR5CpjcHawvuRa4w838JSZbeMJeOimp9TRQs8jr3JREyxo2/LA7MfsOecAuzalMGlugX1r4R0DTSZtLRTwioWsRWm+YGjsGmBbStgxAbZls'
        'bHj3x1UB/p3XiY8/6x9AvlGd5XNRdb5ss9P8vUhkgdGvqj0sbg2O4v8AqSdxg1TYI4EXdG1CdZ6SWSmaAOjK2orLcsGBuL8AH9j4xzgg3XqnOCWwswK0MIha'
        'lYSFAYnaY6Y0H5WXhh4G4PjfCmCZlMyQMsIs8VD2eyaeojStZVMMTgR1JG7Jdhs9vItjNzazpy/pZ7WNgaTwKYpelKWXPZ5Mn7kgkUMklQypKkdvWhu1jbg2'
        've2MXnKA5YUmh+ZizPk83zsyPO8lMY91p4GbtsN1kdWKgrba4vxgBwjzTuY6dbLFPRwilinpVerD3JZIjGTtuQGa9vuOcYk6FZoAEgShqkNJXo0m07eqNp4i'
        'NW1tNmvsRtpvvjXIt11vQBAd4tVvFS01U1W0cdOESHuyIqCYQIhsLMQGABPi5W/GMcwA/wASqQwzp90vFl0M0zKslOslQLhKcixAF9vN/e/OMXFLlCxT0c1Q'
        'iutO0k12MaRsrs5A3KhiCNuebcYxIFpWEnUXSkVFUNFKmYgwAESPJAhkL/bTsdQBH28YOYT4Uga4A5xCagyqEVrCSaSNpYTDNTmo0kScBVKbN6bG4IKt6cDP'
        'a32/On86o92CbnZBv9oXoMhhpBDT00CUccOqOMzHSukm5DMb2Zjzq8nnGc8ukkzKoykKYDWiAi0+VxUVSO2KRaOCqVZaZKpUmRyL6gh2KcgWOn9MTLi4XmSN'
        '3V07WhrobEA6Tf8Awg1WWNRxA65JzUOyWSE2Sx2HpYgKQR+uGz5vZNkyG+3yXQZ40dR1lnNO2YVb0hqUJWX0h1Ee+9ub7Bjzz4x0V9QQNi8Ts+7HAnapMtDP'
        'SZpP3RTGlkkLLGsv8yEEcD+rbc87YjIy2XflcHX0TyZO80cPzTgwVIZKZaNmDLGdm16PUdQBFvbm4wuaD4dfNU7vOPHodITD5UklRE8NahgeRRULKWCIo21K'
        'AtwRt4sf2tgCwiPRMR4gQbKzN01SR1FBK5pqqllLP/iJWAj0Na8iWF3AsQLEWNxxiIc68W6+y6XU2mLSEbNctiTMgplenzDS0NJV0arK0JPlg1gyMQL8fscB'
        'tx5bUXgZp0Ow7lHj1dNUEDZhDIxd2QnMYiGqDf8AmMqqS2m/LDbjnFIzm3JSnI3xc0tXZvl2fTzQJSRNSAK0dLTagYXHMole1r3N73H2wQ1zIO3q0IOeypLd'
        'R1tWailpI8mo6rJ5l+Z7Momp3VJEkYvZEiYG7XAJdtgDpte18aTmh/49z/CBaModTI+6BLnmYp8tLmMVMjI3+XBIyGYAXaVdV1Zk+kqTbfbc4YBtw3ry90hf'
        'UsXgI9RmlNDWvIUWCoEWpGSoaPbzqJHpG4P63GAASP6TlwBn+UlHm8Zq0lp2jd4I0WMwFDEwHq16jcuSfy7C2Hy2gqWcZswRc4/+qRxPJJHSMpaR4YU0xM/I'
        '0lbkXubA7X874zbFaoC8C61WNowHeZ3CxFTHKquiah+YEX1j7cYxITQdSV6WeOooaVY0gSrBYyTASNJMvK6luV9Pi1r+cLF/JGbADVdn0EYsvrM2RI5q2jLQ'
        'PAZbd5jJT3J5sG5sL7m3nHdR/wBsH1XgY7/eI8guFr548s6jzuOjFRAI2jAlT+YVQruGIJ873BOErjNllVwJyh/spdFmEb1o7SNI5DC6xBDL/UAGIub/AH54'
        'xEtML0mPBNkKmq56mujhgmMM0hKiFH9TWHB8frffBLQBJQa8l0ApmqpJKqFfmFaYOd1kJOhR4tey2O/jfCNMaKjwXfVdMZbHXGeoZWjnncqEeoH+Rbkhvcjj'
        'z53wSRAB/wAoMDpJCw9KKnNYppJp4IS7RMrOW7ynlfZhe3jGBgQsWy6ZVGSpjLKtTJSCClb1S61UA8AujerbxpFz7YSIFtvVlWRtiAvV0M1TTCnp6dXrTJu8'
        '6FZrHjUWt6POwuNrnGFrnTks7xCGi6HFCtNTikNRI1muqyKG7p8/zDvYH8n/ADjEyZhZrctpSFbCsctUEWMPqBTuRnVcbXLn0gg+D/fBGxKdTohUOZ11C6zR'
        'a3KjRIzmOVyf9DWNtt8EgOEFAOc0yj1FZHMokndZkmF3dHMRMfBu9ja3FiMKBBtsTkhwudU4tNlzwxR0UNPH2bKiVMwChf8AS2y/8HfEpdJLir5aeUCmBZOx'
        '5k9HHUwSNR3ZrM0kepEttpQ6rC55Jv7g42UGCEe8IkWUKurZazMHcmNw6LZ1AlswNvQ5UEKfNv8Am+LtaGtXK95c8lGpI6OkoQ1REZxMpYnYBwDy3sg9ucIZ'
        'JsuhuVoE6qz1DDS0fXvU6JST00cckaw6E7cRBW51Ri+nUSTybY6a98q8TAQM0+SBVBGyiWBKgmKohZJO0n0E29V7ek7cryDY45ROady9V8FpG9aQZWaqkSaW'
        'aXLpAylaiQtHrYW09srvfYbe+97YxdBsJWa0ObcwuhE2YOqpV1M9USRKSCNTN/U2gbn/AJPOI+HYurxQA4qjXZ1VVs81LAZJneOPXMx7L6rklQB9RIuLkg74'
        'RrQLn8p6jy7whc/WxVsFTUmTRMHRB2iWj7YF/Sx0m22xUXO17i+LCCAudxcHFTZmaSteqqWqHdogmqd9Kjb0AauFHsLDFBpCnHizFeljmosnlqZaia3cETvM'
        'FcSA7cFQFXlduB/fGEF0AImQwklN0Es9XPHFKgikRCtP/DkUyawbBSnAB41IdvIOFMAH+evunaZgHZuTGZVklUzPoVZjIsaisg0qNI+kKdtIN9hvfc3OMABb'
        '7IOM3jigZpT07KHlMDO28yQtpMQ40lWuTceBcc3N8YeSzgCLqJKkPeQU8Mbqw0KukEMWawAUWtbxioO9QIE+FZzhp8oMojeOTRL2UkQ6NT35X7c+PGA0B2qF'
        'Rxpi3ohVET11GXWWVBFE4lkgIV2XVezMeT7X3OGFjCDhLZngsZesgjCr3zAqghZ5PUP19v0H/GAUGGy+jfD/ALVfk+c0nZmAaWF/mhE0hD9t10AqR2wQbsSC'
        'QLWtzjqpWbdeTi71p8guK6l6D62k6rWTKZsnSSuRXaCpYo1l4c6V0g28A/axxd7GuHi2Lio130icm1SsxyLrzLaZxUUmSyWN41WJ5AWHsxt/vxfEhRYTqV2f'
        'G1Rq0LmJejOsNUMhUUDvIZiIxIEDngLvp0j3G3jFwG7brk715MiyrtlfW6CSnqoIYiIxKuikf1D8t1LC3Jt+uJd0waLoGMqmxATiUfX9KtNI+mopFDJHFJTH'
        't2PsNXpt4IN8TNKmZ3qjcZWbeJQqp+tJUKSZfl1/LNTuCB4J3/e/jDCgzeUHY+qf0hehp+uKsCEQZRUSxsA9qMuyjwL6gd+PF8HuGDel+NqnYOClVtd1pm1F'
        'LSRNR0kJkIlNJA/cPjSXLE/b9rYZtFjTmSOxtZwyiB6K/SdLfEyaBnGXwVMEWlJpzRuy34XUb8n25xE0Wa3Vm46sI0WmZ1PX+WrPBmEOW5dbSxo5YXBbewbQ'
        'GJJPkG3jGGHZrdMe0a24cEtPT9b17F5aWkpJnW9qTLCbb8bt++GFFgtfipnHVnbh6BDp/h91ytXSUkNW9RUVYaZF+R1iRV+pyb3sPe2GLKZ/SpjFVmj6lvUd'
        'GdZGqiaLLgKhg0EeqOR4jfZhbksfHnwMAU2iyY4p5M2lPN0l19047LW5VGlSEsxeOR0AHgkfSQNyDa3BwrqLTvhVZjXgaBR6el6qr6uIQx0UuqQEGSGQRk+7'
        'e48Ww3dMjakONqbgu1Pw1+JQyyep+X6Yp6U/zJauQyGOM+DexAvwPcjC9wzeVT5jV0yhe+IlL1MOoZK3pxGWlqZI5BTTxMFLoukerhtjvt9rYo6myoZcuali'
        'alAEMi5XL183Xq1VdJHlVBFZy81NTxPJ2Xt6v0vzb9sIMPTtJKqe0K0mGhCafrSjoafRLAzyEzIqQsxQA3vpJ2HsP1tg9xTJvKUY+uBaE3WZj11X1BzSCXL6'
        'dhGNTQU5jjmH2UHcnyBwR4wgw1IDKZTntHEudmEcEWn/APXsUOs5Hk9dBVMG0TUjyNe29yzXH33tjfDs3nkm+ZVv+DT7ItaOv5TRRS5fDTM95f8ADxSXZRwx'
        'UMLAeLc/fGGGpjaUXdo13RYJM9G9ZjqWCo0S1+YGPtoJ4HeNlY7RlNx+3I5vh+6Zly6BR+Lq953pMnkna2n69WEGbK6CSljfeF0klCupt5I3H/7fExQZvPJX'
        'OPraFreazAnxHokhpqXLaCokcntSxxETPfcA+CLXsfba+D8NTdckoDtKs0WaEGPpT4j1kkU9PQ5XA7I0zR1VS5lQg3a4IuGuL8X2+18N8OzafskOPqkyGjmt'
        's4yvr6iqoFqYMtkkp2WURIpeNmtcDSSLj7e+MKDL6rHH1TBgKDUZV1bXzzVNZRrFG7HXJTQGNYh+bTp2H6DFBSa0ABSdi6jiS4D2RJOlOsRRAxQQzUjMk9N8'
        '3CXMXsVe+pbj9cbu2zdA4mpEQCNk7FsMm6yj7UcMFMsr7iOMu6m2+/252/U4wpM2pjjKsWATVXP1lPD2IMsyqGGVwwRYy5Q8bOfUBtffCjD0xckoux9bQNC7'
        '34e9VjpuhFHmsOY1GdmqM7VPyQ+Xi1R6FiClrMv5tRHuMUawNs3Rc9Suapl+vJdhH+IJ5aWakGUU8LFkkSIQR2VgLJZiTbgci98eYa9cXkcF9J8twu537lH/'
        'AOt0s2Y1dfV5HDJNUkAlYI1CECx0WPn383N9sN39XeOCT5fh9zuIXpvjPBJHT0L9MU7RLIdJ0guL7EWLFXtzpI/4GH7+rEiOaT5dh836uIWa341ZfTtURzZb'
        'llWZ5i6PUUETSagLXLKQQPa/HjERXxDhYDguh3Z2BZ9RdxC0pvi9ARJHHkdPT1lZCUPylMIyQCBqQEsoceCBqtc4Y4ivB+nglHZuDkAZ+ISNR1xR08Yaoyqa'
        'dKq67tGWZlG4DXG7Dc35tfa2FGIqn/jwKZ3Z2Gbfx8WoSfEN8wzaOWPIGWeWMQuwVEMkQUAIZNW91H1cn7Yc4moBJLeBUx2bh3GGh/EJub4rU1BURGDp2mWn'
        'il0vDTSRvARbfWfVrtyLNt4tvjCtUcLxwKB7PoN1zcQmOpfi5S5pBBTQyVXyFNM0oghEcUSsRa9lNiSOTvbnDmvWOoHNSGBwrfpLjwSNN8QKCrpqqily1Yld'
        'RrEskb61J2vvyff9MA1agvbmnGCwzzfNxCr5f8S8vy3MknqcupquaIqggWFPUoFlVvVZW9rG4/3wnf1dw5p/l2Ei7ncQqlJ8asvaGt/hvR8ccWsQxmWJlldi'
        'Lsqky+lByTb9BgnEVRAOXmlHZuEdJBfb0Qqj4+vRUwhbp6lhqDawWBfSBxZy39jb9MMK1U6ZeBSOwGEbrn4j8KLUfHauru/SwZWsOXyraSkKIwduTcEfm/pv'
        'byeMP3tQakKYwWG2B3EJ3JvxGV+RLRS/K0tK1JeWOJ6GOSml8anYEE7bX2022xjWqzYArDA4SDmLgqVV+KPMupKGCOGnyqoiknErikhRoSF4Uh2uT7Djze+A'
        'atUHxAc1m4HCESxzj7hJy/G/Lc5zeQZvSNRRNEIlliojIkek3HbTugAE8vYm/HjANWrEgAoDB4QWc5w4JNfiiErKoZRlqsSuoy9sICOAWLnZxckHnfDd/UAv'
        'AW+BwzjbMeSgjq2qoooGHT87oLGR1ezAgmxG1r/fxgCq47QicHRH6Xck7lXxHqaCWOWl6dUKhZga9TGhJ5I2tv8A2OD3zwbkfdD4GiRo7kEam+KlXS0qzT5R'
        'l6duo0xRVGkmQsbmMFSECD/WQPbA76pNo4FP8Dh4lwcPcJrMfjFm06SrJkwhrXlWfuQ+mQOONTEldI45Fxtgd84jULfA0A6QHclYpfxFVsEUElV07lNMASjP'
        'FEsjITsSFD3F/tbfxh/iKmyOCT4Ch+rNxCX6M+JmT9SZ/XZJWUK5ZTmlasou1LJD33RvVC4BbTsbrbjcHnFWOLgS5efiKTaTwGEwd6sVtZlnSVZEZsyhpJHe'
        'ZnaJzUTwwiPVp7ZN0ka+lUYk6QW2wK9R9KnnaJKbBUG4mt3bnQIJn0UKt+NeV00ECUeUCaFJBOs+Y08DMBb+lfPm2vnxzjm+IrToF6/yzDkSXOPBKL8Tcuq6'
        'WZKiCWkSVv50mlGbU51XDMCyg8nTxxhDiK+yOCoOzcJqc3FGm6xpnzKiFTT1c0NjBA1TDCpkJFxpW4AB8P7bkjCDE1Ym3Pr2VT2VhwQJdf0S1V8Ucr1LC2Ty'
        'yKNXb0hI097A78eSNiOMOMRXInw81J3Z2Fa6CX8QhZT8VMrhvU/waX5moT5eaIaRENJuWBNrW8Hnwb4xrVwT9MehWb2fhHARnn1Co0PxYy2iijLdPjsxSmWN'
        'YqWIxRsfzONQYm292NhxaxwDiK5iMvAo/K8JH6+ISFD8WqWOlq1/gyVErSM3fmETvIrcgqNlHkc2HGCa9YH9PArfLcK4aO/cPwvlRaSTVLFWipnQhjOIdOo+'
        'QLkkn9f2wYAtELqlxuHSfRUjCtLM7NL3hpEoEXAvyClx/cfvhNU8ZTM9eaBHIIZBXzyM/dAUQhO2pUH/ALZGok/cf3wTplHXqlBh3eEosNX3aNpJEpPl+56p'
        'hGd15Gx2DDj3+2ELYMDVOHZmyYhVcvZqLTWIl4iQFkYFEU8dweQVF97+cIb+Hr0VW28exeqcvRoTHDGldlaSDtVKTgKT9iwv5IuefGAHGdx9FUszCAJbvlI1'
        'FOmWzVyTwSRWOt4pF/lKNjsfAI9hzzhwS6L/AJXOQKc2iFpFV5bWU89XSzrIqgK0chCyqzXsNB//ALAWw+V7TDgpd5TeMzCk4auI0xhphDLsZAABpUDkgC9r'
        '+3jk4cgzLlBpaBlCPFQGGgiqgjKssuloi6hpF/pFtyAdy3HAwuaTlVAwhueFUpKaljUvDXqatyCsZkjb03uWYad7e5tv9sISdosqAN2OuklzCaGNwju6ySm0'
        'o9Rja/Ifnc+LYfKDChmIkIdXX6sxqKqQxtLN6Pl5pQwf02FvOoc/vhgLQkLvEXHglkrp507RDgQHRqlfUSR5UDYAf3OGIA90gcXWhBkNRXrKphZroo7DroJ3'
        'tYE7b84NhtS3dsRRQRKU1MzRMnb7ZUgJ406lNm+9sCSjlaAEzBF8wFiiiVhHIp7s0IlsoOyBTsb8XPI++NOW5ShufwhUquKuWWIT0dVTiWQsIG/lIBv9NyQF'
        'HsR++JDLvVnNcNhSkFHLTUE071LSo0wiioZJgLsRvZS26j3H/OHJBMJWsLGl5PsvSzrEkrpC71U2jXKBJP2wNtPcuVVCPyHgjxjAHbpw5JiW3I1KEmYNFLB3'
        'IbxyEqY+6PWv+nYgj7f8YxGsLTvFkKOrimSF4UZgAYy8LHtub7ACwtYXB8XxoIsUsjUIbVT1cmhKcMkv0hQSoHFyQAP1O2NEXlKTNoS/Tr1D9fZbO0KQwxLJ'
        'CsxUXY60BIRj6R4BPIucdtIANMFeLiyS8SIF19y/E/mMEUWUziC7LVVFJNGsil9YjVgEPDAC5D3OwsScasJZA3o9nuDa8m/hK+JU9GRIDHHqDerRHLrYn3AN'
        'hc+/H3x57jOpX07GGJAVXKcxWeL5ZUZpvU6UtUvbEBGzqym9ydzpBAtuThHsy+LmNqtSqB/gA9jsVeGB2pTU9qIU8aiQyxo1UgAPpuATsTbYEDEb5om/BdRh'
        'rZIEcVpM9bVPLSHL6aip4k+Yq55YQsiDkRgs7mMX/ILEsd7DFAGtbIM7urT6rlzVHugiAOugkKygOrVSPKVcDQK6FNhf6dMZIFucYHfy/tEsM+E8UhVU4pqi'
        'edfm455VKGaePSKoDYkAG4t4uNx+uH1EWj7KcQ6RM/dDq6iWOK1LNTpVxWjaF0sIx51kb382xmgE+IGD1ZO57mt/0yAQhNpgpphBBLVSU8hLpR0xKuH/ADNI'
        'eGHFjwNxilzEmPU/woOcGAgAkjcP5QDGEV5ZERHKaiXdWC/c6iAR7f3w2tksReLqhVZWlHJVSg1NRpVYu8I9FgQCJHiJLhTfbTcbYmCTAt1uOicw0Tc9bkxl'
        'FHDTUUojnWrmYAq8DBoZG8ElhfUP9Iv98TqGTey6cOxvdmDJ5LTM8znpKdiwgkWmGs0kEUkpDe/BC+TdmFubYLWyfXahUqFrfTYvf+qWq6yOCmmRLIGtDL3d'
        'RsDdjaxt/SD6cDu8ok9dc0TiM5ytQ62tp5oDJIgd2Zi2n1sGB3Jvb+5tfbDtaQYUqr2lslSYc+p6yvQiTXNL/IHdUuwWxI2Ubj9Tb3x0d2QF53fMc62qovlt'
        'RVTQlIJzGzhJHhS+jUQOWG49xccb3GJ5gJkq2RxIgItZUzZhUvRQ1lPG8DEMY1EiLGPYbLq977ed8I0BozEG6Z7jUJY0i3XFKJQ1k2WVVJRVKBqqoR0NUC/c'
        'YfUrMtjZgPHAxYOGYF40nRc5Y7I5tN2p2oktFV/OShQpjhijMkomv6pDpQeoDlgQo5NrG2BYN62dXQ8eYjyE3QpamTKKSajqGkpFrV7NXTqlmqIw4OhtrhQw'
        'BvcA25ww8Rlt408lnQ0Q7br5pqoUxkmZwushY4zZSP6VQDcnyDiYvoqEhpuslJojpneySIEkkljEhFjewN7hT5IH2wRB0QvtRzQSJKY5a2WmjliCSNPGqrE9'
        '7qyqpJ1EbffAkG4CYsNwTYoohkSbtxRCaIs2lTEO4F+5Q7kb+kja+BqJ2oTltsWiZXKkM5pKYT+WKRGWQD2B32/UbcDBmdUMpF2gLMvzElQuXVGX9uZVWV5E'
        'h5a3pBtcJYb2Fr+caw8QK2Yu8LmrSKhzXOs1SnooKNoXUyGKZSFh7Y3d216dPvcewAwZa0SZSf6jnQ2I80Gkyeen7dX8ysEkpeWaVplk+Ybj0KBZE22sL+MF'
        'zgfDH9eu9BjHDxA+u3ktahxFCHhqadZZASulnvCf6pF8C/5L3OABOo68vyme+PpInrVaSNSrMRT6I2dgZYkZgr+/GxuePPjDQdqnnaTIVDIc1qR1lk6F4Y4K'
        'bXLcR2ZpC6hi7G5IsALflHIx0UQIJXl45xcWgaLuvjX0+0GcUmZJMqx1vzU8rTSKXmK6SGDEEEAOQoUDgffC1z4B6q3Zjc1ZwGxq+a0VYFAliOmy6bMsjNz5'
        '0+fbbHE4bPwvpqbwBI/n+Fmmklp3cRwMsaL3QAHDKfP1m4Bvf/UbjbAdBFz17I0/C4wOvdVpM6tS1dO00kqSRiVV0EJAwsGJ0gKyaWJ07sGUWvibWXBI6/Kr'
        'Uf4XNBsfLRVoaSKuooaiPKcwrKGASGKtEN+8FABmNyEHje+r332wsuBNwCdn8b/4QlhaLExt/lITZRLm9FHOc3SnaGRZIIqGnaJJUNyxaVjdiVFtS34OKZg3'
        '9PH8KOR1S5fEbvyoSZWMtWozFpRX5bXORMlMmqSBT4sSdSqLXufv7YoSXQ3Qjn/lSDSyX/U13JEqcp+X0SG8sTXSJ2UoGCgE8kkEXGxN74AcqlrdUSnnljpo'
        'qCKZzHI7FGm3Nyf6dgBfm2AYnMQsyQ3u2nXep1NHNJHUwPRl5DKy1LyJ2W7in6bNcMvm4sPbFXECDP8AK42AvBGXbB2JqpyuvSjmedhLLSxCSIxIXWGMH+k7'
        '6R/f9sAOBNtqq5j2skm409FnpfOKenLPMtU8THVKsta+p2P/AHBYWH6DxhKtMnT7J8LWY0eKb7yjZzmtJJKtHAkMlEEE0lZHKzOjeIgoWzHyTvtbzgNY6Mx1'
        '3J61dubIweHf/CMlR89UQfJ5VG0qQrrYFYUZQdmI9RufvYX584WMs5nKgd3hGRl0rmaVdPNVspEsbMP5s4EjKD/Tc2+3kbGww7S0xKjVY8TGiTXvUVJDQwU9'
        'DSxwOzvVxUhWeo1m38xzcso4AAH/AJxaQ45jPFcOUsAYALeVyrFZSSZPH/hxBKrSCR9KB+4bWDDUTawv6fHnEQc1iumDTGZq2os7YVFPT1dXMKanWScQydtI'
        '0kcgA2VSZCR78cAYzqcAlo6/hIyrLwHE2lU60UX8qUmoqZX2nkqoTqUjgWv6lP8ApItbjCAu0HJVJZrqpq0FTmFLLMmYQOPUsb1ijtLqFmUhtivj3FgRY4OY'
        'NdEcEnduqNJDh7odF8tGIy8SVEekwkQkur2FiNZ5G36foMO6T1/Ck2BqJQcxzajD1HyVOkdNGQeyzRQqvghCo9QP335w4BtOvFKXtE5RZbwzVFVOjpVyqtVq'
        'Ppj7a2A4VxwQPAO584B8xosHEmxTdd8z8pHPDFJHIiKl1cJFMi8t6fUXP5gebbEYIjQrPzi42LTLaWCrozVF3rGmYKYZgbAeCGBtf2W2rAcSLaddeSzGhwza'
        'ossNNNTTUTNpm1kwrSJpI4s1kO1vIbn2xhOoROWMu3yS9BmFTS5pNGaOnoYom0aEcxrI4HqkNjYk+ObYxAIF5SNe4GIha5vnorauKdYlnhqYyWURLCkZG2gg'
        'c387XO2+GDYBB2IOqXGXakKJvlo5TMqVDzMe5KLxlbflUDbR40+Od8ZxJiOv7Qp+CZusCvhnnkV6dYu4BGe6dQJ8Ek2A9tvGNlIFlszS64TcbfK5k8kCsxUW'
        'ChA7EeTcH0+LEcYEy2EbB0hVOn4jF1rlElHBTh31uKWuIdSVIJJ45uQCfsd8dNAkgyvIx4GZpG1VOuKxM56iM96ii00lTEKSIsTJ60WzFPrJtubAG3AxsT/t'
        '+4VOyzGJP/UrjaimhhqUmjl0Sx7PEacqz++tr7W8WAxwgkiD919IQA4OaURhSyVkEbGxjcsY+7paS4toc7mx5/bGEhp6907yx7hBhEy8x0pmFRm0bTsfWzTG'
        'SNh4AuAAFG1hY4zvFENtwU6YDCcz7n3VDLc3jieritl9Tl8zLG3y6vDFdff0lST5uOeCMK5pMG881RjhcCCCtq6rrJaaRFp0lhjZpGhUMsaJwdNrkHjckcEf'
        'YgRIKzg9otokZo6qhRniSOjjnYJFUJIS7MBe9gAF25IH++HBDtbwpw5mlpR/4jStUn5p2eSldYZ6Wjp0glkDp/n9xgykXsL2v+nODlMW26X5ImoCbm41tzXH'
        'p1nlt1ZJpkksdMnyRPq8WBNucdHcP3c15fzCjFjyQ6PrOlp2Ys0qsbagkDyEn33B/XnBNBztiDe0KLLl3Iret6uopY5Ff5yCV/VE7QOvJ+pmve1r7DkYdtF4'
        '2KT+0KLv1EeyLV9c0FXLDDDSyOsTCT5mSCRA/jthwL286mBOAMO8AkrO7RoOIaNm1Cqes6SOqBMVUKZtrLGXKbcagBe/2/tgig8hY9oUA7W3oj5b8QckpJpp'
        'YWqoahyUaQwMhAIsVFvBH6W/fE34aqbHRdNLtTCsJLSeCNU/EukmrdRdhAIhHdcu7juPvcWH2sNv3wBhXAac0Xdr0nOibeiQpeu8lpteqpqYWUm3bp5C5Hjb'
        'i+KfD1DsXJ8fhx+rkVXfq7Ilg7ay5jGjsDMHoG1KRwRbzf6vfCdzVnTmqfHYeIzHgUlR9XUUNQWiWvjYNtJDTuGtfjg2PN+cUNF5EEKDcXRmQTwKbq+uYKGR'
        'Kml+alAFlaSncszHgW07j7W3/bExQc4Q4KrsbSb4mnklz1pNXTtNI1SYQoELmnYSg29Q0hbC5+nbfzg/DxYBL8eHXcbJOTqyqMLaMizho3IWUyR2Mi+1/B9/'
        'fzbDjDmbuCgceyIDSn4uqMlhKNXUub0MardQMt1n7b7i3jCGjU2QfdVGMofqkeydpuuenEaImLNhMNjIaaV1kPhdAsB97bbWthDRqeSqMbht54JV/iFl9Izz'
        'RUmZzVKA6ddIw9X5bew9x5wwoPsDCU46iJImfRb0XxKyiqpo2q6Kvy+q1sskS0krQ6iN3UoVN77++HNB4NrqbcfRc28g+i2X4gZdT06SyPncskZse7l2i7Dy'
        '7qLtt5Jvb3wO4foAOKPx1EauPBbU3WmRr22kfMJZlfUl6F1Kk72+3+5POAaVTYOaLcZhzq7kvV3XWXTzzpHleZTy7GOdYWXVtue15A8EkeSQcBtF9phZ+MpH'
        'SUm/W1BSQokuX16yPZ+2aJ7yeQbf7Hwdj9sP3DibfdL8bSb6+i5//wBYPU1UlRXUk9LTmfXOnZkkVYz7LpC/a1xfHR3OUQFxDFhzszrBWZ+oen3tNIuZa2Op'
        'XFE8KKPCgKBb2+/nEO7qj/K6jicOTMngqnQ/UFDnHV9K1DSVUMNNGyO0lNs7uwAuH2Nvvzi9Om5gJcuDE1mVS3JsX1r49VtdkWX5Z1DTdPioolmenM8SaQpk'
        'QapAV3YMym1iQosNsI+kaoyTCfCYhuFqd4WzaF8QoOsMueF0qIKiikVxImmJnZj7Nfz977453Yd40uvXZ2jQP1GPZa1HVdBFIjpHJKhbUxjVi6+5UsAL+P32'
        'xhQqEXTHH0AZBlc/N1HUfOJMKR1hhBVkJaxBNwQ1rGw8H2x0CjAhcLscC8OiwVmHrpI53lljZaUBSBaQlv8AVcD6j7WtiJw7iPNdbe0qbSZNlZoevsogpCs1'
        'bUKjOJNTUz6Y1BJC6RyLnz5AxE4aqTZvNdTe08MBd/Ir1X15lNRGHhnllhe+r/BgOgPIAY2383G/P2xm4eoLEc0HdpYYjwut6KdmPWGV1CLJ8xOsibR9yh7h'
        'I86rbWPtf9sUFCoNnNRfj8O6Dnv6L//Z'
    ),
    'planks': (
        '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/'
        '2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADAREAAhEBAxEB/8QA'
        'HAAAAwEBAQEBAQAAAAAAAAAAAwQFAgEGAAcI/8QATBAAAgEDAgMGAwYCBgcECwEAAQIDBAURABIGITEHE0FRYXEUIoEIFTKRobEjQhYkM2KSwRcmQ3LR8PEY'
        'NFLhJTVTY3WCg5OjsrOi/8QAGgEBAQEBAQEBAAAAAAAAAAAAAQIAAwQFBv/EADoRAAIBAQUFBAkEAgMAAwAAAAABAhEDEiExQQQFUZGhExVTYRQiMkJDUrHR'
        '4WJxgaIz8FTB8SNEkv/aAAwDAQACEQMRAD8A/Iqfs67KWORwIkCY5NLep0J+nhr8A9p2rxeiP362TZfD6sLF2Q9mdUBOOEoZUycwxX6bGPLr+ej0zal8Toh9'
        'D2Z+51YnJ2SdmLVQc8BYR2KingutQQo9WLav0zaqf5OiIexbNX/H1Z2o7IeyrauOzhck43SXqfn6fj0Lbdr8Xojeg7L4XVii9jvZYkx+K7N4C780SPiKoRfr'
        '8/L11Xp210wtn/8AlfYO79l1surGh2I9kzoAOzVBI3UJxPUEL7fN++stv2zxf6r7G7u2Twv7P7m6bsf7HC2ZOyiSop1wryw8VTq4P+6W5/TQ9u21fG/qvsbu'
        '/Y/C/s/uMnsb7FZm7yLsrqKeBDtIqOJKlnY+GQGH5DU+n7cs7b+q+xu7tj8Lq/uff6G+xOWbYOy2r/Ccd3xFU8z9WOt6dt9K9t/VfYru/YvC/sw83YJ2Q7UE'
        'XZTU7xzPecUTqCNZbw2zW2/qiXu7ZNLL+zCv2D9jzRI47Ipoy3RP6YTZHvnW7w2zxv6o3d2yeF/Zkmu7Aezanmjkh7NhDBjmknFUjkn11feG1NY2v9UZbv2Z'
        'fD6s+TsQ7MoplFV2fxRRMM7qfiCSQj6Z1Ppu1PK16IfQdl1s+oU9jfZZFG/+oFQoJ+Rk4lYYHqM9db03an8X+oPYdm8PqDHZL2UdxtbgmqWo3Y/iXiV1Iz1P'
        'Pl7afTNs8TojehbJrZ9WfP2Xdk8JJXguadAcMy1dRtX0z4/TR6Vtj+J0Q+h7Kvh9WEg7OuylmJHAiQJjk0t6nQn6eGh7TtXi9EUtk2Xw+rCxdkPZnVATjhKG'
        'VMnMMV+mxjy6/no9M2pfE6IfQ9mfudWJydknZi1UHPAWEdiop4LrUEKPVi2r9M2qn+ToiHsWzV/x9WdqOyHsq2rjs4XJON0l6n5+n49C23a/F6I3oOy+F1Yo'
        'vY72WJMfiuzeAu/NEj4iqEX6/Py9dV6dtdMLZ/8A5X2Du/ZdbLqxodiPZM6ADs1QSN1CcT1BC+3zfvrLb9s8X+q+xu7tk8L+z+5um7H+xwtmTsokqKdcK8sP'
        'FU6uD/uluf00PbttXxv6r7G7v2Pwv7P7jJ7G+xWZu8i7K6ingQ7SKjiSpZ2PhkBh+Q1Pp+3LO2/qvsbu7Y/C6v7n3+hvsTlm2Dstq/wnHd8RVPM/VjrenbfS'
        'vbf1X2K7v2Lwv7MPN2CdkO1BF2U1O8cz3nFE6gjWW8Ns1tv6ol7u2TSy/swr9g/Y80SOOyKaMt0T+mE2R751u8Ns8b+qN3dsnhf2ZJruwHs2p5o5IezYQwY5'
        'pJxVI5J9dX3htTWNr/VGW79mXw+rPk7EOzKKZRVdn8UUTDO6n4gkkI+mdT6btTyteiH0HZdbPqFPY32WRRv/AKgVCgn5GTiVhgeoz11vTdqfxf6g9h2bw+oM'
        'dkvZR3G1uCapajdj+JeJXUjPU8+Xtp9M2zxOiN6Fsmtn1Zx+y7snhJK8FzToDhitXUbV9M+J9tHpW2P4nRD6Hsq+H1Z7l6WSFii11wnkc5iBcBl8wdy9M+Ov'
        'DXWiPfTzMSUFbIr97W1UoxiNS43KfHOE03lwCj4n0kdUsSqa2aNugO8ISfPmOetVVyGjNQxTyrGzzVEkiH5+8eN0B9DjUvB4CvMcMdyFQoL1O1cMzIYV3H/w'
        '8166Eo0NU7X0hijLR00xaUHfHLJExGDyzgc86y/czqT6S01VVG0stHDBCDhTsUMT4nIHIe2tKSWCZkm9Bn7tWmXFTU0Ybm0abZFPljrk++pvVyTFqh2JKkGQ'
        'mrSR2HIJ3iLjw2+g01XA1DUlvkjhMqzRrN0O+okbJ8tZNZGpqiZIK0VD5r1h24yxjnYZz4a6K7wIx4nCkTlC1ZFN4OrCQE+f4l1nXgP8i1wtkcs4mMiQQNyk'
        'Z49mBjr68vDVRbyCSPpeHbe9LH/3iZJRuDxSbQ2OY6D/AJ6aVOSZNxNBU4fgLI0JubeJ7qTJx9Ryxo7R60NcXmUaeyiHDwV99jVuiM4Af6DUO0rmkWoUybOP'
        'SyQsUWuuE8jnMQLgMvmDuXpnx1r1caI1KamJKCtkV+9raqUYxGpcblPjnCaby4BR8T6SOqWJVNbNG3QHeEJPnzHPWqq5DRmoYp5VjZ5qiSRD8/ePG6A+hxqX'
        'g8BXmOGO5CoUF6nauGZkMK7j/wCHmvXQlGhqna+kMUZaOmmLSg745ZImIweWcDnnWX7mdSfSWmqqo2llo4YIQcKdihifE5A5D21pSSwTMk3oM/dq0y4qamjD'
        'c2jTbIp8sdcn31N6uSYtUOxJUgyE1aSOw5BO8RceG30Gmq4Goakt8kcJlWaNZuh31EjZPlrJrI1NUTJBWiofNesO3GWMc7DOfDXRXeBGPE4UicoWrIpvB1YS'
        'Anz/ABLrOvAf5FrhbI5ZxMZEggblIzx7MDHX15eGqi3kEkfS8O296WP/ALxMko3B4pNobHMdB/z00qckybiaCpw/AWRoTc28T3UmTj6jljR2j1oa4vMo09lW'
        'La0NffY1bkEZwA/0GpdpXNItQpqxmS1tWGJn4goULgB1nrXOMdOo6ftrneuvIulVmUEsV2QqBdqKWlU5NRDdljZ/Icx4frovR4dDNP8A1hXNZHTSCaM1bA5W'
        'Vq6OfYvpy56MG/wGgRbhMKYFbNKT0BhSIB/XOpuriNfI4blXJtRrfVKTzLDuAceXP99FFx+o/wAGkvIqYwncvOWJ5zT08e0DzP7aHF1r9xvf7gbienrZjG1D'
        'UEMucLXU7pj0HXOijWKfRinpTqMwpbY5YY6i11gkC53irgwV8tT63H6lUXAxNV2li06pVd/uwE+IXco6Y+Xl01VJUBtVJMlZaKg1ET26VFU4PewNIefjnI11'
        'SmsakVjULRW22mPKLVKgbCBY5FVT+Z1LlIUohJ+GqUSyNJBcZATkdzA7qD6+P00qcqZoHFak9+CqGAxRb3Vpn3qk0roVOOrKwwPQartZZhcSBngRZnYr8XEi'
        'k7djl8eoC+et2wdmLrwjWQSndX3GmikbbtNPMQzeWQD+eq7RPRGutPNjbcKTQRAm6wd6Bkd48yEepyuhTroLQKS1tWGJn4goULgB1nrXOMdOo6ftrXrryNSq'
        'zKCWK7IVAu1FLSqcmohuyxs/kOY8P10Xo8Ohmn/rCuayOmkE0Zq2BysrV0c+xfTlz0YN/gNAi3CYUwK2aUnoDCkQD+udTdXEa+Rw3KuTajW+qUnmWHcA48uf'
        '76KLj9R/g0l5FTGE7l5yxPOaenj2geZ/bQ4utfuN7/cDcT09bMY2oaghlzha6ndMeg650UaxT6MU9KdRmFLbHLDHUWusEgXO8VcGCvlqfW4/Uqi4GJqu0sWn'
        'VKrv92AnxC7lHTHy8umqpKgNqpJkrLRUGoie3SoqnB72BpDz8c5GuqU1jUisahaK220x5RapUDYQLHIqqfzOpcpClEJPw1SiWRpILjICcjuYHdQfXx+mlTlT'
        'NA4rUnvwVQwGKLe6tM+9UmldCpx1ZWGB6DVdrLMLiQM8CLM7Ffi4kUnbscvj1AXz1u2DsxdeEayCU7q+400Ujbdpp5iGbyyAfz1XaJ6I11p5sbbhSaniBa6w'
        'd6Bkd68yEepyuhTroU0OT3e6LJIJKqjqI8fLtaOTPmTkeOoos0mFWSqlrnNEJFtNqqoee0yU/M+fTXRXVhVktSeNCatbXUqOJaKj7ksSYYaf5c+WPHXWkXky'
        'KtZoaa4VcVJFKvD9KiZAUzxsGY+GADqKKtLw1wyGP6Rd1EDJZdkjdBHBuAPoT11NzHCRd6mgxDxBTlmnkpKmnyACkduWUDHjj99Dg8q9RUln/wBDy8WUtSoU'
        'mqVQcMEssYZPU5OufZtf+jfT/wDBObiSx0ss6hqiVycE1VsUYYjw2nrqlZzkvyZziv8AwZp7xa61YysFBHM67WcrLAwHkeWProcZLiZSTxGTTWqdZJJJ1p2Q'
        'YWNbkHEg9ARnU1l/qHAsUFminiQ0dRWQcgWSUJJEx8idc3Jp4pFU4VFqi37pY5IZYQ6N1aKaMt77Wxj110UqZ/8ARLVTSU1XFHIFpBUBjuZkuEyBj7Mp1F6P'
        'HoWoyFJYKiESNNYLr3QUlZqKuVufkQcHVKUXlJfyiXGSzRI+8oISZDLxFSOBzeUyEKc8/wAPhro03wYVSzqPU15rRIY6TidpImGSZqpuf+IdNTdwxiF7gwc9'
        '3uiySCSqo6iPHy7Wjkz5k5HjqqLNJhVkqpa5zRCRbTaqqHntMlPzPn01aurCrJak8aE1a2upUcS0VH3JYkww0/y58seOutIvJkVazQ01wq4qSKVeH6VEyApn'
        'jYMx8MAHUUVaXhrhkMf0i7qIGSy7JG6CODcAfQnrqbmOEi71NBiHiCnLNPJSVNPkAFI7csoGPHH76HB5V6ipLP8A6Hl4spalQpNUqg4YJZYwyepydc+za/8A'
        'Rvp/+Cc3EljpZZ1DVErk4JqrYowxHhtPXVKznJfkznFf+DNPeLXWrGVgoI5nXazlZYGA8jyx9dDjJcTKSeIyaa1TrJJJOtOyDCxrcg4kHoCM6msv9Q4Figs0'
        'U8SGjqKyDkCyShJImPkTrm5NPFIqnCotUW/dLHJDLCHRurRTRlvfa2MeuuilTP8A6JaqaSmq4o5AtIKgMdzMlwmQMfZlOovR49C1GQpLBUQiRprBde6CkrNR'
        'Vytz8iDg6pSi8pL+US4yWaJH3lBCTIZeIqRwObymQhTnn+Hw10ab4MKpZ1Hqa81okaOk4naSJhkmeqYZ/wAQ6aLuGMQvcGHktNpZY6lxSOxP8MfD7h+Q8PXT'
        'WSqgVGxUZ+IZKKqggRfmKxK0Sk+flo85IcNCfVPVwbYxT0dRIeYcyEFh6+uqSTxqDbQrL9/zyOIqKAIGyJDMTu8yB4aqlmtSKz4D9JHc6lVkmrwq5x3YABz9'
        'fHUO6skdFV5sstQwU6ZqbnUJIuGLyyhQPfbqE65IqlNSReaqmIE9BFJVzP1mVmww8yxHPVxTykS8MUefW43CkkE2wb4mwI9+88/TGu12LwObk0PVXFbJAsVX'
        'VrDUyclecnaD/e5ctcuzxrFYFuapiUdyTwLJ3ltrHx8yYz9QcctTk9SswLTRxvteNKTa2Q1MzIpU+BweZ045ph/BYoYmmaUQXSshlfBQ00hXbgeKkEHXNya0'
        'KohS4Wq6tL3qXyWVtpUCqqCnLx5AY10U45OIXXxEIUeldxWUzXEY5yJcnOD5401TydP4Nis0Co7nYmqXbuKyKLHMLWOBn38tZxnRApItd/w3NTwkS4ZWz3cs'
        '+focjGpUbRA3Fh5LTaWWOpkFI7E/wx8PuH5Dw9dNZKqMrreAqM/EMlFVQQIvzFYlaJSfPy0eckOGhPqnq4NsYp6OokPMOZCCw9fXVJJ41BtoVl+/55HEVFAE'
        'DZEhmJ3eZA8NVSzWpFZ8B+kjudSqyTV4Vc47sAA5+vjqHdWSOiq82WWoYKdM1NzqEkXDF5ZQoHvt1CdckVSmpIvNVTECegikq5n6zKzYYeZYjnq4p5SJeGKP'
        'PrcbhSSCbYN8TYEe/eefpjXa7F4HNyaHqritkgWKrq1hqZOSvOTtB/vcuWuXZ41isC3NUxKO5J4Fk7y21j4+ZMZ+oOOWpyepWYFpo432vGlJtbIamZkUqfA4'
        'PM6cc0w/gsUMTTNKILpWQyvgoaaQrtwPFSCDrm5NaFUQpcLVdWl71L5LK20qBVVBTl48gMa6KccnELr4iEKPSu4rKZriMc5EuTnB88aap5On8GxWaBUdzsTV'
        'Lt3FZFFjmFrHAz7+Ws4zogUkWu/4bnp4cS4ZWz3c0+eXkcjGNSlaIG4smm6U8FX31LVwURcfPTyNlV+g1dG1SSqGWKDniqk2GOsuttnCsNyxHYR5Bj/lo7N5'
        'qLNfWrQxLxTQPuSNKQIw+R46lXYHzI8/TUqEhvRHKR4sq5qEIZMs5kUD0JydS0+A1WdRlJ2iDSw3qnaBuYRoVmAPoRz1LXGJSfBgeIKaoraanRbxEs7fNH/U'
        'iv5EDx/XlrpZ0WcepM6vJkxae4fBTSPVzSLEQZGRduxs4xz8fTWbjXBAq0zFKyK4FGqZaKFoYgWDtMUdcDmdw8f20pxyqaVaVaPKXxamnVMwbRUOBkS7w2fE'
        'A+mvTCj1yOE6rQLSUE0NGn4zEh5hSPnOfHx99EpJsuMXQLWirmcNHNVsV5mNtpUDzB89QmlnQ1G8i1aKKdkjWSvUBxzJmC41xlJaI6xXFlmltCxSLGLsjNID'
        'iJJQ5IHudS5Nr2TJUeZyspqCjy9TVp0KqksqjPsB/noV55IW0s2QqtLXUIrvNQtGefzS7znywNdo3loyHdZLtd6p6OpMccdNLhs7ZAMMPDXolFtVxOCaToeg'
        'N0poKvvqWrgoi4+ankbKr9B/ydeejapJVO+WKDniqk2GOsuttnCsNyxHYR5Bj/lo7N5qLNfWrQxLxTQPuSNKQIw+R46lXYHzI8/TUqEhvRHKR4sq5qEIZMs5'
        'kUD0JydS0+A1WdRlJ2iDSw3qnaBuYRoVmAPoRz1LXGJSfBgeIKaoraanRbxEs7fNH/Uiv5EDx/XlrpZ0WcepM6vJkxae4fBTSPVzSLEQZGRduxs4xz8fTWbj'
        'XBAq0zFKyK4FGqZaKFoYgWDtMUdcDmdw8f20pxyqaVaVaPKXxamnVMwbRUOBkS7w2fEA+mvTCj1yOE6rQLSUE0NGn4zEh5hSPnOfHx99EpJsuMXQLWirmcNH'
        'NVsV5mNtpUDzB89QmlnQ1G8i1aKKdkjWSvUBxzJmC41xlJaI6xXFlmltCxSLGLsjNIDiJJQ5IHudS5Nr2TJUeZyspqCjy9TVp0KqksqjPsB/noV55IW0s2Qq'
        'tLXUIrvNQtGefzS7znywNdo3loyHdZMtV5p6OqMaR0suGziRQQw16JRbVcTgmk6F6xW6orFUvS9whPJzGTn9Py15rSSWTPRFN5orT2G3zYLRQ7ujbqcKzLrk'
        'rSSLcYvEC9lsclUVlWKmG0MpWjOCPpqr9olh9SXGNRWqtXDELvI1PFNCBnvJaRxn1x0xqlO1eRLjDUH8VwrSSJ3lStKrAhY6dWQn6Dx1VLaWnM1bNagjxNHB'
        'UxClr7pXUsRwlPUwsF58h8x5403G1ikmF5J4Op5663+sqXqSlpp5Ep5wZJBLM5Zl5lWHLoOf567Rglm8zm5PREKkoqm/y1M9xrpC0kgjamVykZVssWAz+EAA'
        'e+u7cbNJRRwSc3iz2VntMUoEtPBXLUMoWFKd+8AwOjBug145yeToeqMVoNz0Ms1XJFWyTwyBQGGxQFHgQR0GpTSVYl00YzT8FWuIRqtfUxIo3ZEYkXPoT11x'
        'dpJ5pFKEVqO0nDo7wBaqrlp1/GWpo1JHnk8s6HJcOo0Fq2/8PWU91PULUSAZd5liJH0X9tdY2c5YpHNyjHNnnqrjuyy7/h4KyafntENJHtI8MltdVY2iz+pH'
        'aRyRKrrvPcQUiplp45eYIRd0fnkgdddIxSzdTNt5IJR0sij/ALjT4U57wqWYnzJ0t+ZKi+B6mxW6orApel7hCeTmMnP6flrzWkksmdopvNFaew2+bBaKHd0b'
        'dThWZdclaSRbjF4gXstjkqisqxUw2hlK0ZwR9NVftEsPqS4xqK1Vq4Yhd5Gp4poQM95LSOM+uOmNUp2ryJcYag/iuFaSRO8qVpVYELHTqyE/QeOqpbS05mrZ'
        'rUEeJo4KmIUtfdK6liOEp6mFgvPkPmPPGm42sUkwvJPB1PPXW/1lS9SUtNPIlPODJIJZnLMvMqw5dBz/AD12jBLN5nNyeiIVJRVN/lqZ7jXSFpJBG1MrlIyr'
        'ZYsBn8IAA99d242aSijgk5vFnsrPaYpQJaeCuWoZQsKU794BgdGDdBrxzk8nQ9UYrQbnoZZquSKtknhkCgMNigKPAgjoNSmkqxLpoxmn4KtcQjVa+piRRuyI'
        'xIufQnrri7STzSKUIrUdpOHR3gC1VXLTr+MtTRqSPPJ5Z0OS4dRoLVt/4esp7qeoWokAy7zLESPov7a6xs5yxSOblGObPPVXHdll3/DwVk0/PaIaSPaR4ZLa'
        '6qxtFn9SO0jkiVXXee4gpFTLTxy8wQi7o/PJA666Rilm6mbbyQWippEH/caf5TnvCpZifMnS2uJKi+B+hrc62pplWrp5513cvi68LgeGVTXkpFPD6HereaMz'
        'U8VRJ3lTBbQu4A5Zzt9evPUqVMFUtxqG+4KaoaUR3KnjYD/ZbsKPLGdF98Au+YKms8jRyoptshA5yVJlKv7eGNZvXE1HoO/dkEHdyVlkpqzltHw8g+QHyLDp'
        '5kaK/qNTiiXcKCjt1WamOOWgZRlPiYi8Xty8P+urjJyVHiS0ovACbhI8ik2uQSSAMJaWBJYZPJic5PLw8tN3zNXDISS2xLVsaK1CKqH4nWmIQeJypOB+2ul5'
        'tetIiiTwQ7SvNGojoa+2W95GJeSpn3SSHxPdoOufXXN01TZarTApxWedozJHXRtuBDzPTM+8+u7XNzjqupd1vUCLDeYZFP3y8RAOGp1RPlz4A/tpv2b90Lsl'
        'nIltQVO6RbhcmrUYYVqyTCr7gciPXV1T9mNP2JSazdSclgWF0nS02OYISN6sGY58dVebwvM11cEMR3GpppHjey25lHQwU0jcvXljQ4VxvMpTphRBKn4yqdHg'
        '4fEozg7KBvl8jnI5a0UlnLqDbehYpLpcbbSfDNZLhCi/7WnSKPb6YbJGpcIvG8gq1hRmkudbU0yrV08043cjV14XA8Mqg00inh9DVeqMzU8VRJ3lTBbQu4A5'
        'Zzt9evPUqVMFUtxqG+4KaoaUR3KnjYD/AGW7CjyxnRffALvmCprPI0cqKbbIQOclSZSr+3hjWb1xNR6Dv3ZBB3clZZKas5bR8PIPkB8iw6eZGiv6jU4ol3Cg'
        'o7dVmpjjloGUZT4mIvF7cvD/AK6uMnJUeJLSi8AJuEjyKTa5BJIAwlpYElhk8mJzk8vDy03fM1cMhJLbEtWxorUIqofidaYhB4nKk4H7a6Xm160iKJPBDtK8'
        '0aiOhr7Zb3kYl5KmfdJIfE92g659dc3TVNlqtMCnFZ52jMkddG24EPM9Mz7z67tc3OOq6l3W9QIsN5hkU/fLxEA4anVE+XPgD+2m/Zv3QuyWciW1BU7pFuFy'
        'atRhhWrJMKvuByI9dXVP2Y0/YlJrN1JyWBYXSdLTY5ghI3qwZjnx1V5vC8zXVwQxHcammkeN7LbmUdDBTSNy9eWNDhXG8ylOmFEEqfjKp0eDh8SjODsoG+Xy'
        'OcjlrRSWcuoNt6FikulxttJ8MbJcIVX/AGtOsUe30w2SNS4RbreQVawoyU3FFqrUZWmqgrqVZWoZMEH21dyUcvqClFi8lTZ+8Vo5atgq4CpSS5H5jlnz8tTS'
        'flzGsRcVlM7M60k80qnAjjppS3tk45Y/z1aTybBtDlFQTTUpaCKalhJ/htJBMGU+e3Q2k8WZJvIMliemV2lv92jDdTHSSYB9M/trOSfuoKNZseNvt1LREx8Z'
        'XR6wr/DE8JZM+qbfpo19hGab94VoaSaAExXG2ORyLx0hjcn1AOM+uNaTWqfMYp8UZq6ZW/hzVy90TudIpJNvtjGDoTWiNR6morHTSRFKaetjpXJOIECs59Ce'
        'ePbQ5OuNBu4DC8MGCOM0lhvMzBjlqqqOH9OvTQ51zkuQqPkzUdtqqSqYDhWmwoyslVXxk5z0wW6a1U17XQVVP2eozTXmso2AQcLUyD+WtrlJX0IAOda6nxf8'
        'DVrgEl4zuk8wWC8cJQuhCqtOZWI5eBwM6VBcGRV8UCl45usjsx4rtm8ZUxRUZbp5E+Wjsov3WVffEhVHaBdIqhVbiUrT55vDSryHoPEa6qyjSqiQ7R1xYQ8e'
        '0pX+s3m4XHHQCkA2/UaFZPRJA5panW4otVarK01UFdSrK1DJgg+2tcmsvqKlFi8lTZ+8Vo5atgq4CpSS5H5jlnz8tTSflzGsRcVlM7M60k80qnAjjppS3tk4'
        '5Y/z1aTybBtDlFQTTUpaCKalhJ/htJBMGU+e3Q2k8WZJvIMliemV2lv92jDdTHSSYB9M/trOSfuoKNZseNvt1LREx8ZXR6wr/DE8JZM+qbfpo19hGab94Voa'
        'SaAExXG2ORyLx0hjcn1AOM+uNaTWqfMYp8UZq6ZW/hzVy90TudIpJNvtjGDoTWiNR6morHTSRFKaetjpXJOIECs59CeePbQ5OuNBu4DC8MGCOM0lhvMzBjlq'
        'qqOH9OvTQ51zkuQqPkzUdtqqSqYDhWmwoyslVXxk5z0wW6a1U17XQVVP2eozTXmso2AQcLUyD+WtrlJX0IAOda6nxf8AA1a4BJeM7pPMFgvHCULoQqrTmViO'
        'XgcDOlQXBkVfFApeObrI7MeK7ZvGVMUVGW6eRPlo7KL91lX3xIVR2gXSKoVW4lK0+ebw0q8h6DxGuqso0qokO0dcWbPHtKV/rN5uFxx0ApANv1HPQrJ6JIHN'
        'LUBRtdA8byXG+yAkbtwp4SAfRjy1TuZUXUycuLK1VXzQsRHcbkHHVKmqp0CjxJI1CSei6l1fE1FX/P3iXWYxbcFhd4wG9enXUuPl0NXz6gqe6XCaYPT3SdHB'
        'IIe8REY9QP31rqWa6GUnXMLHe7whEY4lKxg9PvNGYn8uei7H5ehrz4j6V94ETyffFZK/Tcahceo6Z+uj1eBWJKmrJJn2yXMxTMcd21emM+ILFeR8c9Dpp5dA'
        'r5mKi6NE3dvflhhLZ7v48/OPM7YyD7DSo1yj0M21nI1LeqOXApr1FMoPymWqlAz44wgxpuv3o/Q15aMyY6SmkE09bbKtiMgPJVy7vXAGPrqk21gn0Ios211G'
        'KO4WuYs3w9jSReuaOo3Z8vmGs4yXHmjJp8Bt7xBRxs6Uthd+oC0jhn+m3pqaPz5hX9gQ4yglLGc21CB8gp7dMxPL8PJf11nB6V5jeVCfLe++n2pUiFJMg91Y'
        '3wPTJ8v11V3iuoXvPoS3qg1QO6mnjwx/sLMO8YeYDHV0wxXUK/7Q0bjXqrvBXX+SEDli1xKwPh9NF2OqXMbzWr5BaNrorxvJcb7ICw3bhTwkA+GGPLWdzKi6'
        'mTlxZWqq+aFiI7jcg46pU1VOgUeJJGoST0XUur4moq/5+8S6zGLbgsLvGA3r066lx8uhq+fUFT3S4TTB6e6To4JBD3iIjHqB++tdSzXQyk65hY73eEIjHEpW'
        'MHp95ozE/lz0XY/L0NefEfSvvAieT74rJX6bjULj1HTP10erwKxJU1ZJM+2S5mKZjju2r0xnxBYryPjnodNPLoFfMxUXRom7t78sMJbPd/Hn5x5nbGQfYaVG'
        'uUehm2s5Gpb1Ry4FNeoplB+Uy1UoGfHGEGNN1+9H6GvLRmTHSU0gmnrbZVsRkB5KuXd64Ax9dUm2sE+hFFm2uoxR3C1zFm+HsaSL1zR1G7Pl8w1nGS480ZNP'
        'gNveIKONnSlsLv1AWkcM/wBNvTU0fnzCv7AhxlBKWM5tqED5BT26ZieX4eS/rrOD0rzG8qE+W999PtSpEKSZB7qxvgemT5frqrvFdQvefQlvVBqgd1NPHhj/'
        'AGFmHeMPMBjq6YYrqFf9oaNwrwrtBXX+SEDkRa4lYHw+mi7HVLmN5rV8j+fx267I3jm4NqZo2/lemnyPqRr7r2DGqtFzR8Nbfxs3yYUfaIj3K03BFVOE5Dck'
        '2T6E7emju56Wi6D3gtbN8mP0v2oko5jIvZnLUpggx1Ecjp747vro7tfjLobvJaWT5MUX7TM8fOLgepjUNkRR0OBjyzszrd2t52q5m7ySysnyMSfapmjm3ydm'
        '0k2P/aRkH89mq7rqv8yIe80vhMBV/axklk3jsri34+VnlnU/moGrW6afH+hL3rX4L6gY/ta3WKAonZ1LFCeQENfVoP8APS90wbxt+iN3rJZWL6gB9rK/mpE6'
        'cI3LI5bFuVRtx/hzp7ps6UdquS+4d6zzVk+bKMn2yeIsANwTcUX/AOJ1A5+f4NQtz2S+MuS+4972ngvm/sBg+2LxNBIH/obWyE5/FcakZ8ug8NV3RZeMuSDv'
        'W00sX1GYvtk8UMx/1JuDZGDtuVXz/TR3RZr4y5IVvSbzsX1NN9rPisjc3B16R/BjXVeNvl01Pddn4q6Fd5y8J9Tr/aq4nqSD/RC6xgjHOprZP0yNHdkPFXQe'
        '8peE+oB/tIXWUjvOEatiBjLxVRJ+udbu2K+IuaHvJ+G+TF37eK2oZpJOC5TL1EgpqncPrq+74r4vVE+nt/DfJhKbt7uago3CNa278Ugp6jJ9SMaHsEfEXNG9'
        'Pl4b5M0O3XZG8c3BtTNG38r00+R9SNS9gxqrRc0Utv42b5MKPtER7labgiqnCchuSbJ9CdvTR3c9LRdB7wWtm+TH6X7USUcxkXszlqUwQY6iOR098d310d2v'
        'xl0N3ktLJ8mKL9pmePnFwPUxqGyIo6HAx5Z2Z1u7W87Vczd5JZWT5GJPtUzRzb5OzaSbH/tIyD+ezVd11X+ZEPeaXwmAq/tYySybx2Vxb8fKzyzqfzUDVrdN'
        'Pj/Ql71r8F9QMf2tbrFAUTs6lihPICGvq0H+el7pg3jb9EbvWSysX1AD7WV/NSJ04RuWRy2Lcqjbj/DnT3TZ0o7Vcl9w71nmrJ82UZPtk8RYAbgm4ov/AMTq'
        'Bz8/wahbnsl8Zcl9x73tPBfN/YDB9sXiaCQP/Q2tkJz+K41Iz5dB4aruiy8ZckHetppYvqMxfbJ4oZj/AKk3BsjB23Kr5/po7os18ZckK3pN52L6mm+1nxWR'
        'ubg69I/gxrqvG3y6anuuz8VdCu85eE+p1/tVcT1JB/ohdYwRjnU1sn6ZGjuyHiroPeUvCfUA/wBpC6ykd5wjVsQMZeKqJP1zrd2xXxFzQ95Pw3yYu/bxW1DN'
        'JJwXKZeokFNU7h9dX3fFfF6on09v4b5MJTdvdzUFG4RrW3fikFPUZPqRjQ9gjpaLmjeny1s3yZ/VR4j4hWNUS/XLfnDFZ3dfQDEXXX5tQs6+yj9Del8xOl4g'
        '4lNSVPE1yKfy/NLkeefk1d2zp7CJrP5mLTXviSOd1j4ruUp5FlaB32k+R2DWUbOnsIzv19pjj3ri0wCJuI7x3OP7JXZM/QAcvTU3bL5UVWfzMDU1XFce6SG7'
        '3IJt6YZm9TzIzpSstYoa2nEFDPxmkhlk4hvPMY/swoA8NvPw/XWfYvC6jLtFjeYaj4k40oUDVHFN2J5hY3mp0A9Pm/fS4WTeEF1NetNZMKnHvG0IITjK5y7x'
        'hlFVSnaPMALyOlWdk/cXU5uVp8z6HwvfFW4s3Fl5dcHmayFsfpppZfIhrN++xetvfEkRVpeM7vuIzyr6YcvLGNZKzfuLkxrNe+xR+Ibl+KfjCswT8jTXCnVu'
        'vTlqrsdIdCbz1kGi4muxdP8AW65TAcysNyi2keXQ6hwh8i5CpTzvsLJxvVCcYvlWRtx3clwizj6Y56OyjT2VyKdo6+0Cl4uuEy95JerlCrZAWGrQ9PYHVKzi'
        'soom/J6s1BxHc4iGHFVU0eCcSVMTk/4l/TRcj8hr7+YPbLxeZJe9/pDWzhhzAnRfqMIfy0SUKUumTda3ikeJOIVjVEv1yD5wxWd2X0AxF11ChZ6xRV6XzE6X'
        'iDiU1JU8TXIp/L80uR55+TV3bOnsIms/mYtNe+JI53WPiu5SnkWVoHfaT5HYNZRs6ewjO/X2mOPeuLTAIm4jvHc4/sldkz9ABy9NTdsvlRVZ/MwNTVcVx7pI'
        'bvcgm3phmb1PMjOlKy1ihracQUM/GaSGWTiG88xj+zCgDw28/D9dZ9i8LqMu0WN5hqPiTjShQNUcU3YnmFjeanQD0+b99LhZN4QXU1601kwqce8bQghOMrnL'
        'vGGUVVKdo8wAvI6VZ2T9xdTm5WnzPofC98VbizcWXl1weZrIWx+mmll8iGs377F6298SRFWl4zu+4jPKvphy8sY1krN+4uTGs177FH4huX4p+MKzBPyNNcKd'
        'W69OWqux0h0JvPWQaLia7F0/1uuUwHMrDcotpHl0OocIfIuQqU877Cycb1QnGL5Vkbcd3JcIs4+mOejso09lcinaOvtApeLrhMveSXq5Qq2QFhq0PT2B1Ss4'
        'rKKJvyerNQcR3OIhhxVVNHgnElTE5P8AiX9NFyPyGvv5g9tvF5kl73+kNbOGHMCdFHuMIfy0SjClLpk3X2jtRaqOmm+SguxMi8g8dUFPrjOpUpPVdDNR/wBq'
        'KC0GX5Y6Cv2KDzWnkwf8Tapt51NRIDHZ7wlWrRWmqcP+BZIwAcebF+utWNMWGuQRbNcpah/9XKZnJwZJJEUE+h389a9FL2jUfAK1prnP9ZstogjUHDzSCTf7'
        'fMfy1LlFZSZSi+COtQ1caBCvDsdORyBj8PHBGhSj51FqXkBgSrnUrS1VhECj5tsQVj6Et4aqsNUwpLijNXFGshNS1krJVIxEtXEMnwJ5YJ99VGWGFUS1pgae'
        'ptyxkyUNseUc3EUcRGPcL9Nb1q4NjRcETVraWlYpDZoacvzxTwocfUrqvWeLkSkloZivEVD39QtjqWLNtOTDzPouCdLTeF41dboa13Frok2y0yKQcgsVQAfl'
        'qZK68WKdcka7x2rEhqAaKAdC+zbn1bbn20aVWI64lFPgKWQkXOCJ5Wx3aFySfAnC4Goq3oUrq1GBQUFUTFLeI1UncVJkG76AaLzWKRmk82NLZ6BYs/eNdLGh'
        '6QpUsffkNa/LgjUXEVqLVR003yUF2zIOQeOqCn1xnSpSeq6EtRFBaDL8sdBX7FB5rTyYP+JtU286mokBjs94SrVorTVOH/AskYAOPNi/XWrGmLDXIItmuUtQ'
        '/wDq5TM5ODJJIign0O/nrXope0aj4BWtNc5/rNltEEag4eaQSb/b5j+WpcorKTKUXwR1qGrjQIV4djpyOQMfh44I0KUfOotS8gMCVc6laWqsIgUfNtiCsfQl'
        'vDVVhqmFJcUZq4o1kJqWslZKpGIlq4hk+BPLBPvqoywwqiWtMDT1NuWMmShtjyjm4ijiIx7hfpretXBsaLgiatbS0rFIbNDTl+eKeFDj6ldV6zxciUktDMV4'
        'ioe/qFsdSxZtpyYeZ9FwTpabwvGrrdDWu4tdEm2WmRSDkFiqAD8tTJXXixTrkjXeO1YkNQDRQDoX2bc+rbc+2jSqxHXEop8BSyEi5wRPK2O7QuST4E4XA1FW'
        '9CldWowKCgqiYpbxGqk7ipMg3fQDReaxSM0nmxoWegWLP3jXTRoekKVJPvyGtflwRqLiOVXHdVTU0ay1NHI2PmLNLiPyxz5nQoVeCJboQ5uLpqio2rfLbTr6'
        'xyOD/wA+OruUXssL1XmN1Fes38N73a2VhjvI6SZgD58tSl+l8y6+YKC3VTviHiag7voVFA/5dNVVaw6m/kpQ8PV/dK9PfqNnK81W1Fvyzjnri5RrRx6l0byf'
        'QZtvBzLCkclXVUsmCwiFBEqyf3lBJOplaRrl1FRZRp7HNSSYMNbXzbeeO5hQDwPTWvJ+RrrNVDGjgieClgkbAaQSywnHLny26yo9QxJs13rKmOV/ulEi/E7/'
        'ABCLjA5HAAHTTRZJjV8BJeJq+GUtFCBCw6jdIy+TcuXPVXE0TeaZxuIKmRe9aRl2nGViKD3zouLIb1RKLiaWarMcq1k7r/NsLqf2xq+zSVcCL+NGMxRVddLi'
        'QIwb51jKBOnv5eeh0RWLKDWi97kMREW5ss3eDp4D21CcXmOOhUhhvjVALTUTSpzUNXBcA+GP8tTSIVdAFxut4oJWDV1sXlnu0qmfafpq0ovRgTqrjuqpaZFl'
        'qaOR8fMWaXEfljn11ahV4IhuhDm4umqKjat8ttOvrHI4P/Pjq7lF7LC9V5jdRXrN/De92tlYY7yOkmYA+fLUpfpfMuvmCgt1U74h4moO76FRQP8Al01VVrDq'
        'b+SlDw9X90r09+o2crzVbUW/LOOeuLlGtHHqXRvJ9Bm28HMsKRyVdVSyYLCIUESrJ/eUEk6mVpGuXUVFlGnsc1JJgw1tfNt547mFAPA9Na8n5Gus1UMaOCJ4'
        'KWCRsBpBLLCccufLbrKj1DEmzXesqY5X+6USL8Tv8Qi4wORwAB000WSY1fASXiavhlLRQgQsOo3SMvk3Llz1VxNE3mmcbiCpkXvWkZdpxlYig986LiyG9USi'
        '4mlmqzHKtZO6/wA2wup/bGr7NJVwIv40YzFFV10uJAjBvnWMoE6e/l56HRFYsoNaL3uQxERbmyzd4OngPbUJxeY46FSGG+NUAtNRNKnNQ1cFwD4Y/wAtTSIV'
        'dAFxut4oJWDV9sXlkRpVM+0/TVpRejAj1VIlDTMjXu0wKn4z3Iyw8eZPPVrF+ywf7ifwlpKl346t1KgH+wCbhy9uuqrLLs2GHzHyV9rTbDTcW1j4HOSJQCw9'
        'OX1Ot6yzgNV8xynu9ibZE964jrirbmxIQHP5dNLU+CQJx4sfqKixSqGSj4tlROZ7uqUBvUgnrrk1LiuRdVwYs8tkeSKVrFfJIyPlapq03/TB5aVGdKXlyF3e'
        'DD0hold5Kax1kO4YVJ5RKR9c6HXWQYLJGklqV7uQRpCIznaaKMg+5J0OmQ4jkl7nePaKwLEgJGzuUTPkDjnoUVwNUFU8RMgBS+SxoQd0ZqByP/yrpUf0g35k'
        'qS7UkSxk1iMx5hRM8gP6dNXdfAKriAS8UEkikRkbOTJAso3++R4aqjoTgVIqkrOu6jpZhGuV+InyGU9QCOhGophmIc3yVpNkdlsiKBlDJWMc/kNa6uLNXyGG'
        'o7jeYZAlp4dWQEFZO+ZgDnmDy8vHR6qebGreiE5+GKxxtmr7TSs5yy00ZOB5DJ66b0dKhRvMHVUqUVMyNe7TAqfjPcjLDx5k89KxfsszyzE/hLSVLvx1bqVA'
        'P9gE3Dl7ddVWWXZsMPmPkr7Wm2Gm4trHwOckSgFh6cvqdb1lnAar5jlPd7E2yJ71xHXFW3NiQgOfy6aWp8EgTjxY/UVFilUMlHxbKicz3dUoDepBPXXJqXFc'
        'i6rgxZ5bI8kUrWK+SRkfK1TVpv8Apg8tKjOlLy5C7vBh6Q0Su8lNY6yHcMKk8olI+udDrrIMFkjSS1K93II0hEZztNFGQfck6HTIcRyS9zvHtFYFiQEjZ3KJ'
        'nyBxz0KK4GqCqeImQApfJY0IO6M1A5H/AOVdKj+kG/MlSXakiWMmsRmPMKJnkB/Tpq7r4BVcQCXigkkUiMjZyZIFlG/3yPDVUdCcCpFUlZ13UdLMI1yvxE+Q'
        'ynqAR0I1FMMxDm+StJsjstkRQMoZKxjn8hrXVxZq+Qw1HcbzDIEtPDqyAgrJ3zMAc8weXl46PVTzY1b0QnPwxWMNs9faKVmOWWmjPIeQyeum9HSoUbzPLJxF'
        'b4kkU01GCo+Vo6YSZ8+WvRdlxITRqK6GtkDxW0VCBcAiniiVfb/jqWqZsU08kcqHeZ1Q0yRc+slQoVfyHM6lLzKw4GXlgSXbI1MykYASokOPfl00pPMKpBVt'
        '1JUsHa6TUzAbCscfyHyJ3Hr661WtDUT1KtLwtSIdj3askbqQrxgYPt09NS5POhkvMZm4Ns7SIXNwq48fMxrQBn1xz1PaSXAbqEaqwWWjeRpYKNYUOFgmqJCf'
        'ZjnmdN+b1Ndis0BilsqxnurZTNKAcIlVtjx7sOQOl39Wb1dETpeJLYCncladwCMAbx+YHM66XJE1joaprvmKL7vWSp+bOAhT9TocPmwG9wKm/iCTYdtPTxtj'
        'KyTM7N+Q1FLNG9dizWW8AkPWJFIx3fw6VmHp8zcs+GqUocApLiYktVXNCHF2rqhwSGhjSKAjzwcapSin7KJab1Fms1NUPHDNFWSgnaWqLixP+FMDGntGsVTk'
        'ZRTzA1TW6zTOojolZiEAmJOznzI59capOUlqS7sRhOIrfEkimmowVHytHTCTPny1N2XEtNGoroa2QPFbRUIFwCKeKJV9v+OpapmxTTyRyod5nVDTJFz6yVCh'
        'V/IczqUvMrDgZeWBJdsjUzKRgBKiQ49+XTSk8wqkFW3UlSwdrpNTMBsKxx/IfIncevrrVa0NRPUq0vC1Ih2PdqyRupCvGBg+3T01Lk86GS8xmbg2ztIhc3Cr'
        'jx8zGtAGfXHPU9pJcBuoRqrBZaN5Glgo1hQ4WCaokJ9mOeZ035vU12KzQGKWyrGe6tlM0oBwiVW2PHuw5A6Xf1ZvV0ROl4ktgKdyVp3AIwBvH5gczrpckTWO'
        'hqmu+Yovu9ZKn5s4CFP1Ohw+bAb3Aqb+IJNh209PG2MrJMzs35DUUs0b12LNZbwCQ9YkUjHd/DpWYenzNyz4apShwCkuJiS1Vc0IcXauqHBIaGNIoCPPBxql'
        'KKfsolpvUWazU1Q8cM0VZKCdpaouLE/4UwMae0axVORlFPMDVNbrNMyiOiVmKxgTEnZz5kc+uNUnKS1Jd2IBbhKiHLSQRYCssUYySfDl+w1LRSDNR22aPEtb'
        'GmRyMkbBg3gdTWS0LonqUTYqD4X5q6TcB0gp2OT6f8dCk3oLiggstL8PGY56l3zlnenY/p/lrVdQoUKKkt0coDrX1LYxIFoevuT10NOmBqlRYqal7ySGCsSk'
        'YgMi0ah/3/TU4vCoZHnOKrn8NEqUEMyZOWldEQgeSjOukIY1kDlgeJErVcjpVXI08e7PeSkcgfDI6H116HRLBHKlcGz0Vr4ft0347uauLoTlefn1GuEpyXu0'
        'O8YLiehhtlipj3ZlgeXHy8wz/T2153K0eJ0UY5F2lrrPHCpmrHTZgLulABPt0z6a5u89BdCXcr29fVOhradokxtCyKDj1I8fbXVQosjm5ECvrpYCX3SmI9Ga'
        'Rjka7RjU5uTJUlyr7p3fw0eQCQHchUA8z4n212UYxzObbeQWLhi6SOHmrJZIcZMFMpQDP8wI/bWvx0QXZPNn0lnhtFOzx26NmYci4LSOfL5vHU3nLBsu6loY'
        'W4Sohy8kEWArCKMZJPh/5alxKTDNR22aPEtbGmRyMkbBg3gdTWS0LonqUTYqD4X5q6TcB0gp2OT6f8dCk3oLiggstL8PGY56l3zlnenY/p/lrVdQoUKKkt0c'
        'oDrX1LYxIFoevuT10NOmBqlRYqal7ySGCsSkYgMi0ah/3/TU4vCoZHnOKrn8NEqUEMyZOWldEQgeSjOukIY1kDlgeJErVcjpVXI08e7PeSkcgfDI6H116HRL'
        'BHKlcGz0Vr4ft0347uauLoTlefn1GuEpyXu0O8YLiehhtlipj3ZlgeXHy8wz/T2153K0eJ0UY5F2lrrPHCpmrHTZgLulABPt0z6a5u89BdCXcr29fVOhrado'
        'kxtCyKDj1I8fbXVQosjm5ECvrpYCX3SmI9GaRjka7RjU5uTJUlyr7p3fw0eQCQHchUA8z4n212UYxzObbeQWLhi6SOHmrJZIcZMFMpQDP8wI/bWvx0QXZPNn'
        'ZLPDZ6dnjt0ZZhyLgtI58vm8dS5OWDZd1LQdqoyzCS4WyuikZvlljbcnoMAcuXL11C4RaOn7o+evoFURxxU1I5zunkjk3HHgD0HrqWpa4lJoXN+uEZAir0Cr'
        'y5yZAHnzGqUVwC8+IKS9V1Vl6e+iasUkhhUbQPQrjpqklrHAh1eTOx3W+1MnO709CmMbkbvXJ8dueQHrqmoLJVJ9Z5soJa56t1R7xVTuFyXkdRn8j11zv090'
        'pxwzGxwXS1UO+aL4ojkfkMhY+w1LtmsnQtWaehOrOBqiod0gtbwRogBaoptpJ9D4jSrVLNmuaJCb8OXqyTKxphFCD8x7wMPpj9Brp2kJo53JRCJXVklXE0kN'
        'hkfae7WppZEYL/v9AT+upajTUVJ10PRUdLea+lAhpbAQ5wEySo9z6a87uJ4tnasmskaXhG60sr9/BYdxOQYojuz5ddX2kHk2RdlqkLQW+qw0FUttqKNDlgC4'
        'wP8Aj5atuOlakpPJ0JUvDPel5YUpqXDHYIp2b5c9T5HzGr7TjiRc4FCS33ymp1SnC1CRLnHed2T/AMR6a5pweZdGsjRud5qJEWttSzyfyyd6CSPEE6Go6SFS'
        'eqEaqMswkuFsropGb5ZYm3J6DAHLly9dWuEWjfuj56+gVRHHFTUjnO6eSOTcceAPQeupalriUmhc364RkCKvQKvLnJkAefMapRXALz4gpL1XVWXp76JqxSSG'
        'FRtA9CuOmqSWscCHV5M7Hdb7Uyc7vT0KYxuRu9cnx255AeuqagslUn1nmyglrnq3VHvFVO4XJeR1GfyPXXO/T3SnHDMbHBdLVQ75oviiOR+QyFj7DUu2aydC'
        '1Zp6E6s4GqKh3SC1vBGiAFqim2kn0PiNKtUs2a5okJvw5erJMrGmEUIPzHvAw+mP0GunaQmjnclEIldWSVcTSQ2GR9p7tamlkRgv+/0BP66lqNNRUnXQ9FR0'
        't5r6UCGlsBDnATJKj3Pprzu4ni2dqyayRpeEbrSyv38Fh3E5BiiO7Pl11faQeTZF2WqQtBb6rDQVS22oo0OWALjA/wCPlq246VqSk8nQlS8M96XlhSmpcMdg'
        'inZvlz1PkfMavtOOJFzgUJLffKanVKcLUJEucd53ZP8AxHprmnB5l0ayNNc71UOi1tqWeTHyyd6CSPEE6KR0kKk9UTlt1wZDEhv0AT5VRK5HUDXW+vLkRcfm'
        'FjtFdTKskcVfCI1JctUK24Y8R+vrqG0+B0WAt8bWNOp+762cthiwiA3L4AjPMaFFUzQXnXIPW3GQRq5t1aykc0FCCx9A3jqox0b6hJ+QG1XCeoXatPVUSkc1'
        'eAAL+Q1U1TWpKddAi0duppS8ix1EQPNZImG1vMEddTWTRVEW6W601K6mOaOgOMJ3VQ6FD45z11yabzxLTSKbVtRXQmGHjGUOw5q1QvyjHqOWuaVM4F5+8Dqq'
        'S5RRrJHxBTzSAbS8rROuPLI8dZOLfsmo+Jn7ouVWhaS4WKcN1apnH/6g6qsVoyaS8hBuB2h/j/H0dM/Qii3AH6eOq7VZUf8AIOzpiKwcFz4dYbpWxhz82KXf'
        'n6t4+uqdquCJ7Ouph7dV0UaU63BKyeNjlai2SRqfLmOp03k3WnUKNYVr/AVVro0KrS29pJeTMGePn6g/pobVc2ViDSjuVA/cyI0u4fhhrdyjn0II66qqeRFG'
        'gtVbqitp0ElLWKR+P+tqjHHny/XQpJPMc9CYtuuLRmNGv0AT5VRK5HUa6Oa8uRNx+YWO0V1MqyRxV8IjUly1QrbhjxH6+uobT4HRYC3xtY06n7vrZy2GLCID'
        'cvgCM8xoUVTNBedcg9bcZBGrm3VrKRzQUILH0DeOqjHRvqEn5AbVcJ6hdq09VRKRzV4AAv5DVTVNakp10CLR26mlLyLHURA81kiYbW8wR11NZNFURbpbrTUr'
        'qY5o6A4wndVDoUPjnPXXJpvPEtNIptW1FdCYYeMZQ7DmrVC/KMeo5a5pUzgXn7wOqpLlFGskfEFPNIBtLytE648sjx1k4t+yaj4mfui5VaFpLhYpw3Vqmcf/'
        'AKg6qsVoyaS8hBuB2h/j/H0dM/Qii3AH6eOq7VZUf8g7OmIrBwXPh1hulbGHPzYpd+fq3j66p2q4Ins66mHt1XRRpTrcErJ42OVqLZJGp8uY6nTeTdadQo1h'
        'Wv8AAVVro0KrS29pJeTMGePn6g/pobVc2ViDSjuVA/cyI0u4fhhrdyjn0II66qqeRFGgtXbqitplElLWKR+P+tqjHHn/AMdCkk8xpUgzT3L5GgvFKQBtyKBg'
        'W9QQddUorOPUhuWjPqP4kRymS50c8ZPQz4fPj1/bQ6aIU3xNQVd0jSTvJAmeQ+GlTLg+p6e2hqOgpy1Y4kdzYLtNwafoqrUqy/kPDRVeRsdB1Z7gpRJTXxqQ'
        'NxjqVQBvAEEZ1LppQatHI6q87yFSSnjQ53tOGPpnA0O4KbLKXaqYR75Z5XwCwNXEAfQApri0jrVjj1qPTyNL38czjASNoZDIfLIHXz1KFfsAarCondW65NE3'
        'J90lMB7bT104av6hXyEqmKyVG7vrZMkyt8zvQwyfkY2B/TVpzWT+pHq6onuLR34KQiN8Bk7ymmTcM9RtY/lqvX49UT6p0zWwR4mkcyH+ZJaleXmOX6ayv6f9'
        'DWKzNz1sVOqpBeLvRoBzalld0A8BucZHvqkm80gr5sUe7RFZImvNzdcbi88aSbh9P89Vd/SgrTURS91dMJXF0mZGXKxmjZw5HReQ6fXV3U8KdSLwBLlU1MXe'
        'z8RQRSOQTE1CVKt4DBOquqvs9SVL9Rqae5ZRoLxSsANuRQMC3qCDqUo6x6lNy4nKP4kRymS50c8ZPQz4fPj1/bWdNEKb4moKu6RpJ3kgTPIfDSplwfU9PbQ1'
        'HQU5ascSO5sF2m4NP0VVqVZfyHhoqvI2Og6s9wUokpr41IG4x1KoA3gCCM6l00oNWjkdVed5CpJTxoc72nDH0zgaHcFNllLtVMI98s8r4BYGriAPoAU1xaR1'
        'qxx61Hp5Gl7+OZxgJG0MhkPlkDr56lCv2ANVhUTurdcmibk+6SmA9tp66cNX9Qr5CVTFZKjd31smSZW+Z3oYZPyMbA/pq05rJ/Uj1dUT3Fo78FIRG+Ayd5TT'
        'JuGeo2sfy1Xr8eqJ9U6ZrYI8TSOZD/MktSvLzHL9NZX9P+hrFZm562KnVUgvF3o0A5tSyu6AeA3OMj31STeaQV82KPdoiskTXm5uuNxeeNJNw+n+equ/pQVp'
        'qIpe6umEri6TMjLlYzRs4cjovIdPrq7qeFOpF4AlyqamPvZ+IoIpHILRNQlSp8BgnVXVX2epKl+o/Fl7VO0mGUSrwTfA6/hb4KX5fyGvsPZNlfxVzR8f0vak'
        '/wDC+QcdsvaO0exuzWuqx1Pe2eRiT5k7dT6Hsvjrmh9N2nwHyCU/blx3S0wgk7LKxuZO77hlz+edS9g2duq2hc0XHb7dLGwfIA/b7xwZvm7KpJdn4R9yT/kc'
        'Nqlu/Z/+QuaIe8bfwHyZz/tK8eU47t+yyNnI+XfZqlG9uT89V3bs7+P1RPeVv4L5MDJ9pPjp0YHsliEh/nFvrAR9N+NPduz/API6oO8rfwOjA1H2iuO6hBs7'
        'M5qdh/LFQ1WCfP8AFoW7dnWduuaKe8ren+B8mLt9oDtCLDvOy2SWPbtCtR1i8/PkdX3bsvj9UQ95bT4HRgZO3TjppAx7KZAhBzGaas2E+DY89Pd2zf8AI+hP'
        'eO0vHsH1AN218XnIPZGyv5rT1YwfPVd32C/+x1Qd4bR4H1N0vblxxDu3dmVUxPMlYKtT78tD3fszyt1zQreG0rOwfJh4u3jjT5dnZfXEDqdtaxP66nu7Z/8A'
        'kL+o94W/gPqdHbJxhUBu97Or3Gh/kigqmA/PT6DYLK2XNG9PtXnYvkwc/atxb3m49nV3VfBJKCbn6k4ydPodh4y5ofTbZ/BfJh4u13jcKyU3Z9dKUvggQ0dU'
        'MHzxjGpex7PrbLmhW22+SsXyY2vHvaIrrOOAr4rDmsht8pI/MaFYbNl2q5j6RtGfZPkFXtU7SYZRMOCb4HX8LfBS/L+Q1L2TZWv8q5ofS9qTr2L5Bx2y9o7R'
        '7G7Na6rHU97Z5GJPmTt1Poey+OuaH03afAfIJT9uXHdLTCCTssrG5k7vuGXP551L2DZ26raFzRcdvt0sbB8gD9vvHBm+bsqkl2fhH3JP+Rw2qW79n/5C5oh7'
        'xt/AfJnP+0rx5Tju37LI2cj5d9mqUb25Pz1Xduzv4/VE95W/gvkwMn2k+OnRgeyWISH+cW+sBH0340927P8A8jqg7yt/A6MDUfaK47qEGzszmp2H8sVDVYJ8'
        '/wAWhbt2dZ265op7yt6f4HyYu32gO0IsO87LZJY9u0K1HWLz8+R1fduy+P1RD3ltPgdGBk7dOOmkDHspkCEHMZpqzYT4Njz093bN/wAj6E947S8ewfUA3bXx'
        'ecg9kbK/mtPVjB89V3fYL/7HVB3htHgfU3S9uXHEO7d2ZVTE8yVgq1Pvy0Pd+zPK3XNCt4bSs7B8mHi7eONPl2dl9cQOp21rE/rqe7tn/wCQv6j3hb+A+p0d'
        'snGFQG73s6vcaH+SKCqYD89PoNgsrZc0b0+1edi+TBz9q3Fvebj2dXdV8EkoJufqTjJ0+h2HjLmh9Ntn8F8mHi7XeNwrJTdn10pS+CBDR1QwfPGMal7Hs+ts'
        'uaFbbb5KxfJja8e9oius44CvisMFZDb5SR+Y1K2fZsu1XMfSNoz7J8j9afiz7T1HKFnHCcTEbtv3rTjHviU6+f2O63rLke3tN48I8wicZ/adnCEUnB7Z/mNw'
        'jOR6/wAbR2G61rLl+DdtvLhHmdqOKftPRRNI83BMEYOP/WMXy+WP4ulWO6v1cjO13l+nmIzX77UMYMi3HhSn6jfFdIkP5mXVqy3UtJcvwTf3m/l5k9+O/tT0'
        'rYF7s2VGc/ecZ5e5k1Sst0vSXL8A570/TzNw9oX2rKlwiVlln5ZybhDg/wD5eus7HdCzvcvwZWu9dFHn+ROt4n+08JJKiqmsNO2efeXWJc/Tv9UrPdOUb3L8'
        'Eue9M2o8/wAgqbtC+04oxBc7EpBxuF2hBPpzm1XYbq1UuT+xu13pkrvP8hh2qfaopZgpv1oc8+RukDD/APro7HdL0lyf2Jv7zWkea+4FO1L7Uk0veC8Wsluq'
        'tdIQD64Munsd1JZS5P7GVpvTS7zX3O1HGv2oCyvJVWVWk/nFyh5+/wDG0Kz3V+rk/sV2m9eEef5Ax8a/aclCpBW2bcx5CK5w5Y//AHtPZbqXzcn9g7Xen6ef'
        '5Ktu40+1XA7RhbLUkDJeproW2/XvhqJWW6OMuX4FT3rwj/v8jJ7UvtRS57un4WLA4/h1ETHl/wDWOp7DdK1ly/BV/enyx/3+Q8PaD9qhiJX/AKNbTy2S1sCr'
        '+Xe6l2W6uMuX4KU956xjz/If+nf2ozN3aU/B8hI/EtdAcD3M3LW7LdVMXLl+Av7yrlHmdk4s+09RyhZxwnExG7b9604x74lOp7Ldb1lyK7TePCPM2nGf2nZw'
        'hFJwe2f5jcIzkev8bR2G61rLl+DdtvLhHmdqOKftPRRNI83BMEYOP/WMXy+WP4ulWO6v1cjO13l+nmIzX77UMYMi3HhSn6jfFdIkP5mXVqy3UtJcvwTf3m/l'
        '5k9+O/tT0rYF7s2VGc/ecZ5e5k1Sst0vSXL8A570/TzNw9oX2rKlwiVlln5ZybhDg/8A5eus7HdCzvcvwZWu9dFHn+ROt4n+08JJKiqmsNO2efeXWJc/Tv8A'
        'VKz3TlG9y/BLnvTNqPP8gqbtC+04oxBc7EpBxuF2hBPpzm1XYbq1UuT+xu13pkrvP8hh2qfaopZgpv1oc8+RukDD/wDro7HdL0lyf2Jv7zWkea+4FO1L7Uk0'
        'veC8WsluqtdIQD64Munsd1JZS5P7GVpvTS7zX3O1HGv2oCyvJVWVWk/nFyh5+/8AG0Kz3V+rk/sV2m9eEef5Ax8a/aclCpBW2bcx5CK5w5Y//e09lupfNyf2'
        'Dtd6fp5/kq27jT7VcDtGFstSQMl6muhbb9e+GolZbo4y5fgVPevCP+/yMntS+1FLnu6fhYsDj+HURMeX/wBY6nsN0rWXL8FX96fLH/f5Dw9oP2qGIlf+jW08'
        'tktbAq/l3updlurjLl+ClPeesY8/yH/p19qNpu7Sn4PckfiWugIA9zNy1uy3XTOXL8Bf3lwjzC0lrtTybu+pnTbmRIqBmY/3SMa8cpy/1n0VGOaN22wUcZl7'
        '2rgigUEx4iMb5J6cxzA1V9si6kFqLDRMkaiamwpLENCxGPcDw1u0aG6mbqLLSTNEJmstTuG1TMZV2j15aFN6VKuryFpLbQQ04Ie17EYfwoZ2bf8AQr0035V1'
        'NdXA2a239yFnp7SueSkVCZHt0JI1k5VwqbDyEZ6DhyWlZjmSdWyGQxjb7Hnq1KaZzuxA1NhtVVTkJS10lVtJUp3Uqkegx8pOm/JahcT0Cw2emFIvxFnukT4+'
        'YR0UTIcfXl7ai+64SXMq6qYoah4WoJwkx4frpM9GS2Rsc+p38tDtZVpf6ioReN0Zg4YNPK5jsdzM5yoiazIV2nl+INy0O0qsZLma7+noDThCkldkm4bqIp1I'
        'YVENBtCjz/Fy9jrdq1lPqa4nnE5UWGkp5goo5jExxIhoEOT6Dfovt69S7qWhiqho4GCLTmkckYcW0IRjyw356ItvWv8AJnRaBIa2gafEjRiQnCJLbc5Hhjrq'
        'mpUw+pKarRn1VDSPIXMdIVHM95QlM/ppjJrKvMGkCpLXamk3CamdNuZEioGZj/dIxqZWkv8AWUoxzRu22CjjMve1cEUCgmPERjfJPTmOYGqvtkXUgtRYaJkj'
        'UTU2FJYhoWIx7geGt2jQ3UzdRZaSZohM1lqdw2qZjKu0evLQpvSpV1eQtJbaCGnBD2vYjD+FDOzb/oV6ab8q6murgbNbb+5Cz09pXPJSKhMj26Ekaycq4VNh'
        '5CM9Bw5LSsxzJOrZDIYxt9jz1alNM53Ygamw2qqpyEpa6Sq2kqU7qVSPQY+UnTfktQuJ6BYbPTCkX4iz3SJ8fMI6KJkOPry9tRfdcJLmVdVMUNQ8LUE4SY8P'
        '10mejJbI2OfU7+Wh2sq0v9RUIvG6MwcMGnlcx2O5mc5URNZkK7Ty/EG5aHaVWMlzNd/T0BpwhSSuyTcN1EU6kMKiGg2hR5/i5ex1u1ayn1NcTzicqLDSU8wU'
        'UcxiY4kQ0CHJ9Bv0X29epd1LQxVQ0cDBFpzSOSMOLaEIx5Yb89EW3rX+TOi0CQ1tA0+JGjEhOESW25yPDHXVNSph9SU1WjPqqGkeQuyUhUcz3lCUz+mmMmsq'
        '8waRep+/nfIo5T0JeOvaEEeuOevNRavod8dCzQlKn5o7XV1xTKrEL6nJumSHGcafVWf0Jak8glNRVj/EItuvffRDc6CvhcKPTz9tS3HDFCq61E47fKwaV6Di'
        'mGnA5sKZGH5ddNUtUOPmDiqKHvSe+4gplA/HU2p1z6AgctDTppzNeXnyIdWaCoidGvss4Vs/NbtpQZ6ZZeX+euivJ+z1IbT16Gaijt9VTKkF7pIEk5FpaCN9'
        '2Oe0HAxrJtPGPUzSawfQp0NLE0kKpd7My7cZa2qBy9mzobwdYvmWl5jVPRVs9YYozw5Ii88ywOUI9g2prFKtGbGtKorw2m6imPd2rhuJFJZe775Nx8z836a5'
        'Xot6lUfkDFJeqkO6cN2RivyoO/qm8efIMNXegtWRSTyFazhe+yzrJ9z0Stj+zpWkTJ8zuc5+ut2kOJShISm4MvgrA1Tw9QGn28wRKWXl4EHnp7SFM3U12XDA'
        'Vm4fdKlKaqsVDAWHed4IJXyvpk6VNUqpA4vJoD8DHHIBJb6QyMSSyULDZz8Mtqr1cn1Iu+QxM8Qpss0MQ3Aq4pnVnPvk51GtDo8j6n7+d8ijmOcEvHXtECPX'
        'HPTRLN9Ax0LNCUqfmjtdXXFMqsQvqcm6ZIcZxp9VZ/QlqTyCU1FWP8Qi26999ENzoK+Fwo9PP21LccMUKrrUTjt8rBpXoOKYacDmwpkYfl101S1Q4+YOKooe'
        '9J77iCmUD8dTanXPoCBy0NOmnM15efIh1ZoKiJ0a+yzhWz81u2lBnpll5f566K8n7PUhtPXoZqKO31VMqQXukgSTkWloI33Y57QcDGsm08Y9TNJrB9CnQ0sT'
        'SQql3szLtxlraoHL2bOhvB1i+ZaXmNU9FWz1hijPDkiLzzLA5Qj2DamsUq0Zsa0qivDabqKY93auG4kUll7vvk3HzPzfprlei3qVR+QMUl6qQ7pw3ZGK/Kg7'
        '+qbx58gw1d6C1ZFJPIVrOF77LOsn3PRK2P7OlaRMnzO5zn663aQ4lKEhKbgy+CsDVPD1AafbzBEpZeXgQeentIUzdTXZcMBWbh90qUpqqxUMBYd53gglfK+m'
        'TpU1SqkDi8mgPwMccgElvpDIxJLJQsNnPwy2qvVyfUi75DEskS02WaGIbgVcUzqzn3yc6jWh0eQ8tyqWICmh75gNsi08bAr5cm8fLRcRr43BV32SFo1ksjqn'
        'P57Yqvj3z4eetSCxx5hWTBz1FbCkcVXRWR42YFcxtGCT48j+ulKLybM66h6gNsJamoyIz8yw1soyfTnz0YCkxillq0kT4ZrrEj9AtzDxr6kE51GGtORWPmAp'
        'Ki9QwiJbhcGiyctWwI4Yk+eqai8aIE5cRl7o4iEFXWWqeRHwKaagwVx5ldFFWqTBtg2mglX4hLTwvMh+YrKsiZ8x15Aa3lVlfwgLvaHcmt4G4fl3/KHgq5QQ'
        'TprJZTZFIt4xQqtRw1EBIeCKSPB2lo6yQY58j8x8dNZ/Oa7Fe6EFbw8HY/0XB65IqsgY6/kOZ0ev8w0XABPNw+J073hmsp425ZhVpT78j+nrppJ5SCsVmhSo'
        'NggLfDW26RE+MiSgD1wW1XrvNo3q6IE9TaizLNdKijZgMF4pQW+vh/10UlnQaxyqM7rVBSK8d9r1kB+dSSVPqoIyNakn7qHDizJ4k7uDfS8QySwxdUdUkUDP'
        'kRkaez4xJv4YMYFyqWYBTQ983JZFp42G3y5N1Plqbi8xvjcFXfZIWjWSyOqc/ntiq+PfPh561ILHHmFZMHPUVsKRxVdFZHjZgVzG0YJPjyP66UovJszrqHqA'
        '2wlqajIjPzLDWyjJ9OfPRgKTGKWWrSRPhmusSP0C3MPGvqQTnUYa05FY+YCkqL1DCIluFwaLJy1bAjhiT56pqLxogTlxGXujiIQVdZap5EfAppqDBXHmV0UV'
        'apMG2DaaCVfiEtPC8yH5isqyJnzHXkBreVWV/CAu9odya3gbh+Xf8oeCrlBBOmsllNkUi3jFCq1HDUQEh4IpI8HaWjrJBjnyPzHx01n85rsV7oQVvDwdj/Rc'
        'HrkiqyBjr+Q5nR6/zDRcAE83D4nTveGaynjblmFWlPvyP6eumknlIKxWaFKg2CAt8NbbpET4yJKAPXBbVeu82jerogT1NqLMs10qKNmAwXilBb6+H/XRSWdB'
        'rHKozutUFIrx32vWQH51JJU+qgjI1qSfuocOLOf0j7uEPS8QySwxYyjqkigZ8iMjT2fGJN/DBnl5J4IKh1qrfJBBnlIIAFPuV/PXpUW1gzhVJ4obZ7dcDG0c'
        'cSKTj+2kDehwTqaSjmV6reAZrdFSd5HFUS06Dnymyo8wM6i83mNEh/bU1BVlrY2VVyiSU7Dn4n5PPXKqWh0o+J2mvqUxZZqQtLtyz06rIMfXBHtrONcUwUuK'
        'KtPdrVWIhkdceCudm33B8da7KI1iytVJaKpVLdxGxGDKWCsyjxyP31y9ZF0ixOXh7h+FX+JggneYbg8VWH5Y64HTVKc9H0NdiKJwpwU+wwS1sJP/AL44/Px1'
        'TtLVcCVCBiThu1rIUjq6tFOTteRZUPqef5aL8nwG7FagqizimhLJVSbRyUtKsYcdOgPTw1SddAoLVP3lEoKVlZGchMxBZQTjkoJ66Uo8CavRkqaO7u5Mlwqi'
        '78h3kKDGB4e366v1VoFHxBw2e9TU3evNG4bn/Hj2k+R5cs+mm9CtKGpLiGlsl1BWYtTNO42hZZiowPAeo/XQpRyGjCtZ66AK89EiMCA8wIdfPB5Y9eeteTyY'
        'UpoSXnp4ahxVW+SngzykEACn3K/nrqotrBnJtJ4obZ7dcDG0ccSKTj+2kDehwTopKOZXqt4Bmt0VJ3kcVRLToOfKbKjzAzqLzeY0SH9tTUFWWtjZVXKJJTsO'
        'fifk89cqpaHSj4naa+pTFlmpC0u3LPTqsgx9cEe2s41xTBS4oq092tVYiGR1x4K52bfcHx1rsojWLK1UloqlUt3EbEYMpYKzKPHI/fXL1kXSLE5eHuH4Vf4m'
        'CCd5huDxVYfljrgdNUpz0fQ12IonCnBT7DBLWwk/++OPz8dU7S1XAlQgYk4btayFI6urRTk7XkWVD6nn+Wi/J8BuxWoKos4poSyVUm0clLSrGHHToD08NUnX'
        'QKC1T95RKClZWRnITMQWUE45KCeulKPAmr0ZKmju7uTJcKou/Id5CgxgeHt+ur9VaBR8QcNnvU1N3rzRuG5/x49pPkeXLPppvQrShqS4hpbJdQVmLUzTuNoW'
        'WYqMDwHqP10KUchowjWeugVXnokRgRvmBDr54PLHrz1qp5MKU0NI9Z3hporjHCZCWkiWkJB88ZP6aqipVrqRV5JjX3OKyMmealkQdZPgiB+YOov0eH1Lu1zI'
        'dRYYKWUyw3eGnkD8kk3IoHtz5a7X28HE5uNMmDS9EsUnq1RXbYJIZCFb3IHLPnrdnwQKejLVripqMxSotNL82JVklfkP7uRzPnnXGVXhU6rDGhUuF8gqpFFR'
        'RwSQH5FWVfl/bnojFrJi2tUTK+3WakVJKWeiimY8446l8bfVcctWpTeZDUVkT4O6qWaNa2NJgflEZkAx9F1bqtAquJpLQSU7mskmjLbQVcuqH2K51qrVGo9G'
        'YrOGqqP+GKuZz+Lmgz9enLSpx4BdlxMw2y6iJu7rEVuiZgUgnxB5/XQ5QrijJSpgzSrc4XRJbnCNo5BqAk+ucN101g8l1BKer6FSlt1xudMpNyiV1+bElvLY'
        '8ue7prjJxi6U6nVXnr0G1gvCLGBcqAAnAEltkIB88A6lXM6PmV63HoHqaa+kNTvX26TPJl+6mG0f4tZXM6PmDvavoarIb+tF8O1bbJIUwe6NueNjjp8245+u'
        'snZ1rR8wd/iuRDR6zvDTRXGOEyEvJGtISD54yf011os2upCbyTGvucVkZM81LIg6yfBED8wdRfo8PqXdrmQ6iwwUsplhu8NPIH5JJuRQPbny12vt4OJzcaZM'
        'Gl6JYpPVqiu2wSQyEK3uQOWfPW7PggU9GWrXFTUZilRaaX5sSrJK/If3cjmfPOuMqvCp1WGNCpcL5BVSKKijgkgPyKsq/L+3PRGLWTFtaomV9us1IqSUs9FF'
        'Mx5xx1L42+q45atSm8yGorInwd1Us0a1saTA/KIzIBj6Lq3VaBVcTSWgkp3NZJNGW2gq5dUPsVzrVWqNR6MxWcNVUf8ADFXM5/FzQZ+vTlpU48Auy4mYbZdR'
        'E3d1iK3RMwKQT4g8/rocoVxRkpUwZpVucLoktzhG0cg1ASfXOG66aweS6glPV9CpS2643OmUm5RK6/NiS3lseXPd01xk4xdKdTqrz16DawXhFjAuVAATgCS2'
        'yEA+eAdSrmdHzK9bj0D1NNfSGp3r7dJnky/dTDaP8WsrmdHzB3tX0NVkN/Wi+HattksKYPdG3PGxx0+bcc6ydnWtHzB36ZrkSIzN3gqZIfhwrYRJpQNwPXmO'
        'mRrphSlSaVdaHoKJ6epppJJIqmNIOqmoiweXLn4+muEqpnVYo83f+IrfVStBRGreYLtKKY2Gf7zAddd4Wc1jKhznOLwRCtvD1e0haRZRuOQqHl1/5667ytI0'
        'wOUYS1Pb0tuudKsQFFOkajJ31OA36chrwNxep6kmhyG3mabfVU9PJMfBqhm2+nPlorTJjTiLyxG21UkqA0seMF4lTaB6+J1S9ZYktXTAmWdGd65YmPRnfJHq'
        'wxrpgskc8XifUnfJOjTVKUrKRJG3eAguPbx8h00Su6FJSpiU5njWMmrudNDLIuSdse8Dx6n9dc15IrHViBrKdHEUNwE8P8uKaIlD6beZ0tVxoCwwqSa6iqK+'
        'WSIQyTRseXybD+/XXSMlHEl1bKdmsUscBcxJgDDJ8Q0Z/wCmonOrpUuMaIepresELNPu70thIvvPYMev+Worw+hWQ5FGUD7qVEQePxu/P1xpr5g0SpuI3pd8'
        'Hw0EhZdu5a0O+PYjVXa416E3qYEKMzbxUSQ/DhW2ok0oG4HrzHTI12qqUqc6VdaHoKJ6epppJJIqmNIOqmoiweXLn4+muEqpnVYo83f+IrfVStBRGreYLtKK'
        'Y2Gf7zAddd4Wc1jKhznOLwRCtvD1e0haRZRuOQqHl1/5667ytI0wOUYS1Pb0tuudKsQFFOkajJ31OA36chrwNxep6kmhyG3mabfVU9PJMfBqhm2+nPlorTJj'
        'TiLyxG21UkqA0seMF4lTaB6+J1S9ZYktXTAmWdGd65YmPRnfJHqwxrpgskc8XifUnfJOjTVKUrKRJG3eAguPbx8h00Su6FJSpiU5njWMmrudNDLIuSdse8Dx'
        '6n9dc15IrHViBrKdHEUNwE8P8uKaIlD6beZ0tVxoCwwqSa6iqK+WSIQyTRseXybD+/XXSMlHEl1bKdmsUscBcxJgDDJ8Q0Z/6aic6ulS4xoh6mt6wQs0+7vS'
        '2Ei+89gx6/5aivD6FZDkUZQPupURB4/G78/XGmvmDRKn4ielD0/w0Ehddu5a0O+PYjV3a416E3qYHnPhuIapjHVTvtbluoYwxA8fxa61sljHqc6TeYWDgOh2'
        'I801VUHd+KpcKgz5gdPL9dPbSrRG7OOo/NSWnh7erNQLLjEYjn3lh5FR++prOfE1IxCQcUTx5pqEVlSDhFEMOXHLmA3TGc6HZrOWAqfA3LT8R10EcUcVZTog'
        '5iuqwfrtXw1NbNMr1tBOo4VuSuklTW1BiMeP6ojS4/8ALVq0jTBBceoGk4KpEmSoqDLLvJ3PLHzTyyPA65ytW3RHRWazH4aS2UTOk1E8zEYXdUlV9iBrXpSy'
        'M0o5hYeH6aaYuvDcNSNuATVMxx/4ees5y+YEktA8HBc9UzSJ2f24SfytU1CKxHhzJzrdo1h2jNdT9wbjt14tSKH4ctlDGu7JWujcKfYHp+2pbjJ1vN/wajXu'
        '0FHnuNupga77mQuw+aqqCCB5AKf31V2L9mpKclnQWqeNqKkVkq6iySLKMxoklQT054CgnWVk3ik+hnNatCS9oVIx2W+wG6zAbXkpaCYqD/vPjXTsX7zp/JHa'
        'LRV/g1NxRxBWohh4eqYNmVEc8sUOfPxJzoULJYOf1Zm5v3SX94cSPMnc0FrpgWx33xCytnyOBro1Y09pk/8AycEE+F4hqmMdVO+G5FqGMMQPH8WprZLGPUqk'
        '9QsHAdDsR5pqqoO78VS4VBnzA6eX66e2lWiN2cdR+aktPD29WagWXGIxHPvLDyKj99TWc+JqRiEg4onjzTUIrKkHCKIYcuOXMBumM50OzWcsBU+BuWn4jroI'
        '4o4qynRBzFdVg/Xavhqa2aZXraCdRwrcldJKmtqDEY8f1RGlx/5atWkaYILj1A0nBVIkyVFQZZd5O55Y+aeWR4HXOVq26I6KzWY/DSWyiZ0monmYjC7qkqvs'
        'QNa9KWRmlHMLDw/TTTF14bhqRtwCapmOP/Dz1nOXzAkloHg4LnqmaROz+3CT+VqmoRWI8OZOdbtGsO0ZrqfuDcduvFqRQ/DlsoY13ZK10bhT7A9P21LcZOt5'
        'v+DUa92go89xt1MDXfcyF2HzVVQQQPIBT++quxfs1JTks6C1TxtRUislXUWSRZRmNEkqCenPAUE6ysm8Un0M5rVoSXtCpGOy32A3WYDa8lLQTFQf958a6di/'
        'edP5I7RaKv8ABqbijiCtRDDw9UwbMqI55Yoc+fiTnQoWSwc/qzNzfuksXDiSSZO5oLXTAtjv/iFlbPkcDXRqyp7TZP8A8nBFOWqFwpwtZPea7Jy1PGdoPodu'
        'Mj66hK6/VSRda4OpRpbTJUgLT8H1vcsObyBUB/Nv+uud6mc0VSuUWMLYbwsqtQcN26m2KV7yqnjQn05Z5a1+FMZMbrWUTaW6/O6H4qw07qmDHHM8mB45wdFY'
        'cGPreRNa610chL8T0cblShSjoFJI93Y8/pqqR+XqGL94JRXfv5Ghhvl0/hrzWCMBfYbV5e2pceMUKelRtbC1UBItPdp8MWZ3jbDsfHwz9dTepwGleJXt9nqq'
        'KknVLVc96NuLgQxZ+rDXJtN5otg3W4SusM9TJTN+KMTXuJFTzwF10os19CKsXuTW6n2tX3CgPLAVbl3hJP8AdHj66qMZPJdAcksWxGS2cMSowZrSSMFu8Yye'
        'PkOei9aJ6mpBqo3RQ2HYZKSnjnK8m7i2M59vmHTQ5T1fUyUeA9TyhEeaipa2Z5Du72SnSALjoOfl4Y1P7sr9gVVDWTW9pIqJJE37d09SAFPieWqSinmFWeYu'
        'NYtPN3Dm3UcwYfLEQzMCeQLHl666qNcVVkNhKi6C3kw095maQfMwphGw98AdfTWUK5xBypkwEtV8fAErJ7zXZOWpoztB9DtxkfXVpXX6qSCtc6lGltMlSAtP'
        'wfW9yw5vIFQH82/6653qZzRVK5RYwthvCyq1Bw3bqbYpXvKqeNCfTlnlrX4UxkxutZRNpbr87ofirDTuqYMcczyYHjnB0VhwY+t5E1rrXRyEvxPRxuVKFKOg'
        'Ukj3djz+mqpH5eoYv3glFd+/kaGG+XT+GvNYIwF9htXl7alx4xQp6VG1sLVQEi092nwxZneNsOx8fDP11N6nAaV4le32eqoqSdUtVz3o24uBDFn6sNcm03mi'
        '2DdbhK6wz1MlM34oxNe4kVPPAXXSizX0Iqxe5Nbqfa1fcKA8sBVuXeEk/wB0ePrqoxk8l0BySxbEZLZwxKjBmtJIwW7xjJ4+Q56L1onqakGqjdFDYdhkpKeO'
        'crybuLYzn2+YdNDlPV9TJR4D1PKER5qKlrZnkO7vZKdIAuOg5+XhjU/uyv2BVUNZNb2kiokkTft3T1IAU+J5apKKeYVZ5i41i083cObdRzBh8sRDMwJ5AseX'
        'rrqo1xVWQ2EqLoLeTDT3mZpBzYUwjYe+AOvprKFcXEHKmTD1HFN5rZGWGvcSuBueloAq58AGOBn9tCs4LNdRc29QFJLBUQE1NXfJJzncpZSr+xzqmmngkCdc'
        '2xCChjjqQ3eVVQWztjqJIwPyzzGrcnQm75nbPRQNUTPFQtUuuULFkwMnxw3XTKTpiwSVS1DJWw0rR0lHSUuz5ch4Q36nXF0eZ1Seh9R3CthjaNaymiI6x/Fq'
        'rZ9dp1LpwMqsxHb7lNVmaWqhpQ39mGklm3e3Pn78hrXlQKOo5Bw9DVB/irvE+zmcUrOM+PIseWi9TJFXeLGqeyWeByBcqSNn/nltjA58hmPGdZylw6ikuPQb'
        'jt1rotypekV1HPbbOf6qNRek/d6jgtegJ6f4hlCXS4VCMcgxW0Rj057empfnFcyl+4FqGlqGk33W/wAzr8uxC0YI8+S5xpUmtEDhXNsmf0fooXaWKlvGFBId'
        'llYN59SNd70ms0cWkuIWKey0MatU22sd5Ccd+C236Z/fWpN5MyaWhOqLqaaraaiopKaJT8rfDxkex3Z56UuLM3wRqfjhqKeN1aiiqBzbbSKSB55Xx0qyclQ1'
        '6jC1PFN5rZGWGvcSuBueloAq58AGOBn9tSrOCxa6i5t6gKSWCogJqau+STnO5SylX9jnVNNPBIE65tiEFDHHUhu8qqgtnbHUSRgflnmNW5OhN3zO2eigaome'
        'KhapdcoWLJgZPjhuumUnTFgkqlqGSthpWjpKOkpdny5Dwhv1OuLo8zqk9D6juFbDG0a1lNER1j+LVWz67TqXTgZVZiO33KarM0tVDShv7MNJLNu9ufP35DWv'
        'KgUdRyDh6GqD/FXeJ9nM4pWcZ8eRY8tF6mSKu8WNU9ks8DkC5UkbP/PLbGBz5DMeM6zlLh1FJceg3HbrXRblS9IrqOe22c/1Uai9J+71HBa9AT0/xDKEulwq'
        'EY5BitojHpz29NS/OK5lL9wLUNLUNJvut/mdfl2IWjBHnyXONKk1ogcK5tkz+j9FC7SxUt4woJDssrBvPqRrvek1mji0lxCxT2WhjVqm21jvITjvwW2/TP76'
        '1JvJmTS0J1RdTTVbTUVFJTRKflb4eMj2O7PPSlxZm+CNTccNRVEbo1FDUDm2KRSQPPK+OlWTktQvUZ+cQ/aJ4EdwrrUKoGFdjE2fXaX173u/aNP+zxLbtn4g'
        'T25cB02GS6yJvb5o1t0DBB6fxOen0LaX7vVh6bs+sugwv2jez+CnkpzX3IQsclqa004Zv7uSentqVu/aW60XNlen7Mteh1/tN9mMMBRLlVwM/wCICz0obHrh'
        '9Pdm1vOPVk947L83Qzb/ALUXZxTq3fXisUdFKWCnGR6nd1Gs92bU8o9WC3lsy97odH2tezW3TOUvvELIVwvwlrponTzwxJ6+mnurape6ubB7z2Ve8wf/AGv+'
        'yoSErUcVyEDlJULTsxJ8OnTVd07XwQLemy8WBP2u+zF5kUm+rF/PI6Q5HkAFPPW7p2vgh702R5sPU/a67N6gKqXasC4/2tJP8p9lfQt0bXm4rmhe9NkphI5H'
        '9qjs0qIGD3eYYH4Xt7HP1L51u69rT9nqPeeyP3hKf7TvAUgxBe+7BGAi01UoPvhtL3XtOseqIW89mWUvqci+0zwYqSGO80xkJwDJHNjHsX0d17QvdfQe8tn+'
        'Ywn2j+EIw3/pa2sGPRqdzjl4fOdU93bR8jDvDZvnQan+0twNJCsct0jhjU8xR28ZYepZv+uh7u2mtbvUpbw2antG/wDT52bTzmT42sXnkKKGHmR0bm+pW79q'
        'SxXUfTtneTCy/aF4FlYK9zrDLnLOKOmTP1B5ay3ftFMvqb06wr7QWH7RPAkjgOtQqgYV2MTf/wCS+h7v2jT/ALFbds/ECe3LgOmwyXWRN7fNGtugYIPT+Jz0'
        '+hbS/d6sPTdn1l0GF+0b2fwU8lOa+5CFjktTWmnDN/dyT09tSt37S3Wi5sr0/Zlr0Ov9pvsxhgKJcquBn/EBZ6UNj1w+nuza3nHqye8dl+boZt/2ouzinVu+'
        'vFYo6KUsFOMj1O7qNZ7s2p5R6sFvLZl73Q6Pta9mtumcpfeIWQrhfhLXTROnnhiT19NPdW1S91c2D3nsq95g/wDtf9lQkJWo4rkIHKSoWnZiT4dOmq7p2vgg'
        'W9Nl4sCftd9mLzIpN9WL+eR0hyPIAKeet3TtfBD3psjzYep+112b1AVUu1YFx/taSf5T7K+hbo2vNxXNC96bJTCRyP7VHZpUQMHu8wwPwvb2OfqXzrd17Wn7'
        'PUe89kfvCU/2neApBiC992CMBFpqpQffDaXuvadY9UQt57MspfU5F9pngxUkMd5pjITgGSObGPYvo7r2he6+g95bP8xhPtH8IRhv/S1tYMejU7nHLw+c6p7u'
        '2j5GHeGzfOg1P9pbgaSFY5bpHDGp5ijt4yw9Szf9dD3dtNa3epS3hs1PaN/6fOzaecyfG1i88hRQw8yOjc31K3ftSWK6j6ds7yYWX7QvAsrAPc6wyg5ZxR0y'
        'Z+oPLWW79oSy+pvTrCvtH//Z'
    ),
    'steel': (
        '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/'
        '2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADAREAAhEBAxEB/8QA'
        'GwAAAwEBAQEBAAAAAAAAAAAAAgMEBQEABgf/xABAEAACAQMCBAQEBAQFAwMFAQABAgMABBESIQUTMUEiUWFxFDKBkQYjobEVJELBM1LR4fAHcoIWNGJDY3OS'
        '8aL/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EACARAQEBAQEBAAMBAQEBAAAAAAABETEhQQJhcRJRMkL/2gAMAwEAAhEDEQA/APwS0vZLa1QR21pIV8Ks'
        'UII26kA4O1e15ypLyeR3SUeNNwqeDfscD9qIYJpwVYHVKceFhnb/ALSdvSiq0lkS1NuYLKVn31shlZW7HIXHsM+9E1X8YpRo5BF8TIoAaECEjf8AqAG5Plmr'
        'gWWuJLq4aRzCF6A3LFSpGwAAO9TF1mSxMHRBGpLDVjOcftTQEBdlbmW7OucHlZyfTbP2NUdlSJIWeazmt37O4JUD6ioim3m4bPYxGO3nmbUdckOhUHoNQy3v'
        'QOgit7mWYcsFYwPCW0uT23GP02xQOv3gUrzLU2rBf8NCG+vjJO/rUaQNFGOHu72szLkjV+WVUd+nX1qHHxs34H+Nm5dtJfR2zZb4WN2KY6nA8u5FY/xFn5Vp'
        '23BIbKKGONJIyBgDlqFxWpMngf8Ah+FbW24/C00qSL+JJ2xGBlv5aI7596k+l5DuL/huw/EcZdm4is0eStzbxB5EPuv7GrZKTxJw3/p/w/hd0l3d3fHL+YjA'
        'kuLVcqNumpgB/ep+P4T8S/la+muLHhNwjBrriETD/DhNkgLddzg4FdGIT8JaQ7vJdrjfJiUk/rtRU0tokMSyTvPHn5QIRuO2xNAt7OORcNdyM2epj/3qYcEL'
        'WBXXRcSjYhnWM4/1q5ENgsYxD4bksiqSGWLdj2Ge9TFaVtZGZ059yqxy4BLxGXfHUKBkjt5UJgp7XhQ5Tc+UON2J4aI1HTpqbLfagiFpBPJIq3kkgGRqW0cj'
        'H9qBVzaJaaAl2ylhjBjZWUeeMbVBG3D3dgpnmaPHztGwBPlqxQeINmVDPJpG6sYemKokv7FL+yeKYyTRSDxF1QBvXrms5rT5tvwUxZh8RdXdquDypJdSDy1Y'
        '+b61j/EX/VfoXC+D3c7xwF0ijbJAnljQA4zndvtXdzNk4LJbrI3KmbU/L1BQFB89Wo7+9QHHwGeGRByXWIDJMMqSgnbqAc1RYvAbyU6/hLkQlMCMncnHXc9+'
        '1AteDXowxtbq2RG8SzsHYntjGANvLegOK2NmjIbedZJPlZcgHzyuevqTTBixXkFsw1JJJIWYaxsF329yaimfxBpt5WllQZK6zgj0yuMe5oQdvezR2uVmlhLd'
        'HGXC+fU0E0ss7vpklaVc9W8JHuBUgWVjDNI0MDMD4X16z7daDkk4dQGIYSNsQDjI65I/SlX9lycxnOZGIGwUQk6R5Db+9RAWq8iR5cvzEBCoqaevXOD+lF0c'
        'NpOAHSCaRX/ypg/cnpQ4m4Fz7mP8SI4e3Q8fkJkG76vhY8g+nTcVme2l+Pp7OR7e3W2We+jkClmR2VImbO2nTv08960moZJZI1Dl7hnbuilyd++DiqI3Aina'
        'QwHSx3bWyMx9Qc/pQcNxHFIweFfEMqSSwHofagW0bQSsukNJhTqBz1GeoO/tVRXGspjQO7rEOgOML7Y3oKLa6SVCAjux8BBYqMbVFUwXccIEYUxuOsZLSkD3'
        'QEVZ/wAQDSQvJM5EZdTq1SQyA4JwMbdKqCkvJItTwM5gAzJKj6QPYnf6AVK1EzXAv0aNLS7uXdepkkAHqFBBP1qHCZJPg2MBs2E6gcxTqUAf/I6sE+e9Dxm3'
        'HFheoiJBbOi76mLuf1OMVFGvNuXLkJAAp3RdC/r1oFTRx/DwnQgcDLMSM5+/6VFNMqRRorqCSNWn/h2ojdjluLNy8rWymVvDmGDUT9RkAeddEUk3CzSx3Ill'
        'jI1MUtY5VJ8iBjFRPgknisQshtVjR8qoW0CsT0yBnB/5iqJVtI5lDQQyz+Qnjkx67KwzUXXprS3iaPnA+FtbaYVVVX21ZBPqc1U0tVt715cSB52JZgY1AKnp'
        'uH22qKODhYRo5Gt4oomBGhceLtkHURn0FXAkz2VuXWMxtMpOGTB048+36GooJ54dcI+FijUnxCKMBmP+Y561A1Zi6GFLaSSHqIYY8DHqO/vViEC2EkkjxWkF'
        'ugXBRsDBH9R8z6Cqgktbm5ZVjie6A2YhCQPrgAedZUdq6MHEVpHeGI5JKOVX7GgdGpZZp0iSMkjW0bEAHPTHaqI5RDPKSYIlkG2qXU2fselQZ3ACLZvxOoFv'
        'cRR/iB2T8slWJtY8lQCNvSs/j2reR9RZRfxCJm5PMnI2+GgXbfyLDA9e9aT+o1cvB+QW076sW6gk5wR83mKApZp5IWElnECBjLyGLV13IBIrQnQzu4+Jht5T'
        'jAPNLhfKiIprRY1CrFaSRqOz4K/bFFXWnCFdBoS1gdgWDzzNjHpUGlZ8Puni0RIHjbrNFOEU/wDxOeg9cUvgYnCboRu0umCNFJWRJ1XOB026mrEsKtOD3F5I'
        'skjC3t2Uj4q4uVVE33OcEt7KDntUtWRncRtOVdJLDOl1hQnxS6gqjt4SNWPXvUOFxRRzI0ksodF8OUKnJ9BjJ9ziqRBNBE4JdYwgJyVt0QAeWd6uIZFc3Ub6'
        '0naWOMZQFFGBjrtt7VAMhhljbnSNcOwzrniyMnvscipVRSSyIUUTlcddMeA3r55+tQOSWNY1WNmKk5dmjUE+g67fXeorbluLSExtFFqZx+aJ7dNOe2kHetoo'
        'i4lZu6/ERRaEiC8yBdOWB31AHcE9MUDSeHQMZ5bznRuuGgPDObp6bAscD3qocLrhTQQxSLHFpjLxtawQ5kHbVtnVRf4C1EMRdsW8YjBcFrKJyAPPzb0oGJxk'
        'RW8YhkeZs8wytaxRDH+VVI+570Epv8ajJKkEm5IjhjUZ8wFGKRGfJxaW4IhS6MiKxbQiqMnyz5fWga1/cxgRoQyKMDmxoSnpvv7UIVZ3t/yyxXSp6uJsEjzq'
        'KLhcF0NDwC6SESlVeNO/lq3qdFL2/wAM2bqW6BZseM6dXvqbGKoP4JLu3n+HluUK7nQYgpONtRyKnAVnwyRiivKzYBJ5EkIOrtkkkYoFtwi2mj0SXc8U+flR'
        'rd1698DOKK+et5V4e/4kjU8xhx+QKPlJxaxbkjZazO0vIqs+KyheWAEXIDlZCx2OQc9hWtoc9495LruADKrMzCLTg5OQxx3ohwSS4Eixz6V06x41A0+p2JrS'
        'OC8ubdUmFysibplZQ3XtUUUV1I5jiaGYs4PLCANn6GgZOjLHEWh4krMSNcixom2chRjOfSppgGeykhMJt7i5diC2JR2xsABv61Ro3HD+F8MtpJ9F20yw8wRu'
        'Na5OAFYqcd98dqWmBgfhJT4o2N2twToYpdougjqACMqvpU0KnjshIS1vfScwflg3cWAe++M4NBO8fDbd43l4dO/Yub0kb5G+kf8ABVP0ldLW2ISS1ZlJ/wAX'
        'U364PSiJWuLRC5SyLAjTgyHHv1oA+IjKrH8MCqjJ1RsxzUUBKkgmCM6jseXp/TNRMVw3KGPVyI5UTZiradz03qqWySsURDpkOwT4hcfUkDH1qoGaIK7LjWEb'
        'UV+IDBz5DT29qKoEMrwgIqLG25HMbK+h1fuaoatrZiR5pL+BVHTl51EgbAYHTzPaoiu1e31RNLNHGpIXGp329CdyfWqutNbewjaYR3o5CEMnxY5AfPkdz9Km'
        'JGKqWzOyieGPLfNqz+p6/WqaO4jhkuBon/LbAzHIq5/+QAHSmAuVbQzgnNyQMATCORFPmfOgK4SAIhWFizHOBCMD1271FWNY6rNM2svImcIJhbyZ276c/rQc'
        'JlhEawyOjAka5IOWuPLLA1RJdmG5gGu+MjKc8o27OmfPO2ffFQJigiikmWK4jhTTuwTRrHftQLt0gF2obiCQxk7yqhyB/eosZPBj4/xK0c6XCjj8nLlc6XkH'
        'w0fiKntWZ2l9h9xrluEYSjwrhl8IGc+natIqeV3tI1WUIGbSsXxCovvjH6mqjYaS1tkgTXd6tHj5M0cyE79WGMe1UQ3TqH1MLjLnA/NB0+vTaoqeTiNuV5cs'
        '8zs53ZnCk/UCgeZIJIPBqK6vnZiSnpmoBS6RpGy93KF2V5Mhe2cACgikmVpPh4w4Ub4wQPoP70oclsqglB8Qw+YGBiq/+WCagckMsqLHBarPJjxKIcMD5dP+'
        'CqaN+HcU06pbRwzbqqppBA64wNh6miEz2oXmaoWxnrJqH7bGqJbyGW3kW3dJBkBgynGfTPfFFLlifKkQsSB0Bcg1PoUYZNOp4Srk/wBQ04HmcnOPSmCswOOY'
        'xUyjYgxyIAPYg/2omli1uDGoeJ5cZzhceu9WKa0RIQNZywkt8zybEeWkDb1oG2awpcMssEM+R4Arygof70/iKtUUWmH4WWKE7atLZYjtltv9aBqW1lFct+Y4'
        'UfI0uNh3Bx0+lNBRvbsiySuqRZOmWMAhfuDqPp2pquQ/BpHPKjTxxuCy8toywIGy4I3J64q9RoGC6lsVvI7NTwmcKOaZYUYkbNk4BGT2HSp+l8acFrYOyraS'
        'Xo8I5qwiBnA8umft2qengLqztVlT4RfxC0qDDhZbdF098f7UEN7Y24b4mePi00DrhJLmcDP/AMdSnH07VqDOjstcsWILkICT4ZhK4/8AE/agrayiuIiZY73x'
        'uEEegrrPqw6jzqaM1pIWv5oXtJYGR9JSCQDfzwetBTHacNtuZLeSXsWSuhY54y3rkY3P7VB87axLbp+JWtYObanjrhJbphzF/l4zggdaz9q3kMiguJ49SWhf'
        'SescQHfpknateprVeCX4ZZAZUIkC6AseQMZ7MaIptLa44gWWSKaaMgheWgY+x7f3qqKOG3tsc6zkidW0tmWZT9OooOPeo8rh/iI1QjAN4WAGPLTt/ag9fG7a'
        'EvJE62h2TVIpXBz5nceuNqmJoVsbiJUtMhdRzzucpUZwdOsbYpi6hWBYrx9Fys8kfyyQzFgKBj3EtuZTLxOWMM2oZlZN/YHf2oPfF213MnOvYyD80mp99umx'
        'zVg7E1oIJ5DcpKZGACFH1BRnuT1/SqaQzxSt/hKAPlCjGB5jemI9zo5J4gZZSqDAQYCn+9TByO9EECK1zMZUB/LRyApJPailQWsXNYgmYFRI0iknc9dz3/Si'
        'KkaExNqE6v8A0cpVYH/uz0ppjOVoblNImVmXOojWDnv4aRVVvbSu/jvLsKi4RI004Xvkk0QclzOw0ZlKggEyy7sMgD0HvVF8NgdaLcSuiR7BU1SgezZx6Gsx'
        'TYuFRBS6TM2pz4QmCvuScfatIVPZ2oVQtvcFo2OktHgL54Or9aYJ5YBbtrFrJGGOAGHX65P1oasjh+Nu2mPD+HyvHhMzPISoxtpycAkUGikCzoZU4Nbzy4wH'
        'EzjGPY70NTKZre5li/h9vb5AB1EsQO+kZPXuc9aBhgiluQotVBlGUJh5YJ8hvjPrRTlgnkkW2S2EiK+7LNu5HXYeXfegHiEFybg6TEDsoU4IUdsHP/8AagwJ'
        '3eBsYjzrwSUGT7E9/Wqmh4hNIqRGOOFXXcBVxke/WoMGEtcW/wCI1MmlpuOlho6Ai1jzj71z/wDqt/IthiLRxqzscD5WGV/3rUZXWNwgidGQx6fFqjQagfI1'
        'oXPJzDE0/PlUjOVBbT66RjaiGTrAEBkxKSdK/wCMCe+/+lF9TxwwCHwW08qZ1M2JMAY6DO2O5NB0MIVd0XPc5wCF/wC4jpTobLC8Th3iXSx2VmUrjboQKgVz'
        'ZgXxDAIS3iVcHG22DTAqWBLyOZTZEaD1yRpOeoqU0sg28gMwj1adKMIsDVgfMRVniV0SogePRs40ySCIYHp//KvBTFNFZWz+ESrhg6qd3XoAB1FVErTI0akx'
        'DPQKsRVicdNX96mqSZjJEoVQ+gk5RAxA9/SopPxPNLflnBH9MYYEepJqDusykRNCHAUyAaNJyPbv2FUDC+dXhAU7lmXJ+uBigawaRQY3AmXZhobb2Pr61T+l'
        'vDKuhpVflse0ZOfpjeiKbNIZNMUltcmLOSXRgT9hgVT6qS3lYLDBE+cnSEVtQ3+XptU1Qx2FwJivLcDTnlvExBI+m/8Aw1dQVrZvl1WJJHK6lYRP4foD+9BV'
        'ZxySoWkheOFGCyvJ+Xkk9PFsxz2FFa3/AKbCRu8l1YLAW1KrTrqb2UAnPpTdTEF0baEQ6OJGzibZ7dmVHB8yFGKnqrI/inkXlXzSQ41xjWo1Hz6HO3brSnEZ'
        'uGDkLz2j3OlZDs3c4Axg0Ed1KWhYPZzLpOWlkkfce2wpozrxMgM0L6GxpOgMN/rtQeSP4s6FSSSUDcRxajj+1NRlcLeRbH8TIQsZfj0gYOMH/wBtHsPL1rE7'
        'W7yNOyYSpBEDEFGXzkhjjfr/AMzWmV0FwwIwwKdSkSY0nyyeta1Matqt1MspjuIsomtLeSJsp6rj70Aw311IUj5/ynOtZSqn1JxgVKOJxrjESyRjizzxSYAY'
        'EOv3xt/eop0Et9aRzI14YmK6jGLbXlvUkbVMEzILe6YvxTiE0ukZSK01qOm25GKuIjDzzvsGllY4LBMMPt0oolL3RmEXPLJ4WGpskg7L/vQiS84W0d2uQ5UK'
        'PCSW0n6/8FMLXZEijh1xzJJhtLrFrldB3OCAMVLo0JJVWxhtRJvpJjDWwRtOe53NXTEakahpS6YICrFI/C308hVCnuFt0ldIpNTNuphK7+Z9aIhhnMUjtyF6'
        'Z8ak4z3xQVR3VxFFGscEccpjCHRsXHng+ee1FiOG6K6GSPRGrAhWkY5I7EDaocWpxNhCuHkBPhZMttv0qhSXgcbvKI0OB/isQcjIGO9NRdFxK4HJdZckKcK8'
        'jqCPMnzoXDUvSwkNxJHGMYdhPLvTFU3jzxRw20KwJIg1MxnJZ89gM7bdap+yra1u3l5ZUvGyhwYc5IPZiDtRH1FpbXHwTJPNeWsIGY1lGQp811ZAx+lZ+qpP'
        '4fvxapJbXU0izgnnRxEjT5gnApvxMS2P4P4vmRbeza6QjA0hdS+hydx6VdnVxK/4W4l8K8nwz8qJjqjVMDPcbH5qmrhdx+Grq2tlOpo8eILMwYAeQy2R6kVZ'
        'dRkcQgmVTPodY8YAdsD2GW3oMszmOFFd0WXRgw6sZ9euMVUiGG45c2JFfDdNLYOfYHpWYrnA4JuIWv4h5YYhfxDIWZVJIBtY8Z+1T8e1fy5Gi5ljj0kjWu5Y'
        'KdQ3/etMGiWSOHeKEyZ3Yq7FRtjtimqdIklykZNvHayRLnmxJMrOd+p7Z8u9LVWPZzzRjnFzEVBYSlsfXC9PT71FxJEtslrlL6PnnblkucD3FRFdjBzoHgW7'
        'Uqp1apZ5FwN8A9e/0pwcEAicJcSxIxOdSs0i48zgVUcmItoXVbyExQk4YFlb2J61VRzcWnmgkRplmVgMIkzZU574GCKIzlYIwZGhTB3JZxk9+g600Ct3yyUf'
        'WQrYTwyEMPfrUWNBOIxuOULe3n04xJcNIC3/AI9ashbr3MkZ5By0n21HlrJGgwPU74oiO44jO8SOsAjXoPzm+oNFxPFdO1yvOL6G+fTEXI8sb/SiKzxBHtRD'
        'plj07iTQrMT6t1+naqEWs0cckbyxLIg3cM5God9xWVEL5Hk56QLEitlVWXIzk4BzuTVgL4i3Gpgi80fMWmIyaXxOrLW7tGiwTDGrAnmamZh9OlFCFttDhrmJ'
        'iMhRMCmry386qF23IhjQuY2diS4HhAAOOo3OfKirVS0l5gkEhaXdo0bQmex2/aiPoLbRZKJrPh7q8QAj1TA4IGCWyfF1zg7fasqhNpbSzyvd2t6qhAwLuCNe'
        'd1PiwB32FVHZorQmJ1jXlEhEUXKsW8yd859apFVqrNBefCcHtbhYQGeeaZhHECcA9QMnsOtRQ3V9NaWoRbGziZjmS5FvzJH8lG+lAPIbmhrFvGN5HILmOEzr'
        'tGwVYz07Z6UGe93NbS8p5RpVcDlKhyfU43oM2MBJHflxhid8ZHtvUHeEJELHjkxLFj+IXBULlTi0j67+tZnat/8AMaltxCBo3ike8OrcrHuDv07YrqyrsOIx'
        'xM0xsuI3kaKQUa6cIBjALEdMeVSiifjct1ZlWgvZDpVYZp71ykKjO4UfMe29TPV3XYb+4DDnXkzhgxjUTtgsBttnpnG/elmEImvpCoCTLFKVDSaCuXyPXyqY'
        'IZrqae8lWMrGuBEViYglB/8AInv+lE1dazTl+WIoAqrq509yVDbgYwOuKBb3XLui4aCeVjlikhI3/wC4Yz69qeqou7sRyHEl1LIdnktXBX2BwMigzEliuX0O'
        'nEJFz05aknHbOofWqPRx825Dt8TpY4OnClfIA5NVGm9xKrYaS/CY8JLI23r5VF8L+FS7MQmEkcbNgvOHYLtsxUdR/wBtQ0i4ubaCMwxwvkvq5zAhvIAA9vfe'
        'tJKiZ1mCnlF9JIY68E/Tt9KyoVZeZIyry13YqAX0jG1VGdFcteNohYBEwCTGBq9AKyt8VhnkclHYBAdTJjGe5JrQdIk0MkbtdyyHGMZHhHlUDo7SR4uZLNLy'
        'x1kLDw/U7YoORw2jawbsOAcfmSjBH/O1UVLDw82/MkuC0MSnMscSPn6569qDT4awhtX+HkuSxIUGN4YgM+ZOe3lQUPcR2cpm58qqoywbQ2RnuR1386qKuJ3k'
        'd1MsltasEMYEgURLnyAwSTip+hKC27TLNFbhcvKwVQM9MnHU9gOtUdjvbhmWK0aNeWS7BrfUkhP9Ugbq3r2qK9dcXnt7aS3mteDFpMBYmzrUZyWABwvuTUVj'
        '8yGQSM1vyjpASOOXXke7VUZUluyuDGqgBs4k3UHuNqgRd6FnY/lPq+ZUDY+m1AHBoLuez4xJDEz2bcckOmJvEr/DRg5PljFZnat5F5lkhlYfDPIuMfmXWrJ8'
        '8DpW0wNtcFISRFI8ZOGCzMNXvg1dFqXNwhdVt1U41Ko2Zfqc/oKagHzLNquY5oywwDrBJ+/aoE6GRXjZyF0agzjBJ2xjG+amKAwmRh+SuSdzI2ft/qaqNOSE'
        'xhEKRAMg0lYlB277nrUqxQt9xJw4kvjGhUnwxoM7enXPnUxS7PiPEBJGHjuWgfKsCyHSM/MD29aGxM95GLuNhuChH5kSNq6dfLHY1pHFa5uPzbZ5zAn+I7Ro'
        'E77YG+aC+3miCxzfCrdr1YXgWIADyTOSfeqh83FLe9ZhNDM8xO/5hdif+4f22rPF6z7y4i52C1whUZ0NJjOe5yOtVGZJLCJ0lkVkUHBdhzCo88bZ8sUE89w0'
        'g0nmEt8ngCgfTNNUu2trh9KJFHKAuWfGakFJiEOt3iwhOQmkquc/oK1nwdSYSSsBFbLvnUUJIHpk7mohsV3NDHBy04fIVPiWWMESDO22etCrhxHiFwZGij4W'
        'U8v4SJPpkb0GpD+Ir2SNxNZcOLKFCW8HC2UnPoR+pqKeeKC6t0hntoYrmIa44oLAoxH+bPQL55qoNLyW7tpTJNpJABEVqjBmzsNh0opF3d3EODGA0zAqQ0Cx'
        'Be3hIHU0Qo8YazjRLHiVqViAZQkByGx4lLEEsR01dBT+htr+JeJtzPiONNBGVyDFZiXJ8tht70Ub/ii9hdcXsEgGRqlt0XJxtkEZ/wB6CG/4rfXltBJPcRSM'
        'qFn0rHjfoTj9qDDnu5GdXiYeEeHL6Nj6YxvU0VQX9wZEKXDxSHoA6jH1xVTEXBZrqO3/ABIsVxAUT8RyOS+kh2NrHv7D0rH49rV5FF3xO+EfKuZoXL7loY0A'
        'AzsCQP0rbIRe3EWp5JNMbDZV0glh07frUEkN7IZMSLysg6m15288f3p9U1ZVJXBXc5zkbj6mgajAuJhMWx/Uo2Ppv/atI5DbM+DHbvPMTuWycHfy/asqZLZx'
        'RXAdoY5UOFJmRkyRjpUJTUkt1vFPKCSBCmV2UZGw/wCdao41tziyBkaXSUaaTpjPVt8L5E1YC+FtbMorsL2XTgNpIgXYdur+5wKIBeGvHzCblllPYqTj/wDX'
        'YUC0V2lRJrp5sH51QnT6586oMRT3VzIXEaAr4XyQuB2GO9RXVtnHOC8qVXTTzGcrpOd8Z61UpSIkeHeU6416NJkY98bD2qKXzi8YlVrSJQCunlnUM+++T1zR'
        'MQcyBJ3HOVEztqjbp61low8lizpLHHk6QEU7n0BOTWtQyyniBf8AP5JAw2pApx9dqiHNfyqE0S3BB2DhUAHlWhRG6oM3D3MasxGjUBrb6dT61BoRThRlrK5e'
        'OQqOcXfOAOmfrQUoOGrJLNNaX0c8Z08yCNi4+vb26UWOmawnk5si8UvJMctFaLJBPbJIA9wM1B2QR2qRkWPF48jbxnD/APPMVRDPxrkQmNYJirNkw6mXtvsB'
        '370RFbN4XxZTLnOrEzZA74zvU7wNlswskam1idcacXQbUp8s5FUOfgl6ZgBwWPDqdIghIxgdjnBNRpmSxta3iqIHLqhDJJDnGTuMHv61UCYZ4pY4ls52dxnT'
        'yDj3zUGbwmWK2Tj3OmWCX+OSqLdoSxbMEe+2wxWJ2reRcLqAxMPiGLAnYW/QefWtsla0nlWONnuNseG2LYH0PSpqi+HnjEcYjfQckRhCuPUjer9D5UlJVGjn'
        'Vh0AOMevSiASK4uYk5kr6gcIjyYx9DRVlo9xZzw3EkU0rI+leXNgZ3zjHb1qcAXEslzMTIWyT4eY+y+mT09+9KEoRDcSBxzXQf4QkG+R3Ydvaqa7JfSw2wtz'
        'biNHl5iRocLq8znrj1ppOrrhDfQxzRKseSEKkkajj9fp0rSceCvyi8SxQIvVQjYPnvmptCoYJ9bNEikufDpydPmQKKoxJAkskhuBKvgIQkk/XOAKqMzmwTXA'
        'ZnmeIrga/P0XOPvUUqSULqVmwjMpXzAzuKgnmUF1OvwA+HfH1xQX3V0Locya6jkA3WNIxpHqFAA+9U/gjcvIgRp9OnoEgj8Pn9KBq38tnFo+NAzuA0aEn1zp'
        '2qmaZJfXjSxPFdnOk6Q8iDT9NON6Ip5vEWBU62kQ6taxoxB7Yx0qDSjt+JTXUcrrxC5KrqaQIQqbDbHQUMHZX/HUnLWR4pbAtkmCMhWHTfP6VOq2Y7/iryTL'
        'LxDiDSDACuGYx4OdTBRpyflCAmiJr5L6+uP4lJcXcszbAPEUAHTSAdgo9OtVf0zZ7e6DmSWSZ5M5GFxn0UAEYoyzZbWYBydXLZcs8isMd+uP2o0SX5kUeDgv'
        'tkqHB8h6H3NBHcu8UURmmGhGJRNLDc9SoB296CW4YTuXZyqDGBzWJH+9UKZ2aZS9zNGn+bmu2n9azRn280b2vHHZvAeOyaZcEhv5ePY965/9a+Pc5Vjy28ZO'
        'Mdz6Z/tVQ5SJ1BQNgf0tk5+oqg+TMF0yJymzspB1e+B0oLUjuWtxII2Jzpzgnbz3rSGwR3BjJMZGCN3TUCe2x71BtW9rNYSiS5tGuX16TbMyx4c53fy9VG9U'
        'KPC768uJAYJFGNb6REox9T0qYhB4ZdXBdY7aZzjG4iyB59a1ACcFueWJxbGWFGKOrOuT6dev6VFhtvbyhogyssgOcuQu2B646dKqHyvbLCYzNIbZZA2CUJY/'
        'Ty7etPgohitZEleK/EAZvkdEbftq75PfFWSJz47JLbx+JZApVcAxRRePbYae/wBapjPjsPiXCcxQG8TSvEmwHzMceQrPxUd6kMi5SAxuW8JVQi6PUHfPfFRU'
        'lsI0lbYsO+2d/Y9aoQImfUjXEaahl2YkZ28qgdAJwqoHOhvCXEbAD/b0qmuq7QNoSdlj6Zwd/p5VKdU2zoLcuXRnzsoV9TfptSJVMEVlMVZ72Is+7RrG+pfP'
        'PTf1qlioiwEeBcskUhCxxQMxGR1yCd6DUt57GGNJbe74jbzr4RKkxHLU9SCDvkegooQ9hbvbrFfcTMY8P5d4Nj1AG/XuTRBSX9uI3D8W40Ihg6HkXr7ZoEDi'
        'Fu+S17dxeAgNIpcyeg0kYpVSniKQyBYPFhdLO2pnLf5hk4XHZRmgU09oZlWW5nDsdTaEMjgee2MVRTccSgeV2NzxC5J2TMGlmPkew96eIluGZkOmS4VBuySs'
        'q79+3Sio7mGPMDNIeU48UhtDhWz8ue+3epYMC05ix8aQ3EmP47IyorBB/gR76fOuU81rzByzs6mJppRpfVlWBz9KqGxvphUap5MHoB18zWvIhqTHUxDXGk7/'
        'AD7fp+1FdLHLKJSqY1HU+M+mM5OT2okOtzIqqyyTeHGgpliD6HOxoKY5bi4yjYaMZ0o0OW6774/WqhohmjtZXSS7CIQxjU5HXyx2oplzMs1ugmN2zj+mSEkC'
        'qCiVZLZGhQuMklvhf6vLNTollgkniWTQqgZOoAAfUnrWsTTFuDGW1/lxhcgnIUn6DahrUg4qEIKLEzKo0oNTKf1zn1pqDNzGyyTC3g2Us0ioq5Pl2PWn6V6T'
        'iDwwJEtta5O7uFlDn7bY86is/iPF1eJF1KXB1Oy3BfT74G3tTgihuHlkKu6sTurSEkj6imlZ66MFGkAdjnQuQfXttUwHJbDmojscFNQDyONPuKEMS7a2kRhc'
        'coDs2ptQ8/X9KHVNn/OXasWwCccySRlAHvn/AJ0rSLWawJljKtLM2VMlxLoX3VRv9WP0qKljVI25UkaFRsTzEzjtg+dAxJVlLN8JbtIx2V5dY9NlxvQAJETQ'
        'klrCWDE6UlWNW9zuRnyoh9vIHch7a10A+LS7Ej652ocVTXdlcEcuzhRlXlxwcxvCvntsR6561FQm4jhuEZUt49OY3DK2Meu+1URwSxx3Msju419OWcBseZ7Y'
        'qoptSJIhLM2tFbBLGQjp8u3c1F+uTtFMitrtbWQn/DKuSvpls7Dzqj3E7WOWG3aORJI0fUxjYlRtgbDvUvRgWFnbxR8fdhyZBxt0EjjKkfDxnT6Vz+1fkc5K'
        'ysQsaSk+Q6+1UVS24HLSPRd/05j1lgdum2/0q4jQHC47WMLPIkNzqJ+HZXdgB0Zj0UE/XvVkNcFjNoGEZmJySF1Z9j1qYaP+HcxNMTXAPXxWwG/0NXDVsNgq'
        'DTJdX0KkfmOVKge2+auEDHZCG3ZjeXUsJbCtHGTnp1yetBLcxR6UcXTFR4FieNiQP/E4+tKOoZrdnRfDC25RFZAfud6RK46c5QIOXIOrDnLlT5DNVP6JLvlx'
        'MGueQwXHKJkJzvsVGx96jSy3nEocu0dyzRKxjdXC6uxHi6D7UQm3ttpZJSmiJeYzRIqt5ADU2P8AaipDesxlhScOuNhGx8HoP9jRDdKxBZMzJKV06BKoGB6d'
        'faopeiLXlJGZcblkyd/fGaIjEPNWDTEh0r1WYjUfOgZaRzXF2Yo4ZJGXLsVl7DOSSRtjzNFUC4hiIkBLZX5tJUJ7mqgwqTiJiY5GDeFgdXuRg7CgpV9R08y3'
        'kV20rgLISfIg7/egTPBMZHkjROY7Kr4hiQjOw049qilQRGZRAZSxBOAkOrp132qgJbaIKjJKq7kswjJB8gO31of0cRiRFCXLnv8AlrjPtnv50K0IrVpmcm6m'
        '/KYEfKVx59sgntUCriySOY6m0KBknmoD743OaoVdpZLdS5AZ9vCkiqqgDYZGw/vTELkmtI41CxyJKdgHnxjzJ9PoKKYt1ZzjSEnUqNw10rZ9eg2odTXSwK7u'
        'kU6OcEyBguOm+2xqCDh0ha3/ABJAsZlI49zFkc5I/lEGCO5NY+1eyBhuWjnWRkUFTnKrj9v+Zq6HtxYr1t5C7fKBKygfrmn+kw2G5hOgtaxtjcrzW3Pt3rUA'
        'C5VCWMCYJ8JQkFRnoN6otjvDK+oQBTpwgcnLbb7+f0oKVuLOLTzQqyHqElfbruABQKjuocpJlQxLahh1ZRkdCds+tAdvyrgys90lvGBhIyrMST0GB+uaUA0c'
        'FrkROq4Oz8tjv5AHIzTUzVcFzaxAPFxQTSMPF+RJGU6bYK4PvVhiSExMszS3stsyv4lCBtR7HB/aoKIWtJ4nlm49eQt8oiNuHJA9hgD0oo+IvZcPgFtBxATX'
        'RAaV5LREYyf5c7kBRtjzyaJiJJlyAJlBAO8YAx7EjFDhYZFMbNMWj28QkTJHuaCdrtTqYSsniIITSxH1/eorsKwyTqLsyhVBOmONQxbHQ5OE9TvQ/g7zi0lz'
        'AlvoW2g3YQxZCkjO57sfUmgC1kk5K4jZWJ3dwWz7AVUPhuHhXcgEnA0Lp+px0pFNldo5UZwx3yxx1HnnFOg3dn2kj1toDxjScDfoQf3FAmOOQ6hoklRhhgXI'
        'U+hqj01ugQNDB8OhXxpJI3Xvg9MVBJGtrbhWMsRDH5I7hiT9ulEVyPEjIEtyy9eU+ptXqc98eVUG3w+mV1VRnx6YkGRk46HcYqKRKYlddLqwxqLGMkj6bCqm'
        'OCVsKqqShI8aqBv2G37mpoNJpYwWLyanyQZCmCAeu+/0qapHEbllES6rgahlUCAaj670oz+CuWs/xEBKYp243IcElVwttHsTjasTtX4dHfy3UIWe6UhdgjS9'
        'PWtQwLSNc4I1uqnTrO+/vUSqfipAoQs0ig4JD5HtnG/7VpDlW5iV5IpZIkY/KFI79jjGfarp4CP4pkhMStMVyyliTv3waopSeVoJpZFYsp0sAVJJJ7eY9qIX'
        'JPDrRnSHT0VW1DT036771FIiNsC8DmC6kOy4ucKu3fFRTrqcRsivDANOwjRmbA9d9qBMUltzkVrh7cSDV+VDqz7ZIoU2VY+ew58/LUf/AFEUMfXGaI1bGaG1'
        'tjci5kjELKoVo01F2zpxgE7bknttRZ6iu7mKOFNPKkUnOtZQSPXcA7mqhJxKC7TyqzZBRSDq9hjcetFKjQKpIA64XEZOD64G3uKBLwqN2lADMNTCNs+ROMDP'
        'tTCU1FMkhlNzBqQkl5F1Z88996YPfBq7Ruk1vMjNjEat3zv5Z9KmIHkmB2xMzYOCkZbr9BQFbsYRpQpKjjOkox8XoGA386qnW0cMJc4uDIDsFkCgevuPKiPS'
        'u/N0lbsLp1YZtsejGg5bwCUuESZQo1NqkGw86CqOBLYmXQx1qAhllUqCepx3OO1UA8NoJcERxpnxaFbBP/PKgqW1s4gdM8MxY5KyJLq/br9aipp4jMJyOTAq'
        'rjDyhBp7YB6+1VOFQqV1Npti5G2txIV9dv70Ut2KFDzUDsN9Q1YH2xk9t6gC3aWeYRRTQMcHBk0qAPQt+1DpN0skHJ1yQnmDJYSCQDfvis6qb8PuDwz8Ra7i'
        'Ng/HpGZlHX+Xj3HfNSfS8hsV688qsjRxJHsq8pTgev8Aaqh9nZmYpHCGnl1f4UR2GT5ZxSDVfgN0JJA0LMUYrpXDH99/9asiWxQfw5fAgLY3mn/7yHH+gphq'
        'eWwltoTriYKg8QZAc+5zt6Vs1LFyQXaW2gXQ2FLaGBznpk49cVnwj0ciRSiPllhsBJHMg1Dt2qApLiSCRoWhhXLalSUo2B5ZxVA3U7kNzYYNbfKyFSv/AJAD'
        'yoEG5vE06pZCvQK4Xw+WPIVDHXvriS4H57AjETEwoo9Bgj9avVaX8WmtkjiW9kSCNs6oQilmPViAN/IVPoXJxGW9mcJJOQwICuwYnI3PStJUksogCaj+YNlU'
        'jJGPMdMelQBPzWgebnspkOnII3PlgdqGBSa6k0ZupWVezsPtnzpoCKSHkss0VyXz4S9xhSPoM5qeLSgLNGBhQo5B1ETuf271PD03mJFCp1iKMbBTKRn6GqCE'
        'kE0YXXHqfoqy+XrmqlV2jKnhCLEunOVYnPvnYfSgdFbSsobS8hZSU/MUDPmd+gqmCa1uBoVUjifIwrSrufXfagourGVZGS1lIOkAlwhDn+ojI2Gen3oLoheQ'
        '2UCyXUZRfAFHLJY+XTfaga1zeS27Qm6EvLP5a69K7+ZwCKYqOWS45SrOZ1kByDFKrqPUrg0Z6WZ4Lh4xOqiZDuUSPHufCMZ9avgnv7q3YOghn1f0utypHuVU'
        'HesrOo1u7aYxIVmMgOGAZVJPkMCimyxpexy3GiWQaljVZZmOtvsMAelYV85wxY47b8Qi4d0Ucfl1CNDhv5ePHU7VJ9X5F3D7GxM6srzaNJfUxCEH0G+fatIt'
        'htLSN3w8ukqW/MXB6eQqyf8AE+nw8PhfRIQGYnHJZgrHA3wDRBJYw3Jcx2js6nBVIdeBnH396ZVdureGzncCJI5gMeEIrICO+M4Pp96IlnxI6FVOnode7Yz5'
        '1RKyNKkhYpHHsSFJwCDtknr7Cop1o7CSQmSVc75jj1Hp3OaaHTySIF5kriM5OzaWJPnTqIRMsca/mAMxIG+SfOqGW8kbM06SrqXz3YHsfWi/0yBJZ2KjmmP5'
        'lzH1Pr0zQUhEkcNCXQEacBCXz36EitMkxIjRpqZHVM/N4Dj1Gagp0W11BHG92FVXbd1xHEMZ6jf96LrOdoJmWMSW8ijdcsDv577isqghuFaXI/mXYbln2PtW'
        'V/alShwjwJak9GY429Dv+lUPtAtvJ4RK482Ut9iRVmRFMUxkjxp/L3JjFurH74oG2fD5L+dVS3uUXVqK8kHHrjIGao0rHg4Lc20sbm6bJH5tpEmk9NW8m5/S'
        'qn9VrwWGydInsbt5BuwSCCVgfI/mdf2pp3oI0RruNbk3MSLJq5UFojMfQDJ39TtUD7gXiSqjWvFBZ5zGZVX8vPUgA6Rnv0xT9rUK2cstrLIDyI1OCJIw5x5e'
        'maqdJWyMLROkcc8fTRyXCtkdDg52NQ0M3DSrq72LJIckHkSjJ+o6UIneEctyEPM1ZyVAVRjyxsSe/arIJrmVkc/DzTBgNLAlQvqo2yalWfswuxsEjQqY8fIE'
        'Azvndvesq+e4PbtcR8eWQO8/8ecZPf8Al4+o86k+l8kfQ8N/D17Pl1gmCx7uYbdn7+2CfTNaxNg4OD3rNKzQtHEMnEzBFBHQH19B0q4m+tS3/D99KQkdtFNE'
        'oGHggYhts/M2+3SrlRTNwni7L8K8t2EfdIQVAPnsGGaXVZz8J4lw6MObcWsa4DMLdFBz7tk1MOltwy4eR5OZHcH5tTMgzjO/zbY8qmqlNnK0AkuZtj/hlSrE'
        'nzIGwFVAwWrJtGymXu2NQHpjANFN4g8iO6w64o1TfwjQCBvg+XrVZZhaedkJEz7YO67emBQPkaQSRqzEMgxq6kN76h98UU65uA8episSr1yhOo+pBNJCvRP8'
        'NqMckMOtcGXks7MPQ52+lAySHXGIoBblSviaK1JP1JP60KSscsEIjiZSinDKIUBYZ7scnrSgr+QQQGNHjmhSQKzNCofV164zis8WMVi0w5iCNtIAUiTYjHn6'
        '+1ZV2OMTyltQViNwSSB5YNXpxdZyaNJkhjcg9NT4PltmkDFkcwr/ACVoysSWd2Iz6BQQBitMqbaa1lVytlZRL8vMQOQTntk/Y01VKxvLyv5W3CKT+bJAo2+v'
        'YfvQX8NkZGlhtbJdUnWNIUV3Ud+mfsRVGhDdD4iCE2FvGGYBjMzBFPl5Dz61BoTtDJExzw2RWP5jJFGSoHbwt50ElrHBHxF2nu+DKJF2SWBnXPbKBv1NKFx3'
        'XDvjY2PC+CKIss4Fg684djgPsP1q4y9cfBXMtwywWEMradMSWEjnHkPzMj3+1SrGfdXFjEBCLCxVFG8kkLrqPorSE486ejE4lcQxXjyJDgyYOqOIxJq9Bnpi'
        'mgbeYvHyhABqGoSaRqAHXBz0rKoeAW8kNlxycCN4Tx6YNzRqAIt48bZz9an49q3kaUUd3fuyPKw7qsbEAb7YBOAR61pnXtDCZXkvNbounQ7NkD2UdfWrVVuD'
        'JnmfzKsudPMbw+3mPfFNQ0W8CwxGO2iVFBMjPAFOSeq5JzjuT1qmaXrtuHLltDgdBpUMPr2qbCO3F7GW8VtFJqCoA0a4652ON9qBUnGLBwQ3CLPl9MtFIx7d'
        'fEKKqEMA8UPCuHhoBh42smd9RHQnmdaqEltTO8tjaw4y2IY2RkPZSAxB37fWrEBZpLCUdoUZpSVjMkSEDzIz9qBN1a3DSGSOLSinZRFFj2OPOsrw2Phs8p5x'
        'KMjDdAVjOew3IwM96pgBwG+S3V5OU5TulzHlf/8AVRceh4FNc3qxJySqJnMlwqqw8ydXWgVc2MsbzRsbVWjzhbacSAD0YGmoG5tZXaRC8LNhH1rMNtumM7mp'
        'ishrVUtiZJow5GFCSKfuR0qNGwWwjAyyKpG7/EIQ30ozT0IVQX5EgHyo7DJ9tqsg6TAyeGO2GSGZT326elaRSs8cSt+TbursCYidQYjodIH+lBTFewr/APRg'
        'hBbUscMYVQcdACe1FWQy2s0cbyQW0rxnJDyMuDv/AJWzjFQMtoXuojJa8Od4wSwaJXKfrkfSg00leC4njfg0to6AeBCuh8jwk7A/aiFQyRvGySSIZQMSLJHv'
        'q/zEgAgUXrkNhbzLBdyXEIi1nJ+GmYZHUAgaT7ZpvxCL9ore4jmhiVI4wfHPbsHbPrnA9B1oMCNF55W3bOW3yck58zj9agVxDAZmcflt4QYgWUfU/vmip/iA'
        'kqsZseDC59O3SgRwGbTYcZRYUZ145IwkGrWSbaPwggdPep+N9sX8p5K3ZJryOKJbm3Kxucqio2Cw8wRua1dYOt+MTqhEE8sTN8xR2H02GfvRS/4m63D/AJjN'
        'LnfUGY6vMEjfHtU1cVwrxMhA890W5gblmJmJx2KnGPY00Tzx3LSGZHu1k6lZUAB9+vTzoJTZylWlupZxhtSajryTnqD0oWu2sMvMAjnaKVjnQIyCfYjrVRa+'
        'mPmANbuSpJWaYA5x+/vVCY2M6K4ZdO7O3MDBV9AN856edBPclJOUEtoVCHcNE0m23ct9aBQMQlkCpGoOcPyRgeeB/foKgfLItxBy8Qk9Oc1uucDsCf3oq2ws'
        'I7aD4uOC2kniwNKiJwWPTKdSAN6CW7El3KBNiQk7zNCq4Oe4Hb/maAGaKMZjZcj5VZApb/xGdvrRC7y1BjYYZdskgKAPQYzt6morPMUMcShbr/v/AC2wv6Uw'
        'dd0idAz82POBoBXHXz7VB2G6kgi/LbVJywrHVjG+/XvQWWt+H1qsWpmU5KsDitSoMtMNH5ckTZ8OrDfoeooHgXDoNVwgk1AjWsYwfXHQVRsJI0cPLmv1XVvy'
        're2BY/VRsPrUtGovD0ZoyeMuYmAJTRITnuVUfao0S/Dp3y9ndX6yg9Y0yVB9G7n3qoz734iyE6ycX4gLg4HLEkZ1/wDce3pUBJcyMcR3VzIrIHLK5AXPUnxB'
        'c+vWlAXF/wAQnjUyXXFG0HKSRkFT5Hc9f+ChWdxLiF1DJCyyXkUjxku00gCn0CjoD5GiMtrt3nEeZDpGrCT6RnyA6ZoI3u5hIxd5B2wratvLeooOB3I+C48Y'
        '7q4hE3G2cxxY8eLWMeeakntW8jfguZZYkKy3bxqDmWV4wSPTJyB5GtMkW1wlujfzdzBr7xurZ+xBNMV234peRIY4ZrlVVtStJJpYY3BG+V333JOagXcs3EHk'
        'mvLqW6eSQySPczaiznqzMWySfOilSJbCFTHfOq/1iOQg+m29aQImhkCqJ5JBnH5gO/33pEdSW2jLaonaT+mQkhQNu1VFcEbbaLqOOCRDq1kLp+/9qi4OQHlT'
        'i3mSeJcNqKBQ5z1HfA7GrgjnDHxMqiUjAHM0gD1A2rJDI1YhkzCAyEEnBOPf7dK0GwmYRw6+GSSW4OAYlwcjsWGenrUFVneXkQIk4bYypJgabgYA8sYOcVUe'
        'cMY20w2pweouWHTtgjt9qNDurUxzKY57O7jePPLVBlT1IIOPv+lQKmDXLeAxs2jJVGRdh6ZxREV7ZXlnbxsyRJI/QNOZGUY8ulKJJbS4tlRioUsNWHJ+nTbN'
        'RXoFmG6Rxk9SWjJz98gVYLT8Wrs3w50ooxpn5anI66cAn6U91kNpZzOzLy0k6hmYZOffHWnFW2PCr+9VW+FuGEQwDoAwPM4AFCteHg3EImhIt73ksmpWWa30'
        '47ZJkyB70vVU3HCb5cRG0dXbcyzXMKhfZuZipKI51FrAI57lGuicDEo2HqVBH2qjNS25eub4m2i5hyFV2Ow7jbepg8kMLXceuVLlWOHHLDAnqMZ6n7UxDfir'
        'VJnYWN6zEZCxXCooH0G1VQSX9nbxQtFwt45R49fxUrs/qVxgCoMW44jDdSySaUfxZIMshyaaI4LuASyOBG7N0VmbC+3es6BgmYWnGVEjxIeMuDhUEf8A7eM7'
        'k7ipL7VvIugumDDm3OmBB1jmjGn12Xf2reslmaJpWeVp5y3yl7kAgewxRVDLaNDEMnHzAOUY59s1fE9GtsJVR0AIIJCgIc79wN6ivGzaSJTDA5ZvlKrvt18I'
        '3P2ohckNwFVXEyquQSVIJO/XarMxAiF4S6OsiqoyS8Z2Hrnb/WqNGGDjTJGkPCZcyrsxty0hHbdun0AqfVOHC+Oqj28nDb8sWBZPhm1YzsNh0z2oEnhV/byT'
        'QycLuojjSddrIpXI69N6BT2U9rEuq0nQK2FRoXTOBkgnGR51FDHcIY5GfmguCrLblunfJ64960hSI8ci8oPEFHhIODj171B15I5dQUOoUF/zHONvLFA22Nni'
        'RwtzGrgARxzE5HuRvk1NUtrGxklLpb5dRvEzAnV28P36fWnnV9QrILVfgmCAoBrWVs6PID+9U76aLYFXVXjWP/8ALt+vaogUnZJY1W6KqP6jIQufPYZpxWha'
        '3cUjSsbpAwUct9cgjB8m8PSqihZJXuFVbxplYgN8KxkB38iBn2oihBKHmiYXEZDhTHcQmNs9iRkDcUVXY29qsjSxWrXcoQ61iQuoY9iAu2KAzZ3V3ES9nMtt'
        'FkkRwqgQd8FgMmiPWlnIYMvJeBcEgPamQkYyFBDDeoM17i5iVddzPaCQhXEild/Rd/uKip5gYHjaGUyIwKu7orZ8sKd8DzNXQhWTWQXheM5HMliyFPc+E53o'
        'Jp10wuzENHjqq6FI8gAaUSIqIsnKjSNQgBZlBCg/896zVT3Eas6pzVwer9vvUCuDzgW3GreK3kmP8ZciZcYx8PGMb96kW8VRzzGUosPLjXYKCC31PSrqHI1w'
        'ghZ7eNXPh1uqAH1wTmqLkmlaVCArSHwkII1B9D5VWXZ3kieNXmsmHU4kDld+hIA/SqJZpJVBZDHq2wVkAOPT/TNVRKOSR4lIPXE+cDz69fSpIlOka3MhzJJc'
        'BiMYmY56b77VvE9dRlnjldopJpC3zGVtz6kntUVT8FakESiOPI3Ms0oOfZTkn0qUdhPJEUUIW5GTiY8w7+XibfFXhpTzKqkxzQiRnzpQO0hx31eXaooEhluH'
        'OhWIP+WOQkH3A2+u9QUngl9DbG4m4PccrOn4j4SXRnyJIzn0qaJrjhUgRm0sudxrUpqHswH2qgLmzEHLIMJYoDIDIwGT59voKYccgEiTECRH8yuWH6imGjbi'
        'N7LEpKagh0ltKDfsOnlWt0cluZbhY2kilkkX5NLgafbI/eoasheWCVXW3ZnAwHlmQAH/AMaRHnv5g/LmmYsSMo0p057Hwig4/EJL1+XGVnB2VS5KgDoRk7mq'
        'LbGUIzTyoyyICunBkEz42Xc4GOpJyPKpR6LiEryxIBzHXZFe7kj1HvnBAo0KSSPiMhluoYzIDpEQZyoA75zt+tIg04eqxyc7QvLwMyBQq56YyaUKbhkVqqJL'
        'KFDHAkiCN9D5f6VA64isZWRGndI4u6JEgY+bYXcVMV7RwYR3B+JnDLpVAs8WJCfTT2p6eI+IWdjNayrHNNPKo/quI9LevTfNaRloYbyB+cziIMPDG6LoYDA2'
        'J3qUiTkwrNhpA8A81JY/bpmsVWfbprXjxxmH+NNpKsTj+VjP1qTrW+DVFXTjSTnbG4NVFCxOQshVnV2wWjTJFVGgUVYo30zQgEjYKxb0wRtVQ0LEyjCTAjsy'
        'gE/r+tXxHJfhviCNFyYckYWNBjboDjf3qjjRo0IOpwAMhWIxjyyBnPrViHcmFWRnVsatKKMsT6f71dFCRWztGOXIgYFjyrUSu4A65J296lpi6KHhVupZP4jJ'
        'cN8sb2S6QM9Tl+npU1fCnksAwklvrtJACrIeHINseWvb609Ikaa1LovxFxDENh+UFK/+IJ+1MKk+IiikfkT3OjPz6HUt64B/WqdHBBmJnbTqXfmTA7fXP7Vn'
        'IKoLqJYpJXU6hgFiWKDO2rcE/SrQi8mhtrNlSdmydOkEqx88eDY+e9RWel6sbhojIAvYSksR3wcDFTTHYvgJEVZln8GTq5xQN6YAOP71rBRI1mw0WluYcj5H'
        'ndz98ZP7UwW/CtZxRMYra3Ru/wDEizHptpC5piJJZ7USKwK4iHiDyFi577EfSmBGIJwpCwAlyDFGCZB7LjBH70Fy350xQPl0t9WlimkrncqV9KFc/iETKqOs'
        'jJIuoFH0L6ds5qiiXiDLCiR8zOosyrN27Zxvn3oRK8yMWBRWAKsWBDHbqAainyxwGSNDOAdPhVAGOPboKobFbg3IjWWLxjpIwTSfM7YFZAh2jjxrRoica1kz'
        'jHbOOg60MS8RmkkVQiQEnVrZ5NTEdtgMAEU1cYl0ZIm0iMHP9RAx7A4qUBIIXddauVI3GagVZppg468RRUPGjhZGCgD4WP8AWp9p8hyxqxQC4LNpwCjAqPpj'
        'YVcFkcX5cOuRyxB5miTGnyoNew4aLmB+VG0uRsCS5FaZXScDkV4kMYTPy64wn3y25qL/AAueygtCBzraAlcShrgnHkByx+9aGY2h43MEDgscBy8vTJ3AI2p8'
        'RTatnncuE3ChsBWMyDO2cHFAPx0kk2qKwVdKYbOt8L31HtU9VMvEHkckCCTDbK5kUehFAMF87HmflZBOrWA658jVQ038s3hBgCqNTISkagfuaLhDypcSoUhK'
        'J30rufX/AGqiiedJIYs26akGFTDDPqd8E1OoD+JrHEQtojqdj82PbNLVKuRr5WpDAGGFjkdRkehrJGYxCayAj4fAQNkAVlo20lSSUKURsK2CLgrg42J/361v'
        'bWfI8t2Y8sAeYDoWRZ3058yB9sUApeSxTPJpTSW1eE6WUeWfKgc3ETKWdXimyfGeZsNvI9cVdMd+LV1P8zbjljUqNIV79BgVKHPKqqzAqNI1EoxOT39z51Ue'
        'inKuGlhdlwQCjDUPqaKVLbctpbi5jEC9n5SFHJ6DGcn370GxHLB8Nbm2CQzjDGEwtuO+GGdjQULeLcNcM1polb5BDEEIbsDn0p7BQk+my1CGZFbwsXYHfuc/'
        '3phop5YLUHkRTqCpV3nKsSCNwNOwqLxAbiKXLIIFATBEzBtOOmxPbtRN/wCsSdGeWMNMJTnGF07f2pRJdEQTupXxg4wxAXb2rLRfDy8ttxeFmWMnjbAuIxg/'
        'y0ewHY1idq3kaCWUU0Th5RHKoJVpLZuW2PNl3BxWkIs+HxkKkkqnO6lLaQ59DmrBbHbKXKSXHKI2CrCfF67dTWmOtKHhD/DcyFHvZgcsEtmbAz1Iq/0dbh0t'
        'kS0kEojcBlMcZUt679PrQHJNMsDDDoW6Fgd9+uf7irp0k8TkUpGXyT1Rmz5bAZ60Uu6d5QS5YZOCzBiGOOhxsTWQDtcvA7xyTqy7YB6juP8AaheCt7lTIpeW'
        'U6QdyQT02yOhPvVQ5ZLV0CGeRGBBIFvEN/Q46VfAzm2r8yMTH/8ALyY8n642HrQDNBZgAy3LozKGBWJTlex8gPKlyHtLu+GWSWys3FkYMdQtwsgZffbGani+'
        'oL2G3kRZPjIdS7BSHJx/+tZuLEDiM4XnJv8A1ajj9qlivW900kYBbUh2VU0r29BvRFF1c8uLSxaTAzmNQcCqJFmdkI5rtr6fTzGOlAbTThAWMnUbJgffaoKj'
        'xG4tpgBJKxcDUqaWC57Zx19KqDtLuSSOYJGAp2LyeFcd8ef0qhkd8Y3UxwSIVIB5UjEe2COhoLm43xCTIlZZF1ZVXjDlPQFhtQFN+I+MySpmedttnMg0geWA'
        'KBi8VmmtxBKCJWfVzgCXP9s+tVf2ut7+4tIYpYZpJViJy11AAMeQODk+pqJwu74y95JHzrlwIl8CnAAB6kKcZzThWTxLjRFs65PhkD8lQuojGADhck9Kpj6v'
        'iv8A0Z4/YcJtry4vOCQXtzHzzYPdyNJEp3Cu4HLDenQHbNY1v/L81ZhJNNFOJLeeFzHJG2Moy9R5fXvTrOG8JSWXhfGoo2eVP/UDs8pIBx8LH1J6VieWtfI+'
        'h/Bf4K4r+NuLy2HDp7a0gt0D3F/xCVlhhBPhXC+J2P8AlX3JxV3E/wA6Z+KeC8V/AV4ttcX9pfxatKz2TthG6gFX3X9RWp+ULEkHFuIqupL+Y6z4ijDp59Nv'
        'atsNaK/lWJ7Vr2CeMsGYMXJLf9y4zVxEzLEsy3KTwO0uGcRyjHkPX6d6inSEnnYma4mGGBVZZSNzqBI8IwP3oqJeOXGteSWjjTfKRaCx7nbfb9aiJJb+e5ds'
        'yzTKASA4OR57HYZpqkytcyqkcr3DgH5MYHtgf3qQcjgWFMyKcZyDoz+n/M1pHpLpJXkcLJy1XCofFke3maKoE9wFREkk0EDCg+H9B+lNp4fZXV0FfVJKuRgo'
        'sjYwOuNu396nqJL6/vLtgr8yQIPBqfOF7HJxRSOGwcQ49xnh/B+F20t3xK7l5UVsrhAWIzksdlGASWOwFZ1evofxl/0c4z+ErFribiHBOJXiDmS2NheSPKi9'
        '/EyhWPpt6ZqNY+Y/CPCku+FWYliuDeNGCf5mGKLPXALb53qxmtniHCVtDzJLPXCoy7fxWMtnf/KtVEFkbG6nUQ27RrHlist00iH3CgEVFTzjluV5Fsu+dQld'
        's/c1Q3nWXLBMXDomGxEzzHPtpPSgQbiBQum3svA2RoaVgc+hoBlvS8mI7hYox20sq/QeVB2W6aSHKXLrqOMqvb0/0oGw3QWdzFdTOqAaToyzfQCqhr23Er/l'
        'ukHg+Vcqep9yKGmzw8T5qoYwbiI6eXHgjV5YBwfeopd0lxBIHmgW2ZBgKUGxPXzyT+lMTUl3PeWa295oOLeVJQFQAeE5IGKUnW7xf/rHc33BILZbxXtAhQgE'
        'AHc757ddx2rj/p2/r4Phd+vGbi8uCxWCSQCNyOqqMA+uT+lX8bsZsxq8Dma54ZxqOKFZE/j0m7xhyf5aMAeg9a1O1m/G1wL8d/8AoviU8EuVkkcSxrkAnbBx'
        'nbIx9jWfy8a/Fi/i38dj8TcQitkRVlmlXSiD5EyCTjsBj61mW241ea3LQ8PtreQG8dWj30xWbudye5wK9Lgui+CuHJ13ksAX54o1iOfLJ6ChiZbuwROUyX8H'
        'iBMiXYLYxv0Xv3qofxGbh/wjpBrLDw8s3cmsjfw9OnepVjOccPS6jC3Akj0gMqq40nbbcb4qKTdLZq4dJ4yuRiIM5IHtjH1qYu4pSWw5crPb2sj48K6pEzv3'
        'x2qlL59pOrhVtCCAPy3myn3ogrI2zy+O4toY0G2uJmLHy60TMUNPaiBo45LaNQSBILeTVp8tzsKhj1rLaLFKTxPh8WtdBjktXDY9waKmuYbadjItzw6fR10R'
        'vj6jNMP0xRxqL8O8Yt7/AJsUMS6o2lhRlRAw/qz/AEkjBIrP5eRv8etb8Xf9Xm4jbeK4FwQgDzuQfrn9uvpXP/Tc/FlJNJDA0fJSOQY/OEuSo9F866uSq3l+'
        'L1M15MVRTjWM774HvTT1K4MKDPM8Ry/5ybH2qEGIkfPMDbDb8wMWPlTVN8aRmNYAqt8xZgSR9+lNHEVljQ+IsHyqqRqC469aBmqQxEtaz8zzLKEA8+tVHpDM'
        'jqRE5jx8wCj65qoctzOsmNBXUmFxcsNJ8zj9jQIBw6rMI5e5E7asfZqobJCwjYMI4Y+o5egKv2OTU4tJRbhoiRqROhKuo/c7VN+ApoLiSMNIZJVQba5Bgewz'
        'tU1WJP8Ag2zu7pXe2i1uc52w367/AFrOSr7GxZ2jWmpIhGkYwCPD/rVEXCmZeG8ZEILMPxBMSEYEj+Xj369KSsncU4bFxSzEd3Yu+d9Mjr9xvkVq+ibhnBLT'
        'gas1va6S3VsjLe5Jz7VJJDrdW5SVFdFnDZ3DXA6eRx+9a1GhZSmVpmjgSBwAFAmMmd/fGfOgKS1ukZQksMwChw8JKoD5ZY9u9XYmIWuZyZCzPFKzbvDPnbfp'
        'vir4EO8iTRsIjddysj5BHrg1FKubiVkc8jSxYHSCQKlHE1xSrlGVm7tNp2z1ODUDFinuJNMYBPfMhbPvk0UTwSmYymBgynToDgD7g7+9B2aK7SZHkhyZdscw'
        'YYD69PWiPabguWeJtRHXUgHoMA1VxM006CUSlGYjH+OEP0C9R6UgnZDfRsGjVFxggvrz9D2qakjLt/wPYW90kyWlukmcqMjA9QM4FZyNbX//2Q=='
    ),
    'concrete': (
        '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/'
        '2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADAREAAhEBAxEB/8QA'
        'GwAAAwEBAQEBAAAAAAAAAAAAAwQFAgYBAAf/xAA1EAACAgEEAQMDAwMDBAIDAAABAgMEEQAFEiExEyJBFDJRBkJhI3GBFTOhBySRsVLhFkNi/8QAFgEBAQEA'
        'AAAAAAAAAAAAAAAAAQAC/8QAIBEBAAICAwEAAwEAAAAAAAAAAAERITFBYXFRAoHwEv/aAAwDAQACEQMRAD8Aj02pvPagvRSSsWxlo2BdMfcRnIbHYz41hrKr'
        'tu4uol9P1XjkQQCFFJQxqcHmfAZOm5H4JA0ScmL0cUm5NWXjKoA9O1VkZo7J+WCfcEHgfOmNCi0kBF5I2jjqSQKwmCFnUjyzE4yRjA4+OsauFDFhJmuGOExf'
        '6fIUDGXHEkt/uEN0inwcHJxo/a6Y2XbqMwa7Q3dd32iaaZzMIfT4vGxU5XOMDBww8gaYypuJytUrVmWeSnDJJZNdwyxOxiETMOeWY+0FlAwB2R4+dA6Tf/x4'
        'NHPudn1GuLJ6kFaJeOGIPIg+MKgyD57PzpwQFaCSG5BUr17VPu/YlimYtHgBMcD+7sdfGc6Uc3GrDBWF5bs0EaOiSWhWDOMjixcecDw356xqDit73OjWtrFW'
        'ijkks2nqrbvykSzRKoYiJQOJbx58DGgno9vaNYrqWY460riITz1zwY+FBP8AwP5/A06G5VqGzySzWLMsb0GEh4TOMSl89ALnJHnx1qmSzuS0NoWxaE3JJrYS'
        'tHcn4pArfCgnyT9o/toTU1+StBJDKrAO3ORpQQW4n2kr4LYJ7+QcaklbTuF95jHft/TXfVwk9GsFiZcniUj/AGnGR+c/304Bum1Np7UF6KSUlsZaNgXTH3EZ'
        'yGx2M+NBVdt3F1Evp+q8ciCAQopKGNTg8z4DJ03I/BIGiTkxejik3Jqy8ZVAHp2qsjNHZPywT7gg8D50xoUWkgIvJG0cdSSBWEwQs6keWYnGSMYHHx1jVwoY'
        'sJM1wxwmL/T5CgYy44klv9whukU+Dg5ONH7XTGy7dRmDXaG7ru+0TTTOZhD6fF42KnK5xgYOGHkDTGVNxOVqlasyzyU4ZJLJruGWJ2MQiZhzyzH2gsoGAOyP'
        'HzoHSb/+PBo59zs+o1xZPUgrRLxwxB5EHxhUGQfPZ+dOCArQSQ3IKlevap937EsUzFo8AJjgf3djr4znSjm41YYKwvLdmgjR0SS0KwZxkcWLjzgeG/PWNQcV'
        've50a1tYq0Ucklm09Vbd+UiWaJVDERKBxLePPgY0E9Ht7RrFdSzHHWlcRCeeueDHwoJ/4H8/gadDcq1DZ5JZrFmWN6DCQ8JnGJS+egFzkjz461TJZ3JaG0LY'
        'tCbkk1sJWjuT8UgVvhQT5J+0f20Jqa/JWgkhlVgHbnI0oILcT7SV8FsE9/IONSStq3C/JMY79v6a76mI56NYLEy5PEpH+046/Of76sBilO1W7NXDcwik1rEw'
        'LENgEZB7+cjPzjUfVWC5JQYSR2Za9dZDF9Qxdvaw5cWXyQTkkY8+OtFK1H63ckkLrOiNYcJC0ESxc08sTg55YwRjAxqkxBys/r2pa8CS26rRsLElV1XOBkBC'
        '/UmCMkH50SkScVzNJIJEj9QJLwaTjB5wrOuCXVj0AuATknoDSo6U1WOyKsNlFlm9Ni1eGPjxK+eKrgMEOOj3jzptmn31O2z3bu4VWeeWCpOstZwZPWGFwSAR'
        'kqMlDjK+740RU6kzExDJp7rb2zlYsSQiGVlrLEnqiYDsP+CCDgD570oNPSs2RZrTF9wl9skprCPOV+0IP84Pk4/zq1tV8KyyJJKyWNyjWeZ1axEmUSZEB9ML'
        '57DfJ89+dGzPSdFtA2YVJLVmCKWuMrBPH6hJZTkxkAgMQe2BwBnWgNHcorWrC5DLaj4Sq0SEkOx8hV+3JPWfwPzoHT3aNtrUDJJCr1zOP6YnhecK48Ro2cgY'
        '8fGmkb36vT/UWxxVtx2ajKKaxXBcySxnB5B1APWDxBHfeqlaZuFq5vUNeWIPORJJKeRCBT10UPZJOf8AGfxqlUxLVSaIRMsNeU8YGVXbCeTnke15YxnyMYx8'
        '6JtoKlO1S7NXDcwisa1iYFiGwCMg9/ORnycah6qwXJKDCSOzLXrrIYvqGLt7WHLiy+SCckjHnx1opWo/W7kkhdZ0RrDhIWgiWLmnlicHPLGCMYGNUmIOVn9e'
        '1LXgSW3VaNhYkquq5wMgIX6kwRkg/OiUiTiuZpJBIkfqBJeDScYPOFZ1wS6segFwCck9AaVHSmqx2RVhsoss3psWrwx8eJXzxVcBghx0e8edNs0++p22e7d3'
        'CqzzywVJ1lrODJ6wwuCQCMlRkocZX3fGiKnUmYmIZNPdbe2crFiSEQystZYk9UTAdh/wQQcAfPelBp6VmyLNaYvuEvtklNYR5yv2hB/nB8nH+dWtqvhWWRJJ'
        'WSxuUazzOrWIkyiTIgPphfPYb5Pnvzo2Z6TotoGzCpJaswRS1xlYJ4/UJLKcmMgEBiD2wOAM60Bo7lFa1YXIZbUfCVWiQkh2PkKv25J6z+B+dA6e7RttagZJ'
        'IVeuZx/TE8LzhXHiNGzkDHj400je/V6f6i2OKtuOzUZRTWK4LmSWM4PIOoB6weII771UrTNwtXN6hryxB5yJJJTyIQKeuih7JJz/AIz+NUqmJaqTRCJ1hryn'
        'jAyo7YTyc8j2vLGM+RjGPnRNtLSbRISs0lCOaV09nJ39oIx0vlh/P/1oDdueeSiYJkeWek3smsJ7FGQFA4e5uuvd18fnQage4u4xrFG8KRxRShobqQsjKx+G'
        'HYIGfK+f8ainw7pujreWPNVYp3iSzfT3hF6DhB0FY9d+R3ozoTTlP0idyEO6NukUm4SzzskQlOTUQn/byMf089rjsZ605hTLsVtyIleaxWszpVjTjGFHqcsh'
        'HJ+QT1lvJHWNPKMRbvNILIGzybafrmAVCrvKgHUw4+VYnHE4x86omFJfa5JZ6NSbPOvK8nCC0zmQKCcgeMcT0f79aZEAU5H2Sd/rZEaJEZylpmgVmY8kYEjO'
        'B9nEfHZ61eGBNq3f6mOwJJB68iH0plUMpjU8uPLHsxgjx2BnPeqhby+leHbaNSlK8UElSL1sjkoLkkFVHx33g+OvzpFOarbU+z0YpRNM0jczI8ShoIir45Bs'
        '5weiFx12NW5SuP1Ddk+llnuGnOJAryyS+m2OweJA+cnyOs/yNONAegrUpvRUpJTdykcU2VYnjkEH+R5x89+dUKW622wb3JcppKwAlLMq/Z6qeck//wA/J+fH'
        'egltwtLPFHUNk3AkbSMHfPM+OYGBkDAH/OiiortMrFZ5KEc0rp7OTv7QRjpfLD+f/rQsN2555KJgmR5Z6TeyawnsUZAUDh7m6693Xx+dBqB7i7jGsUbwpHFF'
        'KGhupCyMrH4YdggZ8r5/xqKfDum6Ot5Y81VineJLN9PeEXoOEHQVj135HejOhNOU/SJ3IQ7o26RSbhLPOyRCU5NRCf8AbyMf089rjsZ605hTLsVtyIleaxWs'
        'zpVjTjGFHqcshHJ+QT1lvJHWNPKMRbvNILIGzybafrmAVCrvKgHUw4+VYnHE4x86omFJfa5JZ6NSbPOvK8nCC0zmQKCcgeMcT0f79aZEAU5H2Sd/rZEaJEZy'
        'lpmgVmY8kYEjOB9nEfHZ61eGBNq3f6mOwJJB68iH0plUMpjU8uPLHsxgjx2BnPeqhby+leHbaNSlK8UElSL1sjkoLkkFVHx33g+OvzpFOarbU+z0YpRNM0jc'
        'zI8ShoIir45Bs5weiFx12NW5SuP1Ddk+llnuGnOJAryyS+m2OweJA+cnyOs/yNONAegrUpvRUpJTdykcU2VYnjkEH+R5x89+dUKW622wb3JcppKwAlLMq/Z6'
        'qeck/wD8/J+fHegltwsrPHFUNk3AsZdg755nxzAwMgYA/wCdFE8k9dqkT145IbXqDADkFSvkg5Oc99dHRZhu/s9iSpBbi3o7bY+oVo0NYyqgjcf7wz2jlivp'
        'ecHOszlrHLU26ujNLOXnaCz9P6lSQ+mqs2Ayjvio8H5zjGtQzIMxNy5JK1eNPaxUoxcFQMZB85z0f+NIJ3NxrX6zrJVlSGEAxCOwDwfwSW6PIt84IxrN5PB+'
        '7KJTCbFiWvHKqho24IvIA8irL27HGeR07HhZ7kMgpMkHJ0hZJZorGChZsqwA6UgD93z3ps9qFoTxbSZoWuShQiR2eCF2JOfPkgf/ACx8Z+dVQL+vN0v1tpsT'
        '2FjmC2bKF7COZ2DhAC49T7Swx0B30dPS4R7l6veEG21oxC0YJkkjbHBfLDkcd4GOHjvQh6U4+oRYoYgpWRRRAz04z3IxwoUfH5PWqzEcjWlvIBFTqpKoUvI6'
        'x5eTOPkDivEAd9cu9MDCbtsVGW1O1Wskn1BM9l44e5JDgMXGckkADrrONQmKwYSCvW22a2YpGaOZBFYV8gK3hSh/n29f20gKO7BNYsGejLWXgHJYGT1eJ8Mg'
        '7Hnr/nRbUQw8zu9UyIfVknWLFuQKGLghUBPQY8SePYONZmYg1aqs9dqsb145IbXqDA5kMpXyQcnOe+ujpUN39nsSVILcW9HbbH1CtGhrGVUEbj/eGe0csV9L'
        'zg51ictY5am3V0ZpZy87QWfp/UqSH01VmwGUd8VHg/OcY1qGZBmJuXJJWrxp7WKlGLgqBjIPnOej/wAaQTubjWv1nWSrKkMIBiEdgHg/gkt0eRb5wRjWbyeD'
        '92USmE2LEteOVVDRtwReQB5FWXt2OM8jp2PCz3IZBSZIOTpCySzRWMFCzZVgB0pAH7vnvTZ7ULQni2kzQtclChEjs8ELsSc+fJA/+WPjPzqqBf15ul+ttNie'
        'wscwWzZQvYRzOwcIAXHqfaWGOgO+jp6XCPcvV7wg22tGIWjBMkkbY4L5YcjjvAxw8d6EPSnH1CLFDEFKyKKIGenGe5GOFCj4/J61WYjka0t5AIqdVJVCl5HW'
        'PLyZx8gcV4gDvrl3pgYTdtioy2p2q1kk+oJnsvHD3JIcBi4zkkgAddZxqExWDCQV622zWzFIzRzIIrCvkBW8KUP8+3r+2kBR3YJrFgz0Zay8A5LAyerxPhkH'
        'Y89f86LaiGHmd5KhkQiSSwkWLcgUMXBCoCegx4k8ewcazMxCq1eDbLNpIDHSjHIGRmcYkDKcR8BkdDHbHOkDbpdcbSkUX9crKJUhZ+JjB+4lyOwT0P4xpo9p'
        'i2J9xnRIhWMbtylrpF6ToVy2T8HoHr5I1mcIa8llrdextFm1WjMgsI5TnM5CHDEr9ufAUefn86ukToUkagolikeFq45zKoSVH7zyV8H+CP8Axp2Xu3JZWam0'
        'skckYQpGkZ4OVHROCMYzxJx8j8aJCpsm0qslKS/HxpvZSSw6Jw9VQDzAGPewYgjPyT+NUEHfJKiWH9O7ZqyK5XjUL5dwcglgMKP4PWlWTgF+SF1awry5e3HP'
        'L7mD98T+SBk948agly10rbhO6/V2Inwq1p0CrCOOGwfPZJY5znPWrlKZ26Wrcm9Pb5rVdeCK8ZXATj00gOTno9/wNIMSbnS2hZa9aBtt25hzmZXk7f4aTBJ/'
        '+9C5Tr9aNlVo5qcu6JMs1VJVZwrEgMAwxgsPHnBI6xq8L9Bh2/Z6/wD01ju2EatuD25S94WEmf1RlRAYwcEAYyB33nPesxOaNYctYEyUI9whq/ThZlPOTg8c'
        'Y/8A2Nx8t8Ar8Z1pnkvPSP6h9KCermWRlkVGTkpKMWTiD9vHv2+QNRmTUG22LiQNHSjHMGRmcYkDKcR8BkdDHbHOoaG3S642lIov65WUSpCz8TGD9xLkdgno'
        'fxjTR7TFsT7jOiRCsY3blLXSL0nQrlsn4PQPXyRrM4Q15LLW69jaLNqtGZBYRynOZyEOGJX7c+Ao8/P51dInQpI1BRLFI8LVxzmVQkqP3nkr4P8ABH/jTsvd'
        'uSys1NpZI5IwhSNIzwcqOicEYxniTj5H40SFTZNpVZKUl+PjTeyklh0Th6qgHmAMe9gxBGfkn8aoIO+SVEsP6d2zVkVyvGoXy7g5BLAYUfwetKsnAL8kLq1h'
        'Xly9uOeX3MH74n8kDJ7x41BLlrpW3Cd1+rsRPhVrToFWEccNg+eySxznOetXKUzt0tW5N6e3zWq68EV4yuAnHppAcnPR7/gaQYk3OltCy160DbbtzDnMyvJ2'
        '/wANJgk//ehcp1+tGyq0c1OXdEmWaqkqs4ViQGAYYwWHjzgkdY1eF+gw7fs9f/prHdsI1bcHtyl7wsJM/qjKiAxg4IAxkDvvOe9Zic0aw5awJkoR7hDV+nCz'
        'KecnB44x/wDsbj5b4BX4zrTPJeemd/8ARhnqgyyMsioyclJRiycQft49+3yBqMyFWsWaW2JNU2WR7crDCyOSFQA+xesjl35GM4J606F9iPu1yPZorMVhlkWh'
        'FYipyYVpuZ+w5BGeuPePAP8AGonor8VexNhxIxbqKYcsMejlR2WA6yOutEwi23yGCC0zQPFalb0YZLxDJ49xRlOTnAAz0B/bRHwvt0/Sz2vburBL0QFmKGKV'
        'ZpDnwSB14/B0jgOtW2xYoDuBedXUn64Rn04wOlBYjIOeuvOiIyTtPcpari8a3r+lCwezWk/qj8FUzxxjBJ0hLS9WlMwJvRV5IhOb0eCY/PHkucMzEf486ZQQ'
        'oncUuXA6Q0OCR/WklpXdjklUH8eT8fHnR0oU6+3uVkk2/wBGKaFuUkgZuLKTjj30vL8HxppA/qPbI9r47hYsU4zXZpIJIwXnkZxxZQFPafw2fzo2Qdm3CtLY'
        'omCjTaSwssFh0EiiNQvhcn7gfkjHzqZWYLL75QrGnFNZsRWBHFNLGsLBUyGAOccyMjLDsYPzq4Pqedgjt2aZmrJCsNgua06GOQN4ywHk4wcj/wB6u1cqdeGB'
        'd1kgrJXre4mwyKzZ6z0xJ4DA7P5wPnUA95k+p2ipE9SblIGkw8wAYK2Fxjs/znGdWij1rFmltkc1TZZHtysMJI5IVAD7F6yOXfkY8E9aR+xH3a5Hs0VmKwyy'
        'LQisRU5MK03M/YcgjPXHvHgH+NRPRX4q9ibDiRi3UUw5YY9HKjssB1kddaJhFtvkMEFpmgeK1K3owyXiGTx7ijKcnOABnoD+2iPhfbp+lnte3dWCXogLMUMU'
        'qzSHPgkDrx+DpHAdattixQHcC86upP1wjPpxgdKCxGQc9dedERknae5S1XF41vX9KFg9mtJ/VH4KpnjjGCTpCWl6tKZgTeiryRCc3o8Ex+ePJc4ZmI/x50yg'
        'hRO4pcuB0hocEj+tJLSu7HJKoP48n4+POjpQp19vcrJJt/oxTQtykkDNxZScce+l5fg+NNIH9R7ZHtfHcLFinGa7NJBJGC88jOOLKAp7T+Gz+dGyDs24VpbF'
        'EwUabSWFlgsOgkURqF8Lk/cD8kY+dTKzBZffKFY04prNiKwI4ppY1hYKmQwBzjmRkZYdjB+dXB9TzsEduzTM1ZIVhsFzWnQxyBvGWA8nGDkf+9XauVOvDAu6'
        'yQVkr1vcTYZFZs9Z6Yk8Bgdn84HzqAe8yCzs9SJ6kxaQNJh5gAwVsLgDs/znGdWi9Sa423R1YrLi4QUS3TIMrsBj3FhjOcZ4nsdabkVeUamfXWxVuRFppCPq'
        'DAeLKcgMmcdkHB68Z0Eb9WULu0R52us7zxQ+mYbbmYKH6KEqA4yD8HIznUnuz029eLbtv2tq0orrJXqUmaaOJQMdSSHDKWyDywf/AHoUl97/AFLNX22hX3Lb'
        '3pXGmfjCuHLOhxyyhIQY/PWQMaoM/QIrFjcb8zyQSNTiwHs8XliMYTKtgfd6bHJIHzjGoagxW/Umx1KvpwWIxCIXke4ziOHLfsCnBAfHz84+NKi067u8lgRv'
        'DSehXgy0FlcRSLgYLJA3bjsj3YyexqKxt261xUd0rVjAVKGFwTZ9p6IUHkjf+QTpG1XnWhVJAWsholCQM3pogHYHEAMSp75EZJzoSfZgjr/6m6SCqgCelJMF'
        'jMj+GZlzkA58A9gatqSgsKt6V1jDsSYq8qNyLggK3WcAEnAP460s6D2iODav1FuNmtHPauM8Edkyzn6ZzEpCmNf258M3yVA0rcOlaepa3O7WgtzfUMxkSK1G'
        'WEIYZzzbyR2Fx4+dHZpkbPDtG6U3ntCcLFJyWugEpUj25I9p5HonvGdR2m2at60LUbeik0lvgrtZbnDCV98i4X3EdDDYznQDaTW226OrDZcXCCiW6ZBldgMD'
        'kWGM5xniex13puVV5lGpn11sVbkRaaQj6gwHiynIDJnHZBwevGdBG/VlC7tEedrrO88UPpmG25mCh+ihKgOMg/ByM51J7s9NvXi27b9ratKK6yV6lJmmjiUD'
        'HUkhwylsg8sH/wB6FJfe/wBSzV9toV9y296Vxpn4wrhyzoccsoSEGPz1kDGqDP0CKxY3G/M8kEjU4sB7PF5YjGEyrYH3emxySB84xqGoMVv1JsdSr6cFiMQi'
        'F5HuM4jhy37ApwQHx8/OPjSotOu7vJYEbw0noV4MtBZXEUi4GCyQN247I92MnsaisbdutcVHdK1YwFShhcE2faeiFB5I3/kE6RtV51oVSQFrIaJQkDN6aIB2'
        'BxADEqe+RGSc6En2YI6/+pukgqoAnpSTBYzI/hmZc5AOfAPYGrakoLCreldYw7EmKvKjci4ICt1nABJwD+OtLOg9ojg2r9RbjZrRz2rjPBHZMs5+mcxKQpjX'
        '9ufDN8lQNK3DpWnqWtzu1oLc31DMZEitRlhCGGc828kdhcePnR2aZGzw7RulN57QnCxSclroBKVI9uSPaeR6J7xnUdptmretC0jeik0lvgrtZbnDCV98igKe'
        'RHQw2M50AbcJmCiQcIF9ZVAJB9uOl6xnrzjvJ86pT55bQSQWLFapRMYLmSQxokh6RcN4bOO1Pfk6vFGDW21jZjlpSXq8JrV3mVZJD9RdcftT8yM2cKcDrRBt'
        'qzDNFtN7dIPXo32Uf0BIMPkYOE/j5PxpJLbNvWagRZm/oqzUwROYm7AYjK9tj5Bz8apDkv1Lt0O0i7F6D03vsYoI4ZTGzsw4jtT2WX3MRoOmqW2Jsm2VpqzQ'
        'm1t0bqZJ0WexZV8cy0xHbADoEfwCNIOWWXctoWeSZtxqXHWOaSxgSGM+Qce4NnGAcEAfzq8Af11K08tWeU0qcVj0nkjgLN6a4wyOvYHLA+TnV4VX1L05GJLU'
        'RTMS2beJJZg7e31F+5QgH9yG70Qjlfb0vSI8sKFazMXMs6QhfgkKfg/IHffxrdgjLGlqxEv01WaiOZkEETIY/B5ZAOc9HrwO+tZyVibb5tsv1/QsVqs0Uyid'
        'YXWQMXX9zDPYwCAOu8nB09Dg/JWjhj9WSQ2pXYRQLWYupLKRhsj7CQRnz111qnRTYRtr0n3CO4y5JFeSKcQwQge10Cnzj4/Pf8aJQkdva5nWKnJFIJVLPbWG'
        'RmnblhAjnsH7uRP+NVovuEzBRIOFcesqAEg9Y6XrGevOO8nzqkPnltBJBYsVqlExguZJDGiSHpFw3hs47U9+Tq8UYNbbWNmOWlJerwmtXeZVkkP1F1x+1PzI'
        'zZwpwOtEG2rMM0W03t0g9ejfZR/QEgw+Rg4T+Pk/Gkkts29ZqBFmb+irNTBE5ibsBiMr22PkHPxqkOS/Uu3Q7SLsXoPTe+xigjhlMbOzDiO1PZZfcxGg6apb'
        'YmybZWmrNCbW3RupknRZ7FlXxzLTEdsAOgR/AI0g5ZZdy2hZ5Jm3GpcdY5pLGBIYz5Bx7g2cYBwQB/OrwB/XUrTy1Z5TSpxWPSeSOAs3prjDI69gcsD5OdXh'
        'VfUvTkYktRFMxLZt4klmDt7fUX7lCAf3IbvRCOV9vS9IjywoVrMxcyzpCF+CQp+D8gd9/Gt2CMsaWrES/TVZqI5mQQRMhj8HlkA5z0evA761nJWJtvm2y/X9'
        'CxWqzRTKJ1hdZAxdf3MM9jAIA67ycHT0OD8laOGP1ZJDaldhFAtZi6kspGGyPsJBGfPXXWqdFNhG2vSfcI7jLkkV5IpxDBCB7XQKfOPj89/xolCR29rmdYqc'
        'kUolUs9tYZGaduWECOewfu5E6k1XRbjRZo2prsUnKMErx4qO5ORxgH8AZ1AbdYqu6T8PqKtGlGgkggKmdFZRkmRm7Jz4/k6mntOud8sxwwpHtrS12f1mPqAs'
        'PJH4bwAv4OhCW9zsPQqPukaV5khMjcI8McdBgPknywOBgedNApW3d7UVinYqJAlOcoZpOKwB+IZzWx36JBB5E+cjxoilKFWq1J/TmSlPLashmKSPl4AT1GM/'
        'aCBnI8A41pegzRLG6OuHCBo5JHX01QrnsnHuIz2PHWhdPNwTequ3RPc+hhetDmx7kMlpTjhyK9IwBwCMnvB8akSG91LG6x0tv2fczHKWsrXSi8wEaj3B5I8q'
        'Pd4JI1JQ2ze7qxO/11eGZJSyqIykoOPcqchk56yx8Y60SjVqyZIUhuVolNT+s9u05IlXHtHg8cZ8eGx50nwOmbm47SYrCmjCJmdMNwdoGwcsgOPd5/t5/Gr1'
        'nwxtNCmk3pVmMKPZYQpK3pxv2che/u6J4nsg/wA6uSV3L/qc/wCmdz/0qT9O2LIM8RDRTpG0CNkK5Vhl1PknHQ8Y0TJU3rQ3YzjbJIVkkKAIylCuQfU4H2hP'
        'OCMZz2NCY3iAJuP00DWrhaWOy6lyUg6I4+mMemcYyB5+Na0D0CrcaPNG1Ndik5RjK8eKjuQMcYB/AGdQF3WKruk/D6irRpRoJIICpnRWUZJkZuyc+P5Opp7T'
        'rnfLMcMKR7a0tdn9Zj6gLDyR+G8AL+DoQlvc7D0Kj7pGleZITI3CPDHHQYD5J8sDgYHnTQKVt3e1FYp2KiQJTnKGaTisAfiGc1sd+iQQeRPnI8aIpShVqtSf'
        '05kpTy2rIZikj5eAE9RjP2ggZyPAONaXoM0SxujrhwgaOSR19NUK57Jx7iM9jx1oXTzcE3qrt0T3PoYXrQ5se5DJaU44civSMAcAjJ7wfGpEhvdSxusdLb9n'
        '3MxylrK10ovMBGo9weSPKj3eCSNSUNs3u6sTv9dXhmSUsqiMpKDj3KnIZOessfGOtEo1asmSFIblaJTU/rPbtOSJVx7R4PHGfHhsedJ8Dpm5uO0mKwpowiZn'
        'TDcHaBsHLIDj3ef7efxq9Z8MbTQppN6VZjCj2WEKSt6cb9nIXv7uieJ7IP8AOrkldy/6nP8Apnc/9Kk/TtiyDPEQ0U6RtAjZCuVYZdT5Jx0PGNEyVN60N2M4'
        '2ySFZJCgCMpQrkH1OB9oTzgjGc9jQmN4gEe5CtA1q6WljsupclIOiOPpjHpnGMgefjWtMhfUbfR3M1q0iS23rrHHXWxy5o6gqSQTgjzjz3jRZNPLdrUoI79m'
        'CvuVKMmWMr6MAUnppeQJyRgYPYPemlgC3Sn/AFoleCruNna6+0WVfMCqrTsFzhgftQeA3k6Kyro7Y3Gpb/Txv3TZlsmXh9PCqSTyKAfD5xx6+f5HxqI1nbNq'
        'lords2Eoq0eYoPUAe6FXkYUB65HAGR1q0fHO3don3B4Fa4lwGFbZpVVZRX5n7QP3EHGRk/PjSzpmvt5S19ZuNuvHET3UauxHP5Ylshcj4x8d6hb2GzsqzpVr'
        'WIJGkJkkHplRA/7cggZ5AkkeNJyaoGJCIa1gUa7PJIi4ZYEAOAOfZAJ8csg5xjrVKgStFejqhrMEz8f6kcUuDKFwftfGD1jx486BhG2WeyNsfDTJJyljVtyU'
        'epMwfBEgGQRyxgjHWD8nUduj27YLkkUM8UFexLOZDMY8grggFnVQT23jPjz40rkPedhacQvJSatK7FHe0hiCuP3iQHDHIP8AUIx4z51ef398BCWGav8AqU37'
        'Q2z61KohjsuSZseWyD2yv37Qfxoq4IcEjVrssrbfLBVdAIXV8id+iIgc+wk+7jg4AOjSs1ds0t2jRNylh+ncNes7pIr4qhMhi3Acjyx0PnoadHLX1G3UdzNe'
        'tIktp66Rx11scucbqCpJBOCPOM57xotGnlu1qUEd+zBX3KlGTLGV9GAKT00vIE5IwMHsHvTQwBbpT/rRK8FXcbO119osq+YFVWnYLnDA/ag8BvJ0VlXR2xuN'
        'S3+njfumzLZMvD6eFUknkUA+Hzjj18/yPjURrO2bVLRW7ZsJRVo8xQeoA90KvIwoD1yOAMjrVo+Odu7RPuDwK1xLgMK2zSqqyivzP2gfuIOMjJ+fGlnTNfby'
        'lr6zcbdeOInuo1diOfyxLZC5Hxj471C3sNnZVnSrWsQSNITJIPTKiB/25BAzyBJI8aTk1QMSEQ1rAo12eSRFwywIAcAc+yAT45ZBzjHWqVAlaK9HVDWYJn4/'
        '1I4pcGULg/a+MHrHjx50DCNss9kbY+GmSTlLGrbko9SZg+CJAMgjljBGOsH5Oo7dHt2wXJIoZ4oK9iWcyGYx5BXBALOqgntvGfHnxpXIe87C04heSk1aV2KO'
        '9pDEFcfvEgOGOQf6hGPGfOrz+/vgISwzV/1Kb9obZ9alUQx2XJM2PLZB7ZX79oP40VcEOCRq12WVtvlgqugELq+RO/REQOfYSfdxwcAHRpWbuWaW6xou5SQe'
        'g/K9Z3SRXxVCdMW4DkeWOh89DVo5Zrqav6e/0+tRp1NrrXWsgrCFsfUuuGZj9+WAAAHWANKHkaCOKwlqpcvO8kcvrgDgjg/a2Tyc5Oc47AxjQH1yjuW5bkar'
        'UBV2NoxDYladnNxOyGQgchls5VvAAGna0gbxXtw7c9fa61OOVpYU9MyOYl9+C68cnx1x/JznzqS5fqpuVqrLNI9gxgxfTzQBHqeFJ5dggdfb4/nUlcbTtbx7'
        'fDau2HtUkMUQQ8PULN9in4bOf8E6tLZF609S1TgmhsS11D+tJCvqRIzdgSyk5BwPHeMd/GpEd8rwXFkPpywtIwPNVMj58JyYjIH7jjyDp8DdU7l+mox9TPHB'
        'ZmkaN4QQ0Z+GY8c55+AT40relJt2nqwkPWkAACD0YW4qik5KjOGK+G4+dZko+9T3o4FnC8pol5panqNJHJzPGXEa57RSpPPo940g9BM/OER7u7vHnMiMIGj6'
        '9zL4yv5UHx0dVUiCtVvyQboeQeyTG/BmcOucMjDyOWMkj86rXS3Mt27sP+rQ0ZI6ZtFEsSREokpBKxZbx0Paf/HnRR5JyV4JrrW7NWq8SxLUgmNoxz0eTAyW'
        'EQ9Fi3tPkhQR4OkDbpu+5WlmUMJY0f0ZbEEIiWdicJgeTkeQvXedZ6kkK6Gp+nv9OrUadPa611rIKwhbH1LrhmY/flgAAB1gDUcDSNBHFYS1UuXneSOX1wBw'
        'RwftbJ5OcnOcdgYxqD65R3LctyNVqAq7G0YhsStOzm4nZDIQOQy2cq3gADTtaQN4r24duevtdanHK0sKemZHMS+/BdeOT464/k5z51Jcv1U3K1VlmkewYwYv'
        'p5oAj1PCk8uwQOvt8fzqSuNp2t49vhtXbD2qSGKIIeHqFm+xT8NnP+CdWlsi9aepapwTQ2Ja6h/WkhX1IkZuwJZScg4HjvGO/jUiO+V4LiyH05YWkYHmqmR8'
        '+E5MRkD9xx5B0+Buqdy/TUY+pnjgszSNG8IIaM/DMeOc8/AJ8aVvSk27T1YSHrSAABB6MLcVRSclRnDFfDcfOsyUfep70cCzheU0S80tT1Gkjk5njLiNc9op'
        'Unn0e8aQegmfnCI93d3jzmRGEDR9e5l8ZX8qD46OqqRBWq35IN0PIPZJjfgzOHXOGRh5HLGSR+dVrpbmW7d2H/VoaMkdM2iiWJIiUSUglYst46HtP/jzoo8k'
        '5K8E11rdmrVeJYlqQTG0Y56PJgZLCIeixb2nyQoI8HSBt03bcraTKG9WNH9CWxBCIlsMThMDycjyF67B1muJJHZN1X1a0kEDXRIBGTK/uJI9nHOCGT4Ynx33'
        'qPrW3VKFW8LFGmleVYmSQysxZ2PXZYn3dkk+MnrTI9MRRLYWlDE1h5SxksTFnjAX5iTsFhjJZj/bUrIXqdKlf29Nsth680azT2HgM/EliFSJ48KzEDPuA4n8'
        '6EboU47Um6W22uxWnlkUV6qSo0mEGOZHjJGSwHj++tAruVeGY1oFElsllmLVCmVYHCkqeyT3kL+NSUJ7yrz/AKrmnIy5PA8i3jmT0MHrIPkjRwuRrETbhbrp'
        'W9ZIYzIiwGTALIuXfGfPn26drWA90qzlvQhqRHa65DfVvIABHjJkUk5KgHJ+evzq+qNlA9DcN2WFtzq2LlSuqVIH/ppLAP3BQOKhj2xbB8daLNK+7bXJTp1I'
        'LdaRtzsxvYD+rmRcDC4KEBTj4YnoaQ52yJtzpwR1ZIohErIGVFy7Z8d9gBcgfk51HRnbdpNinalSAQXmsFobCuBFPBgYwo75/cCvQ1Qm9s/VO4brf3Jt22e5'
        'ta0QIonqTJNDbbic4j88VXGX8joayr4OWLv+kqpSvDNSmHN55YkkXmcZ4se1z11/jWg8Tbhu1arYr0qsbCvK7i4zNHIVBMjE5HpYTGAPPWs1ZT9i3dGerLXr'
        'tdWQBMyuORJHs45wQyfDE+O+9Wj63t1ShVvCxRppXlWJkkMrMWdj12WJ93ZJPjJ60yPTEUS2FpQxNYeUsZLExZ4wF+Yk7BYYyWY/21KyF6nSpX9vTbLYevNG'
        's09h4DPxJYhUiePCsxAz7gOJ/OhG6FOO1JulttrsVp5ZFFeqkqNJhBjmR4yRksB4/vrQK7lXhmNaBRJbJZZi1QplWBwpKnsk95C/jUlCe8q8/wCq5pyMuTwP'
        'It45k9DB6yD5I0cLkaxE24W66VvWSGMyIsBkwCyLl3xnz59una1gPdKs5b0IakR2uuQ31byAAR4yZFJOSoByfnr86vqjZQPQ3Ddlhbc6ti5UrqlSB/6aSwD9'
        'wUDioY9sWwfHWizSvu21yU6dSC3Wkbc7Mb2A/q5kXAwuChAU4+GJ6GkOdsibc6cEdWSKIRKyBlRcu2fHfYAXIH5OdR0Z23aTYp2pUgEF5rBaGwrgRTwYGMKO'
        '+f3Ar0NUJvbP1TuG639ybdtnubWtECKJ6kyTQ224nOI/PFVxl/I6Gsq+Dli7/pKqUrwzUphzeeWJJF5nGeLHtc9df41oMrt43SrVsV6VWNhXldxcZmjkKgmR'
        's5HpYTGAPPWs1ZJw01ttY5iKysoM0daBAoMoGB56I+c/+NSNUZvRQWJ47FWmp9Cwy5dS3wCxGB34GfGmE3flmksX1prYtRiDjJDWRfUOT2QGPgjo940Lt5Rt'
        'RWayivBXlAhCqsMpWRGAweSeB14A+R/Om1VN3NyuzJLVZ4o4mijIhWEqJ1b95+SSB32MH86rMJED16N+j6cqxpEJJAasJJ5FTxB5dlR/8R3nUzLEVY7hswqg'
        'tfEoSx/3kbFAM9Bm6wM58+NJhQO/SwRuuxJI9BofTtxoVkc4/dyPQGfhfI6/Oi5GIbQ2JGWJl+mnUJICV4wqzdgEkEp12cjHwNV/VSTd2wwG7Ok1UvBhq8oT'
        'i9mPwVaQgfOcHH4/jUly7Sii2LMnpW4JApaITZnVjjAKYwe+8/A/zoaFppa9JrLR2QRxjAklIiIPt6ZVxn48/wBvGdNACzL/AKLBarfQYjI5F4iGklfOCnfQ'
        'TIAGP5bSAaW3LNWrOWkELKVcwy8YYfx7f47Bz58+NCc7uk1aO3VlnjEaAtHFMATJKOu5FHRIHXXgd6mpXY97fZ4GpWPbGJPXjiilEiCE9rnPkfI+SD/GgW8g'
        'pLaaxzEVlZAZo60CBQZQMDz0R85/8aiaozeigsTx2KtNT6Fhly6lvgFiMDvwM+NMBu/LNJYvrTWxajEHGSGsi+ocnsgMfBHR7xoXbyjais1lFeCvKBCFVYZS'
        'siMBg8k8DrwB8j+dNqqbubldmSWqzxRxNFGRCsJUTq37z8kkDvsYP51WYSIHr0b9H05VjSISSA1YSTyKniDy7Kj/AOI7zqZliKsdw2YVQWviUJY/7yNigGeg'
        'zdYGc+fGkwoHfpYI3XYkkeg0Pp240KyOcfu5HoDPwvkdfnRcjENobEjLEy/TTqEkBK8YVZuwCSCU67ORj4Gq/qpJu7YYDdnSaqXgw1eUJxezH4KtIQPnODj8'
        'fxqS5dpRRbFmT0rcEgUtEJszqxxgFMYPfefgf50NC00tek1lo7II4xgSSkREH29Mq4z8ef7eM6aAFmX/AEWC1W+gxGRyLxENJK+cFO+gmQAMfy2kA0tuWatW'
        'ctIIWUq5hl4ww/j2/wAdg58+fGhOd3SatHbqyzxiNAWjimAJklHXcijokDrrwO9TUrqb0+0QPRsYEQk9eOKKUSIIT2uc+R8j5IP8aAao1htieiHLVqiBJNxA'
        'JDxEe3inw+SB5yfI1XOzDo9q32xun6fqbDAIobNYO7wmf/dYn2SGIgg4/cOyTrFfldt3+P8AmpSJJK67huFQs0NeQcStmARepIP9xWx4Ut4HjWoucsTUEK9O'
        'vTgqxVHhpRyguixOjrG2SAMjoNnP3eNIE3K/boVnfbr8D3JEaCS28H1CxDoNIoBw8ijPnoE50q/o9aala227USNVLAot1JRzWHIJcZ658hknrSCy7BU3eF4P'
        'UjvuXLJHFKeHP4Oc4HQJOegdSudgm1LYpipUrxRVoJeLCwhijm4Hogj7hnP4Ge+xo2SkUq15rb7m09ZIY2ntTNNH6BQke5pOXI46Hj+NChZs25NwauntMcMb'
        'zNXtS5DwxjMj+pgDkqkH4HHSkHfdws77uFG7PZsXqyN7aqyha8zEf02BUd8f74OsxWybz6dqglWmjCaYQiFZ2jgmCEEnkrHB8nOOh1rV8sqP6l3prrlwqRtF'
        'mKpLHE3puWb3yTN8MqgDPjiAPOmTVI+87DDTqDZ4y0FhcWRc9UepIrDrkmevwR5xjGgPq0G4WII5WAMVbkrSN0zk/e2PP8D8+NVEHk8swVjDHBM5RA0CSMiH'
        'IHFWGWYfBHQz/GhVazSrDbF9FXLVqi8JNxAJDxEe3inw+SB5yfI1ZLo9q32xun6fqbDAIobNYO7wmf8A3WJ9khiIIOP3Dsk6xX5Xbd/j/mpSJJK67huFQs0N'
        'eQcStmARepIP9xWx4Ut4HjWoucsTUEK9OvTgqxVHhpRyguixOjrG2SAMjoNnP3eNIE3K/boVnfbr8D3JEaCS28H1CxDoNIoBw8ijPnoE50q/o9aala227USN'
        'VLAot1JRzWHIJcZ658hknrSCy7BU3eF4PUjvuXLJHFKeHP4Oc4HQJOegdSudgm1LYpipUrxRVoJeLCwhijm4Hogj7hnP4Ge+xo2SkUq15rb7m09ZIY2ntTNN'
        'H6BQke5pOXI46Hj+NChZs25NwauntMcMbzNXtS5DwxjMj+pgDkqkH4HHSkHfdws77uFG7PZsXqyN7aqyha8zEf02BUd8f74OsxWybz6dqglWmjCaYQiFZ2jg'
        'mCEEnkrHB8nOOh1rV8sqP6l3prrlwqRtFmKpLHE3puWb3yTN8MqgDPjiAPOmTVI+87DDTqDZ4y0FhcWRc9UepIrDrkmevwR5xjGgPq0G4WII5WAMVbkrSN0z'
        'k/e2PP8AA/PjVRCBeadUYwxwzOUQNAkjIhyBxVhlmHwR0M6FVrVbd3WGJEUvWsj1VWSdEjX9uTFjPZOBj/jOg2HXv24Kl+OpO72FbjA1WH0ZKjscM4B8cRjB'
        'ye+jpoFNoezS2P8AT0Frd5f1DfqQyQPNYA9Wy5ckmVh17chSdPoOWN63AQIsUdO19U+JKs8SrCY/tPjvln2gjvUTGy7hAvq06SRVxTl5MkkfI+l5HpN8gHPf'
        'nAOdUj06/wCk/wDWYrRp1VsVBOrpPBEJVD48KPPXfkY8aimQ15bm6T3tv3CWvThlIcPU9OQOqlQ7hsE9ZAOMYOqhYthzuErU4pHH08IVvQXKcx2FVmx7VPn4'
        '70rl9brULpEM8KwmOsENsqrO+QfVXAGPu8A9EjRSmXPPucgeshlikswBZ5IV4v6qODG5dT5DKMAYwe/41TCVVSa+BSk4VKPFI0aNOGOY4gMw8RqB0AOiMakg'
        '7jdka1sybW0CoGdbqywD/uIh0sY/cijHIeC2e9E2YwotdTdd8avapz9RH0ZI7RaN484KiMj7s9ED5606R2Tc61YXpX+m+rlZJBMQ39FwOPBnxjIHaqPzg6qI'
        'bytuNirMiSCHmUVKcZPM9EgHxzI+D4GoN7lVu7cybhudR2aItG01iu4ikRjlUVh7V7x1keM+TrNtGa27yLFEiKz17I9VVknRI1/bkxY5dk4GP+M6aFh179uC'
        'pfjqTu9hW4wNVh9GSo7HDOAfHEYwcnvo6qBTaHs0tj/T0Frd5f1DfqQyQPNYA9Wy5ckmVh17chSdPoOWN63AQIsUdO19U+JKs8SrCY/tPjvln2gjvUTGy7hA'
        'vq06SRVxTl5MkkfI+l5HpN8gHPfnAOdUj06/6T/1mK0adVbFQTq6TwRCVQ+PCjz135GPGopkNeW5uk97b9wlr04ZSHD1PTkDqpUO4bBPWQDjGDqoWLYc7hK1'
        'OKRx9PCFb0FynMdhVZse1T5+O9K5fW61C6RDPCsJjrBDbKqzvkH1VwBj7vAPRI0Uplzz7nIHrIZYpLMAWeSFeL+qjgxuXU+QyjAGMHv+NUwlVUmvgUpOFSjx'
        'SNGjThjmOIDMPEagdADojGpIO43ZGtbMm1tAqBnW6ssA/wC4iHSxj9yKMch4LZ70TZjCi11N13xq9qnP1EfRkjtFo3jzgqIyPuz0QPnrTpHZNzrVhelf6b6u'
        'VkkExDf0XA48GfGMgdqo/ODqohvK242KsyJIIeZRUpxk8z0SAfHMj4PgagJuNW7tzJuG51XLRFo2nsV3EUiMcqisPaveOsjxnydZtoCYRtL9TO86kSR+rIvs'
        'kSM+cHHtA+B8jv41qWfTJ/Tdext809eeSWshKCaSQqAAc45DxkeG/djVCyVqq1WrDNXqW9xlrvwMLuq8V8+4r7mHYI67PnVoGqFtLFmFaZjsK0vKZQ3GU8um'
        'BJ6VgBnrrOj0m4aSUdzYyRrF9SrRGg0g7CZKAsD0Tkk8T/GpUNX2aeLcpKZmjSe2iqssVj0/Rkxnph9hI+D+PydNK6OSy39w26K88T20DeizuATYK+QCfuHj'
        '+T8adCUaO7UFRTcs8oCSnrzgwxsWPUYAySfGAfxqUh1YYb21V1Ui0/JgyxzcUJU+1ifjo5x8EfnOlOai2QXLbLC0Zmd1VrQQMQveMnogAAn+MaKWTEMm07TH'
        'bhgjknjCs0n1TdRKR7Ox3g+5s/AP86CVr2Nr3dnuxLb9VXASSWRFEuMe5CPcnx0wPIeNVcJdrQWmnWZIZIxW97h2KheiGfv3HPnI/wDepR0U2xWuFKklGNY5'
        'h6az3Y2j5qc8kVvs8ZIOORPzq2pPRLM7OwN1KiuqTTCUqGUDhEfaMADHlsNgd6qR6tPNttdtvr7vaan6vrz0I7AsVH+P6ieCfBAH99Synzem0v1U7TqRJH6s'
        'i+yRIz5wce0D4HyO/jVKMn9N17G3zT155JayEoJpJCoABzjkPGR4b92NULJWqrVasM1epb3GWu/Awu6rxXz7ivuYdgjrs+dWgaoW0sWYVpmOwrS8plDcZTy6'
        'YEnpWAGeus6PSbhpJR3NjJGsX1KtEaDSDsJkoCwPROSTxP8AGpUNX2aeLcpKZmjSe2iqssVj0/Rkxnph9hI+D+PydNK6OSy39w26K88T20DeizuATYK+QCfu'
        'Hj+T8adCUaO7UFRTcs8oCSnrzgwxsWPUYAySfGAfxqUh1YYb21V1Ui0/JgyxzcUJU+1ifjo5x8EfnOlOai2QXLbLC0Zmd1VrQQMQveMnogAAn+MaKWTEMm07'
        'THbhgjknjCs0n1TdRKR7Ox3g+5s/AP8AOgla9ja93Z7sS2/VVwEklkRRLjHuQj3J8dMDyHjVXCXa0Fpp1mSGSMVve4dioXohn79xz5yP/epR0U2xWuFKklGN'
        'Y5h6az3Y2j5qc8kVvs8ZIOORPzq2pPRLM7OwN1KiuqTTCUqGUDhEfaMADHlsNgd6qR6vPNttdtvrbvaNP1fXnoR2BYqP8f1E8E+CAP76llCpmm89qC9FJKxb'
        'HJo2BdMfcRnIOOxnxqWVbbdxdRL6fqvHIggEKKShjU4PM+AydNyPwSBoJi/FFJubVl4ygAGO1VkZo7JHlgv3BB4HzpjQotLAfrUjaOOo8CsJQhZ1I8sxOMkY'
        'wOPjrGrhQHYjla2YoPS/06QoGMuOBJb/AHCG6RT4ODk4Gj9pjZNsoShrtDdl3faJpppDN6Pp8XjYqcrnGBg4YeQNMZU3E5W6VqzLPJThkksmu4ZYnYxCJmHP'
        'LMfaCyjoDsjx86Bab/8AjwdJ90teo11ZPUgrxLxwxB5MD4wqDIPns/OnBAVoJYbkFWvXtU+71iWKZi0YACY4H93Y6+M51I5uNWGCsL63Zq8aOiSWhWDOMjix'
        'cecDw356xpHbit73OjWtrHWijkks2nqpbvykSzRKoYiJQOJb+/gY0E8lB0Ed1bUcdeVxEJ5654OfCgn/AIH8/gadDc0q0NleWee1LG9BxIfTmcYlL56AXOSP'
        'PjrVMl5uS0NpWxaE3OOa2qVY7k5VIA3woJ8k/aP7aE1NfkqwSQyqwDtzlaUEFuJ9pK+C2Ce/kHGpJW07hfeYx37f0t31cRz0aoWJlyeJSP8AacZH5z/B04Bq'
        'mabT2oL0MkrFsZaNgXTH3EZyGx2M+NBVtt3F1Evp+q8ciCAQopKGNTg8z4DJ03I/BIGgmL8UUm5tWXjKAAY7VWRmjskeWC/cEHgfOmNCi0sB+tSNo46jwKwl'
        'CFnUjyzE4yRjA4+OsauFAdiOVrZig9L/AE6QoGMuOBJb/cIbpFPg4OTgaP2mNk2yhKGu0N2Xd9ommmkM3o+nxeNipyucYGDhh5A0xlTcTlbpWrMs8lOGSSya'
        '7hlidjEImYc8sx9oLKOgOyPHzoFpv/48HSfdLXqNdWT1IK8S8cMQeTA+MKgyD57PzpwQFaCWG5BVr17VPu9YlimYtGAAmOB/d2OvjOdSObjVhgrC+t2avGjo'
        'kloVgzjI4sXHnA8N+esaR24re9zo1rax1oo5JLNp6qW78pEs0SqGIiUDiW/v4GNBPJQdBHdW1HHXlcRCeeueDnwoJ/4H8/gadDc0q0NleWee1LG9BxIfTmcY'
        'lL56AXOSPPjrVMl5uS0NpWxaE3OOa2qVY7k5VIA3woJ8k/aP7aE1NfkqwSQyqwDtzlaUEFuJ9pK+C2Ce/kHGpJW1bhfeYx37f0131cRz0aoWJlyeJSP9pxkf'
        'nP8AB1YoMUp2q3Zq4bmEUmtYmBYhsAjIPfzkZ+caj6qwXJKDCSOzLXrrIYvqGLt7WHLiy+SCckjHnx1opWo/W7kkhdZ0RrDhIWgiWLmnlicHPLGCMYGNUmIO'
        'Vn9e1LXgSW3VaNhYkquq5wMgIX6kwRkg/OiUiTiuZpJBIkfqBJeDScYPOFZ1wS6segFwCck9AaVHSmqx2RVhsoss3psWrwx8eJXzxVcBghx0e8edNs0++p22'
        'e7d3CqzzywVJ1lrODJ6wwuCQCMlRkocZX3fGiKnUmYmIZNPdbe2crFiSEQystZYk9UTAdh/wQQcAfPelBp6VmyLNaYvuEvtklNYR5yv2hB/nB8nH+dWtqvhW'
        'WRJJWSxuUazzOrWIkyiTIgPphfPYb5Pnvzo2Z6TotoGzCpJaswRS1xlYJ4/UJLKcmMgEBiD2wOAM60Bo7lFa1YXIZbUfCVWiQkh2PkKv25J6z+B+dA6e7Rtt'
        'agZJIVeuZx/TE8LzhXHiNGzkDHj400je/V6f6i2OKtuOzUZRTWK4LmSWM4PIOoB6weII771UrTNwtXN6hryxB5yJJJTyIQKeuih7JJz/AIz+NUqmJaqTRCJl'
        'hrynjAyq7YTyc8j2vLGM+RjGPnRNtBUp2qXZq4bmEVjWsTAsQ2ARkHv5yM+TjUPVWC5JQYSR2Za9dZDF9Qxdvaw5cWXyQTkkY8+OtFK1H63ckkLrOiNYcJC0'
        'ESxc08sTg55YwRjAxqkxBys/r2pa8CS26rRsLElV1XOBkBC/UmCMkH50SkScVzNJIJEj9QJLwaTjB5wrOuCXVj0AuATknoDSo6U1WOyKsNlFlm9Ni1eGPjxK'
        '+eKrgMEOOj3jzptmn31O2z3bu4VWeeWCpOstZwZPWGFwSARkqMlDjK+740RU6kzExDJp7rb2zlYsSQiGVlrLEnqiYDsP+CCDgD570oNPSs2RZrTF9wl9skpr'
        'CPOV+0IP84Pk4/zq1tV8KyyJJKyWNyjWeZ1axEmUSZEB9ML57DfJ89+dGzPSdFtA2YVJLVmCKWuMrBPH6hJZTkxkAgMQe2BwBnWgNHcorWrC5DLaj4Sq0SEk'
        'Ox8hV+3JPWfwPzoHT3aNtrUDJJCr1zOP6YnhecK48Ro2cgY8fGmkb36vT/UWxxVtx2ajKKaxXBcySxnB5B1APWDxBHfeqlaZuFq5vUNeWIPORJJKeRCBT10U'
        'PZJOf8Z/GqVTEtVJohE6w15TxgZUdsJ5OeR7XljGfIxjHzom2lpNokJWaShHNK6ezk7+0EY6Xyw/n/60Bu3PPJRMEyPLPSb2TWE9ijICgcPc3XXu6+PzoNQP'
        'cXcY1ijeFI4opQ0N1IWRlY/DDsEDPlfP+NRT4d03R1vLHmqsU7xJZvp7wi9Bwg6Cseu/I70Z0Jpyn6RO5CHdG3SKTcJZ52SISnJqIT/t5GP6ee1x2M9acwpl'
        '2K25ESvNYrWZ0qxpxjCj1OWQjk/IJ6y3kjrGnlGIt3mkFkDZ5NtP1zAKhV3lQDqYcfKsTjicY+dUTCkvtcks9GpNnnXleThBaZzIFBOQPGOJ6P8AfrTIgCnI'
        '+yTv9bIjRIjOUtM0CszHkjAkZwPs4j47PWrwwJtW7/Ux2BJIPXkQ+lMqhlManlx5Y9mMEeOwM571ULeX0rw7bRqUpXigkqRetkclBckgqo+O+8Hx1+dIpzVb'
        'an2ejFKJpmkbmZHiUNBEVfHINnOD0QuOuxq3KVx+obsn0ss9w05xIFeWSX02x2DxIHzk+R1n+RpxoD0FalN6KlJKbuUjimyrE8cgg/yPOPnvzqhS3W22De5L'
        'lNJWAEpZlX7PVTzkn/8An5Pz470EtuFpZ4o6hsm4EjaRg755nxzAwMgYA/50UVFdplYrPJQjmldPZyd/aCMdL5Yfz/8AWhYbtzzyUTBMjyz0m9k1hPYoyAoH'
        'D3N117uvj86DUD3F3GNYo3hSOKKUNDdSFkZWPww7BAz5Xz/jUU+HdN0dbyx5qrFO8SWb6e8IvQcIOgrHrvyO9GdCacp+kTuQh3Rt0ik3CWedkiEpyaiE/wC3'
        'kY/p57XHYz1pzCmXYrbkRK81itZnSrGnGMKPU5ZCOT8gnrLeSOsaeUYi3eaQWQNnk20/XMAqFXeVAOphx8qxOOJxj51RMKS+1ySz0ak2edeV5OEFpnMgUE5A'
        '8Y4no/360yIApyPsk7/WyI0SIzlLTNArMx5IwJGcD7OI+Oz1q8MCbVu/1MdgSSD15EPpTKoZTGp5ceWPZjBHjsDOe9VC3l9K8O20alKV4oJKkXrZHJQXJIKq'
        'PjvvB8dfnSKc1W2p9noxSiaZpG5mR4lDQRFXxyDZzg9ELjrsatylcfqG7J9LLPcNOcSBXlkl9Nsdg8SB85PkdZ/kacaA9BWpTeipSSm7lI4psqxPHIIP8jzj'
        '5786oUt1ttg3uS5TSVgBKWZV+z1U85J//n5Pz470EtuFlZ44qhsm4FjLsHfPM+OYGBkDAH/OiieSeu1SJ68ckNr1BgByCpXyQcnOe+ujosw3f2exJUgtxb0d'
        'tsfUK0aGsZVQRuP94Z7RyxX0vODnWZy1jlqbdXRmlnLztBZ+n9SpIfTVWbAZR3xUeD85xjWoZkGYm5cklavGntYqUYuCoGMg+c56P/GkE7m41r9Z1kqypDCA'
        'YhHYB4P4JLdHkW+cEY1m8ng/dlEphNixLXjlVQ0bcEXkAeRVl7djjPI6djws9yGQUmSDk6Qsks0VjBQs2VYAdKQB+75702e1C0J4tpM0LXJQoRI7PBC7EnPn'
        'yQP/AJY+M/OqoF/Xm6X6202J7CxzBbNlC9hHM7BwgBcep9pYY6A76OnpcI9y9XvCDba0YhaMEySRtjgvlhyOO8DHDx3oQ9KcfUIsUMQUrIoogZ6cZ7kY4UKP'
        'j8nrVZiORrS3kAip1UlUKXkdY8vJnHyBxXiAO+uXemBhN22KjLanarWST6gmey8cPckhwGLjOSSAB11nGoTFYMJBXrbbNbMUjNHMgisK+QFbwpQ/z7ev7aQF'
        'HdgmsWDPRlrLwDksDJ6vE+GQdjz1/wA6LaiGHmd3qmRD6sk6xYtyBQxcEKgJ6DHiTx7BxrMzEGrVVnrtVjevHJDa9QYHMhlK+SDk5z310dKhu/s9iSpBbi3o'
        '7bY+oVo0NYyqgjcf7wz2jlivpecHOsTlrHLU26ujNLOXnaCz9P6lSQ+mqs2Ayjvio8H5zjGtQzIMxNy5JK1eNPaxUoxcFQMZB85z0f8AjSCdzca1+s6yVZUh'
        'hAMQjsA8H8ElujyLfOCMazeTwfuyiUwmxYlrxyqoaNuCLyAPIqy9uxxnkdOx4We5DIKTJBydIWSWaKxgoWbKsAOlIA/d896bPahaE8W0maFrkoUIkdnghdiT'
        'nz5IH/yx8Z+dVQL+vN0v1tpsT2FjmC2bKF7COZ2DhAC49T7Swx0B30dPS4R7l6veEG21oxC0YJkkjbHBfLDkcd4GOHjvQh6U4+oRYoYgpWRRRAz04z3IxwoU'
        'fH5PWqzEcjWlvIBFTqpKoUvI6x5eTOPkDivEAd9cu9MDCbtsVGW1O1Wskn1BM9l44e5JDgMXGckkADrrONQmKwYSCvW22a2YpGaOZBFYV8gK3hSh/n29f20g'
        'KO7BNYsGejLWXgHJYGT1eJ8Mg7Hnr/nRbUQw8zvJUMiESSWEixbkChi4IVAT0GPEnj2DjWZmIVWrwbZZtJAY6UY5AyMzjEgZTiPgMjoY7Y50gbdLrjaUii/r'
        'lZRKkLPxMYP3EuR2Ceh/GNNHtMWxPuM6JEKxjduUtdIvSdCuWyfg9A9fJGszhDXkstbr2Nos2q0ZkFhHKc5nIQ4Ylftz4Cjz8/nV0idCkjUFEsUjwtXHOZVC'
        'So/eeSvg/wAEf+NOy925LKzU2lkjkjCFI0jPByo6JwRjGeJOPkfjRIVNk2lVkpSX4+NN7KSWHROHqqAeYAx72DEEZ+Sfxqgg75JUSw/p3bNWRXK8ahfLuDkE'
        'sBhR/B60qycAvyQurWFeXL2455fcwfvifyQMnvHjUEuWulbcJ3X6uxE+FWtOgVYRxw2D57JLHOc561cpTO3S1bk3p7fNarrwRXjK4CcemkByc9Hv+BpBiTc6'
        'W0LLXrQNtu3MOczK8nb/AA0mCT/96FynX60bKrRzU5d0SZZqqSqzhWJAYBhjBYePOCR1jV4X6DDt+z1/+msd2wjVtwe3KXvCwkz+qMqIDGDggDGQO+8571mJ'
        'zRrDlrAmShHuENX6cLMp5ycHjjH/AOxuPlvgFfjOtM8l56R/UPpQT1cyyMsioyclJRiycQft49+3yBqMyag22xcSBo6UY5gyMzjEgZTiPgMjoY7Y51DQ26XX'
        'G0pFF/XKyiVIWfiYwfuJcjsE9D+MaaPaYtifcZ0SIVjG7cpa6Rek6Fctk/B6B6+SNZnCGvJZa3XsbRZtVozILCOU5zOQhwxK/bnwFHn5/OrpE6FJGoKJYpHh'
        'auOcyqElR+88lfB/gj/xp2Xu3JZWam0skckYQpGkZ4OVHROCMYzxJx8j8aJCpsm0qslKS/HxpvZSSw6Jw9VQDzAGPewYgjPyT+NUEHfJKiWH9O7ZqyK5XjUL'
        '5dwcglgMKP4PWlWTgF+SF1awry5e3HPL7mD98T+SBk948agly10rbhO6/V2Inwq1p0CrCOOGwfPZJY5znPWrlKZ26Wrcm9Pb5rVdeCK8ZXATj00gOTno9/wN'
        'IMSbnS2hZa9aBtt25hzmZXk7f4aTBJ/+9C5Tr9aNlVo5qcu6JMs1VJVZwrEgMAwxgsPHnBI6xq8L9Bh2/Z6//TWO7YRq24PblL3hYSZ/VGVEBjBwQBjIHfec'
        '96zE5o1hy1gTJQj3CGr9OFmU85ODxxj/APY3Hy3wCvxnWmeS89M7/wCjDPVBlkZZFRk5KSjFk4g/bx79vkDUZkKtYs0tsSapssj25WGFkckKgB9i9ZHLvyMZ'
        'wT1p0L7EfdrkezRWYrDLItCKxFTkwrTcz9hyCM9ce8eAf41E9Ffir2JsOJGLdRTDlhj0cqOywHWR11omEW2+QwQWmaB4rUrejDJeIZPHuKMpyc4AGegP7aI+'
        'F9un6We17d1YJeiAsxQxSrNIc+CQOvH4OkcB1q22LFAdwLzq6k/XCM+nGB0oLEZBz1150RGSdp7lLVcXjW9f0oWD2a0n9UfgqmeOMYJOkJaXq0pmBN6KvJEJ'
        'zejwTH548lzhmYj/AB50yghRO4pcuB0hocEj+tJLSu7HJKoP48n4+POjpQp19vcrJJt/oxTQtykkDNxZScce+l5fg+NNIH9R7ZHtfHcLFinGa7NJBJGC88jO'
        'OLKAp7T+Gz+dGyDs24VpbFEwUabSWFlgsOgkURqF8Lk/cD8kY+dTKzBZffKFY04prNiKwI4ppY1hYKmQwBzjmRkZYdjB+dXB9TzsEduzTM1ZIVhsFzWnQxyB'
        'vGWA8nGDkf8AvV2rlTrwwLuskFZK9b3E2GRWbPWemJPAYHZ/OB86gHvMn1O0VInqTcpA0mHmADBWwuMdn+c4zq0UetYs0tsjmqbLI9uVhhJHJCoAfYvWRy78'
        'jHgnrSP2I+7XI9misxWGWRaEViKnJhWm5n7DkEZ64948A/xqJ6K/FXsTYcSMW6imHLDHo5UdlgOsjrrRMItt8hggtM0DxWpW9GGS8QyePcUZTk5wAM9Af20R'
        '8L7dP0s9r27qwS9EBZihilWaQ58EgdePwdI4DrVtsWKA7gXnV1J+uEZ9OMDpQWIyDnrrzoiMk7T3KWq4vGt6/pQsHs1pP6o/BVM8cYwSdIS0vVpTMCb0VeSI'
        'Tm9HgmPzx5LnDMxH+POmUEKJ3FLlwOkNDgkf1pJaV3Y5JVB/Hk/Hx50dKFOvt7lZJNv9GKaFuUkgZuLKTjj30vL8HxppA/qPbI9r47hYsU4zXZpIJIwXnkZx'
        'xZQFPafw2fzo2Qdm3CtLYomCjTaSwssFh0EiiNQvhcn7gfkjHzqZWYLL75QrGnFNZsRWBHFNLGsLBUyGAOccyMjLDsYPzq4Pqedgjt2aZmrJCsNgua06GOQN'
        '4ywHk4wcj/3q7Vyp14YF3WSCslet7ibDIrNnrPTEngMDs/nA+dQD3mQWdnqRPUmLSBpMPMAGCthcAdn+c4zq0XqTXG26OrFZcXCCiW6ZBldgMe4sMZzjPE9j'
        'rTciryjUz662KtyItNIR9QYDxZTkBkzjsg4PXjOgjfqyhd2iPO11neeKH0zDbczBQ/RQlQHGQfg5Gc6k92em3rxbdt+1tWlFdZK9SkzTRxKBjqSQ4ZS2QeWD'
        '/wC9Ckvvf6lmr7bQr7lt70rjTPxhXDlnQ45ZQkIMfnrIGNUGfoEVixuN+Z5IJGpxYD2eLyxGMJlWwPu9NjkkD5xjUNQYrfqTY6lX04LEYhELyPcZxHDlv2BT'
        'ggPj5+cfGlRadd3eSwI3hpPQrwZaCyuIpFwMFkgbtx2R7sZPY1FY27da4qO6VqxgKlDC4Js+09EKDyRv/IJ0jarzrQqkgLWQ0ShIGb00QDsDiAGJU98iMk50'
        'JPswR1/9TdJBVQBPSkmCxmR/DMy5yAc+AewNW1JQWFW9K6xh2JMVeVG5FwQFbrOACTgH8daWdB7RHBtX6i3GzWjntXGeCOyZZz9M5iUhTGv7c+Gb5KgaVuHS'
        'tPUtbndrQW5vqGYyJFajLCEMM55t5I7C48fOjs0yNnh2jdKbz2hOFik5LXQCUqR7cke08j0T3jOo7TbNW9aFqNvRSaS3wV2stzhhK++RcL7iOhhsZzoBtJrb'
        'bdHVhsuLhBRLdMgyuwGByLDGc4zxPY6703Kq8yjUz662KtyItNIR9QYDxZTkBkzjsg4PXjOgjfqyhd2iPO11neeKH0zDbczBQ/RQlQHGQfg5Gc6k92em3rxb'
        'dt+1tWlFdZK9SkzTRxKBjqSQ4ZS2QeWD/wC9Ckvvf6lmr7bQr7lt70rjTPxhXDlnQ45ZQkIMfnrIGNUGfoEVixuN+Z5IJGpxYD2eLyxGMJlWwPu9NjkkD5xj'
        'UNQYrfqTY6lX04LEYhELyPcZxHDlv2BTggPj5+cfGlRadd3eSwI3hpPQrwZaCyuIpFwMFkgbtx2R7sZPY1FY27da4qO6VqxgKlDC4Js+09EKDyRv/IJ0jarz'
        'rQqkgLWQ0ShIGb00QDsDiAGJU98iMk50JPswR1/9TdJBVQBPSkmCxmR/DMy5yAc+AewNW1JQWFW9K6xh2JMVeVG5FwQFbrOACTgH8daWdB7RHBtX6i3GzWjn'
        'tXGeCOyZZz9M5iUhTGv7c+Gb5KgaVuHStPUtbndrQW5vqGYyJFajLCEMM55t5I7C48fOjs0yNnh2jdKbz2hOFik5LXQCUqR7cke08j0T3jOo7TbNW9aFpG9F'
        'JpLfBXay3OGEr75FAU8iOhhsZzoA24TMFEg4QL6yqASD7cdL1jPXnHeT51Snzy2gkgsWK1SiYwXMkhjRJD0i4bw2cdqe/J1eKMGttrGzHLSkvV4TWrvMqySH'
        '6i64/an5kZs4U4HWiDbVmGaLab26QevRvso/oCQYfIwcJ/HyfjSSW2bes1AizN/RVmpgicxN2AxGV7bHyDn41SHJfqXbodpF2L0HpvfYxQRwymNnZhxHanss'
        'vuYjQdNUtsTZNsrTVmhNrbo3UyTos9iyr45lpiO2AHQI/gEaQcssu5bQs8kzbjUuOsc0ljAkMZ8g49wbOMA4IA/nV4A/rqVp5as8ppU4rHpPJHAWb01xhkde'
        'wOWB8nOrwqvqXpyMSWoimYls28SSzB29vqL9yhAP7kN3ohHK+3pekR5YUK1mYuZZ0hC/BIU/B+QO+/jW7BGWNLViJfpqs1EczIIImQx+DyyAc56PXgd9azkr'
        'E23zbZfr+hYrVZoplE6wusgYuv7mGexgEAdd5ODp6HB+StHDH6skhtSuwigWsxdSWUjDZH2EgjPnrrrVOimwjbXpPuEdxlySK8kU4hghA9roFPnHx+e/40Sh'
        'I7e1zOsVOSKQSqWe2sMjNO3LCBHPYP3cif8AGq0X3CZgokHCuPWVACQesdL1jPXnHeT51SHzy2gkgsWK1SiYwXMkhjRJD0i4bw2cdqe/J1eKMGttrGzHLSkv'
        'V4TWrvMqySH6i64/an5kZs4U4HWiDbVmGaLab26QevRvso/oCQYfIwcJ/HyfjSSW2bes1AizN/RVmpgicxN2AxGV7bHyDn41SHJfqXbodpF2L0HpvfYxQRwy'
        'mNnZhxHanssvuYjQdNUtsTZNsrTVmhNrbo3UyTos9iyr45lpiO2AHQI/gEaQcssu5bQs8kzbjUuOsc0ljAkMZ8g49wbOMA4IA/nV4A/rqVp5as8ppU4rHpPJ'
        'HAWb01xhkdewOWB8nOrwqvqXpyMSWoimYls28SSzB29vqL9yhAP7kN3ohHK+3pekR5YUK1mYuZZ0hC/BIU/B+QO+/jW7BGWNLViJfpqs1EczIIImQx+DyyAc'
        '56PXgd9azkrE23zbZfr+hYrVZoplE6wusgYuv7mGexgEAdd5ODp6HB+StHDH6skhtSuwigWsxdSWUjDZH2EgjPnrrrVOimwjbXpPuEdxlySK8kU4hghA9roF'
        'PnHx+e/40ShI7e1zOsVOSKUSqWe2sMjNO3LCBHPYP3cidSarotxos0bU12KTlGCV48VHcnI4wD+AM6gNusVXdJ+H1FWjSjQSQQFTOisoyTIzdk58fydTT2nX'
        'O+WY4YUj21pa7P6zH1AWHkj8N4AX8HQhLe52HoVH3SNK8yQmRuEeGOOgwHyT5YHAwPOmgUrbu9qKxTsVEgSnOUM0nFYA/EM5rY79Egg8ifOR40RSlCrVak/p'
        'zJSnltWQzFJHy8AJ6jGftBAzkeAca0vQZoljdHXDhA0ckjr6aoVz2Tj3EZ7HjrQunm4JvVXbonufQwvWhzY9yGS0pxw5FekYA4BGT3g+NSJDe6ljdY6W37Pu'
        'ZjlLWVrpReYCNR7g8keVHu8EkakobZvd1Ynf66vDMkpZVEZSUHHuVOQyc9ZY+MdaJRq1ZMkKQ3K0Smp/We3ackSrj2jweOM+PDY86T4HTNzcdpMVhTRhEzOm'
        'G4O0DYOWQHHu8/28/jV6z4Y2mhTSb0qzGFHssIUlb0437OQvf3dE8T2Qf51ckruX/U5/0zuf+lSfp2xZBniIaKdI2gRshXKsMup8k46HjGiZKm9aG7GcbZJC'
        'skhQBGUoVyD6nA+0J5wRjOexoTG8QBNx+mga1cLSx2XUuSkHRHH0xj0zjGQPPxrWgegVbjR5o2prsUnKMZXjxUdyBjjAP4AzqAu6xVd0n4fUVaNKNBJBAVM6'
        'KyjJMjN2Tnx/J1NPadc75ZjhhSPbWlrs/rMfUBYeSPw3gBfwdCEt7nYehUfdI0rzJCZG4R4Y46DAfJPlgcDA86aBStu72orFOxUSBKc5QzScVgD8Qzmtjv0S'
        'CDyJ85HjRFKUKtVqT+nMlKeW1ZDMUkfLwAnqMZ+0EDOR4BxrS9BmiWN0dcOEDRySOvpqhXPZOPcRnseOtC6ebgm9Vduie59DC9aHNj3IZLSnHDkV6RgDgEZP'
        'eD41IkN7qWN1jpbfs+5mOUtZWulF5gI1HuDyR5Ue7wSRqShtm93Vid/rq8MySllURlJQce5U5DJz1lj4x1olGrVkyQpDcrRKan9Z7dpyRKuPaPB44z48Njzp'
        'PgdM3Nx2kxWFNGETM6Ybg7QNg5ZAce7z/bz+NXrPhjaaFNJvSrMYUeywhSVvTjfs5C9/d0TxPZB/nVySu5f9Tn/TO5/6VJ+nbFkGeIhop0jaBGyFcqwy6nyT'
        'joeMaJkqb1obsZxtkkKySFAEZShXIPqcD7QnnBGM57GhMbxAI9yFaBrV0tLHZdS5KQdEcfTGPTOMZA8/GtaZC+o2+juZrVpEltvXWOOutjlzR1BUkgnBHnHn'
        'vGiyaeW7WpQR37MFfcqUZMsZX0YApPTS8gTkjAwewe9NLAFulP8ArRK8FXcbO119osq+YFVWnYLnDA/ag8BvJ0VlXR2xuNS3+njfumzLZMvD6eFUknkUA+Hz'
        'jj18/wAj41Eaztm1S0Vu2bCUVaPMUHqAPdCryMKA9cjgDI61aPjnbu0T7g8CtcS4DCts0qqsor8z9oH7iDjIyfnxpZ0zX28pa+s3G3XjiJ7qNXYjn8sS2QuR'
        '8Y+O9Qt7DZ2VZ0q1rEEjSEySD0yogf8AbkEDPIEkjxpOTVAxIRDWsCjXZ5JEXDLAgBwBz7IBPjlkHOMdapUCVor0dUNZgmfj/UjilwZQuD9r4wesePHnQMI2'
        'yz2Rtj4aZJOUsatuSj1JmD4IkAyCOWMEY6wfk6jt0e3bBckihnigr2JZzIZjHkFcEAs6qCe28Z8efGlch7zsLTiF5KTVpXYo72kMQVx+8SA4Y5B/qEY8Z86v'
        'P7++AhLDNX/Upv2htn1qVRDHZckzY8tkHtlfv2g/jRVwQ4JGrXZZW2+WCq6AQur5E79ERA59hJ93HBwAdGlZq7ZpbtGiblLD9O4a9Z3SRXxVCZDFuA5Hljof'
        'PQ06OWvqNuo7ma9aRJbT10jjrrY5c43UFSSCcEecZz3jRaNPLdrUoI79mCvuVKMmWMr6MAUnppeQJyRgYPYPemhgC3Sn/WiV4Ku42drr7RZV8wKqtOwXOGB+'
        '1B4DeTorKujtjcalv9PG/dNmWyZeH08KpJPIoB8PnHHr5/kfGojWds2qWit2zYSirR5ig9QB7oVeRhQHrkcAZHWrR8c7d2ifcHgVriXAYVtmlVVlFfmftA/c'
        'QcZGT8+NLOma+3lLX1m4268cRPdRq7Ec/liWyFyPjHx3qFvYbOyrOlWtYgkaQmSQemVED/tyCBnkCSR40nJqgYkIhrWBRrs8kiLhlgQA4A59kAnxyyDnGOtU'
        'qBK0V6OqGswTPx/qRxS4MoXB+18YPWPHjzoGEbZZ7I2x8NMknKWNW3JR6kzB8ESAZBHLGCMdYPydR26PbtguSRQzxQV7Es5kMxjyCuCAWdVBPbeM+PPjSuQ9'
        '52FpxC8lJq0rsUd7SGIK4/eJAcMcg/1CMeM+dXn9/fAQlhmr/qU37Q2z61KohjsuSZseWyD2yv37Qfxoq4IcEjVrssrbfLBVdAIXV8id+iIgc+wk+7jg4AOj'
        'Ss3cs0t1jRdykg9B+V6zukiviqE6YtwHI8sdD56GrRyzXU1f09/p9ajTqbXWutZBWELY+pdcMzH78sAAAOsAaUPI0EcVhLVS5ed5I5fXAHBHB+1snk5yc5x2'
        'BjGgPrlHcty3I1WoCrsbRiGxK07ObidkMhA5DLZyreAANO1pA3ivbh256+11qccrSwp6ZkcxL78F145Pjrj+TnPnUly/VTcrVWWaR7BjBi+nmgCPU8KTy7BA'
        '6+3x/OpK42na3j2+G1dsPapIYogh4eoWb7FPw2c/4J1aWyL1p6lqnBNDYlrqH9aSFfUiRm7AllJyDgeO8Y7+NSI75XguLIfTlhaRgeaqZHz4TkxGQP3HHkHT'
        '4G6p3L9NRj6meOCzNI0bwghoz8Mx45zz8AnxpW9KTbtPVhIetIAAEHowtxVFJyVGcMV8Nx86zJR96nvRwLOF5TRLzS1PUaSOTmeMuI1z2ilSefR7xpB6CZ+c'
        'Ij3d3ePOZEYQNH17mXxlfyoPjo6qpEFarfkg3Q8g9kmN+DM4dc4ZGHkcsZJH51WuluZbt3Yf9WhoyR0zaKJYkiJRJSCViy3joe0/+POijyTkrwTXWt2atV4l'
        'iWpBMbRjno8mBksIh6LFvafJCgjwdIG3Td9ytLMoYSxo/oy2IIREs7E4TA8nI8heu86z1JIV0NT9Pf6dWo06e11rrWQVhC2PqXXDMx+/LAAADrAGo4GkaCOK'
        'wlqpcvO8kcvrgDgjg/a2Tyc5Oc47AxjUH1yjuW5bkarUBV2NoxDYladnNxOyGQgchls5VvAAGna0gbxXtw7c9fa61OOVpYU9MyOYl9+C68cnx1x/JznzqS5f'
        'qpuVqrLNI9gxgxfTzQBHqeFJ5dggdfb4/nUlcbTtbx7fDau2HtUkMUQQ8PULN9in4bOf8E6tLZF609S1TgmhsS11D+tJCvqRIzdgSyk5BwPHeMd/GpEd8rwX'
        'FkPpywtIwPNVMj58JyYjIH7jjyDp8DdU7l+mox9TPHBZmkaN4QQ0Z+GY8c55+AT40relJt2nqwkPWkAACD0YW4qik5KjOGK+G4+dZko+9T3o4FnC8pol5pan'
        'qNJHJzPGXEa57RSpPPo940g9BM/OER7u7vHnMiMIGj69zL4yv5UHx0dVUiCtVvyQboeQeyTG/BmcOucMjDyOWMkj86rXS3Mt27sP+rQ0ZI6ZtFEsSREokpBK'
        'xZbx0Paf/HnRR5JyV4JrrW7NWq8SxLUgmNoxz0eTAyWEQ9Fi3tPkhQR4OkDbpu25W0mUN6saP6EtiCERLYYnCYHk5HkL12DrNcSSOybqvq1pIIGuiQCMmV/c'
        'SR7OOcEMnwxPjvvUfWtuqUKt4WKNNK8qxMkhlZizseuyxPu7JJ8ZPWmR6YiiWwtKGJrDyljJYmLPGAvzEnYLDGSzH+2pWQvU6VK/t6bZbD15o1mnsPAZ+JLE'
        'KkTx4VmIGfcBxP50I3Qpx2pN0tttditPLIor1UlRpMIMcyPGSMlgPH99aBXcq8MxrQKJLZLLMWqFMqwOFJU9knvIX8akoT3lXn/Vc05GXJ4HkW8cyehg9ZB8'
        'kaOFyNYibcLddK3rJDGZEWAyYBZFy74z58+3TtawHulWct6ENSI7XXIb6t5AAI8ZMiknJUA5Pz1+dX1RsoHobhuywtudWxcqV1SpA/8ATSWAfuCgcVDHti2D'
        '460WaV922uSnTqQW60jbnZjewH9XMi4GFwUICnHwxPQ0hztkTbnTgjqyRRCJWQMqLl2z477AC5A/JzqOjO27SbFO1KkAgvNYLQ2FcCKeDAxhR3z+4FehqhN7'
        'Z+qdw3W/uTbts9za1ogRRPUmSaG23E5xH54quMv5HQ1lXwcsXf8ASVUpXhmpTDm88sSSLzOM8WPa566/xrQeJtw3atVsV6VWNhXldxcZmjkKgmRicj0sJjAH'
        'nrWasp+xbujPVlr12urIAmZXHIkj2cc4IZPhifHferR9b26pQq3hYo00ryrEySGVmLOx67LE+7sknxk9aZHpiKJbC0oYmsPKWMliYs8YC/MSdgsMZLMf7alZ'
        'C9TpUr+3ptlsPXmjWaew8Bn4ksQqRPHhWYgZ9wHE/nQjdCnHak3S2212K08siivVSVGkwgxzI8ZIyWA8f31oFdyrwzGtAoktkssxaoUyrA4UlT2Se8hfxqSh'
        'PeVef9VzTkZcngeRbxzJ6GD1kHyRo4XI1iJtwt10reskMZkRYDJgFkXLvjPnz7dO1rAe6VZy3oQ1Ijtdchvq3kAAjxkyKSclQDk/PX51fVGygehuG7LC251b'
        'FypXVKkD/wBNJYB+4KBxUMe2LYPjrRZpX3ba5KdOpBbrSNudmN7Af1cyLgYXBQgKcfDE9DSHO2RNudOCOrJFEIlZAyouXbPjvsALkD8nOo6M7btJsU7UqQCC'
        '81gtDYVwIp4MDGFHfP7gV6GqE3tn6p3Ddb+5Nu2z3NrWiBFE9SZJobbcTnEfniq4y/kdDWVfByxd/wBJVSleGalMObzyxJIvM4zxY9rnrr/GtBldvG6Vativ'
        'SqxsK8ruLjM0chUEyNnI9LCYwB561mrJOGmttrHMRWVlBmjrQIFBlAwPPRHzn/xqRqjN6KCxPHYq01PoWGXLqW+AWIwO/Az40wm78s0li+tNbFqMQcZIayL6'
        'hyeyAx8EdHvGhdvKNqKzWUV4K8oEIVVhlKyIwGDyTwOvAHyP502qpu5uV2ZJarPFHE0UZEKwlROrfvPySQO+xg/nVZhIgevRv0fTlWNIhJIDVhJPIqeIPLsq'
        'P/iO86mZYirHcNmFUFr4lCWP+8jYoBnoM3WBnPnxpMKB36WCN12JJHoND6duNCsjnH7uR6Az8L5HX50XIxDaGxIyxMv006hJASvGFWbsAkglOuzkY+Bqv6qS'
        'bu2GA3Z0mql4MNXlCcXsx+CrSED5zg4/H8akuXaUUWxZk9K3BIFLRCbM6scYBTGD33n4H+dDQtNLXpNZaOyCOMYEkpERB9vTKuM/Hn+3jOmgBZl/0WC1W+gx'
        'GRyLxENJK+cFO+gmQAMfy2kA0tuWatWctIIWUq5hl4ww/j2/x2Dnz58aE53dJq0durLPGI0BaOKYAmSUddyKOiQOuvA71NSux72+zwNSse2MSevHFFKJEEJ7'
        'XOfI+R8kH+NAt5BSW01jmIrKyAzR1oECgygYHnoj5z/41E1Rm9FBYnjsVaan0LDLl1LfALEYHfgZ8aYDd+WaSxfWmti1GIOMkNZF9Q5PZAY+COj3jQu3lG1F'
        'ZrKK8FeUCEKqwylZEYDB5J4HXgD5H86bVU3c3K7MktVnijiaKMiFYSonVv3n5JIHfYwfzqswkQPXo36PpyrGkQkkBqwknkVPEHl2VH/xHedTMsRVjuGzCqC1'
        '8ShLH/eRsUAz0GbrAznz40mFA79LBG67Ekj0Gh9O3GhWRzj93I9AZ+F8jr86LkYhtDYkZYmX6adQkgJXjCrN2ASQSnXZyMfA1X9VJN3bDAbs6TVS8GGryhOL'
        '2Y/BVpCB85wcfj+NSXLtKKLYsyelbgkClohNmdWOMApjB77z8D/OhoWmlr0mstHZBHGMCSUiIg+3plXGfjz/AG8Z00ALMv8AosFqt9BiMjkXiIaSV84Kd9BM'
        'gAY/ltIBpbcs1as5aQQspVzDLxhh/Ht/jsHPnz40Jzu6TVo7dWWeMRoC0cUwBMko67kUdEgddeB3qaldTen2iB6NjAiEnrxxRSiRBCe1znyPkfJB/jQDVGsN'
        'sT0Q5atUQJJuIBIeIj28U+HyQPOT5Gq52YdHtW+2N0/T9TYYBFDZrB3eEz/7rE+yQxEEHH7h2SdYr8rtu/x/zUpEklddw3CoWaGvIOJWzAIvUkH+4rY8KW8D'
        'xrUXOWJqCFenXpwVYqjw0o5QXRYnR1jbJAGR0Gzn7vGkCblft0Kzvt1+B7kiNBJbeD6hYh0GkUA4eRRnz0Cc6Vf0etNStbbdqJGqlgUW6ko5rDkEuM9c+QyT'
        '1pBZdgqbvC8HqR33LlkjilPDn8HOcDoEnPQOpXOwTalsUxUqV4oq0EvFhYQxRzcD0QR9wzn8DPfY0bJSKVa81t9zaeskMbT2pmmj9AoSPc0nLkcdDx/GhQs2'
        'bcm4NXT2mOGN5mr2pch4YxmR/UwByVSD8DjpSDvu4Wd93Cjdns2L1ZG9tVZQteZiP6bAqO+P98HWYrZN59O1QSrTRhNMIRCs7RwTBCCTyVjg+TnHQ61q+WVH'
        '9S7011y4VI2izFUljib03LN75Jm+GVQBnxxAHnTJqkfedhhp1Bs8ZaCwuLIueqPUkVh1yTPX4I84xjQH1aDcLEEcrAGKtyVpG6ZyfvbHn+B+fGqiDyeWYKxh'
        'jgmcogaBJGRDkDirDLMPgjoZ/jQqtZpVhti+irlq1ReEm4gEh4iPbxT4fJA85Pkasl0e1b7Y3T9P1NhgEUNmsHd4TP8A7rE+yQxEEHH7h2SdYr8rtu/x/wA1'
        'KRJJXXcNwqFmhryDiVswCL1JB/uK2PClvA8a1FzliaghXp16cFWKo8NKOUF0WJ0dY2yQBkdBs5+7xpAm5X7dCs77dfge5IjQSW3g+oWIdBpFAOHkUZ89AnOl'
        'X9HrTUrW23aiRqpYFFupKOaw5BLjPXPkMk9aQWXYKm7wvB6kd9y5ZI4pTw5/BznA6BJz0DqVzsE2pbFMVKleKKtBLxYWEMUc3A9EEfcM5/Az32NGyUilWvNb'
        'fc2nrJDG09qZpo/QKEj3NJy5HHQ8fxoULNm3JuDV09pjhjeZq9qXIeGMZkf1MAclUg/A46Ug77uFnfdwo3Z7Ni9WRvbVWULXmYj+mwKjvj/fB1mK2TefTtUE'
        'q00YTTCEQrO0cEwQgk8lY4Pk5x0OtavllR/Uu9NdcuFSNosxVJY4m9Nyze+SZvhlUAZ8cQB50yapH3nYYadQbPGWgsLiyLnqj1JFYdckz1+CPOMY0B9Wg3Cx'
        'BHKwBirclaRumcn72x5/gfnxqohAvNOqMYY4ZnKIGgSRkQ5A4qwyzD4I6GdCq1qtu7rDEiKXrWR6qrJOiRr+3JixnsnAx/xnQbDr37cFS/HUnd7CtxgarD6M'
        'lR2OGcA+OIxg5PfR00Cm0PZpbH+noLW7y/qG/UhkgeawB6tly5JMrDr25Ck6fQcsb1uAgRYo6dr6p8SVZ4lWEx/afHfLPtBHeomNl3CBfVp0kirinLyZJI+R'
        '9LyPSb5AOe/OAc6pHp1/0n/rMVo06q2KgnV0ngiEqh8eFHnrvyMeNRTIa8tzdJ7237hLXpwykOHqenIHVSodw2CesgHGMHVQsWw53CVqcUjj6eEK3oLlOY7C'
        'qzY9qnz8d6Vy+t1qF0iGeFYTHWCG2VVnfIPqrgDH3eAeiRopTLnn3OQPWQyxSWYAs8kK8X9VHBjcup8hlGAMYPf8aphKqpNfApScKlHikaNGnDHMcQGYeI1A'
        '6AHRGNSQdxuyNa2ZNraBUDOt1ZYB/wBxEOljH7kUY5DwWz3omzGFFrqbrvjV7VOfqI+jJHaLRvHnBURkfdnogfPWnSOybnWrC9K/031crJIJiG/ouBx4M+MZ'
        'A7VR+cHVRDeVtxsVZkSQQ8yipTjJ5nokA+OZHwfA1Bvcqt3bmTcNzqOzRFo2msV3EUiMcqisPaveOsjxnydZtozW3eRYokRWevZHqqsk6JGv7cmLHLsnAx/x'
        'nTQsOvftwVL8dSd3sK3GBqsPoyVHY4ZwD44jGDk99HVQKbQ9mlsf6egtbvL+ob9SGSB5rAHq2XLkkysOvbkKTp9ByxvW4CBFijp2vqnxJVniVYTH9p8d8s+0'
        'Ed6iY2XcIF9WnSSKuKcvJkkj5H0vI9JvkA5784BzqkenX/Sf+sxWjTqrYqCdXSeCISqHx4Ueeu/Ix41FMhry3N0nvbfuEtenDKQ4ep6cgdVKh3DYJ6yAcYwd'
        'VCxbDncJWpxSOPp4QreguU5jsKrNj2qfPx3pXL63WoXSIZ4VhMdYIbZVWd8g+quAMfd4B6JGilMuefc5A9ZDLFJZgCzyQrxf1UcGNy6nyGUYAxg9/wAaphKq'
        'pNfApScKlHikaNGnDHMcQGYeI1A6AHRGNSQdxuyNa2ZNraBUDOt1ZYB/3EQ6WMfuRRjkPBbPeibMYUWupuu+NXtU5+oj6MkdotG8ecFRGR92eiB89adI7Jud'
        'asL0r/TfVyskgmIb+i4HHgz4xkDtVH5wdVEN5W3GxVmRJBDzKKlOMnmeiQD45kfB8DUBNxq3duZNw3Oq5aItG09iu4ikRjlUVh7V7x1keM+TrNtATem0v1M7'
        'zKRJH6si+yRIz5wce0D4HyO/jWpZ9Mn9N17G3zTV55Ja6ZQTSSFQADnHIeMjw37saoXZWsrVKsE1erb3GWB+Hou6rxXz7ivuYdgjrsjvVoGqNtJ7MK1DHYVp'
        'eUyhuMp5dMCT0rYGeus6PSahpx0dydpI1j+pVojQaQdhMlAWB6JySeJ/jUqFrbRLHuUlMzxrPbRVWWGxw9GQDPTD7CR8H8fk6avSuj0st7cNviuvE9tQ3os7'
        'gE2CvkAn7h4/k/GnQlFju1BUU3LPKEkp68+YY2LHqMAZJPjAP40cqQ60MN7aq4Ui0/JgyxzcUJU+1ifjo5x8EfnOtBzcWx/WWysLRtM7qrWggYhe8ZPRAwCf'
        '4xoo5MQybTtUduGCOSeMKzSfUt1EpHs7HeD7mz8A/wA6CWgn2zdme7Elv1VcBJJJEUS4x7kI9yY66YHkNURwlutFZawsyRSRit7nDMVC9EM/fuOfOR/71Uo6'
        'KbYGtlKclKMRyj0xPdRo+anPJFb7PGSDjkfzq2pPxLMzOwN1KiuqzTCYqGUDhEfaMADHlsNgd6qUHq0022122+vu9o0/V9eehHYFio/x/UTwT4IA/vqWU+b0'
        '2l+pneZSJI/VkX2SJGfODj2gfA+R38akZP6br2NvmmrzyS10ygmkkKgAHOOQ8ZHhv3Y1QuytZWqVYJq9W3uMsD8PRd1Xivn3Ffcw7BHXZHerQNUbaT2YVqGO'
        'wrS8plDcZTy6YEnpWwM9dZ0ek1DTjo7k7SRrH9SrRGg0g7CZKAsD0Tkk8T/GpULW2iWPcpKZnjWe2iqssNjh6MgGemH2Ej4P4/J01eldHpZb24bfFdeJ7ahv'
        'RZ3AJsFfIBP3Dx/J+NOhKLHdqCopuWeUJJT158wxsWPUYAySfGAfxo5Uh1oYb21VwpFp+TBljm4oSp9rE/HRzj4I/OdaDm4tj+stlYWjaZ3VWtBAxC94yeiB'
        'gE/xjRRyYhk2nao7cMEck8YVmk+pbqJSPZ2O8H3Nn4B/nQS0E+2bsz3Ykt+qrgJJJIiiXGPchHuTHXTA8hqiOEt1orLWFmSKSMVvc4ZioXohn79xz5yP/eql'
        'HRTbA1spTkpRiOUemJ7qNHzU55IrfZ4yQccj+dW1J+JZmZ2BupUV1WaYTFQygcIj7RgAY8thsDvVSg9Xnm22u23193tGn6vrz0I7AsVH+P6ieCfBAH99Sy//'
        '2Q=='
    ),
    'wood': (
        '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/'
        '2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADAREAAhEBAxEB/8QA'
        'HAAAAwEBAQEBAQAAAAAAAAAABAUGBwMCAQAI/8QAORAAAgIBAwMCBQMEAQMDBQEAAQIDBBEFEiEABjETQQcUIlFhMkJxFSNSgZEWYrEkM3JDRKHR4Rf/xAAa'
        'AQADAQEBAQAAAAAAAAAAAAADBAUCAQAG/8QAMREAAgEDAgQFAwQDAQEBAAAAAQIRAAMhEjEEQVFhInGBsfATkaEjwdHhMkLxUhQF/9oADAMBAAIRAxEAPwD+'
        'W51qd490aYkdtbqxYnmuRS5CyyDCoTgDIIJOBgHjr5IFrNtsRPLyr7Rgt+6oBkCqrUKO8+htrGNsQhSuZ2Xd9QbdwgPGPzj79LK0Z/5/dNlTMYqD+Jz6jDoc'
        'dd5pbC0NSewbM8IVnQjapyP27jz9+On+F0FyQNxU3jdYtjOxmvtCStHNUtmvM+YfWkRBh1mY7FGTxyRkH7cdeaYIn/ldQiQxH/aqOxZ9M7g1eKOamzz1TqFm'
        'eWWXamyPaFjAPkYJYg88Y9+lr4a2pIO8fmmuHK3GAI6/iqruOXULadyV6T17OnvQ9KCEyKJ4HIVVlbPKbgeCfwOlkCgoxwZ9PLvTLliHUGRFJNI+To67JZtS'
        'xtWiUyLJTjJjDIiK7KV8YYjd7ck9EbUywBnv8+1DQKjSamfita1Cn3hpcSQBoa9uDUZUQZaMFioVmPPPJx7g9M8KFa2xPQilOLLLdUDkQaB+IvcFG1b0tK6S'
        '1S9x52lmGxplIG1ljBwqjkcef56Nw1tlDTnAHlQeLuqzKB1mvulxCXt+vYVtjrGGkiJ5mVmAJAPufp8fbnobYYiioPADVH2V2qjfDbUrEtSa4j6xK/pqSzna'
        'VyQPbGec+fHS/EXD9dYMYpjhbY/+dyc+KmGtXqfxF1uDUqjPqEdatZr2sQsiQwARrEZM+NxBzj7dYtq1hCrYmCPPnFFuMl+4rLkAEH9qL1mZtT0fUKr3rVgC'
        'L9cmNyqVDCMsPKgp/wAYHWVXQ6tA+c6051Wys0D8M9a0uTV7VuzU1GWGez6/ztQF1jL4VEkUc/UB9J8c89GvIwAEjA2/j96BZuKSTByd6694d46fr/aXd9nT'
        'Bp0EyQy07UVy8Un8bYlQgbZHwG4Htx1i3aZLtsPPUQMd56US7fV7NwrHMHPtWf8AaXxF0XQaElS8GqX4qqilY9IWVDkfUGQ/pOfB9unb3D3HbUmROeVTuH4q'
        '3bXQ+DGOdOJ0qd4d0aZHHcW8sWJprkUuQssgwqE4AyCCTgYB46CC1m22Inl5UwwW/dUAyBzqq1CjvPobaxjbEIUrmdl3fUG3cIDxj84+/SytGf8An902VMxi'
        'oP4nPqMOhx13mlsLQ1J7BszwhWdCNqnI/buPP346f4XQXJA3FTeN1i2M7Ga+0JK0c1S2a8z5h9aREGHWZjsUZPHJGQftx15pgif+V1CJDEf9qo7Fn0zuDV4o'
        '5qbPPVOoWZ5ZZdqbI9oWMA+RgliDzxj36Wvhrakg7x+aa4crcYAjr+Kqu45dQtp3JXpPXs6e9D0oITIongchVWVs8puB4J/A6WQKCjHBn08u9MuWIdQZEUk0'
        'j5Ojrslm1LG1aJTIslOMmMMiIrspXxhiN3tyT0RtTLAGe/z7UNAqNJqZ+K1rUKfeGlxJAGhr24NRlRBlowWKhWY888nHuD0zwoVrbE9CKU4sst1QORBoH4i9'
        'wUbVvS0rpLVL3HnaWYbGmUgbWWMHCqORx5/no3DW2UNOcAeVB4u6rMoHWa+6XEJe369hW2OsYaSInmZWYAkA+5+nx9uehthiKKg8ANUfZXaqN8NtSsS1JriP'
        'rEr+mpLOdpXJA9sZ5z58dL8RcP11gximOFtj/wCdyc+KmGtXqfxF1uDUqjPqEdatZr2sQsiQwARrEZM+NxBzj7dYtq1hCrYmCPPnFFuMl+4rLkAEH9qL1mZt'
        'T0fUKr3rVgCL9cmNyqVDCMsPKgp/xgdZVdDq0D5zrTnVbKzQPwz1rS5NXtW7NTUZYZ7Pr/O1AXWMvhUSRRz9QH0nxzz0a8jAASMDb+P3oFm4pJMHJ3rr3h3j'
        'p+v9pd32dMGnQTJDLTtRXLxSfxtiVCBtkfAbge3HWLdpku2w89RAx3npRLt9Xs3Cscwc+1Z/2l8RNF0KjJUvBql+Kqq0rHpCwoYj6gyH9Jz4Pt05e4e47aky'
        'Jzyqfw/FW7a6HwYxzp/Vh+W1qL5CT0ZmrTOZ2iKgFfqQYI9gOT9jnpfJTxU2RD+E8qtNds07Xbzahtdp7ZhMsKf/AEw5JZs/YgED2x0sgIbT0mnHYFNZFQ3c'
        'kf8A1Fo+vwwWp4qkOjGyqyJ6jWJCw2KwH6AFU/V9h+enLJFt0JGZj51pK+DdS4F2CzUxDPY17R4trMgCoodOQjD69x+7HGMfjpuBbfNTwTcQRV/8JJ9F7htX'
        'b1qAQRTLXuw043y+fqSXn3d2XcQePqPSHFB7cKD1E+32qjwZS5qbrB/mn+sSaPJTu3bUInq3LFVZxp+PmvTgUmL1P8gGIBGOSMdBTWCFXcTvtnembgTLHYxt'
        'vjav1OZaclynrUUFGSujmxFJGUEm4AtDJs5wSyEY+3PWWEwyZ+bia0hAlWqT1zTa+oXFsPPXqAaiIWmkZnhRPTJUHGScNyB926atswWACcT3pJ0DNPePxU53'
        'lpcVjRNSmMHrvHHE8FnnMRVgCF+wYYyPOej2HIdRO9A4m0DbYkbRQcV6tJpazNM5aOssEMcuSHfJYqgXx7HP89b0sGiOdY1KUmeVM9D7jn+H1OxHNqM8NfWf'
        'qmMMh+iY4Knjyp/Sfx46y9scQcDK163cPCzqOGqu7f7Vt26l2/Utvo9PUJSFYt9Mij9rAeV3BufOek3ugEIRJFP2rJIZ1MTQ9prMHaep2LLYlmpzIFoSACQ8'
        'DcreNuDz/wAdaGk3FA68660i0xPSvvZ95ezO3LJqVTds6nVFVhLMYoIpUXckm4cnapLAL74zx1y7+vcGrEGe8dKzaH0bcqJmpXX9DcadXWrShVFi9dY4+cME'
        'ByM/qLHe38k9MW7ksdR7fPalrlrwjSKD7X0mPUdZk0tqVZJq9ieRWlcKzEqrrGG+4+o9avNpXXJyB/2sWEDObZGxNUtWL5fWovkJPRmerM5naLaAV+pBgj2A'
        '5P2Oel8lPFTREP4Tyq012zTtdvNqG12ntmEywp/9MOSWbP2IBA9sdLICG09Jpx2BTWRUN3JH/wBRaPr8MFqeKpDoxsqsieo1iQsNisB+gBVP1fYfnpyyRbdC'
        'RmY+daSvg3UuBdgs1MQz2Ne0eLazIAqKHTkIw+vcfuxxjH46bgW3zU8E3EEVf/CSfRe4bV29agEEUy17sNON8vn6kl593dl3EHj6j0hxQe3Cg9RPt9qo8GUu'
        'am6wf5p/rEmjyU7t21CJ6tyxVWcafj5r04FJi9T/ACAYgEY5Ix0FNYIVdxO+2d6ZuBMsdjG2+Nq/U5lpyXKetRQUZK6ObEUkZQSbgC0MmznBLIRj7c9ZYTDJ'
        'n5uJrSECVapPXNNr6hcWw89eoBqIhaaRmeFE9MlQcZJw3IH3bpq2zBYAJxPeknQM094/FTneWlxWNE1KYweu8ccTwWecxFWAIX7BhjI856PYch1E70DibQNt'
        'iRtFBxXq0mlrM0zlo6ywQxy5Id8liqBfHsc/z1vSwaI51jUpSZ5Uz0PuOf4fU7Ec2ozw19Z+qYwyH6JjgqePKn9J/HjrL2xxBwMrXrdw8LOo4aq7t/tW3bqX'
        'b9S2+j09QlIVi30yKP2sB5XcG5856Te6AQhEkU/askhnUxND2mswdp6nYstiWanMgWhIAJDwNyt424PP/HWhpNxQOvOutItMT0r72feXsztyyalU3bOp1RVY'
        'SzGKCKVF3JJuHJ2qSwC++M8dcu/r3BqxBnvHSs2h9G3KiZqV1/Q3GnV1q0oVRYvXWOPnDBAcjP6ix3t/JPTFu5LHUe3z2pa5a8I0ig+19Kj1DWZNMalWSavY'
        'nkVpXCsxKq6xhvuPqPWrzaV1ycgf9rFhQz6CNiavDaXVNV1F4GstUmhtKyBNsoIhY5APgHnx9uk40KAd8e9UC2tz3n2qoNaWt2lWlArzq0Y+RkSVR6wcgjfH'
        'nKohXnPsxHS2qX9+3r1NNaIt+1SlOhq9PWdVlp0mS1qmmsjU2GVrxocMFx5XJIUHyCPx01KFVBOAd+tKgMGYgZYbVn/YBgo9l6jcevYbaphhkI+gODtznySB'
        '9v49+qN+WuATUjhiFskxX74M63T0OSRZj8x8xNPGYE/WyqA4yfbJB8fc9e4tGfPSK5wVwJ6zWy6BpsE66hqTulaQVYr0aYwJQ74QKfYq2fPnGeo7sRC94q7a'
        'Eye01P8AxaWxB3Z8w1qS5rOqVo3rI+SdxbDySH9oBXA+44+3R+Gg2oiFBzS/FDTdmckYoPs+az3bX1iPU6bTLTtvLMKY9CP1WwkbJjwVGWwffrt2LJXQdxGc'
        '+desTe1BxseVCfFPSVXUdUWAm1SGnNHbS3IQyy+hxICnkjAOceTg9E4VyQs4M4jz2oXFpGoKZEZ+1RvaiVrHYeliRPTYgP6rZ/tgIB9JHGGOct7eOnL2oX2I'
        'pHhyv/zKDTX4haRJpk717S+uY6KTvF7ruI2kH7nz/HQ+HbVlcZrfELpMHOKqu24JV7Qe0bYgkkeeEYckMDG/0qvsRlTnpO8f1IjpVDhwTZmetddEh39ru9uK'
        'SHT5gkU61VzvwgBKDwTwCQPsesuT9Tw78v7rdsTazsd671mSn23CrSRBEjSzFlubGS8RCL9xxn/+dYZSXJ9P3oikC2B6+4oBQ0NBFr1YrK0pJZXDuwZQRkAH'
        '328n8+OiHJJJ3ig/64ExSCbT00PXIpK1eSaSCOnq9qeQ5BZ3PAHsMf8AjHTAb6iZPUfakyPp3JUbQx9arJbS6nrGpvXayak0NpSgTbKpELHIB8A8+Pt0tGhV'
        'B3x70+W1XG7z7VTGtLW7SrSgV51aMfIyJKo9YOQRvjzlUQrzn2YjpbVL+/b16mmdEW/apSnQ1enrOqy06TJa1TTWRqbDK140OGC48rkkKD5BH46alCqgnAO/'
        'WlQGDMQMsNqz/sAwUey9RuPXsNtUwwyEfQHB25z5JA+38e/VG/LXAJqRwxC2SYr98Gdbp6HJIsx+Y+YmnjMCfrZVAcZPtkg+PuevcWjPnpFc4K4E9ZrZdA02'
        'CddQ1J3StIKsV6NMYEod8IFPsVbPnzjPUd2Ihe8VdtCZPaan/i0tiDuz5hrUlzWdUrRvWR8k7i2HkkP7QCuB9xx9uj8NBtREKDml+KGm7M5IxQfZ81nu2vrE'
        'ep02mWnbeWYUx6EfqthI2THgqMtg+/XbsWSug7iM5869Ym9qDjY8qE+Kekquo6osBNqkNOaO2luQhll9DiQFPJGAc48nB6JwrkhZwZxHntQuLSNQUyIz9qje'
        '1ErWOw9LEiemxAf1Wz/bAQD6SOMMc5b28dOXtQvsRSPDlf8A5lBpr8QtIk0yd69pfXMdFJ3i913EbSD9z5/jofDtqyuM1viF0mDnFVXbcEq9oPaNsQSSPPCM'
        'OSGBjf6VX2Iypz0neP6kR0qhw4JszPWuuiQ7+13e3FJDp8wSKdaq534QAlB4J4BIH2PWXJ+p4d+X91u2JtZ2O9d6zJT7bhVpIgiRpZiy3NjJeIhF+44z/wDz'
        'rDKS5Pp+9EUgWwPX3FAKGhoIterFZWlJLK4d2DKCMgA++3k/nx0Q5JJO8UH/AFwJikT6emia9FJXryTSQR09XtTyHILO54A9hj/xjpjUbiZPUD0pMqLdzwja'
        'GPrVtoupNr9inOsDR6xTmhksWZfoVkXMZi/7vUUk4PjnPSjqLYOfCZj3n0p+25uEGPEN/neuOt14/wCn/M06JDnENqUVWZYUBKlMjiQkYPt1y2c6WPl85Vu4'
        'MSooHuzU7GnvWs6TbZ5I60teqzgxvOGZUJIPI8gjP26JaUHDjnQrzlQCh2FZ323Ha/okVN5nJgmkrRowOGf1ApAPjdk4OfI6o3CNeodJqVaDG3oPLFBdkVn0'
        'SrqutTQq0mn6zCPkgP8A3I2Do4H44OPz0W+Q5VAdxQbClA9w7qwr+krEz1aOlW69ZI6mpErF6kQmlSIKGXaPGWBPPgHHXzukkkHlX0uqACNjUJ3rWsXe7NQ1'
        'KO1lKOmRZnmIR58sxRdrHjBP+9vHTlkhbQQjc/akuIk3i0/4iqX4daZd06jpUkEteys7/N+kFBE5TIaWZTyfP+wOOluIIYmR28uwpnhwVAg7/mlnxHnu6VVF'
        'qrJN8xbCpZFisgiDbchA48McYIHBUDo3DopMNyzvWOJcjI5mKiqVOpnVtM06pEtKtZljStuLAo4BGP8AsVyePbp1mY6XY5I+etTkUDVbUYBpZ3HqQvaPfjul'
        'zeZ4RPMeS4jDDge3JX/x0S0ulxp2z+aHdbUhnf8AiqjsbWynZEFGWrMzNYW4szRlEiX0wkgGf1cjI/IPSfEJN3UD2/in+FaLOkjvRnbto0tItwus3rQT5gLs'
        'VhjiLZLL7Es304/546xdAJB6/f4KLZMAg8q8dt2Y5rr2WmKxJJKprRx5ZAHLAIPYHLHI8f765dECK7ZOoz05V4klhk7O14w1Go2RJJJNDuLkkAMoH4VTyo9j'
        '1uCLiSZFBLA2H0iDUpY1M6zqtiOO8teKSvTqERSLIZdqEqc+2GblfPTen6ajGxJpDWbjGDuAK0LRtTbuCzTnEDR6xTmhksWZfoVkXMZi/PqKScHxznpB1FsE'
        'T4TMe8+lVbbm4QY8Q3+d64a3Xj/p/wAzTokOcQ2pRVZlhQEqUyOJCRg+3XLZzpY+XzlWrgxKige7NTsae9azpNtnkjrS16rODG84ZlQkg8jyCM/bolpQcOOd'
        'CvOVAKHYVnfbcdr+iRU3mcmCaStGjA4Z/UCkA+N2Tg58jqjcI16h0mpVoMbeg8sUF2RWfRKuq61NCrSafrMI+SA/9yNg6OB+ODj89FvkOVQHcUGwpQPcO6sK'
        '/pKxM9WjpVuvWSOpqRKxepEJpUiChl2jxlgTz4Bx187pJJB5V9LqgAjY1Cd61rF3uzUNSjtZSjpkWZ5iEefLMUXax4wT/vbx05ZIW0EI3P2pLiJN4tP+Iql+'
        'HWmXdOo6VJBLXsrO/wA36QUETlMhpZlPJ8/7A46W4ghiZHby7CmeHBUCDv8AmlnxHnu6VVFqrJN8xbCpZFisgiDbchA48McYIHBUDo3DopMNyzvWOJcjI5mK'
        'iqVOpnVtM06pEtKtZljStuLAo4BGP+xXJ49unWZjpdjkj561ORQNVtRgGlncepC9o9+O6XN5nhE8x5LiMMOB7clf/HRLS6XGnbP5od1tSGd/4qo7G1sp2RBR'
        'lqzMzWFuLM0ZRIl9MJIBn9XIyPyD0nxCTd1A9v4p/hWizpI70Z27aNLSLcLrN60E+YC7FYY4i2Sy+xLN9OP+eOsXQCQev3+Ci2TAIPKvHbdmOa69lpisSSSq'
        'a0ceWQBywCD2ByxyPH++uXRAiu2TqM9OVeJJYZOzteMNRqNkSSSTQ7i5JADKB+FU8qPY9bgi4kmRQSwNh9Ig1KT6o2r6tOkd5YIngp1SI5FkMu1CV59sM3K+'
        'emtOhRI5k0jrNxjB3AFPrjSqlnT2vQxocSzvJnIAjDEjAyQByQPcAdAWJDR8mmzIlZqg1WSXRNIrtV1QPDSMYiLs6ifKq3qlce5fdzxj36WQB3IZcn5FNtNt'
        'MHAilHfSf1jXBp1PaRuenG0ILspykhf885I++Oj2DoTW3n+1A4gG4+hfL+6lqy3KlGx6mpST6mL1qKz6SemjszYMhxx9S+D7E8dMwrMIXECKRGpUMnxSZpKN'
        'OaD1qdT/ANOiV6zSSH9OUZ2IH/gn79MFphj3peCCVXGBWkaD3P3Bq17tztmS/K2ltQeSGwF9I1XSL1JY0fyY9p5B+/U65btqr3QMz95wPWqNq7cZktk4I+0C'
        'ld+0vdXdOnTW5KmorcrxbI2RjZ2R5YyMRxtYHClvbrYBtW2CyI+2a40Xbo1QZHrjnWjpo8MN6jYuUpDpy6c8UeS0e2T1MKrOrZkG3K8DHSGs6TBzPzyqiLY1'
        'iRiKV95B9N7p0CjYiO5xJLHHIxeFP7JVJSpJDbcqAD9ujWfEjMPmdqDeMXFU9/as17Ijls9y2ZprkcavZqSNPWhKsZPTBfafCLkcn/jqheIW2BHWplkFrpJP'
        'Sgu+ZoYxrJgtn0ZJLEbO4bcGxuDBiMuCTyetWJOmR0rHEkDVB61Z9mxLQ1aSzEsnyb6dHE1KZyQr7BsbJ8AuAekrx1LB3nf3/FUbK6WkbRt6UTp8Fi+uoxFo'
        '7bGcwuGkL1kmKgtx/kMEBV4z1hyFI5e8fxRrYJB5+wNAaVDYji1CnUjaUxMZkkjkH9pROASR5Y7sEgeB9+ttGGPl54oCagGUDvVP8wmoUdSjikFJGpWZLME8'
        'JIErYCRLxyRtfDjyWAPQo0leeRH8/wBUYkuG8jNZF8OYLNfTtTgWurGRmcwOAfqCgbz9yAfb36q8Vp1AzUTg1OkiKtLrTItnT2vQxIcSzvITkARhieByAOSB'
        '7gDpFYw0fJqkZErNP9Vkl0TSK7VdUDw0jGIi7Oonyqt6pXHuX3c8Y9+l0AdyGXJ+RTbTbTBwIpR30n9Y1wadT2kbnpxtCC7KcpIX/POSPvjo9g6E1t5/tQOI'
        'BuPoXy/upastypRsepqUk+pi9ais+knpo7M2DIccfUvg+xPHTMKzCFxAikRqVDJ8UmaSjTmg9anU/wDToles0kh/TlGdiB/4J+/TBaYY96XgglVxgVpGg9z9'
        'wate7c7ZkvytpbUHkhsBfSNV0i9SWNH8mPaeQfv1OuW7aq90DM/ecD1qjau3GZLZOCPtApXftL3V3Tp01uSpqK3K8WyNkY2dkeWMjEcbWBwpb262AbVtgsiP'
        'tmuNF26NUGR6451o6aPDDeo2LlKQ6cunPFHktHtk9TCqzq2ZBtyvAx0hrOkwcz88qoi2NYkYilfeQfTe6dAo2IjucSSxxyMXhT+yVSUqSQ23KgA/bo1nxIzD'
        '5nag3jFxVPf2rNeyI5bPctmaa5HGr2akjT1oSrGT0wX2nwi5HJ/46oXiFtgR1qZZBa6ST0oLvmaGMayYLZ9GSSxGzuG3BsbgwYjLgk8nrViTpkdKxxJA1Qet'
        'WfZsS0NWksxLJ8m+nRxNSmckK+wbGyfALgHpK8dSwd539/xVGyulpG0belE6fBYvrqMRaO2xnMLhpC9ZJioLcf5DBAVeM9YchSOXvH8Ua2CQefsDQGlQ2I4t'
        'Qp1I2lMTGZJI5B/aUTgEkeWO7BIHgffrbRhj5eeKAmoBlA71T/MJqFHUo4pBSRqVmSzBPCSBK2AkS8ckbXw48lgD0KNJXnkR/P8AVGJLhvIzWR/DeCzX0/Uq'
        '611YysXMDgfqCgbz/APt79VeK06gZqJwSnSRFW2nNDe7nIttAYgayboG4Ll9nPsQf0k/fnpBgRb8O+apo03Tq2xTW4k0Gm6nGEe1chjFOWa64K11jZi0KbT9'
        'W1BgseOB+OhiCynYHOOff+qOSQpG5GPKpjR5rsvcMEGo2JYNOSrDAxSTZHHGAWTdgcjnd98Dnpl9Ogld5pS2W+oA20VzGqpe7/jj0eKw227M21AAJYxCCRg+'
        'cnkA+3jrunTa8fT96xq1X4Tr+1KrmKliKKVp5AyuWDYZieWUD2zzj8Y6KuRQrnhMdZqp1KCK78PdBszIthdkcEcLFhh2JV2I8nKgH7ED89LoSLzqMU0yhuHR'
        'jmnHblV075g1JKshqz/+nl9CdYpguOPTB9lODtxjHHQLhmyUJyM9qYt4va4xtRneQ09alfW9KuWp2r25LFtZ4RH6ES7VYA5wxOd3Axxx1ywGk23G4gd61xBA'
        'UOh2Mmgtd1GtqPeM9+WayIJNNENSCZNrQDaRECPA3NyW/I6MoK2go5HPfrSrHVeLHmMVMfCDQ5tS1zUIGexVljsQ1pkjG9JAFA2sSfpbPOffHt0xxb6VB350'
        'twSEu2YO1Lfiqq0NShWI14ltkmURE7gN5jO7PAxjOBxg9d4TKmeVc44aXEc6sqldq3cVnUJ4oNVqQhIXriRtsaKnC5HIOQGyPbPSLGUCjBqoBDljkbUHpNm1'
        'Z7bnMUNdJpLT59H1FX087ztjXzyfflvbz1sqPqCenz5yoSM30jEb0d24G0+/Ynvb7Ake1tNdAjrG2CoRM8AOOAfOfx1i5DABcbVq1Kkls71z7eMw1G9qTQvt'
        'iRBHSmmJjaQoTtOPAAG84PB6JcAgKOfP59qHbPiZj0rOO19QbVu80TfVrpPZRN8Y+XghIiI8c7dxwMe5OfPVC6um1zx6mpdl9d4Z3PlV3pzxX+5yLbQekDWX'
        'MDcFy+zn2IP6Sfvz1PYEW/DvmqaGbp17YprcSaDTdTjCPauQxinLNdcFa6xsxaFNp+ragwWPHA/HQxBZTsDnHPv/AFRySFI3Ix5VMaPNdl7hgg1GxLBpyVYY'
        'GKSbI44wCybsDkc7vvgc9Mvp0ErvNKWy31AG2iuY1VL3f8cejxWG23Zm2oABLGIQSMHzk8gH28dd06bXj6fvWNWq/Cdf2pVcxUsRRStPIGVywbDMTyyge2ec'
        'fjHRVyKFc8JjrNVOpQRXfh7oNmZFsLsjgjhYsMOxKuxHk5UA/YgfnpdCRedRimmUNw6Mc047cqunfMGpJVkNWf8A9PL6E6xTBccemD7KcHbjGOOgXDNkoTkZ'
        '7Uxbxe1xjajO8hp61K+t6VctTtXtyWLazwiP0Il2qwBzhic7uBjjjrlgNJtuNxA71riCAodDsZNBa7qNbUe8Z78s1kQSaaIakEybWgG0iIEeBubkt+R0ZQVt'
        'BRyOe/WlWOq8WPMYqY+EGhzalrmoQM9irLHYhrTJGN6SAKBtYk/S2ec++Pbpji30qDvzpbgkJdswdqW/FVVoalCsRrxLbJMoiJ3AbzGd2eBjGcDjB67wmVM8'
        'q5xw0uI51ZVK7Vu4rOoTxQarUhCQvXEjbY0VOFyOQcgNke2ekWMoFGDVQCHLHI2oPSbNqz23OYoa6TSWnz6PqKvp53nbGvnk+/Le3nrZUfUE9PnzlQkZvpGI'
        '3o7twNp9+xPe32BI9raa6BHWNsFQiZ4AccA+c/jrFyGAC42rVqVJLZ3rn28ZhqN7UmhfbEiCOlNMTG0hQnaceAAN5weD0S4BAUc+fz7UO2fEzHpWcdr6i2q9'
        '6Iu+rXSezGm9B8vBCRER4527jgY9ycnqhdXTa549TUuy+u8MjJ8htWqx6TBW0ltQryCzFYVYGQxghGQ4+pvcA48/5A+3UksS2k8qtKq6NfI0lMFl+1teSo8Y'
        'gr1Z0khGcsZcAEj7AAc55JPno8jWurmR+KAJ0OB0P5pMaa1dVtQCOS+be+vF6b7BLIFAGT42j3A9hjo0yoO0UADSxG80q0g2tK+IesxWIS/ppHMsrnaMPGFV'
        '1I9jyB/HPjozgNZSKApKcQ4PL+KcwVK2palq0TvFBG1SJoZmG9YsON5C/u4yPucHoBLKFPc0wAHZh2x96o7ixW+1tI04WpDZghlllNesVjQgYDNn9ORkqv5I'
        '89AXw3WeMGOdGY6rSpOR9q82dIuaFp0cAtPGLkqhlEQklaSQZ2A/q27Rk7fvz460HVzMbftXSjWxE7xTrvf5mfsjWLUU9aVLEcUNeAErGGbCE+A2cLjnjnA6'
        'XsFVuqpG0mmeJUmyxB3rxf0SrBpiwivJBYirKXtrJus2yrK+dx425GwKPGOtrcJbt05D++dCa0AvcCsy0UX9Au9xn6p651AXVJX65i5EihyMeCSDjg4PVG4E'
        'uBPKPtUq0XtF/OfvSnvcwW+4tJo16CrNcklBl3kiNZGBzz+0DJJ+w63YBCMxO37VniiC6KBk1p2m6rFe0nUm/txxm4ix2mOUuBMqMDOfBz+RjqayaWHlt0mq'
        'y3Nat79a96G0k2ktTp2X05GkNExsVzI6ncDk4Ic8YIPA46y+G1ETz+dq3bBZdK45V10HtaWnO9qRS8zW9jTbwqgqOVIz7H9v5J9+vNdBGkdK4loiWPWgO9DL'
        '2rX2W7MhS3DLFCiRAvDJOQSNvghYlP8AG7o1ki8fCNiPx/dL8QrWf8jvj7/1UJ2j21HbvagXxHU9OGZp4uUjV84b/hcjpy9cIUdc0hZs6mYHbFacmlQV9KbU'
        'a8gsxWVWBlMYIRkOPqb3Gcef8gfbqXqOrSeVWFVdGvkaSmCy/a2vJUeMQV6s6SQjOWMuACR9gAOc8knz0eRrXVzI/FAE6HA6H80mNNauq2oBHJfNvfXi9N9g'
        'lkCgDJ8bR7gewx0aZUHaKABpYjeaVaQbWlfEPWYrEJf00jmWVztGHjCq6kex5A/jnx0ZwGspFAUlOIcHl/FOYKlbUtS1aJ3igjapE0MzDesWHG8hf3cZH3OD'
        '0AllCnuaYADsw7Y+9UdxYrfa2kacLUhswQyyymvWKxoQMBmz+nIyVX8keegL4brPGDHOjMdVpUnI+1ebOkXNC06OAWnjFyVQyiISStJIM7Af1bdoydv358da'
        'Dq5mNv2rpRrYid4p13v8zP2RrFqKetKliOKGvACVjDNhCfAbOFxzxzgdL2Cq3VUjaTTPEqTZYg714v6JVg0xYRXkgsRVlL21k3WbZVlfO48bcjYFHjHW1uEt'
        '26ch/fOhNaAXuBWZaKL+gXe4z9U9c6gLqkr9cxciRQ5GPBJBxwcHqjcCXAnlH2qVaL2i/nP3pT3uYLfcWk0a9BVmuSSgy7yRGsjA55/aBkk/YdbsAhGYnb9q'
        'zxRBdFAya07TdVivaTqTf244zcRY7THKXAmVGBnPg5/Ix1NZNLDy26TVZbmtW9+te9DaSbSWp07L6cjSGiY2K5kdTuBycEOeMEHgcdZfDaiJ5/O1btgsulcc'
        'q66D2tLTne1IpeZrexpt4VQVHKkZ9j+38k+/XmugjSOlcS0RLHrQHehl7Vr7LdmQpbhlihRIgXhknIJG3wQsSn+N3RrJF4+EbEfj+6X4hWs/5HfH3/qoTtDt'
        'uO1e1BnxHT9OGZpouUjV84b/AIXI6cvXCFHXNIWLOpmnbFaxoLWv+gK2kUdLZ2tSWK8k6yCSUO0mTx+3jg//AB6lvp+sWY7RVm3P0Qiiv3eLQaFremaVCK1i'
        're0+dHSNjnbXG5Zdy8gEsR9vPv123NxC/MEfnlXr0WrioNiD+KztI7I1btciSOrFFOS6KmFRTGSr5JPPBHPVEkabnOpI1a7ZG1Lp7T2/iBdqzPPZWejUjSWX'
        'gwBpj5x7YYj/AH1sD9EMORPtXmJ/+llOcCrLtrtrHcOookiiWzK8EUnpDciRjfgE8DdgH/npK7d/THanLVn9Q1RtWShRTQ4ARdtXIPUsr9Sei0hLKP8AuznH'
        '8/noE6j9Q7RRQoUfTHWvusxVqncdcVvVbUI2PplzwjMpZAw9ieAw8DrlvU1vO3z4KNdhbuN6Ctaousz6XYvRmzWrNFFb+Wb9M21i7FvfJ5UAeM9EW2VDBfTy'
        'oT3NRXV60Vb1StboRxS3pa89Rvl9tGrumsO587uQHA+kgceOshCGmN85OBHya0XDJE9sVnPdGrGPUGM9aeb17yvKjyenHH6RARd3lsc5X756o2VkYPL3qXxB'
        'hojc+1dextPXXfiTBqKVWlpUdyBbMgMbTSsQA7NwqHzt/gdcutos6Scn2FesILl7UNh+9U+h0IV07UkSOGKSaOexADESgcSESMg8hVIAGPPSVxzqE8oH8VSt'
        'W1CGBvJrvpFRdM06zevsvo2plsetYG4MXwCoUc+fceM9DuEs2leWK3aGhdT88017Z02xQ0jUqksEc01/UrjvYaUNJCgZcAxnw3+LA+M9BuPLK07AfJpiyhCs'
        'DzY86hu99Zs9yavoMkqyCtBcEL3D+iwhj2Bh/peW9+qHDItsPG5Ex0qXxjm6yTsDE9aN7GpLWPcsaBFqGKvG0RcgsVRgCqj9Q8efBP269eMhOua9ZWGceVVf'
        'b7Wv/wDPquj0dLd2tST15J1kEkodpMnj9vHB/wDj0pc0/WLMdop21P0QiivveLQaFremaVCK1ire0+dHSNjnbXG5Zdy8gEsR9vPv123NxC/MEfnlXr0WrioN'
        'iD+KztI7I1btciSOrFFOS6KmFRTGSr5JPPBHPVEkabnOpI1a7ZG1Lp7T2/iBdqzPPZWejUjSWXgwBpj5x7YYj/fWwP0Qw5E+1eYn/wCllOcCrLtrtrHcOook'
        'iiWzK8EUnpDciRjfgE8DdgH/AJ6Su3f0x2py1Z/UNUbVkoUU0OAEXbVyD1LK/UnotISyj/uznH8/noE6j9Q7RRQoUfTHWvusxVqncdcVvVbUI2PplzwjMpZA'
        'w9ieAw8DrlvU1vO3z4KNdhbuN6Ctaousz6XYvRmzWrNFFb+Wb9M21i7FvfJ5UAeM9EW2VDBfTyoT3NRXV60Vb1StboRxS3pa89Rvl9tGrumsO587uQHA+kgc'
        'eOshCGmN85OBHya0XDJE9sVnPdGrGPUGM9aeb17yvKjyenHH6RARd3lsc5X756o2VkYPL3qXxBhojc+1dextPXXfiTBqKVWlpUdyBbMgMbTSsQA7NwqHzt/g'
        'dcutos6Scn2FesILl7UNh+9U+h0IV07UkSOGKSaOexADESgcSESMg8hVIAGPPSVxzqE8oH8VStW1CGBvJrvpFRdM06zevsvo2plsetYG4MXwCoUc+fceM9Du'
        'Es2leWK3aGhdT88017Z02xQ0jUqksEc01/UrjvYaUNJCgZcAxnw3+LA+M9BuPLK07AfJpiyhCsDzY86hu99Zs9yavoMkqyCtBcEL3D+iwhj2Bh/peW9+qHDI'
        'tsPG5Ex0qXxjm6yTsDE9aM7IpLWHc0aBFqGGvG0RcgsVRgCqj9Q8efBP269eMhOua5ZWGuDyq6m1yp2XpmhXKTQ6xcEqO8Vex6qSsyKJYl2jPv58ZXH36QCG'
        '8zq2BHlzwao6xZVWUyZqRW9N3N3bqJrQ/JS09AuxwmyuGJnlJPHAAABBb2J/jptlFu2JMyy7dhSeo3LxgRCnfvQdSavY0f1o0SrA0cUSmY4+tkwwLc/UMfTn'
        'z56K06433+fzQlIZAT2qV0KnZi1nXtTZmlMVqvG0ccgOUGXcMxGC2Bjj3Ptnpp2UqidQaTtqQzvOxFaJ2hbF7QaVnT0mktSWbc0k0j4AR8RouM/4jjxjHUy8'
        'ulyG2gf3Vew2tAV6n8170S3Rk1+bTq1yF46t6SuVtzFYoY1hJ5fznkgH89ecMFDMNxNctkayo5GKpYdOrWdOs7GkZY5IJUGwmWUbcld2MhjnJ4HC/noGsgg+'
        'dNfTG3cVL1PmK+vmtRlDywTJXkkCenDJE7Mikf44TcOecgY8nprBTUwwRPf5NI5FzSp2P4oujbxrOkVpERaWo6sk8FlJNpCJuZyR+oDgcn3PWGAIZuYHvWwS'
        'rKvIsPxUX3jIZO6ZILttNR9CyLgCkKJYJCdzLnzyCCfOenLOLcqIkR60lehrsMZgz6GivhJqVG7p2p7WjjsPcndYUJXfsI9PY3g+5JP+PQ+KVlYeQo3BMjo3'
        'marO1Ugk0HVZq0UWoWlNieSy5JeKFWDFlbIyDu8e2elb061BwMfeneHZRbYjJzXmKQax/TK8lMiEO9cKCN0b7uQT/ic5AP8A468fBqINcHj0qa43pJYjWEdq'
        'KCVqLWnXDPO4aRo1CKPOQOD+OuBQeU5jt1rZJBwYxNZ/3nfmraDP6wmioV5IjvdQksZVsFG/gE8efJ6f4dQbgjc1L4q4RbM7CK71Ndk7e70vN8vJaousOzI5'
        'DLFuiJ/GDz/289eZNdoCYOffNZD/AE7zYwY9q1WfWqnZOm6FbpPDrNwSo7x17HqpKzIPViXaM+/nxlcffqYEN5nVsCPLng1WLiyFZTJmpBb03c3duomtD8lL'
        'T0C7HCbK4YmeUk8cAAAEFvYn+Om2UW7YkzLLt2FJ6jcvGBEKd+9B1Jq9jR/WjRKsDRxRKZjj62TDAtz9Qx9OfPnorTrjff5/NCUhkBPapXQqdmLWde1NmaUx'
        'Wq8bRxyA5QZdwzEYLYGOPc+2emnZSqJ1BpO2pDO87EVonaFsXtBpWdPSaS1JZtzSTSPgBHxGi4z/AIjjxjHUy8ulyG2gf3Vew2tAV6n8170S3Rk1+bTq1yF4'
        '6t6SuVtzFYoY1hJ5fznkgH89ecMFDMNxNctkayo5GKpYdOrWdOs7GkZY5IJUGwmWUbcld2MhjnJ4HC/noGsgg+dNfTG3cVL1PmK+vmtRlDywTJXkkCenDJE7'
        'Mikf44TcOecgY8nprBTUwwRPf5NI5FzSp2P4oujbxrOkVpERaWo6sk8FlJNpCJuZyR+oDgcn3PWGAIZuYHvWwSrKvIsPxUX3jIZO6ZILttNR9CyLgCkKJYJC'
        'dzLnzyCCfOenLOLcqIkR60lehrsMZgz6GivhJqVG7p2p7WjjsPcndYUJXfsI9PY3g+5JP+PQ+KVlYeQo3BMjo3marO1Ugk0HVZq0UWoWlNieSy5JeKFWDFlb'
        'IyDu8e2elb061BwMfeneHZRbYjJzXmKQax/TK8lMiEO9cKCN0b7uQT/ic5AP/jrx8Gog1wePSprjekliNYR2ooJWotadcM87hpGjUIo85A4P464FB5TmO3Wt'
        'kkHBjE1n/ed+atoM/rCaKhXkiO91CSxlWwUb+ATx58np/h1BuCNzUvirhFszsIoinrkmgd7Xf/TyWaEghCZHIKxboifxg8/9vPXmTXaAmDn3zWQ/07zQMGKq'
        '9I0utrkzmQGFYHMUTVAA4kLFmbHhVUDP58e/SrsUGMz16U+ircOcR0oLuGwr6Pa1Z5wmoC3XpROXKrjcFIJxkIwJY+w6JbWGFsDEE/O4oN1vCbk+KQKVyag+'
        'm0rMfqCNWDl51AIiCja7InuFA8+fq46KBrINBLaARSj/AKmaHt9TXggjgvxvOS6H1HSRsncc4DYXGceMdE+lL5ORj7UL60W/CMHNVOjaTqfbVN9VqvV1avfo'
        'xx+lGzLHE2AQQo5JUEH3ySw89KXHW42gyCDT1pHtL9Rcgilfc9O1Q73tSmVA0kNaJGijwrnYY5PI+ptxB58ADo1pg1oCOZ/kUC6pF4nrH91pE+oC9FPdpwWh'
        'ZazFQaVv7ax4O0lMeWIXz9mPU8LHhbaJqkWnKbyBUx8Rkqp3VfNKOWm9GhMgZ5A0jMSrb9o88njPI5PTPDFvpDUZkilOKAF1io2Br72xQt6h3WqT1xOprI6w'
        'yrlnjCYypHkZySB/J65eYKmDzr1lS1zxdKmvizQOn616foARD0VWZ02thZCxx/CEnHTnCkMsz1+fek+MBVoI6Uq+F2ssmmSf0ohAdUedIrHJMDtjAGPpzzn+'
        'Pz1vi08Xj6R61jgX8B0f+p9Kt+15a2nx6yZoIb8ckNyAxKcGZpnCKqnx9O0EHpG8CxWDBx+KoWCEDTnf80fY1OzTaRljM7JZIkMWNiSlAq7yfAUZzjknH36D'
        'pB+cqNrKjHX8151nSrEOq1NYE0nqERaa1aaLbEAB/YVSMFeck59yOt2iCuj1/mhXQyuLnkI9qz/vK5YrVNW/rNj+pXpHEK0mXMYyw3HjHgDHGSfPjqjYVSym'
        '2IHWp19mCsLhknlWhy6d8j3NbksVioexI6qCGX6cf21zgBNv7vsMffqcW1Jg/OvnVIDS5oPR9Lra7K5lBiWu5iiaoAHEhYszYPCqoGfz49+tOxTbM9elcRVu'
        'Gdo6UF3DYV9Htas84TUBbr0onLlVxuCkE4yEYEsfYdEtrDC2BiCfncUK63hNyfFIFK5NQfTaVmP1BGrBy86gERBRtdkT3CgefP1cdFA1kGgltAIpR/1M0Pb6'
        'mvBBHBfjecl0PqOkjZO45wGwuM48Y6J9KXycjH2oX1ot+EYOaqdG0nU+2qb6rVerq1e/Rjj9KNmWOJsAghRySoIPvklh56UuOtxtBkEGnrSPaX6i5BFK+56d'
        'qh3valMqBpIa0SNFHhXOwxyeR9TbiDz4AHRrTBrQEcz/ACKBdUi8T1j+60ifUBeinu04LQstZioNK39tY8HaSmPLEL5+zHqeFjwttE1SLTlN5AqY+IyVU7qv'
        'mlHLTejQmQM8gaRmJVt+0eeTxnkcnpnhi30hqMyRSnFAC6xUbA197YoW9Q7rVJ64nU1kdYZVyzxhMZUjyM5JA/k9cvMFTB516ypa54ulTXxZoHT9a9P0AIh6'
        'KrM6bWwshY4/hCTjpzhSGWZ6/PvSfGAq0EdKVfC7WWTTJP6UQgOqPOkVjkmB2xgDH055z/H563xaeLx9I9axwL+A6P8A1PpVv2vLW0+PWTNBDfjkhuQGJTgz'
        'NM4RVU+Pp2gg9I3gWKwYOPxVCwQgac7/AJo+xqdmm0jLGZ2SyRIYsbElKBV3k+AoznHJOPv0HSD85UbWVGOv5rzrOlWIdVqawJpPUIi01q00W2IAD+wqkYK8'
        '5Jz7kdbtEFdHr/NCuhlcXPIR7Vn/AHlcsVqmrf1mx/Ur0jiFaTLmMZYbjxjwBjjJPnx1RsKpZTbEDrU6+zBWFwyTyrQrGnfIdyW5LFYoHsSOqghh9OP7a5wA'
        'm3932XH36natSCD86+dUgulzT3timaOh3WbV61L+qRb6ZswEPsBwzBfDFuAD+MjoLv4x4ZjeKYtp4TLRO1SXcbepo84KQRSR3KrLCXyskiPlVAP7eDnH36Zt'
        'HxDyNKXh4SDvIqd7tlgOpa9OIAkDyzn5Fj9SEx5KZH7SWHPTNidKCemaUvkarh88VO3NOtTVtF0tPTlkihhiZkbOZCFTarDzgnn8AdNBlDM/maVZWZUtjtW3'
        'aXppm7E7VEc8ddIS1RllbdNPLDuj3iPjav0HAHvz1EcxduEjv6HNfQW11WbUeX2xSHvjQtLl1mlfqyS6ct6aeI6baJUwKsUbLJ/Lc5+/tjrdm4+kq2YjPWhc'
        'RbXWrAwDIimHYdpJu47BgtmhSRXvLK8ZnkkKrtyqnhSeSP8A99ZviLeRJ26Vvhm1XIG29c6kINTuOxGDPrlhJFBsoY1TKn9B/d9J3EecEDrXNF/1FDP+Nxv9'
        'jQ/wrvtqk/zVpJGsRQxQpZDsqpkFcRKPH6SpPvn/AH1viwFwNj8zWODYt4juB8ik3xouLqkL6pekikrHUlMG+TP0EbFjUDlgedzH3H26NwUhtK9KBx8FNbda'
        'meyBd0TTdCnrrCL+pQiq8eP/AG1RmzN491yMfx0fiNNxmB2XP9UDhJtqhXdsf3V32JV0/S5dfnMbRtW1ARPVkXfH6Txbyef3BgG/1jpK+zOE7in+GVUNzsaZ'
        'W9KTTb2hzxpFqFi1jUmk5kV15c5xxlivv+noIeQw2Ax8+ZopUAqRmc0f8QNU1GxokV6hRnpRSWINTkjZg7sA4HLkftLcj/XXuHChtDGcEV3imYrrURkGse1/'
        'SZu4O56NV5rUkdaZ3xKcyfqJbG0e5BH29uq9txbQkDeol22btxQTtV/UvtbalWizMXgYoRndHETlU2+Cd24YPt0gy6QWPw1SRixAFUPa9P5HQrrNq9akNVi3'
        '0zZgIfYDhmC+GLcAH8ZHSzv4x4Zjem7aeAy0TtUn3G3qaPOCkEUkdyqywl8rJIj5VQD+3g5x9+mbR8Q8jSl4eEg7yKne7ZYDqWvTiAJA8s5+RY/UhMeSmR+0'
        'lhz0zYnSgnpmlL5Gq4fPFTtzTrU1bRdLT05ZIoYYmZGzmQhU2qw84J5/AHTQZQzP5mlWVmVLY7Vt2l6aZuxO1RHPHXSEtUZZW3TTyw7o94j42r9BwB789RHM'
        'XbhI7+hzX0FtdVm1Hl9sUh740LS5dZpX6skunLemniOm2iVMCrFGyyfy3Ofv7Y63ZuPpKtmIz1oXEW11qwMAyIph2HaSbuOwYLZoUkV7yyvGZ5JCq7cqp4Un'
        'kj/99ZviLeRJ26Vvhm1XIG29c6kINTuOxGDPrlhJFBsoY1TKn9B/d9J3EecEDrXNF/1FDP8Ajcb/AGND/Cu+2qT/ADVpJGsRQxQpZDsqpkFcRKPH6SpPvn/f'
        'W+LAXA2PzNY4Ni3iO4HyKTfGi4uqQvql6SKSsdSUwb5M/QRsWNQOWB53Mfcfbo3BSG0r0oHHwU1t1qZ7IF3RNN0KeusIv6lCKrx4/wDbVGbM3j3XIx/HR+I0'
        '3GYHZc/1QOEm2qFd2x/dXfYlXT9Ll1+cxtG1bUBE9WRd8fpPFvJ5/cGAb/WOkr7M4TuKf4ZVQ3Oxplb0pNNvaHPGkWoWLWNSaTmRXXlznHGWK+/6egh5DDYD'
        'Hz5milQCpGZzR/xA1TUbGiRXqFGelFJYg1OSNmDuwDgcuR+0tyP9de4cKG0MZwRXeKZiutRGQax7X9Jm7g7no1XmtSR1pnfEpzJ+olsbR7kEfb26r23FtCQN'
        '6iXbZu3FBO1X9W+bZpVo8zF4GKEZ3RxE5VNvjO7cMH26QZdILfJqkjFiBT/tCmorPT2m/AregY3bfIq+P0+QC31DH59ul7pkzsaatr4dO4pV33W0/TI9I0yX'
        '5hrrzAK4j3KHjBYA45yc7ePt0SzLFnGw/eg3wq6UO9Y3q8z6t3rcYTvBRv2hJLZZOFijARiP9jB/nqzbAt2QCMgfk1AvE3L7RsTVFeatpMa23JjjikikhhgT'
        'LJ6R3HH4HBJPt0sup8fM06xVPEfkVpna9Jx2rpEK5vRxpLI9tZAVEkqswA9+S2Cc4yAOpd1v1GO234qxZEW0G+5nzqe78uyaoKrSSssqyRBpJ+RI25Vd8f5K'
        'W/SOOmOGQKT0z8/uleLYtHaqLQtP02mlKOlfWSnYvzxGKOBpLfG3fImeNmRkqfB6BdZmnUMgelMWVVI0nc+tBfFrRrtDUINOmuMoStamRUYAxsRlC5zt3kH/'
        'AED1vhGUqWjmPnlQ+NVgYJ5GpTStdvUe19H1StBNpqUvXrV69Vy0tqwsG1Gd14AIJO37D89OXLatcZCZmDnkJqfauMEVwIiR5mv3xNmoa/2zpEMUNWtTg0+M'
        'LHTRmV5Y1AMyluSWZ2JzwSD17hiyXWbnPwVrigLllV5RSb4dn+pRVNQaSStHR9QFHPiRThdv+R/dgdE4rwyo50Pg/EAx5e9V/wAOrFKp3PrFq20sL2oDJDWV'
        'yRJOj48Hy+08A+AelOIlraqOXtTvDQLrE8xTTUNWrdt/LRx2ki3U7GyOlGWkrncC53DOUIJznxz0LQbvLmN+dFZxaIg8j6Uf8YO660mnV9Bhv1455tGhmglh'
        'G5HJcMgZhwMhQB4J9x1zhLTK31Y2Y13jLylPpA7is30fuIN3jNbsyypNf0/ZB6bbEEhkAZnx+3Gcke/VFk/SgcjUxLn68nmPzWh9kaZqB7hmpaZpU9vUpKzV'
        'q0ki7Ugkbks5PBBXLZ9up15lKambEye4qlYVg8IMxjtRvZtNRTamAb8CN6BR33yKvgZXyAT9Qx+fbrN0y07E0a2vh0bgUr77rafpkekaZL8w115gFcR7lDxg'
        'sAcc5OdvH263ZlizjYfvQb4VdKHesb1eZ9W71uMJ3go37QklssnCxRgIxH+xg/z1ZtgW7IBGQPyagXibl9o2JqivNW0mNbbkxxxSRSQwwJlk9I7jj8Dgkn26'
        'WXU+PmadYqniPyK0ztek47V0iFc3o40lke2sgKiSVWYAe/JbBOcZAHUu636jHbb8VYsiLaDfcz51Pd+XZNUFVpJWWVZIg0k/Ikbcqu+P8lLfpHHTHDIFJ6Z+'
        'f3SvFsWjtVFoWn6bTSlHSvrJTsX54jFHA0lvjbvkTPGzIyVPg9AuszTqGQPSmLKqkaTufWgvi1o12hqEGnTXGUJWtTIqMAY2Iyhc527yD/oHrfCMpUtHMfPK'
        'h8arAwTyNSmla7eo9r6PqlaCbTUpevWr16rlpbVhYNqM7rwAQSdv2H56cuW1a4yEzMHPITU+1cYIrgREjzNfvibNQ1/tnSIYoatanBp8YWOmjMryxqAZlLck'
        'szsTngkHr3DFkus3OfgrXFAXLKryik3w7P8AUoqmoNJJWjo+oCjnxIpwu3/I/uwOicV4ZUc6HwfiAY8veq/4dWKVTufWLVtpYXtQGSGsrkiSdHx4Pl9p4B8A'
        '9KcRLW1UcvaneGgXWJ5immoatW7b+WjjtJFup2NkdKMtJXO4FzuGcoQTnPjnoWg3eXMb86Kzi0RB5H0o/wCMHddaTTq+gw368c82jQzQSwjcjkuGQMw4GQoA'
        '8E+465wlplb6sbMa7xl5Sn0gdxWb6P3EG7xmt2ZZUmv6fsg9NtiCQyAMz4/bjOSPfqiyfpQORqYlz9eTzH5rQezNMvnXp6Wm6VPb1GSq1atJIu1IJG5LOTwQ'
        'Vy2fbqfeZSmpjiZPcVSsKwchRmMdqeVtLkp6nNNp9N6eoZRYJPp2RKQBuBHL8ftPIyeltciGMj59qcKHUSozWbfFSxe0f4kTxxXrWoWoqMMddnODXeXJlYD9'
        'uB4+2eqfChXsSwgTnvG1RuLL2+IwZMD0nes6o6gyG2m4tDFdZQG5yrLsdc/nGce56pMNu4qarbjoa0KbS9LSvVjkldXatNDE0i5R8DbtLDwxP/PjqdrcknuK'
        'qtbtwB2qt7S11Ye1FpCKE14kq396nDbli2vCfbbkbvwekbqH6k85I/uqFpgLYA6Cg9Vmp2u1dTeJFdqsTK1FSRIGaaI75M8425GV8f76LbLB1n7+lBuhTaYr'
        'y/mqHsSSFY4bkk0bNPYcOzrkV1YjCqP8Pz7+T0teBkrHKmbGmA1L/iKYbHc0mkWRLWS5qUCskigq6EPuUn9gztyfB6Y4cEJrXMA/O9KcSwL/AE25kfaoX5lL'
        'Ola8KVmeurX7UtZKxCJmIJG0xGMHgtwOeOnDhkLCcCZ78qTWNDhcZP4qj7jsU6vY8PqSWEnKKpaXEqJ6Y3A5wNo8HHg7se3SltWN4/N6dulRYHlSb4WRNpmh'
        'adBcWHUB6VqzUkmG1Vsh/rA/JRj5+2B0bjCHdiMbA+VL8CulFDZ3I86JTtSxqPeEXydxpY4IJr8ksb8woOA+cfTliBzzxz56yLoFvI6CtG0Td8J6mqr4L1e4'
        'O5KeoanLcTUbUVswTzTIiqiqOEVQPpDe5PB9+g8WbaEIogRReD1updmkzVRpEfbum6TPp1qoltL0s8b0xAm0lSWd3YjgAHC48Hx0u5uMdYORFNILaroIkGa/'
        'n7R6Q0Tv0ac9htRjr0iq2GXHowiZXxt92wdhH3BPnq67a7OoCJP5j4agIot8QEJmAftNa38K2+V1vuqXTrq6aKmmT72AZzIszemyhyf0Y5yBn6uPHUriZNtQ'
        'wmSPxVjhYFxo5D3ppU0l6OoyS6dSelqA9NIH+nZEhAG4Ecvx+08jJ6W1yIYyPn2prQZlRms3+Kli9o/xInjivWtQtRUYY67OcGu8uTKwH7cDx9s9U+FCvYlh'
        'AnPeNqj8WXt8RgyYHpO9Z1R1BkNtNxaGK6ygNzlWXY65/OM49z1SYbdxU1W3HQ1oU2l6WlerHJK6u1aaGJpFyj4G3aWHhif+fHU7W5JPcVVa3bgDtVb2lrqw'
        '9qLSEUJrxJVv71OG3LFteE+23I3fg9I3UP1J5yR/dULTAWwB0FB6rNTtdq6m8SK7VYmVqKkiQM00R3yZ5xtyMr4/30W2WDrP39KDdCm0xXl/NUPYkkKxw3JJ'
        'o2aew4dnXIrqxGFUf4fn38npa8DJWOVM2NMBqX/EUw2O5pNIsiWslzUoFZJFBV0IfcpP7Bnbk+D0xw4ITWuYB+d6U4lgX+m3Mj7VC/MpZ0rXhSsz11a/alrJ'
        'WIRMxBI2mIxg8FuBzx04cMhYTgTPflSaxocLjJ/FUfcdinV7Hh9SSwk5RVLS4lRPTG4HOBtHg48Hdj26UtqxvH5vTt0qLA8qTfCyJtM0LToLiw6gPStWakkw'
        '2qtkP9YH5KMfP2wOjcYQ7sRjYHypfgV0oobO5HnRKdqWNR7wi+TuNLHBBNfkljfmFBwHzj6csQOeeOfPWRdAt5HQVo2ibvhPU1VfBer3B3JT1DU5biajaitm'
        'CeaZEVUVRwiqB9Ib3J4Pv0HizbQhFECKLwet1Ls0maqNIj7d03SZ9OtVEtpelnjemIE2kqSzu7EcAA4XHg+Ol3NxjrByIppBbVdBEgzX8/aPSGid+jTnsNqM'
        'dekVWwy49GETK+Nvu2DsI+4J89XXbXZ1ARJ/MfDUBFFviAhMwD9prWvhYfl9a7rk066umirpk+8gM5kWZvTZQ5P6Mc5Az9XHjqVxMm2uoTJH4qxwsfUaOQ96'
        'bza7PqVFngaxAyqYo4BGBDNG7ZVyw5SQ4b6vbHjoAQKc/wBiPcUw1wkYrKe4Vt2viVqUEERa41dXUM28sREDnHkjnBHnB6qW4WwCdv7qRcluIYDeP2qQEFea'
        '7ckRMzI/zKQB8As6Ak/6w2PtjpuSAB6UpCkmPP71oWvUotLrSSQN66NOjrIWPpozqCwyPIzjH2JPU+22swapXl0LI2p/SoppbVYWlir/ADNR689BxiRQldpk'
        'lD/pViy4weT/AL6X/wAwx3g7+sRTGbZUDmP2mmt3S4dX7S1bUrqPUmZESOvCQ8hyEbZuHJDE4/BU9CB0XVVc/P2opUXLJdhS7Sra2tBpWqssYaMy7YfVUmJ1'
        'ADpJuIO3aMY8ZH8dEZYcg/PLvQ0YG2GU0B8RdQ0zS+7DckkZ0WKLOxjJ6rMoIZmBwFZjwT9uemeHVjb0ik+KYC8WPapu3p0qdk1fUidZ1nutwv8AblKhWDhv'
        'BVicf89bDfqn0rJWLI9a793K1Ptd3vRmaJYFghZSZArFc4JHBXGR+MdZteK74a1d8NmXGIrv8LNAWTTK170g8cirZBmZt9ePIOEA4yQCxJ9s9Z4x4cr8Nb4K'
        '2NAameu6O0Pd1DEyy/1Gk0tVIgQjiOb6lfH7CpByeSR0G2wNo4/xOft70a8um8BP+Qx6U0+CBjpy63caJ4pdMvz78MR6kJAYo49yPbP/AOetcWJ0jqBWOEMB'
        'j0Jqy12/Tu9waLVrUtwjdmgjDHY5d1eaRz/jjA/kdKKCEYk/OVPEgsqgVjnfw9fveg8VkV9c33Kdv5df2rLuTj7MCRjz1Vs+G0wI8OCPtUa/4rqkHxZB+9VX'
        'w9qRtq+pQzpGrPFEkcecB8fU5T/4gZx+OlL58II+edO8MIZpqkl16fVKBkgaxAyqYo4BGBDNG7ZVy3lJDhvq9seOlggU5/sR7im2uFhisq7hW3a+JWpQQRFr'
        'jV1dQzbyxEQOceSOcEecHqpbhbAJ2/upFyW4hgN4/apAQV5rtyREzMj/ADKQB8As6Ak/6w2PtjpuSAB6UpCkmPP71oWvUotLrSSQN66NOjrIWPpozqCwyPIz'
        'jH2JPU+22swapXl0LI2p/SoppbVYWlir/M1Hrz0HGJFCV2mSUP8ApViy4weT/vpf/MMd4O/rEUxm2VA5j9pprd0uHV+0tW1K6j1JmREjrwkPIchG2bhyQxOP'
        'wVPQgdF1VXPz9qKVFyyXYUu0q2trQaVqrLGGjMu2H1VJidQA6SbiDt2jGPGR/HRGWHIPzy70NGBthlNAfEXUNM0vuw3JJGdFiizsYyeqzKCGZgcBWY8E/bnp'
        'nh1Y29IpPimAvFj2qbt6dKnZNX1InWdZ7rcL/blKhWDhvBVicf8APWw36p9KyViyPWu/dytT7Xd70ZmiWBYIWUmQKxXOCRwVxkfjHWbXiu+GtXfDZlxiK7/C'
        'zQFk0yte9IPHIq2QZmbfXjyDhAOMkAsSfbPWeMeHK/DW+CtjQGpnrujtD3dQxMsv9RpNLVSIEI4jm+pXx+wqQcnkkdBtsDaOP8Tn7e9GvLpvAT/kMelNPggY'
        '6cut3GieKXTL8+/DEepCQGKOPcj2z/8AnrXFidI6gVjhDAY9Castdv07vcGi1a1LcI3ZoIwx2OXdXmkc/wCOMD+R0ooIRiT85U8SCyqBWOd/D1+96DxWRX1z'
        'fcp2/l1/asu5OPswJGPPVWz4bTAjw4I+1Rr/AIrqkHxZB+9VPw+qx/1bU4p441Z4Y0ijzgPj6nKf/EDOPx0pfPhBHzzp3hxDNNBjuW1oes6bourw/IQz2RCH'
        'sLl4q5O9S7L+rZjafcDon0xcDOmTH52x51j6ptMtu5jP4pLoGr0Na79v6zG7K9zUnnrTFOdrf21b8AqG4+xz0S6rJaFvoM0GyyPeNzqcVPavHVo95NdiqMun'
        '2UjlRJGDuJFYxOSRxjeA2Ps3TKS1rTOR/wBpW5C3tUYOf2qx7kRkoQ0ZK0Ui2pFjZ4/oMH1A71AOCpz79IWiNRYHaqV4eELG9PLOnpN2jReCRGCdwMlqvMdz'
        'MsSEAlvITbgZ+x6yreMzzXHr+9ddZURyPtQfd12zLSo6ZHVfTC92CKxqNY/3DDDC0y7o/aUljyOCB121ElyZwcdzjfpXLmrSEAiTv2GaFpadDT7apV0VfQWB'
        '7InWMv8ANu7fWefqweM/x9uuMSzknfbyrSKEQAec167i00vpduKtpXzMLQxRPKGAaZ2I+oD24J4+w467beCCWjes3UkGFnahe+bNTtvsT5GRf6cummWy1Wd2'
        'zYZsKpUE4J+4HjHW7Aa7e1bzA8qFxLLZsado/NT/AH7r3raPBpenTtJHNX3GVHVwpkh3MoUcDORz5xnpuwkOXcc/Y0pxFwFBbtnBHuKf/CvULtLtyKjNGthJ'
        '68emyw1oiWzGPpffz9R3YI+wUdK8Wqu+oedNcEzJbAPlR902dA1EvLNSmghqRwViUJlEbSfu9lLHGfY46EsOsAGSc9JpltSPJjG3WvPYGs2tE1u/otu1NNp1'
        '2xbn+bDxrFJJEBuEhcjwORg88DrV9BcQXFGRGM7HpQbD/TYoxwSc1RdupLqOp1dcXU1CwxmGCtIPoNUOS5XHJY53n7YHt0FzCm2R/wBplASwuA+nap74pVYn'
        'R79RojFp+seqJQP7hWdQctnBAz4z5yei8MxnSeY9qX4pBGtf9W96N7Q1Gc9t9yX4oIL2rW7i10IcLLHWVQNsK+QXJ8gcjAPXboAZV2EfnvXbJJRn3Mx6UAvc'
        'lrQdY0zRNXh+QhmsiEPYX64a+d6l2X9WzG0+4HWvpi4C6ZMfnbHn+az9U2mW3cxJ/FJtA1ehrXft/WY3ZXuak89aYpztb+2rfgFQ3H2OeiXVZLQt9BmhWWR7'
        'xudTip7V46tHvJrsVRl0+ykcqJIwdxIrGJySOMbwGx9m6ZSWtaZyP+0rchb2qMHP7VY9yIyUIaMlaKRbUixs8f0GD6gd6gHBU59+kLRGosDtVK8PCFjenlnT'
        '0m7RovBIjBO4GS1XmO5mWJCAS3kJtwM/Y9ZVvGZ5rj1/euusqI5H2oPu67ZlpUdMjqvphe7BFY1Gsf7hhhhaZd0ftKSx5HBA67aiS5M4OO5xv0rlzVpCARJ3'
        '7DNC0tOhp9tUq6KvoLA9kTrGX+bd2+s8/Vg8Z/j7dcYlnJO+3lWkUIgA85r13FppfS7cVbSvmYWhiieUMA0zsR9QHtwTx9hx1228EEtG9ZupIMLO1C982anb'
        'fYnyMi/05dNMtlqs7tmwzYVSoJwT9wPGOt2A129q3mB5ULiWWzY07R+an+/de9bR4NL06dpI5q+4yo6uFMkO5lCjgZyOfOM9N2Ehy7jn7GlOIuAoLds4I9xT'
        '/wCFeoXaXbkVGaNbCT149NlhrREtmMfS+/n6juwR9go6V4tVd9Q86a4JmS2AfKj7ps6BqJeWalNBDUjgrEoTKI2k/d7KWOM+xx0JYdYAMk56TTLakeTGNute'
        'ewNZtaJrd/RbdqabTrti3P8ANh41ikkiA3CQuR4HIweeB1q+guILijIjGdj0oNh/psUY4JOaou3Ul1HU6uuLqahYYzDBWkH0GqHJcrjksc7z9sD26C5hTbI/'
        '7TKAlhcB9O1T3xSqxOj36jRGLT9Y9USgf3Cs6g5bOCBnxnzk9F4ZjOk8x7UvxSCNa/6t70Z2jqE7dtdy3ooIL2r27i10IcLLHXVQNsK+QXY+QORgHrt0AMq7'
        'CPz3rtkkoz7mY9KC76vz3NRqxtfsSyXYTSjt20QHZjdKI8f5ABcnzk9dsqApMbZx+J8qxfPjAnfGaTadpiaelq/DfkM8cTsK2AI1/aoA98ZzuHAx0Zn1QpG/'
        'OhrbCywbNc+4lpaDd0eukwFivLPWaRwDy6I+7n9X1gknwPB67b1XFYxgwftWbgW2yeorxqs5U01CzwtXsRNHLvjd7LF8FigPBx7f764gyT1H2olw7diPWrv4'
        'exR6c9abV9Qgha1qc6To0g9ePBP1Y8EEELnx79J3gGMKMADypmzKr4juTXb4hQxaW2pNTW3egdFkhmncSGFkAV23eWUKeM8nP2HXbUMRyrt7Uqk0F2jbJuQ1'
        'ole6JKjivBIwbZIV42N9jksV9v8Ajr14QpJxnNcsmTHUUFrHcWm6RHLXNqdpZdQoQWY1TC1hESGbd7nAGAB9+upaZyDHJvWa895EnuR6RUh8bKg1rQNLRKEr'
        'SOoSCQgEyb3LSOp+3jj2J6d4E6HJn5ypD/8ASi4gAFTHa2iudGLPWamzVWhhkP0tIcgkY9yFxz7Zx0e6/j3nNL2Lc28iMVonwvvLpNBFkc0oU7iaM2X4XOwA'
        'KT7YP/PSPEjU2P8AzT/CNoXP/qj/AIpV5tN7th9dIbFOOItJRViqSQxHOxffliDu/J6xwzBreN+vc0XipW523+1cL3Znr9vx07UMTouLE8bx7kDO2WJB8bNw'
        'GffHXBfi4WU/P7rTcPNsKR3p92PO1bsntnQpK0Mvc1fULMryp/8Aa01fgyY8huAE9h1m8A117g/xIHqfnOvWdS2ktn/IE+gpH8SIbI0PVPnoA9rcacsVJeIV'
        'ST1Fl58R4bg+3PROHgOuk98+3nQ+JJNpiw7Y96W9gwVbGlTvfgjgmnm3VdQeX0THtH6Vk8jB8D363xBIYBeW4oXCwVJYeRpn33qE93UqqNfsyyXYTSjt3EQH'
        'ZjdKI8f5ABcnzk9YsqApxtnH4nyrfEE6wCd8ZpNp2mJp6Wr8N+QzxxOwrYAjX9qgD3xnO4cDHRmfVCkb86GtsLLBs1z7iWloN3R66TAWK8s9ZpHAPLoj7uf1'
        'fWCSfA8HrtvVcVjGDB+1ZuBbbJ6ivGqzlTTULPC1exE0cu+N3ssXwWKA8HHt/vriDJPUfaiXDt2I9au/h7FHpz1ptX1CCFrWpzpOjSD148E/VjwQQQufHv0n'
        'eAYwowAPKmbMqviO5NdviFDFpbak1Nbd6B0WSGadxIYWQBXbd5ZQp4zyc/YddtQxHKu3tSqTQXaNsm5DWiV7okqOK8EjBtkhXjY32OSxX2/469eEKScZzXLJ'
        'kx1FBax3FpukRy1zanaWXUKEFmNUwtYREhm3e5wBgAffrqWmcgxyb1mvPeRJ7kekVIfGyoNa0DS0ShK0jqEgkIBMm9y0jqft449ieneBOhyZ+cqQ/wD0ouIA'
        'BUx2tornRiz1mps1VoYZD9LSHIJGPchcc+2cdHuv495zS9i3NvIjFaJ8L7y6TQRZHNKFO4mjNl+FzsACk+2D/wA9I8SNTY/80/wjaFz/AOqP+KVebTe7YfXS'
        'GxTjiLSUVYqkkMRzsX35Yg7vyescMwa3jfr3NF4qVudt/tXC92Z6/b8dO1DE6LixPG8e5AztliQfGzcBn3x1wX4uFlPz+603DzbCkd6fdjztW7J7Z0KStDL3'
        'NX1CzK8qf/a01fgyY8huAE9h1m8A117g/wASB6n5zr1nUtpLZ/yBPoKR/EiGyND1T56APa3GnLFSXiFUk9RZefEeG4Ptz0Th4DrpPfPt50PiSTaYsO2Pelvw'
        '/hqz6XPJfgjgmnm3VdQeX0Wj2j9KyeRg+B79b4iQwCnbcULhYKksPI1znSn3j3RpiR21vLFiea5FLkLLIMKhOAMggk4GAeOvAtZttiJ5eVdYLfuqAZAqr1Gk'
        'ZMQYrGNsQhSuZ2Xd9QbdwgPGPzj79KqYz/z+6cKkmMVB/E6TUYdCjrPPLZShqUlg2LEIVnQjapyB+ncefvx1Q4XQXkCJFTON1i2M7Ga/ae1WKapcNeZyYfWk'
        'SNdrrMx2KMnjkjIP24680wVn/ldSJDEf9qo7Fm0vuDV4kmpF56p1CzPLLLtTZHtCxgHyMEsQeeMe/S18NbWQen5prhytxgCM5/FVncc2o2o+5K9F69jTnoel'
        'BD6iieByFVZWzym4Hgn8DpZAoKMcGfTy7005Yh1BkRSPSPk6WuyWbUsbVolMiyUoyYwyIiuylfGGI3e3JPRG1MsAZ7/PtQ0Co2amvitc1Gn3fpUSQhoa1uDU'
        'ZUQAtGCzKFZjzzyce4PTPCqrW2J5gik+LLLdUdCDQHxF7gpWrelpXSWqXuPO0sw2NMpA2ssYOFUcjjz/AD0bhrbKGnOAPL1oPF3VZlA6zX3S4hLoFewrbHWM'
        'NLEx5mVmAJAPufp8fbnobYYiioPADVH2V2qjfDXUrEtSa4j6xK/pqSznaVyQPbGec+fHS/EXD9dYMYpjhbYPDvOfFTDWr1P4ia3BqVQvqCVq1mtaxCyJDABG'
        'sRkz43EHOPt1i2rcOhVsTBHnzii3GS/cVl2AIP7UXrU7apo+oVZL1qwBFkvJjcFKhhGWHlQU/wCMDrijQ6sAPnOtuS1srNA/DPWdLk1a1bs1NRlhns/MfO0w'
        'XWMvhUSRRz9QH0nxzz0W8jAASMDb+P3pezcWSYOTvXXu/vLT9e7S7vs6YNOrzJDLTtRXLxSfxtiVCBtkfAb6RxgY6xbtMl22HnqIGO89KJdvq1m4yRzBz7Vn'
        '/aXxG0XQKElW8GqX4qqrSsekLKhyPqDIeFOfB9unb3D3HbUmROeVTrHFW7a6HwYxzpxYSn3h3TpiJbW8sWJ5rkUuQssgwqE4AyCCTgYB6CC1m22Inl5UwwW/'
        'dUAyBzqq1GkZMQYrGNsQhSuZ2Xd9QbdwgPGPzj79KqYz/wA/unCpJjFQfxOk1GHQo6zzy2UoalJYNixCFZ0I2qcgfp3Hn78dUOF0F5AiRUzjdYtjOxmv2ntV'
        'imqXDXmcmH1pEjXa6zMdijJ45IyD9uOvNMFZ/wCV1IkMR/2qjsWbS+4NXiSakXnqnULM8ssu1Nke0LGAfIwSxB54x79LXw1tZB6fmmuHK3GAIzn8VWdxzaja'
        'j7kr0Xr2NOeh6UEPqKJ4HIVVlbPKbgeCfwOlkCgoxwZ9PLvTTliHUGRFI9I+Tpa7JZtSxtWiUyLJSjJjDIiK7KV8YYjd7ck9EbUywBnv8+1DQKjZqa+K1zUa'
        'fd+lRJCGhrW4NRlRAC0YLMoVmPPPJx7g9M8KqtbYnmCKT4sst1R0INAfEXuClat6WldJape487SzDY0ykDayxg4VRyOPP89G4a2yhpzgDy9aDxd1WZQOs190'
        'uIS6BXsK2x1jDSxMeZlZgCQD7n6fH256G2GIoqDwA1R9ldqo3w11KxLUmuI+sSv6aks52lckD2xnnPnx0vxFw/XWDGKY4W2Dw7znxUw1q9T+ImtwalUL6gla'
        'tZrWsQsiQwARrEZM+NxBzj7dYtq3DoVbEwR584otxkv3FZdgCD+1F61O2qaPqFWS9asARZLyY3BSoYRlh5UFP+MDrijQ6sAPnOtuS1srNA/DPWdLk1a1bs1N'
        'Rlhns/MfO0wXWMvhUSRRz9QH0nxzz0W8jAASMDb+P3pezcWSYOTvXXu/vLT9e7S7vs6YNOrzJDLTtRXLxSfxtiVCBtkfAb6RxgY6xbtMl22HnqIGO89KJdvq'
        '1m4yRzBz7Vn/AGj8RdF0GlJUvBql+Kqi07HpCyoYj6gyHhTnwfbpy9w9x21JkTnlU/h+Ktouh8GMc6f1Yfltai+Qk9GZq0zmdoioBX6kGCPYDk/Y56XyU8VN'
        'kQ/hPKrTXbNO1282obXae2YTLCn/ANMOSWbP2IBA9sdLICG09Jpx2BTWRUN3JH/1Fo+vwwWp4qkOjGyqyJ6jWJCw2KwH6AFU/V9h+enLJFt0JGZj51pK+DdS'
        '4F2CzUxDPY17R4trMgCoodOQjD69x+7HGMfjpuBbfNTwTcQRV/8ACSfRe4bV29agEEUy17sNON8vn6kl593dl3EHj6j0hxQe3Cg9RPt9qo8GUuam6wf5p/rE'
        'mjyU7t21CJ6tyxVWcafj5r04FJi9T/IBiARjkjHQU1ghV3E77Z3pm4Eyx2Mbb42r9TmWnJcp61FBRkro5sRSRlBJuALQybOcEshGPtz1lhMMmfm4mtIQJVqk'
        '9c02vqFxbDz16gGoiFppGZ4UT0yVBxknDcgfdumrbMFgAnE96SdAzT3j8VOd5aXFY0TUpjB67xxxPBZ5zEVYAhfsGGMjzno9hyHUTvQOJtA22JG0UHFerSaW'
        'szTOWjrLBDHLkh3yWKoF8exz/PW9LBojnWNSlJnlTPQ+45/h9TsRzajPDX1n6pjDIfomOCp48qf0n8eOsvbHEHAytet3Dws6jhqru3+1bdupdv1Lb6PT1CUh'
        'WLfTIo/awHldwbnznpN7oBCESRT9qySGdTE0PaazB2nqdiy2JZqcyBaEgAkPA3K3jbg8/wDHWhpNxQOvOutItMT0r72feXsztyyalU3bOp1RVYSzGKCKVF3J'
        'JuHJ2qSwC++M8dcu/r3BqxBnvHSs2h9G3KiZqV1/Q3GnV1q0oVRYvXWOPnDBAcjP6ix3t/JPTFu5LHUe3z2pa5a8I0ig+19Jj1HWZNLalWSavYnkVpXCsxKq'
        '6xhvuPqPWrzaV1ycgf8AaxYQM5tkbE1S1Yvl9ai+Qk9GZ6szmdotoBX6kGCPYDk/Y56XyU8VNEQ/hPKrTXbNO1282obXae2YTLCn/wBMOSWbP2IBA9sdLICG'
        '09Jpx2BTWRUN3JH/ANRaPr8MFqeKpDoxsqsieo1iQsNisB+gBVP1fYfnpyyRbdCRmY+daSvg3UuBdgs1MQz2Ne0eLazIAqKHTkIw+vcfuxxjH46bgW3zU8E3'
        'EEVf/CSfRe4bV29agEEUy17sNON8vn6kl593dl3EHj6j0hxQe3Cg9RPt9qo8GUuam6wf5p/rEmjyU7t21CJ6tyxVWcafj5r04FJi9T/IBiARjkjHQU1ghV3E'
        '77Z3pm4Eyx2Mbb42r9TmWnJcp61FBRkro5sRSRlBJuALQybOcEshGPtz1lhMMmfm4mtIQJVqk9c02vqFxbDz16gGoiFppGZ4UT0yVBxknDcgfdumrbMFgAnE'
        '96SdAzT3j8VOd5aXFY0TUpjB67xxxPBZ5zEVYAhfsGGMjzno9hyHUTvQOJtA22JG0UHFerSaWszTOWjrLBDHLkh3yWKoF8exz/PW9LBojnWNSlJnlTPQ+45/'
        'h9TsRzajPDX1n6pjDIfomOCp48qf0n8eOsvbHEHAytet3Dws6jhqru3+1bdupdv1Lb6PT1CUhWLfTIo/awHldwbnznpN7oBCESRT9qySGdTE0PaazB2nqdiy'
        '2JZqcyBaEgAkPA3K3jbg8/8AHWhpNxQOvOutItMT0r72feXsztyyalU3bOp1RVYSzGKCKVF3JJuHJ2qSwC++M8dcu/r3BqxBnvHSs2h9G3KiZqV1/Q3GnV1q'
        '0oVRYvXWOPnDBAcjP6ix3t/JPTFu5LHUe3z2pa5a8I0ig+19Kj1DWZNMalWSavYnkVpXCsxKq6xhvuPqPWrzaV1ycgf9rFhQz6CNiavDaXVNV1F4GstUmhtK'
        'yBNsoIhY5APgHnx9uk40KAd8e9UC2tz3n2qoNaWt2lWlArzq0Y+RkSVR6wcgjfHnKohXnPsxHS2qX9+3r1NNaIt+1SlOhq9PWdVlp0mS1qmmsjU2GVrxocMF'
        'x5XJIUHyCPx01KFVBOAd+tKgMGYgZYbVn/YBgo9l6jcevYbaphhkI+gODtznySB9v49+qN+WuATUjhiFskxX74M63T0OSRZj8x8xNPGYE/WyqA4yfbJB8fc9'
        'e4tGfPSK5wVwJ6zWy6BpsE66hqTulaQVYr0aYwJQ74QKfYq2fPnGeo7sRC94q7aEye01P/FpbEHdnzDWpLms6pWjesj5J3FsPJIf2gFcD7jj7dH4aDaiIUHN'
        'L8UNN2ZyRig+z5rPdtfWI9TptMtO28swpj0I/VbCRsmPBUZbB9+u3YsldB3EZz516xN7UHGx5UJ8U9JVdR1RYCbVIac0dtLchDLL6HEgKeSMA5x5OD0ThXJC'
        'zgziPPahcWkagpkRn7VG9qJWsdh6WJE9NiA/qtn+2AgH0kcYY5y3t46cvahfYikeHK//ADKDTX4haRJpk717S+uY6KTvF7ruI2kH7nz/AB0Ph21ZXGa3xC6T'
        'BziqrtuCVe0HtG2IJJHnhGHJDAxv9Kr7EZU56TvH9SI6VQ4cE2ZnrXXRId/a7vbikh0+YJFOtVc78IASg8E8AkD7HrLk/U8O/L+63bE2s7Heu9Zkp9twq0kQ'
        'RI0sxZbmxkvEQi/ccZ//AJ1hlJcn0/eiKQLYHr7igFDQ0EWvVisrSkllcO7BlBGQAffbyfz46IckkneKD/rgTFIJtPTQ9cikrV5JpII6er2p5DkFnc8Aewx/'
        '4x0wG+omT1H2pMj6dyVG0MfWqyW0up6xqb12smpNDaUoE2yqRCxyAfAPPj7dLRoVQd8e9PltVxu8+1UxrS1u0q0oFedWjHyMiSqPWDkEb485VEK859mI6W1S'
        '/v29eppnRFv2qUp0NXp6zqstOkyWtU01kamwyteNDhguPK5JCg+QR+OmpQqoJwDv1pUBgzEDLDas/wCwDBR7L1G49ew21TDDIR9AcHbnPkkD7fx79Ub8tcAm'
        'pHDELZJiv3wZ1unockizH5j5iaeMwJ+tlUBxk+2SD4+569xaM+ekVzgrgT1mtl0DTYJ11DUndK0gqxXo0xgSh3wgU+xVs+fOM9R3YiF7xV20Jk9pqf8Ai0ti'
        'Duz5hrUlzWdUrRvWR8k7i2HkkP7QCuB9xx9uj8NBtREKDml+KGm7M5IxQfZ81nu2vrEep02mWnbeWYUx6EfqthI2THgqMtg+/XbsWSug7iM5869Ym9qDjY8q'
        'E+Kekquo6osBNqkNOaO2luQhll9DiQFPJGAc48nB6JwrkhZwZxHntQuLSNQUyIz9qje1ErWOw9LEiemxAf1Wz/bAQD6SOMMc5b28dOXtQvsRSPDlf/mUGmvx'
        'C0iTTJ3r2l9cx0UneL3XcRtIP3Pn+Oh8O2rK4zW+IXSYOcVVdtwSr2g9o2xBJI88Iw5IYGN/pVfYjKnPSd4/qRHSqHDgmzM9a66JDv7Xd7cUkOnzBIp1qrnf'
        'hACUHgngEgfY9Zcn6nh35f3W7Ym1nY713rMlPtuFWkiCJGlmLLc2Ml4iEX7jjP8A/OsMpLk+n70RSBbA9fcUAoaGgi16sVlaUksrh3YMoIyAD77eT+fHRDkk'
        'k7xQf9cCYpE+npomvRSV68k0kEdPV7U8hyCzueAPYY/8Y6Y1G4mT1A9KTKi3c8I2hj61baLqTa/YpzrA0esU5oZLFmX6FZFzGYv+71FJOD45z0o6i2DnwmY9'
        '59KftubhBjxDf53rjrdeP+n/ADNOiQ5xDalFVmWFASpTI4kJGD7dctnOlj5fOVbuDEqKB7s1Oxp71rOk22eSOtLXqs4MbzhmVCSDyPIIz9uiWlBw450K85UA'
        'odhWd9tx2v6JFTeZyYJpK0aMDhn9QKQD43ZODnyOqNwjXqHSalWgxt6DyxQXZFZ9Eq6rrU0KtJp+swj5ID/3I2Do4H44OPz0W+Q5VAdxQbClA9w7qwr+krEz'
        '1aOlW69ZI6mpErF6kQmlSIKGXaPGWBPPgHHXzukkkHlX0uqACNjUJ3rWsXe7NQ1KO1lKOmRZnmIR58sxRdrHjBP+9vHTlkhbQQjc/akuIk3i0/4iqX4daZd0'
        '6jpUkEteys7/ADfpBQROUyGlmU8nz/sDjpbiCGJkdvLsKZ4cFQIO/wCaWfEee7pVUWqsk3zFsKlkWKyCINtyEDjwxxggcFQOjcOikw3LO9Y4lyMjmYqKpU6m'
        'dW0zTqkS0q1mWNK24sCjgEY/7Fcnj26dZmOl2OSPnrU5FA1W1GAaWdx6kL2j347pc3meETzHkuIww4HtyV/8dEtLpcads/mh3W1IZ3/iqjsbWynZEFGWrMzN'
        'YW4szRlEiX0wkgGf1cjI/IPSfEJN3UD2/in+FaLOkjvRnbto0tItwus3rQT5gLsVhjiLZLL7Es304/546xdAJB6/f4KLZMAg8q8dt2Y5rr2WmKxJJKprRx5Z'
        'AHLAIPYHLHI8f765dECK7ZOoz05V4klhk7O14w1Go2RJJJNDuLkkAMoH4VTyo9j1uCLiSZFBLA2H0iDUpY1M6zqtiOO8teKSvTqERSLIZdqEqc+2GblfPTen'
        '6ajGxJpDWbjGDuAK0LRtTbuCzTnEDR6xTmhksWZfoVkXMZi/PqKScHxznpB1FsET4TMe8+lVbbm4QY8Q3+d64a3Xj/p/zNOiQ5xDalFVmWFASpTI4kJGD7dc'
        'tnOlj5fOVauDEqKB7s1Oxp71rOk22eSOtLXqs4MbzhmVCSDyPIIz9uiWlBw450K85UAodhWd9tx2v6JFTeZyYJpK0aMDhn9QKQD43ZODnyOqNwjXqHSalWgx'
        't6DyxQXZFZ9Eq6rrU0KtJp+swj5ID/3I2Do4H44OPz0W+Q5VAdxQbClA9w7qwr+krEz1aOlW69ZI6mpErF6kQmlSIKGXaPGWBPPgHHXzukkkHlX0uqACNjUJ'
        '3rWsXe7NQ1KO1lKOmRZnmIR58sxRdrHjBP8Avbx05ZIW0EI3P2pLiJN4tP8AiKpfh1pl3TqOlSQS17Kzv836QUETlMhpZlPJ8/7A46W4ghiZHby7CmeHBUCD'
        'v+aWfEee7pVUWqsk3zFsKlkWKyCINtyEDjwxxggcFQOjcOikw3LO9Y4lyMjmYqKpU6mdW0zTqkS0q1mWNK24sCjgEY/7Fcnj26dZmOl2OSPnrU5FA1W1GAaW'
        'dx6kL2j347pc3meETzHkuIww4HtyV/8AHRLS6XGnbP5od1tSGd/4qo7G1sp2RBRlqzMzWFuLM0ZRIl9MJIBn9XIyPyD0nxCTd1A9v4p/hWizpI70Z27aNLSL'
        'cLrN60E+YC7FYY4i2Sy+xLN9OP8AnjrF0AkHr9/gotkwCDyrx23ZjmuvZaYrEkkqmtHHlkAcsAg9gcscjx/vrl0QIrtk6jPTlXiSWGTs7XjDUajZEkkk0O4u'
        'SQAygfhVPKj2PW4IuJJkUEsDYfSINSk+qNq+rTpHeWCJ4KdUiORZDLtQlefbDNyvnprToUSOZNI6zcYwdwBT640qpZ09r0MaHEs7yZyAIwxIwMkAckD3AHQF'
        'iQ0fJpsyJWaoNVkl0TSK7VdUDw0jGIi7Oonyqt6pXHuX3c8Y9+lkAdyGXJ+RTbTbTBwIpR30n9Y1wadT2kbnpxtCC7KcpIX/ADzkj746PYOhNbef7UDiAbj6'
        'F8v7qWrLcqUbHqalJPqYvWorPpJ6aOzNgyHHH1L4PsTx0zCswhcQIpEalQyfFJmko05oPWp1P/Toles0kh/TlGdiB/4J+/TBaYY96XgglVxgVpGg9z9wate7'
        'c7ZkvytpbUHkhsBfSNV0i9SWNH8mPaeQfv1OuW7aq90DM/ecD1qjau3GZLZOCPtApXftL3V3Tp01uSpqK3K8WyNkY2dkeWMjEcbWBwpb262AbVtgsiPtmuNF'
        '26NUGR6451o6aPDDeo2LlKQ6cunPFHktHtk9TCqzq2ZBtyvAx0hrOkwcz88qoi2NYkYilfeQfTe6dAo2IjucSSxxyMXhT+yVSUqSQ23KgA/bo1nxIzD5nag3'
        'jFxVPf2rNeyI5bPctmaa5HGr2akjT1oSrGT0wX2nwi5HJ/46oXiFtgR1qZZBa6ST0oLvmaGMayYLZ9GSSxGzuG3BsbgwYjLgk8nrViTpkdKxxJA1QetWfZsS'
        '0NWksxLJ8m+nRxNSmckK+wbGyfALgHpK8dSwd539/wAVRsrpaRtG3pROnwWL66jEWjtsZzC4aQvWSYqC3H+QwQFXjPWHIUjl7x/FGtgkHn7A0BpUNiOLUKdS'
        'NpTExmSSOQf2lE4BJHljuwSB4H3620YY+XnigJqAZQO9U/zCahR1KOKQUkalZkswTwkgStgJEvHJG18OPJYA9CjSV55Efz/VGJLhvIzWRfDmCzX07U4Frqxk'
        'ZnMDgH6goG8/cgH29+qvFadQM1E4NTpIirS60yLZ09r0MSHEs7yE5AEYYngcgDkge4A6RWMNHyapGRKzT/VZJdE0iu1XVA8NIxiIuzqJ8qreqVx7l93PGPfp'
        'dAHchlyfkU2020wcCKUd9J/WNcGnU9pG56cbQguynKSF/wA85I++Oj2DoTW3n+1A4gG4+hfL+6lqy3KlGx6mpST6mL1qKz6SemjszYMhxx9S+D7E8dMwrMIX'
        'ECKRGpUMnxSZpKNOaD1qdT/06JXrNJIf05RnYgf+Cfv0wWmGPel4IJVcYFaRoPc/cGrXu3O2ZL8raW1B5IbAX0jVdIvUljR/Jj2nkH79Trlu2qvdAzP3nA9a'
        'o2rtxmS2Tgj7QKV37S91d06dNbkqaityvFsjZGNnZHljIxHG1gcKW9utgG1bYLIj7ZrjRdujVBkeuOdaOmjww3qNi5SkOnLpzxR5LR7ZPUwqs6tmQbcrwMdI'
        'azpMHM/PKqItjWJGIpX3kH03unQKNiI7nEksccjF4U/slUlKkkNtyoAP26NZ8SMw+Z2oN4xcVT39qzXsiOWz3LZmmuRxq9mpI09aEqxk9MF9p8IuRyf+OqF4'
        'hbYEdamWQWukk9KC75mhjGsmC2fRkksRs7htwbG4MGIy4JPJ61Yk6ZHSscSQNUHrVn2bEtDVpLMSyfJvp0cTUpnJCvsGxsnwC4B6SvHUsHed/f8AFUbK6Wkb'
        'Rt6UTp8Fi+uoxFo7bGcwuGkL1kmKgtx/kMEBV4z1hyFI5e8fxRrYJB5+wNAaVDYji1CnUjaUxMZkkjkH9pROASR5Y7sEgeB9+ttGGPl54oCagGUDvVP8wmoU'
        'dSjikFJGpWZLME8JIErYCRLxyRtfDjyWAPQo0leeRH8/1RiS4byM1kfw3gs19P1KutdWMrFzA4H6goG8/wAA+3v1V4rTqBmonBKdJEVbac0N7uci20BiBrJu'
        'gbguX2c+xB/ST9+ekGBFvw75qmjTdOrbFNbiTQabqcYR7VyGMU5ZrrgrXWNmLQptP1bUGCx44H46GILKdgc459/6o5JCkbkY8qmNHmuy9wwQajYlg05KsMDF'
        'JNkccYBZN2ByOd33wOemX06CV3mlLZb6gDbRXMaql7v+OPR4rDbbszbUAAljEIJGD5yeQD7eOu6dNrx9P3rGrVfhOv7UquYqWIopWnkDK5YNhmJ5ZQPbPOPx'
        'joq5FCueEx1mqnUoIrvw90GzMi2F2RwRwsWGHYlXYjycqAfsQPz0uhIvOoxTTKG4dGOacduVXTvmDUkqyGrP/wCnl9CdYpguOPTB9lODtxjHHQLhmyUJyM9q'
        'Yt4va4xtRneQ09alfW9KuWp2r25LFtZ4RH6ES7VYA5wxOd3Axxx1ywGk23G4gd61xBAUOh2Mmgtd1GtqPeM9+WayIJNNENSCZNrQDaRECPA3NyW/I6MoK2go'
        '5HPfrSrHVeLHmMVMfCDQ5tS1zUIGexVljsQ1pkjG9JAFA2sSfpbPOffHt0xxb6VB350twSEu2YO1Lfiqq0NShWI14ltkmURE7gN5jO7PAxjOBxg9d4TKmeVc'
        '44aXEc6sqldq3cVnUJ4oNVqQhIXriRtsaKnC5HIOQGyPbPSLGUCjBqoBDljkbUHpNm1Z7bnMUNdJpLT59H1FX087ztjXzyfflvbz1sqPqCenz5yoSM30jEb0'
        'd24G0+/Ynvb7Ake1tNdAjrG2CoRM8AOOAfOfx1i5DABcbVq1Kkls71z7eMw1G9qTQvtiRBHSmmJjaQoTtOPAAG84PB6JcAgKOfP59qHbPiZj0rOO19QbVu80'
        'TfVrpPZRN8Y+XghIiI8c7dxwMe5OfPVC6um1zx6mpdl9d4Z3PlV3pzxX+5yLbQekDWXMDcFy+zn2IP6Sfvz1PYEW/DvmqaGbp17YprcSaDTdTjCPauQxinLN'
        'dcFa6xsxaFNp+ragwWPHA/HQxBZTsDnHPv8A1RySFI3Ix5VMaPNdl7hgg1GxLBpyVYYGKSbI44wCybsDkc7vvgc9Mvp0ErvNKWy31AG2iuY1VL3f8cejxWG2'
        '3Zm2oABLGIQSMHzk8gH28dd06bXj6fvWNWq/Cdf2pVcxUsRRStPIGVywbDMTyyge2ecfjHRVyKFc8JjrNVOpQRXfh7oNmZFsLsjgjhYsMOxKuxHk5UA/Ygfn'
        'pdCRedRimmUNw6Mc047cqunfMGpJVkNWf/08voTrFMFxx6YPspwduMY46BcM2ShORntTFvF7XGNqM7yGnrUr63pVy1O1e3JYtrPCI/QiXarAHOGJzu4GOOOu'
        'WA0m243EDvWuIICh0Oxk0Fruo1tR7xnvyzWRBJpohqQTJtaAbSIgR4G5uS35HRlBW0FHI579aVY6rxY8xipj4QaHNqWuahAz2KssdiGtMkY3pIAoG1iT9LZ5'
        'z749umOLfSoO/OluCQl2zB2pb8VVWhqUKxGvEtskyiIncBvMZ3Z4GMZwOMHrvCZUzyrnHDS4jnVlUrtW7is6hPFBqtSEJC9cSNtjRU4XI5ByA2R7Z6RYygUY'
        'NVAIcscjag9Js2rPbc5ihrpNJafPo+oq+nnedsa+eT78t7eetlR9QT0+fOVCRm+kYjeju3A2n37E97fYEj2tproEdY2wVCJngBxwD5z+OsXIYALjatWpUktn'
        'eufbxmGo3tSaF9sSII6U0xMbSFCdpx4AA3nB4PRLgEBRz5/PtQ7Z8TMelZx2vqLar3oi76tdJ7Mab0Hy8EJERHjnbuOBj3JyeqF1dNrnj1NS7L67wyMnyG1a'
        'rHpMFbSW1CvILMVhVgZDGCEZDj6m9wDjz/kD7dSSxLaTyq0qro18jSUwWX7W15KjxiCvVnSSEZyxlwASPsABznkk+ejyNa6uZH4oAnQ4HQ/mkxprV1W1AI5L'
        '5t768XpvsEsgUAZPjaPcD2GOjTKg7RQANLEbzSrSDa0r4h6zFYhL+mkcyyudow8YVXUj2PIH8c+OjOA1lIoCkpxDg8v4pzBUralqWrRO8UEbVImhmYb1iw43'
        'kL+7jI+5wegEsoU9zTAAdmHbH3qjuLFb7W0jThakNmCGWWU16xWNCBgM2f05GSq/kjz0BfDdZ4wY50ZjqtKk5H2rzZ0i5oWnRwC08YuSqGURCSVpJBnYD+rb'
        'tGTt+/PjrQdXMxt+1dKNbETvFOu9/mZ+yNYtRT1pUsRxQ14ASsYZsIT4DZwuOeOcDpewVW6qkbSaZ4lSbLEHevF/RKsGmLCK8kFiKspe2sm6zbKsr53Hjbkb'
        'Ao8Y62twlu3TkP750JrQC9wKzLRRf0C73GfqnrnUBdUlfrmLkSKHIx4JIOODg9UbgS4E8o+1SrRe0X85+9Ke9zBb7i0mjXoKs1ySUGXeSI1kYHPP7QMkn7Dr'
        'dgEIzE7ftWeKILooGTWnabqsV7SdSb+3HGbiLHaY5S4EyowM58HP5GOprJpYeW3SarLc1q3v1r3obSTaS1OnZfTkaQ0TGxXMjqdwOTghzxgg8DjrL4bURPP5'
        '2rdsFl0rjlXXQe1pac72pFLzNb2NNvCqCo5UjPsf2/kn36810EaR0riWiJY9aA70MvatfZbsyFLcMsUKJEC8Mk5BI2+CFiU/xu6NZIvHwjYj8f3S/EK1n/I7'
        '4+/9VCdo9tR272oF8R1PThmaeLlI1fOG/wCFyOnL1whR1zSFmzqZgdsVpyaVBX0ptRryCzFZVYGUxghGQ4+pvcZx5/yB9upeo6tJ5VYVV0a+RpKYLL9ra8lR'
        '4xBXqzpJCM5Yy4AJH2AA5zySfPR5GtdXMj8UATocDofzSY01q6ragEcl8299eL032CWQKAMnxtHuB7DHRplQdooAGliN5pVpBtaV8Q9ZisQl/TSOZZXO0YeM'
        'KrqR7HkD+OfHRnAaykUBSU4hweX8U5gqVtS1LVoneKCNqkTQzMN6xYcbyF/dxkfc4PQCWUKe5pgAOzDtj71R3Fit9raRpwtSGzBDLLKa9YrGhAwGbP6cjJVf'
        'yR56Avhus8YMc6Mx1WlScj7V5s6Rc0LTo4BaeMXJVDKIhJK0kgzsB/Vt2jJ2/fnx1oOrmY2/aulGtiJ3inXe/wAzP2RrFqKetKliOKGvACVjDNhCfAbOFxzx'
        'zgdL2Cq3VUjaTTPEqTZYg714v6JVg0xYRXkgsRVlL21k3WbZVlfO48bcjYFHjHW1uEt26ch/fOhNaAXuBWZaKL+gXe4z9U9c6gLqkr9cxciRQ5GPBJBxwcHq'
        'jcCXAnlH2qVaL2i/nP3pT3uYLfcWk0a9BVmuSSgy7yRGsjA55/aBkk/YdbsAhGYnb9qzxRBdFAya07TdVivaTqTf244zcRY7THKXAmVGBnPg5/Ix1NZNLDy2'
        '6TVZbmtW9+te9DaSbSWp07L6cjSGiY2K5kdTuBycEOeMEHgcdZfDaiJ5/O1btgsulccq66D2tLTne1IpeZrexpt4VQVHKkZ9j+38k+/XmugjSOlcS0RLHrQH'
        'ehl7Vr7LdmQpbhlihRIgXhknIJG3wQsSn+N3RrJF4+EbEfj+6X4hWs/5HfH3/qoTtDtuO1e1BnxHT9OGZpouUjV84b/hcjpy9cIUdc0hYs6madsVrGgta/6A'
        'raRR0tna1JYryTrIJJQ7SZPH7eOD/wDHqW+n6xZjtFWbc/RCKK/d4tBoWt6ZpUIrWKt7T50dI2Odtcbll3LyASxH28+/Xbc3EL8wR+eVevRauKg2IP4rO0js'
        'jVu1yJI6sUU5LoqYVFMZKvkk88Ec9USRpuc6kjVrtkbUuntPb+IF2rM89lZ6NSNJZeDAGmPnHthiP99bA/RDDkT7V5if/pZTnAqy7a7ax3DqKJIolsyvBFJ6'
        'Q3IkY34BPA3YB/56Su3f0x2py1Z/UNUbVkoUU0OAEXbVyD1LK/UnotISyj/uznH8/noE6j9Q7RRQoUfTHWvusxVqncdcVvVbUI2PplzwjMpZAw9ieAw8Drlv'
        'U1vO3z4KNdhbuN6Ctaousz6XYvRmzWrNFFb+Wb9M21i7FvfJ5UAeM9EW2VDBfTyoT3NRXV60Vb1StboRxS3pa89Rvl9tGrumsO587uQHA+kgceOshCGmN85O'
        'BHya0XDJE9sVnPdGrGPUGM9aeb17yvKjyenHH6RARd3lsc5X756o2VkYPL3qXxBhojc+1dextPXXfiTBqKVWlpUdyBbMgMbTSsQA7NwqHzt/gdcutos6Scn2'
        'FesILl7UNh+9U+h0IV07UkSOGKSaOexADESgcSESMg8hVIAGPPSVxzqE8oH8VStW1CGBvJrvpFRdM06zevsvo2plsetYG4MXwCoUc+fceM9DuEs2leWK3aGh'
        'dT88017Z02xQ0jUqksEc01/UrjvYaUNJCgZcAxnw3+LA+M9BuPLK07AfJpiyhCsDzY86hu99Zs9yavoMkqyCtBcEL3D+iwhj2Bh/peW9+qHDItsPG5Ex0qXx'
        'jm6yTsDE9aN7GpLWPcsaBFqGKvG0RcgsVRgCqj9Q8efBP269eMhOua9ZWGceVVfb7Wv/APPquj0dLd2tST15J1kEkodpMnj9vHB/+PSlzT9Ysx2inbU/RCKK'
        '+94tBoWt6ZpUIrWKt7T50dI2Odtcbll3LyASxH28+/Xbc3EL8wR+eVevRauKg2IP4rO0jsjVu1yJI6sUU5LoqYVFMZKvkk88Ec9USRpuc6kjVrtkbUuntPb+'
        'IF2rM89lZ6NSNJZeDAGmPnHthiP99bA/RDDkT7V5if8A6WU5wKsu2u2sdw6iiSKJbMrwRSekNyJGN+ATwN2Af+ekrt39MdqctWf1DVG1ZKFFNDgBF21cg9Sy'
        'v1J6LSEso/7s5x/P56BOo/UO0UUKFH0x1r7rMVap3HXFb1W1CNj6Zc8IzKWQMPYngMPA65b1Nbzt8+CjXYW7jegrWqLrM+l2L0Zs1qzRRW/lm/TNtYuxb3ye'
        'VAHjPRFtlQwX08qE9zUV1etFW9UrW6EcUt6WvPUb5fbRq7prDufO7kBwPpIHHjrIQhpjfOTgR8mtFwyRPbFZz3Rqxj1BjPWnm9e8ryo8npxx+kQEXd5bHOV+'
        '+eqNlZGDy96l8QYaI3PtXXsbT1134kwailVpaVHcgWzIDG00rEAOzcKh87f4HXLraLOknJ9hXrCC5e1DYfvVPodCFdO1JEjhikmjnsQAxEoHEhEjIPIVSABj'
        'z0lcc6hPKB/FUrVtQhgbya76RUXTNOs3r7L6NqZbHrWBuDF8AqFHPn3HjPQ7hLNpXlit2hoXU/PNNe2dNsUNI1KpLBHNNf1K472GlDSQoGXAMZ8N/iwPjPQb'
        'jyytOwHyaYsoQrA82POobvfWbPcmr6DJKsgrQXBC9w/osIY9gYf6XlvfqhwyLbDxuRMdKl8Y5usk7AxPWjOyKS1h3NGgRahhrxtEXILFUYAqo/UPHnwT9uvX'
        'jITrmuWVhrg8quptcqdl6ZoVyk0OsXBKjvFXseqkrMiiWJdoz7+fGVx9+kAhvM6tgR5c8GqOsWVVlMmakVvTdzd26ia0PyUtPQLscJsrhiZ5STxwAAAQW9if'
        '46bZRbtiTMsu3YUnqNy8YEQp370HUmr2NH9aNEqwNHFEpmOPrZMMC3P1DH058+eitOuN9/n80JSGQE9qldCp2YtZ17U2ZpTFarxtHHIDlBl3DMRgtgY49z7Z'
        '6adlKonUGk7akM7zsRWidoWxe0GlZ09JpLUlm3NJNI+AEfEaLjP+I48Yx1MvLpchtoH91XsNrQFep/Ne9Et0ZNfm06tcheOrekrlbcxWKGNYSeX855IB/PXn'
        'DBQzDcTXLZGsqORiqWHTq1nTrOxpGWOSCVBsJllG3JXdjIY5yeBwv56BrIIPnTX0xt3FS9T5ivr5rUZQ8sEyV5JAnpwyROzIpH+OE3DnnIGPJ6awU1MMET3+'
        'TSORc0qdj+KLo28azpFaREWlqOrJPBZSTaQibmckfqA4HJ9z1hgCGbmB71sEqyryLD8VF94yGTumSC7bTUfQsi4ApCiWCQncy588ggnznpyzi3KiJEetJXoa'
        '7DGYM+hor4SalRu6dqe1o47D3J3WFCV37CPT2N4PuST/AI9D4pWVh5CjcEyOjeZqs7VSCTQdVmrRRahaU2J5LLkl4oVYMWVsjIO7x7Z6VvTrUHAx96d4dlFt'
        'iMnNeYpBrH9MryUyIQ71woI3Rvu5BP8Aic5AP/jrx8Gog1wePSprjekliNYR2ooJWotadcM87hpGjUIo85A4P464FB5TmO3WtkkHBjE1n/ed+atoM/rCaKhX'
        'kiO91CSxlWwUb+ATx58np/h1BuCNzUvirhFszsIrvU12Tt7vS83y8lqi6w7MjkMsW6In8YPP/bz15k12gJg5981kP9O82MGPatVn1qp2TpuhW6Tw6zcEqO8d'
        'ex6qSsyD1Yl2jPv58ZXH36mBDeZ1bAjy54NVi4shWUyZqQW9N3N3bqJrQ/JS09AuxwmyuGJnlJPHAAABBb2J/jptlFu2JMyy7dhSeo3LxgRCnfvQdSavY0f1'
        'o0SrA0cUSmY4+tkwwLc/UMfTnz56K06433+fzQlIZAT2qV0KnZi1nXtTZmlMVqvG0ccgOUGXcMxGC2Bjj3Ptnpp2UqidQaTtqQzvOxFaJ2hbF7QaVnT0mktS'
        'Wbc0k0j4AR8RouM/4jjxjHUy8ulyG2gf3Vew2tAV6n8170S3Rk1+bTq1yF46t6SuVtzFYoY1hJ5fznkgH89ecMFDMNxNctkayo5GKpYdOrWdOs7GkZY5IJUG'
        'wmWUbcld2MhjnJ4HC/noGsgg+dNfTG3cVL1PmK+vmtRlDywTJXkkCenDJE7Mikf44TcOecgY8nprBTUwwRPf5NI5FzSp2P4oujbxrOkVpERaWo6sk8FlJNpC'
        'JuZyR+oDgcn3PWGAIZuYHvWwSrKvIsPxUX3jIZO6ZILttNR9CyLgCkKJYJCdzLnzyCCfOenLOLcqIkR60lehrsMZgz6GivhJqVG7p2p7WjjsPcndYUJXfsI9'
        'PY3g+5JP+PQ+KVlYeQo3BMjo3marO1Ugk0HVZq0UWoWlNieSy5JeKFWDFlbIyDu8e2elb061BwMfeneHZRbYjJzXmKQax/TK8lMiEO9cKCN0b7uQT/ic5AP/'
        'AI68fBqINcHj0qa43pJYjWEdqKCVqLWnXDPO4aRo1CKPOQOD+OuBQeU5jt1rZJBwYxNZ/wB535q2gz+sJoqFeSI73UJLGVbBRv4BPHnyen+HUG4I3NS+KuEW'
        'zOwiiKeuSaB3td/9PJZoSCEJkcgrFuiJ/GDz/wBvPXmTXaAmDn3zWQ/07zQMGKq9I0utrkzmQGFYHMUTVAA4kLFmbHhVUDP58e/SrsUGMz16U+ircOcR0oLu'
        'Gwr6Pa1Z5wmoC3XpROXKrjcFIJxkIwJY+w6JbWGFsDEE/O4oN1vCbk+KQKVyag+m0rMfqCNWDl51AIiCja7InuFA8+fq46KBrINBLaARSj/qZoe31NeCCOC/'
        'G85LofUdJGydxzgNhcZx4x0T6Uvk5GPtQvrRb8Iwc1U6NpOp9tU31Wq9XVq9+jHH6UbMscTYBBCjklQQffJLDz0pcdbjaDIINPWke0v1FyCKV9z07VDve1KZ'
        'UDSQ1okaKPCudhjk8j6m3EHnwAOjWmDWgI5n+RQLqkXiesf3WkT6gL0U92nBaFlrMVBpW/trHg7SUx5YhfP2Y9TwseFtomqRacpvIFTHxGSqndV80o5ab0aE'
        'yBnkDSMxKtv2jzyeM8jk9M8MW+kNRmSKU4oAXWKjYGvvbFC3qHdapPXE6msjrDKuWeMJjKkeRnJIH8nrl5gqYPOvWVLXPF0qa+LNA6frXp+gBEPRVZnTa2Fk'
        'LHH8IScdOcKQyzPX596T4wFWgjpSr4XayyaZJ/SiEB1R50isckwO2MAY+nPOf4/PW+LTxePpHrWOBfwHR/6n0q37XlrafHrJmghvxyQ3IDEpwZmmcIqqfH07'
        'QQekbwLFYMHH4qhYIQNOd/zR9jU7NNpGWMzslkiQxY2JKUCrvJ8BRnOOScffoOkH5yo2sqMdfzXnWdKsQ6rU1gTSeoRFprVpotsQAH9hVIwV5yTn3I63aIK6'
        'PX+aFdDK4ueQj2rP+8rlitU1b+s2P6lekcQrSZcxjLDceMeAMcZJ8+OqNhVLKbYgdanX2YKwuGSeVaHLp3yPc1uSxWKh7EjqoIZfpx/bXOAE2/u+wx9+pxbU'
        'mD86+dUgNLmg9H0utrsrmUGJa7mKJqgAcSFizNg8KqgZ/Pj3607FNsz16VxFW4Z2jpQXcNhX0e1qzzhNQFuvSicuVXG4KQTjIRgSx9h0S2sMLYGIJ+dxQrre'
        'E3J8UgUrk1B9NpWY/UEasHLzqAREFG12RPcKB58/Vx0UDWQaCW0AilH/AFM0Pb6mvBBHBfjecl0PqOkjZO45wGwuM48Y6J9KXycjH2oX1ot+EYOaqdG0nU+2'
        'qb6rVerq1e/Rjj9KNmWOJsAghRySoIPvklh56UuOtxtBkEGnrSPaX6i5BFK+56dqh3valMqBpIa0SNFHhXOwxyeR9TbiDz4AHRrTBrQEcz/IoF1SLxPWP7rS'
        'J9QF6Ke7TgtCy1mKg0rf21jwdpKY8sQvn7Mep4WPC20TVItOU3kCpj4jJVTuq+aUctN6NCZAzyBpGYlW37R55PGeRyemeGLfSGozJFKcUALrFRsDX3tihb1D'
        'utUnridTWR1hlXLPGExlSPIzkkD+T1y8wVMHnXrKlrni6VNfFmgdP1r0/QAiHoqszptbCyFjj+EJOOnOFIZZnr8+9J8YCrQR0pV8LtZZNMk/pRCA6o86RWOS'
        'YHbGAMfTnnP8fnrfFp4vH0j1rHAv4Do/9T6Vb9ry1tPj1kzQQ345IbkBiU4MzTOEVVPj6doIPSN4FisGDj8VQsEIGnO/5o+xqdmm0jLGZ2SyRIYsbElKBV3k'
        '+AoznHJOPv0HSD85UbWVGOv5rzrOlWIdVqawJpPUIi01q00W2IAD+wqkYK85Jz7kdbtEFdHr/NCuhlcXPIR7Vn/eVyxWqat/WbH9SvSOIVpMuYxlhuPGPAGO'
        'Mk+fHVGwqllNsQOtTr7MFYXDJPKtCsad8h3JbksVigexI6qCGH04/trnACbf3fZcffqdq1IIPzr51SC6XNPe2KZo6HdZtXrUv6pFvpmzAQ+wHDMF8MW4AP4y'
        'Ogu/jHhmN4pi2nhMtE7VJdxt6mjzgpBFJHcqssJfKySI+VUA/t4Ocffpm0fEPI0peHhIO8ip3u2WA6lr04gCQPLOfkWP1ITHkpkftJYc9M2J0oJ6ZpS+RquH'
        'zxU7c061NW0XS09OWSKGGJmRs5kIVNqsPOCefwB00GUMz+ZpVlZlS2O1bdpemmbsTtURzx10hLVGWVt008sO6PeI+Nq/QcAe/PURzF24SO/oc19BbXVZtR5f'
        'bFIe+NC0uXWaV+rJLpy3pp4jptolTAqxRssn8tzn7+2Ot2bj6SrZiM9aFxFtdasDAMiKYdh2km7jsGC2aFJFe8srxmeSQqu3KqeFJ5I//fWb4i3kSdulb4Zt'
        'VyBtvXOpCDU7jsRgz65YSRQbKGNUyp/Qf3fSdxHnBA61zRf9RQz/AI3G/wBjQ/wrvtqk/wA1aSRrEUMUKWQ7KqZBXESjx+kqT75/31viwFwNj8zWODYt4juB'
        '8ik3xouLqkL6pekikrHUlMG+TP0EbFjUDlgedzH3H26NwUhtK9KBx8FNbdameyBd0TTdCnrrCL+pQiq8eP8A21RmzN491yMfx0fiNNxmB2XP9UDhJtqhXdsf'
        '3V32JV0/S5dfnMbRtW1ARPVkXfH6Txbyef3BgG/1jpK+zOE7in+GVUNzsaZW9KTTb2hzxpFqFi1jUmk5kV15c5xxlivv+noIeQw2Ax8+ZopUAqRmc0f8QNU1'
        'GxokV6hRnpRSWINTkjZg7sA4HLkftLcj/XXuHChtDGcEV3imYrrURkGse1/SZu4O56NV5rUkdaZ3xKcyfqJbG0e5BH29uq9txbQkDeol22btxQTtV/Uvtbal'
        'WizMXgYoRndHETlU2+Cd24YPt0gy6QWPw1SRixAFUPa9P5HQrrNq9akNVi30zZgIfYDhmC+GLcAH8ZHSzv4x4Zjem7aeAy0TtUn3G3qaPOCkEUkdyqywl8rJ'
        'Ij5VQD+3g5x9+mbR8Q8jSl4eEg7yKne7ZYDqWvTiAJA8s5+RY/UhMeSmR+0lhz0zYnSgnpmlL5Gq4fPFTtzTrU1bRdLT05ZIoYYmZGzmQhU2qw84J5/AHTQZ'
        'QzP5mlWVmVLY7Vt2l6aZuxO1RHPHXSEtUZZW3TTyw7o94j42r9BwB789RHMXbhI7+hzX0FtdVm1Hl9sUh740LS5dZpX6skunLemniOm2iVMCrFGyyfy3Ofv7'
        'Y63ZuPpKtmIz1oXEW11qwMAyIph2HaSbuOwYLZoUkV7yyvGZ5JCq7cqp4Unkj/8AfWb4i3kSdulb4ZtVyBtvXOpCDU7jsRgz65YSRQbKGNUyp/Qf3fSdxHnB'
        'A61zRf8AUUM/43G/2ND/AArvtqk/zVpJGsRQxQpZDsqpkFcRKPH6SpPvn/fW+LAXA2PzNY4Ni3iO4HyKTfGi4uqQvql6SKSsdSUwb5M/QRsWNQOWB53Mfcfb'
        'o3BSG0r0oHHwU1t1qZ7IF3RNN0KeusIv6lCKrx4/9tUZszePdcjH8dH4jTcZgdlz/VA4SbaoV3bH91d9iVdP0uXX5zG0bVtQET1ZF3x+k8W8nn9wYBv9Y6Sv'
        'szhO4p/hlVDc7GmVvSk029oc8aRahYtY1JpOZFdeXOccZYr7/p6CHkMNgMfPmaKVAKkZnNH/ABA1TUbGiRXqFGelFJYg1OSNmDuwDgcuR+0tyP8AXXuHChtD'
        'GcEV3imYrrURkGse1/SZu4O56NV5rUkdaZ3xKcyfqJbG0e5BH29uq9txbQkDeol22btxQTtV/Vvm2aVaPMxeBihGd0cROVTb4zu3DB9ukGXSC3yapIxYgU/7'
        'QpqKz09pvwK3oGN23yKvj9PkAt9Qx+fbpe6ZM7Gmra+HTuKVd91tP0yPSNMl+Ya68wCuI9yh4wWAOOcnO3j7dEsyxZxsP3oN8KulDvWN6vM+rd63GE7wUb9o'
        'SS2WThYowEYj/Ywf56s2wLdkAjIH5NQLxNy+0bE1RXmraTGttyY44pIpIYYEyyekdxx+BwST7dLLqfHzNOsVTxH5FaZ2vScdq6RCub0caSyPbWQFRJKrMAPf'
        'ktgnOMgDqXdb9Rjtt+KsWRFtBvuZ86nu/LsmqCq0krLKskQaSfkSNuVXfH+Slv0jjpjhkCk9M/P7pXi2LR2qi0LT9NppSjpX1kp2L88RijgaS3xt3yJnjZkZ'
        'KnwegXWZp1DIHpTFlVSNJ3PrQXxa0a7Q1CDTprjKErWpkVGAMbEZQuc7d5B/0D1vhGUqWjmPnlQ+NVgYJ5GpTStdvUe19H1StBNpqUvXrV69Vy0tqwsG1Gd1'
        '4AIJO37D89OXLatcZCZmDnkJqfauMEVwIiR5mv3xNmoa/wBs6RDFDVrU4NPjCx00ZleWNQDMpbklmdic8Eg9e4Ysl1m5z8Fa4oC5ZVeUUm+HZ/qUVTUGkkrR'
        '0fUBRz4kU4Xb/kf3YHROK8MqOdD4PxAMeXvVf8OrFKp3PrFq20sL2oDJDWVyRJOj48Hy+08A+AelOIlraqOXtTvDQLrE8xTTUNWrdt/LRx2ki3U7GyOlGWkr'
        'ncC53DOUIJznxz0LQbvLmN+dFZxaIg8j6Uf8YO660mnV9Bhv1455tGhmglhG5HJcMgZhwMhQB4J9x1zhLTK31Y2Y13jLylPpA7is30fuIN3jNbsyypNf0/ZB'
        '6bbEEhkAZnx+3Gcke/VFk/SgcjUxLn68nmPzWh9kaZqB7hmpaZpU9vUpKzVq0ki7Ugkbks5PBBXLZ9up15lKambEye4qlYVg8IMxjtRvZtNRTamAb8CN6BR3'
        '3yKvgZXyAT9Qx+fbrN0y07E0a2vh0bgUr77rafpkekaZL8w115gFcR7lDxgsAcc5OdvH263ZlizjYfvQb4VdKHesb1eZ9W71uMJ3go37QklssnCxRgIxH+xg'
        '/wA9WbYFuyARkD8moF4m5faNiaorzVtJjW25MccUkUkMMCZZPSO44/A4JJ9ull1Pj5mnWKp4j8itM7XpOO1dIhXN6ONJZHtrICoklVmAHvyWwTnGQB1Lut+o'
        'x22/FWLIi2g33M+dT3fl2TVBVaSVllWSINJPyJG3Krvj/JS36Rx0xwyBSemfn90rxbFo7VRaFp+m00pR0r6yU7F+eIxRwNJb4275EzxsyMlT4PQLrM06hkD0'
        'piyqpGk7n1oL4taNdoahBp01xlCVrUyKjAGNiMoXOdu8g/6B63wjKVLRzHzyofGqwME8jUppWu3qPa+j6pWgm01KXr1q9eq5aW1YWDajO68AEEnb9h+enLlt'
        'WuMhMzBzyE1PtXGCK4ERI8zX74mzUNf7Z0iGKGrWpwafGFjpozK8sagGZS3JLM7E54JB69wxZLrNzn4K1xQFyyq8opN8Oz/UoqmoNJJWjo+oCjnxIpwu3/I/'
        'uwOicV4ZUc6HwfiAY8veq/4dWKVTufWLVtpYXtQGSGsrkiSdHx4Pl9p4B8A9KcRLW1UcvaneGgXWJ5immoatW7b+WjjtJFup2NkdKMtJXO4FzuGcoQTnPjno'
        'Wg3eXMb86Kzi0RB5H0o/4wd11pNOr6DDfrxzzaNDNBLCNyOS4ZAzDgZCgDwT7jrnCWmVvqxsxrvGXlKfSB3FZvo/cQbvGa3ZllSa/p+yD022IJDIAzPj9uM5'
        'I9+qLJ+lA5GpiXP15PMfmtB7M0y+denpabpU9vUZKrVq0ki7Ugkbks5PBBXLZ9up95lKamOJk9xVKwrByFGYx2p5W0uSnqc02n03p6hlFgk+nZEpAG4Ecvx+'
        '08jJ6W1yIYyPn2pwodRKjNZt8VLF7R/iRPHFetahaiowx12c4Nd5cmVgP24Hj7Z6p8KFexLCBOe8bVG4svb4jBkwPSd6zqjqDIbabi0MV1lAbnKsux1z+cZx'
        '7nqkw27ipqtuOhrQptL0tK9WOSV1dq00MTSLlHwNu0sPDE/8+Op2tySe4qq1u3AHaq3tLXVh7UWkIoTXiSrf3qcNuWLa8J9tuRu/B6RuofqTzkj+6oWmAtgD'
        'oKD1Wana7V1N4kV2qxMrUVJEgZpojvkzzjbkZXx/votssHWfv6UG6FNpivL+aoexJIVjhuSTRs09hw7OuRXViMKo/wAPz7+T0teBkrHKmbGmA1L/AIimGx3N'
        'JpFkS1kualArJIoKuhD7lJ/YM7cnwemOHBCa1zAPzvSnEsC/025kfaoX5lLOla8KVmeurX7UtZKxCJmIJG0xGMHgtwOeOnDhkLCcCZ78qTWNDhcZP4qj7jsU'
        '6vY8PqSWEnKKpaXEqJ6Y3A5wNo8HHg7se3SltWN4/N6dulRYHlSb4WRNpmhadBcWHUB6VqzUkmG1Vsh/rA/JRj5+2B0bjCHdiMbA+VL8CulFDZ3I86JTtSxq'
        'PeEXydxpY4IJr8ksb8woOA+cfTliBzzxz56yLoFvI6CtG0Td8J6mqr4L1e4O5KeoanLcTUbUVswTzTIiqiqOEVQPpDe5PB9+g8WbaEIogRReD1updmkzVRpE'
        'fbum6TPp1qoltL0s8b0xAm0lSWd3YjgAHC48Hx0u5uMdYORFNILaroIkGa/n7R6Q0Tv0ac9htRjr0iq2GXHowiZXxt92wdhH3BPnq67a7OoCJP5j4agIot8Q'
        'EJmAftNa38K2+V1vuqXTrq6aKmmT72AZzIszemyhyf0Y5yBn6uPHUriZNtQwmSPxVjhYFxo5D3ppU0l6OoyS6dSelqA9NIH+nZEhAG4Ecvx+08jJ6W1yIYyP'
        'n2prQZlRms3+Kli9o/xInjivWtQtRUYY67OcGu8uTKwH7cDx9s9U+FCvYlhAnPeNqj8WXt8RgyYHpO9Z1R1BkNtNxaGK6ygNzlWXY65/OM49z1SYbdxU1W3H'
        'Q1oU2l6WlerHJK6u1aaGJpFyj4G3aWHhif8Anx1O1uST3FVWt24A7VW9pa6sPai0hFCa8SVb+9ThtyxbXhPttyN34PSN1D9Seckf3VC0wFsAdBQeqzU7Xaup'
        'vEiu1WJlaipIkDNNEd8mecbcjK+P99Ftlg6z9/Sg3QptMV5fzVD2JJCscNySaNmnsOHZ1yK6sRhVH+H59/J6WvAyVjlTNjTAal/xFMNjuaTSLIlrJc1KBWSR'
        'QVdCH3KT+wZ25Pg9McOCE1rmAfnelOJYF/ptzI+1QvzKWdK14UrM9dWv2payViETMQSNpiMYPBbgc8dOHDIWE4Ez35UmsaHC4yfxVH3HYp1ex4fUksJOUVS0'
        'uJUT0xuBzgbR4OPB3Y9ulLasbx+b07dKiwPKk3wsibTNC06C4sOoD0rVmpJMNqrZD/WB+SjHz9sDo3GEO7EY2B8qX4FdKKGzuR50SnaljUe8Ivk7jSxwQTX5'
        'JY35hQcB84+nLEDnnjnz1kXQLeR0FaNom74T1NVXwXq9wdyU9Q1OW4mo2orZgnmmRFVFUcIqgfSG9yeD79B4s20IRRAii8HrdS7NJmqjSI+3dN0mfTrVRLaX'
        'pZ43piBNpKks7uxHAAOFx4PjpdzcY6wciKaQW1XQRIM1/P2j0honfo057DajHXpFVsMuPRhEyvjb7tg7CPuCfPV1212dQESfzHw1ARRb4gITMA/aa1r4WH5f'
        'Wu65NOurpoq6ZPvIDOZFmb02UOT+jHOQM/Vx46lcTJtrqEyR+KscLH1GjkPem82uz6lRZ4GsQMqmKOARgQzRu2VcsOUkOG+r2x46AECnP9iPcUw1wkYrKe4V'
        't2viVqUEERa41dXUM28sREDnHkjnBHnB6qW4WwCdv7qRcluIYDeP2qQEFea7ckRMzI/zKQB8As6Ak/6w2PtjpuSAB6UpCkmPP71oWvUotLrSSQN66NOjrIWP'
        'pozqCwyPIzjH2JPU+22swapXl0LI2p/SoppbVYWlir/M1Hrz0HGJFCV2mSUP+lWLLjB5P++l/wDMMd4O/rEUxm2VA5j9pprd0uHV+0tW1K6j1JmREjrwkPIc'
        'hG2bhyQxOPwVPQgdF1VXPz9qKVFyyXYUu0q2trQaVqrLGGjMu2H1VJidQA6SbiDt2jGPGR/HRGWHIPzy70NGBthlNAfEXUNM0vuw3JJGdFiizsYyeqzKCGZg'
        'cBWY8E/bnpnh1Y29IpPimAvFj2qbt6dKnZNX1InWdZ7rcL/blKhWDhvBVicf89bDfqn0rJWLI9a793K1Ptd3vRmaJYFghZSZArFc4JHBXGR+MdZteK74a1d8'
        'NmXGIrv8LNAWTTK170g8cirZBmZt9ePIOEA4yQCxJ9s9Z4x4cr8Nb4K2NAameu6O0Pd1DEyy/wBRpNLVSIEI4jm+pXx+wqQcnkkdBtsDaOP8Tn7e9GvLpvAT'
        '/kMelNPggY6cut3GieKXTL8+/DEepCQGKOPcj2z/APnrXFidI6gVjhDAY9Castdv07vcGi1a1LcI3ZoIwx2OXdXmkc/44wP5HSighGJPzlTxILKoFY538PX7'
        '3oPFZFfXN9ynb+XX9qy7k4+zAkY89VbPhtMCPDgj7VGv+K6pB8WQfvVV8PakbavqUM6RqzxRJHHnAfH1OU/+IGcfjpS+fCCPnnTvDCGaapJden1SgZIGsQMq'
        'mKOARgQzRu2Vct5SQ4b6vbHjpYIFOf7Ee4ptrhYYrKu4Vt2viVqUEERa41dXUM28sREDnHkjnBHnB6qW4WwCdv7qRcluIYDeP2qQEFea7ckRMzI/zKQB8As6'
        'Ak/6w2PtjpuSAB6UpCkmPP71oWvUotLrSSQN66NOjrIWPpozqCwyPIzjH2JPU+22swapXl0LI2p/SoppbVYWlir/ADNR689BxiRQldpklD/pViy4weT/AL6X'
        '/wAwx3g7+sRTGbZUDmP2mmt3S4dX7S1bUrqPUmZESOvCQ8hyEbZuHJDE4/BU9CB0XVVc/P2opUXLJdhS7Sra2tBpWqssYaMy7YfVUmJ1ADpJuIO3aMY8ZH8d'
        'EZYcg/PLvQ0YG2GU0B8RdQ0zS+7DckkZ0WKLOxjJ6rMoIZmBwFZjwT9uemeHVjb0ik+KYC8WPapu3p0qdk1fUidZ1nutwv8AblKhWDhvBVicf89bDfqn0rJW'
        'LI9a793K1Ptd3vRmaJYFghZSZArFc4JHBXGR+MdZteK74a1d8NmXGIrv8LNAWTTK170g8cirZBmZt9ePIOEA4yQCxJ9s9Z4x4cr8Nb4K2NAameu6O0Pd1DEy'
        'y/1Gk0tVIgQjiOb6lfH7CpByeSR0G2wNo4/xOft70a8um8BP+Qx6U0+CBjpy63caJ4pdMvz78MR6kJAYo49yPbP/AOetcWJ0jqBWOEMBj0Jqy12/Tu9waLVr'
        'UtwjdmgjDHY5d1eaRz/jjA/kdKKCEYk/OVPEgsqgVjnfw9fveg8VkV9c33Kdv5df2rLuTj7MCRjz1Vs+G0wI8OCPtUa/4rqkHxZB+9VPw+qx/wBW1OKeONWe'
        'GNIo84D4+pyn/wAQM4/HSl8+EEfPOneHEM00GO5bWh6zpui6vD8hDPZEIewuXirk71Lsv6tmNp9wOifTFwM6ZMfnbHnWPqm0y27mM/ikugavQ1rv2/rMbsr3'
        'NSeetMU52t/bVvwCobj7HPRLqsloW+gzQbLI943OpxU9q8dWj3k12Koy6fZSOVEkYO4kVjE5JHGN4DY+zdMpLWtM5H/aVuQt7VGDn9qse5EZKENGStFItqRY'
        '2eP6DB9QO9QDgqc+/SFojUWB2qleHhCxvTyzp6Tdo0XgkRgncDJarzHczLEhAJbyE24Gfsesq3jM81x6/vXXWVEcj7UH3ddsy0qOmR1X0wvdgisajWP9wwww'
        'tMu6P2lJY8jggddtRJcmcHHc436Vy5q0hAIk79hmhaWnQ0+2qVdFX0FgeyJ1jL/Nu7fWefqweM/x9uuMSzknfbyrSKEQAec167i00vpduKtpXzMLQxRPKGAa'
        'Z2I+oD24J4+w467beCCWjes3UkGFnahe+bNTtvsT5GRf6cummWy1Wd2zYZsKpUE4J+4HjHW7Aa7e1bzA8qFxLLZsado/NT/fuveto8Gl6dO0kc1fcZUdXCmS'
        'HcyhRwM5HPnGem7CQ5dxz9jSnEXAUFu2cEe4p/8ACvULtLtyKjNGthJ68emyw1oiWzGPpffz9R3YI+wUdK8Wqu+oedNcEzJbAPlR902dA1EvLNSmghqRwViU'
        'JlEbSfu9lLHGfY46EsOsAGSc9JpltSPJjG3WvPYGs2tE1u/otu1NNp12xbn+bDxrFJJEBuEhcjwORg88DrV9BcQXFGRGM7HpQbD/AE2KMcEnNUXbqS6jqdXX'
        'F1NQsMZhgrSD6DVDkuVxyWOd5+2B7dBcwptkf9plASwuA+nap74pVYnR79RojFp+seqJQP7hWdQctnBAz4z5yei8MxnSeY9qX4pBGtf9W96N7Q1Gc9t9yX4o'
        'IL2rW7i10IcLLHWVQNsK+QXJ8gcjAPXboAZV2EfnvXbJJRn3Mx6UAvclrQdY0zRNXh+QhmsiEPYX64a+d6l2X9WzG0+4HWvpi4C6ZMfnbHn+az9U2mW3cxJ/'
        'FJtA1ehrXft/WY3ZXuak89aYpztb+2rfgFQ3H2OeiXVZLQt9BmhWWR7xudTip7V46tHvJrsVRl0+ykcqJIwdxIrGJySOMbwGx9m6ZSWtaZyP+0rchb2qMHP7'
        'VY9yIyUIaMlaKRbUixs8f0GD6gd6gHBU59+kLRGosDtVK8PCFjenlnT0m7RovBIjBO4GS1XmO5mWJCAS3kJtwM/Y9ZVvGZ5rj1/euusqI5H2oPu67ZlpUdMj'
        'qvphe7BFY1Gsf7hhhhaZd0ftKSx5HBA67aiS5M4OO5xv0rlzVpCARJ37DNC0tOhp9tUq6KvoLA9kTrGX+bd2+s8/Vg8Z/j7dcYlnJO+3lWkUIgA85r13Fppf'
        'S7cVbSvmYWhiieUMA0zsR9QHtwTx9hx1228EEtG9ZupIMLO1C982anbfYnyMi/05dNMtlqs7tmwzYVSoJwT9wPGOt2A129q3mB5ULiWWzY07R+an+/de9bR4'
        'NL06dpI5q+4yo6uFMkO5lCjgZyOfOM9N2Ehy7jn7GlOIuAoLds4I9xT/AOFeoXaXbkVGaNbCT149NlhrREtmMfS+/n6juwR9go6V4tVd9Q86a4JmS2AfKj7p'
        's6BqJeWalNBDUjgrEoTKI2k/d7KWOM+xx0JYdYAMk56TTLakeTGNuteewNZtaJrd/RbdqabTrti3P82HjWKSSIDcJC5HgcjB54HWr6C4guKMiMZ2PSg2H+mx'
        'Rjgk5qi7dSXUdTq64upqFhjMMFaQfQaoclyuOSxzvP2wPboLmFNsj/tMoCWFwH07VPfFKrE6PfqNEYtP1j1RKB/cKzqDls4IGfGfOT0XhmM6TzHtS/FII1r/'
        'AKt70Z2jqE7dtdy3ooIL2r27i10IcLLHXVQNsK+QXY+QORgHrt0AMq7CPz3rtkkoz7mY9KB771Ca3qVWNr9iSW7CaUdq2iA7MFpRHj/IALk+cnrtlQFJjbOP'
        'xPlWL58YE74zSjTtLXTktX4b0hnjidhX2gRr+1QBjnGc7hwMdGZ9UKR60NbemWDZrn3FHT0G7o8CSgT15Z6zSOAeXRHzz+r6wSSeB4PXbeq4rGMGD9qzcAts'
        'nqK56pYwaagTRNXniaOTfG72WL4LFAeDj2/31xBknqD6Vu40wOhHrV18PUi0560ur6hBC9rU50nQyf348E/VjwQQQufHv0peGowowAPKmrMqviO5Nd/iDBFp'
        'h1JqS270DoskM07iQwsgCu27yyhTxnzn7detEEicf3Xb2pVJoLtK2fnIa0StcElVxXryMDskK8bG+xyWK+3/AB166IUnbOa9ZMmOooPWO4dO0iKSubVhpZdQ'
        'oQWI1TC1hESGfd7nAGAB9+upaZyDHJvWa495EnuR6RUf8bKg1rQNLjShK0jKEhkIBMm9y0jqft449ieneB8Dkz85Uh/+lDoBFTPa+iudGLPVamzVWhhkP0tI'
        'cgkY9yFxz7Zx0e7c8e85pezbm3kRitD+F95NJoIsjmlCncTRmy/C52ABSfbB/wCekeJGpsf+af4RtC5/9Uf8Uq82m92w+usNinHCWkoqxVJIYjnYvvyxB3fk'
        '9Y4Zg1vG/XuaLxUrc7b/AGrhe7LM3b8VO3DEyLixPHJHuQM7ZY4PjZuAz7464t+LhZT8/utNYm2AfOn3Y87Vuye2dCkrwy9zV9RsyvKv/wBrTV+DJjyG4AT2'
        'HWbwBuvcH+JA9T8516zqW0ls/wCQJ+1JPiRBa/oeqfO1w9rcacsVJeIVST1Fl58R4bg+3PW+HgOuk98+3nQ+JJNpiw7Y96WdgV61nS53vQRwzTzbquoPL6Ji'
        '2jwsnkYPIHv0S+SGGnluKFwsFSWHkaZ996jPd1KqjX7Mst2E0o7dxEB2YLSiPH+QAXJ85PWLKgKcbZx+J8q3xDHWATvjNJ9O0tdOS1fhvSGeOJ2FfaBGv7VA'
        'GOcZzuHAx0Zn1QpHrQ1t6ZYNmufcUdPQbujwJKBPXlnrNI4B5dEfPP6vrBJJ4Hg9dt6risYwYP2rNwC2yeornqljBpqBNE1eeJo5N8bvZYvgsUB4OPb/AH1x'
        'BknqD6Vu40wOhHrV18PUi0560ur6hBC9rU50nQyf348E/VjwQQQufHv0peGowowAPKmrMqviO5Nd/iDBFph1JqS270DoskM07iQwsgCu27yyhTxnzn7detEE'
        'icf3Xb2pVJoLtK2fnIa0StcElVxXryMDskK8bG+xyWK+3/HXrohSds5r1kyY6ig9Y7h07SIpK5tWGll1ChBYjVMLWERIZ93ucAYAH366lpnIMcm9Zrj3kSe5'
        'HpFR/wAbKg1rQNLjShK0jKEhkIBMm9y0jqft449ieneB8Dkz85Uh/wDpQ6ARUz2vornRiz1Wps1VoYZD9LSHIJGPchcc+2cdHu3PHvOaXs25t5EYrQ/hfeTS'
        'aCLI5pQp3E0ZsvwudgAUn2wf+ekeJGpsf+af4RtC5/8AVH/FKvNpvdsPrrDYpxwlpKKsVSSGI52L78sQd35PWOGYNbxv17mi8VK3O2/2rhe7LM3b8VO3DEyL'
        'ixPHJHuQM7ZY4PjZuAz7464t+LhZT8/utNYm2AfOn3Y87Vuye2dCkrwy9zV9RsyvKv8A9rTV+DJjyG4AT2HWbwBuvcH+JA9T8516zqW0ls/5An7Uk+JEFr+h'
        '6p87XD2txpyxUl4hVJPUWXnxHhuD7c9b4eA66T3z7edD4kk2mLDtj3pb8P4K1jTJ5L1eOGaebfU1B5PSaPaP0rJ5GD4Hv0S/IYBTtuKHwsFSWHka/9k='
    ),
}

def _glass_tile():
    """A 1 m window pane, made here (no picture needed): pale blue-green glass, a dark frame rim with a bright inner edge,
    soft diagonal sheen bands and a faint grain. Every term repeats once per tile, so panes tile seamlessly."""
    n = TILE_SIZE
    y, x = np.mgrid[0:n, 0:n].astype(np.float64) / n
    rng = np.random.RandomState(11)
    col = np.empty((n, n, 3))
    col[...] = (0.58, 0.80, 0.88)
    col *= (0.93 + 0.07 * np.sin((x + y) * 2.0 * np.pi))[..., None]         # a slow tint wave across the pane
    for c, w, a in ((0.22, 0.030, 0.34), (0.31, 0.010, 0.26), (0.70, 0.060, 0.17), (0.84, 0.014, 0.20)):
        d = ((x - y) - c + 0.5) % 1.0 - 0.5                                    # distance to a diagonal line, wrapping
        col += (np.exp(-(d / w) ** 2) * a)[..., None]
    g = rng.rand(n, n)
    g = (g + np.roll(g, 1, 0) + np.roll(g, 1, 1) + np.roll(np.roll(g, 1, 0), 1, 1)) * 0.25
    col *= (0.975 + 0.05 * g)[..., None]
    e = np.minimum(np.minimum(x, 1.0 - x), np.minimum(y, 1.0 - y))             # distance to the tile's edge
    col *= (1.0 - 0.55 * np.clip(1.0 - e / 0.022, 0.0, 1.0) ** 0.7)[..., None]  # dark frame rim
    col += (np.exp(-((e - 0.036) / 0.007) ** 2) * 0.22)[..., None]              # bright bevel just inside it
    return np.clip(col * 255.0, 0, 255).astype(np.uint8)

def _decode_tiles():
    import base64, io
    out = []
    for n in ('dirt', 'brick', 'planks', 'steel', 'concrete', 'wood', 'glass'):
        if n == 'glass':
            out.append(_glass_tile())
            continue
        raw = base64.b64decode(''.join(_TILE_PNG[n]))
        surf = pygame.image.load(io.BytesIO(raw), n + '.jpg')
        assert surf.get_size() == (TILE_SIZE, TILE_SIZE)
        out.append(np.frombuffer(pygame.image.tostring(surf, 'RGB'), np.uint8).reshape(TILE_SIZE, TILE_SIZE, 3).copy())
    return np.stack(out)

TILE_RGB = _decode_tiles()                         # (layers, 256, 256, 3) uint8
_S_TEXLAYER = np.full(256, -1.0, np.float32)       # block id -> texture layer, -1 = plain colour
for _k, _b in enumerate(TILE_MATS):
    _S_TEXLAYER[_b] = _k
    _S_RGB[_b] = TILE_RGB[_k].reshape(-1, 3).mean(axis=0) / 255.0    # a tile's average colour: debris and chips match it

_TILE_TEX = [0]

def tile_texture():
    """The GL texture array holding every material tile (made on first use, needs a GL context)."""
    if not _TILE_TEX[0]:
        t = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D_ARRAY, t)
        data = np.ascontiguousarray(TILE_RGB)
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        gl.glTexImage3D(gl.GL_TEXTURE_2D_ARRAY, 0, gl.GL_RGB8, TILE_SIZE, TILE_SIZE, len(data), 0,
                        gl.GL_RGB, gl.GL_UNSIGNED_BYTE, data)
        gl.glGenerateMipmap(gl.GL_TEXTURE_2D_ARRAY)
        gl.glTexParameteri(gl.GL_TEXTURE_2D_ARRAY, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR_MIPMAP_LINEAR)
        gl.glTexParameteri(gl.GL_TEXTURE_2D_ARRAY, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
        gl.glTexParameteri(gl.GL_TEXTURE_2D_ARRAY, gl.GL_TEXTURE_WRAP_S, gl.GL_REPEAT)
        gl.glTexParameteri(gl.GL_TEXTURE_2D_ARRAY, gl.GL_TEXTURE_WRAP_T, gl.GL_REPEAT)
        try:
            aniso = gl.glGetFloatv(0x84FF)                                 # GL_MAX_TEXTURE_MAX_ANISOTROPY
            gl.glTexParameterf(gl.GL_TEXTURE_2D_ARRAY, 0x84FE, min(8.0, float(aniso)))
        except Exception:
            pass
        _TILE_TEX[0] = t
    return _TILE_TEX[0]

# Face order everywhere: -x, +x, -y, +y, -z, +z.
_FACE_DIRS = np.array([[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1]], np.int64)


def _q_mul(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([aw * bw - ax * bx - ay * by - az * bz,
                     aw * bx + ax * bw + ay * bz - az * by,
                     aw * by - ax * bz + ay * bw + az * bx,
                     aw * bz + ax * by - ay * bx + az * bw])


def _q_mat(q):
    w, x, y, z = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def _cross(a, b):
    """Row-wise cross product, faster than np.cross for the small arrays the solver uses."""
    return np.stack([a[..., 1] * b[..., 2] - a[..., 2] * b[..., 1],
                     a[..., 2] * b[..., 0] - a[..., 0] * b[..., 2],
                     a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]], axis=-1)


def _label_cells_xp(xp, alive, bonds):
    """Connected groups of live cells. Cells share a label when a chain of bonds joins them; empty cells
    get a label larger than any real one."""
    big = alive.size + 1
    lab = xp.where(alive, xp.arange(alive.size).reshape(alive.shape), big)
    for _ in range(alive.size + 1):
        old = lab.copy()
        for a in range(3):
            lo = [slice(None)] * 3
            hi = [slice(None)] * 3
            lo[a], hi[a] = slice(0, -1), slice(1, None)
            lo, hi = tuple(lo), tuple(hi)
            m = xp.minimum(lab[lo], lab[hi])
            b = bonds[a]
            lab[lo] = xp.where(b, m, lab[lo])
            lab[hi] = xp.where(b, m, lab[hi])
        for a in range(2, -1, -1):                      # sweep back, so a label crosses the grid in few passes
            lo = [slice(None)] * 3
            hi = [slice(None)] * 3
            lo[a], hi[a] = slice(0, -1), slice(1, None)
            lo, hi = tuple(lo), tuple(hi)
            m = xp.minimum(lab[lo], lab[hi])
            b = bonds[a]
            lab[hi] = xp.where(b, m, lab[hi])
            lab[lo] = xp.where(b, m, lab[lo])
        if bool(xp.array_equal(old, lab)):
            break
    return lab


def _label_scipy(alive, bonds, cut=None):
    """Connected groups with scipy. While every neighbouring pair of live cells is still bonded, the groups are
    plain flood-filled blobs (ndimage.label); with `cut` = (axis, plane) the two sides of that plane are labelled
    separately. Once some bonds have broken, the bonds themselves are handed to a graph labeller. Empty cells get
    a label larger than any real one, the same as the numpy version."""
    big = alive.size + 1
    full = True
    for a in range(3):
        lo = [slice(None)] * 3
        hi = [slice(None)] * 3
        lo[a], hi[a] = slice(0, -1), slice(1, None)
        if not np.array_equal(bonds[a], alive[tuple(lo)] & alive[tuple(hi)]):
            full = False
            break
    if full:
        if cut is None:
            lab, _ = _ndi.label(alive)
        else:
            a, p = cut
            first = tuple(slice(0, p + 1) if k == a else slice(None) for k in range(3))
            second = tuple(slice(p + 1, None) if k == a else slice(None) for k in range(3))
            l1, n1 = _ndi.label(alive[first])
            l2, _ = _ndi.label(alive[second])
            lab = np.concatenate([l1, np.where(l2 > 0, l2 + n1, 0)], axis=a)
        return np.where(lab > 0, lab, big).astype(np.int64)
    idx = np.arange(alive.size, dtype=np.int64).reshape(alive.shape)
    us, vs = [], []
    for a in range(3):
        lo = [slice(None)] * 3
        hi = [slice(None)] * 3
        lo[a], hi[a] = slice(0, -1), slice(1, None)
        m = bonds[a]
        if cut is not None and cut[0] == a:
            m = m.copy()
            m[tuple(cut[1] if k == a else slice(None) for k in range(3))] = False
        us.append(idx[tuple(lo)][m])
        vs.append(idx[tuple(hi)][m])
    u, v = np.concatenate(us), np.concatenate(vs)
    g = _coo_matrix((np.ones(len(u), np.int8), (u, v)), shape=(alive.size, alive.size)).tocsr()
    _, comp = _connected_components(g, directed=False)
    lab = comp.reshape(alive.shape).astype(np.int64)
    lab[~alive] = big
    return lab


def _label_cells(alive, bonds, cut=None):
    """Connected groups of live cells (see _label_cells_xp). `cut` = (axis, plane) leaves out the bonds between
    that plane's two layers. Uses scipy when it is installed. Otherwise large grids are labelled on the GPU when
    it is available and switched on (any GPU error turns it off), and the CPU does the rest."""
    global GPU_OK
    if HAS_SCIPY:
        try:
            return _label_scipy(alive, bonds, cut)
        except Exception as err:
            print(f"scipy labelling failed ({type(err).__name__}: {err}); using the slow path")
    if cut is not None:
        bonds = [b.copy() for b in bonds]
        bonds[cut[0]][tuple(cut[1] if k == cut[0] else slice(None) for k in range(3))] = False
    if GFX['physics_device'] == 'gpu' and GPU_OK and alive.size >= GPU_MIN_CELLS:
        try:
            lab = _label_cells_xp(cp, cp.asarray(alive), [cp.asarray(b) for b in bonds])
            return cp.asnumpy(lab)
        except Exception as err:
            GPU_OK = False
            print(f"GPU physics failed ({type(err).__name__}: {err}); continuing on the CPU")
    return _label_cells_xp(np, alive, bonds)


def _group_mass_com(cell_mass, grp, cs):
    """Mass and centre of mass (in the grid's own frame) of the cells selected by the boolean mask `grp`,
    from per-axis profiles of the grid instead of listing every cell."""
    w = np.where(grp, cell_mass, 0.0)
    mass = float(w.sum())
    if mass <= 0.0:
        return 0.0, None
    com = np.empty(3)
    for k in range(3):
        other = tuple(i for i in range(3) if i != k)
        profile = w.sum(axis=other)
        com[k] = float((profile * (np.arange(w.shape[k]) + 0.5)).sum()) * cs / mass
    return mass, com


class GridObject:
    """Cells on a regular grid, in a frame that can be moved and rotated. A structure's frame stays put;
    a rigid body's frame is its centre of mass, turned by its rotation matrix. Local coordinates of a
    cell corner are  cs * grid_index + corner."""

    def __init__(self, mat, cdmg, tint, cs):
        mat = np.asarray(mat, np.int16)
        self.mat = np.ascontiguousarray(np.where(mat == STONE, DIRT, mat))
        self.cdmg = np.ascontiguousarray(cdmg, np.float32)
        self.tint = np.ascontiguousarray(tint, np.float32)
        self.cs = float(cs)
        self.stress = np.zeros(self.mat.shape, np.float32)   # stress / strength per cell from the last support pass (1 = about to break)
        self.idmg = np.zeros(self.mat.shape, np.float32)     # impact damage per cell (1 = its bonds let go), see _apply_impacts
        self.stress_ver = 0
        self.frame_pos = np.zeros(3)
        self.R = np.eye(3)
        self.corner = np.zeros(3)
        self.mesh_ver = 0
        self._mesh_cache = None
        self._bricks = None
        self._brick_dirty = set()
        self._aabb = None
        self._geometry()

    # ---- geometry, rebuilt after every change to the cells -------------------------------------------
    def _geometry(self, box=None):
        """Rebuild the exposed-face flags, cell masses and bounds. With `box` = (lo, hi), the cells in [lo, hi) are the only ones
        that changed, so only that box (plus a one-cell margin, where a neighbour's faces change) is redone."""
        inc = (box is not None and getattr(self, 'expo', None) is not None and getattr(self, 'alive', None) is not None
               and self.alive.shape == self.mat.shape and self.expo.shape[:3] == self.mat.shape)
        if not inc:
            self.alive = self.mat > 0
            self._live = int(self.alive.sum())
        n = self.alive.shape
        if inc:
            Ub = tuple(slice(max(int(box[0][k]), 0), min(int(box[1][k]), n[k])) for k in range(3))
            before = int(self.alive[Ub].sum())
            self.alive[Ub] = self.mat[Ub] > 0                      # only the changed cells; the rest of `alive` stands
            self._live += int(self.alive[Ub].sum()) - before
            lo = [max(int(box[0][k]) - 1, 0) for k in range(3)]
            hi = [min(int(box[1][k]) + 1, n[k]) for k in range(3)]
            U = tuple(slice(lo[k], hi[k]) for k in range(3))
            ext = tuple(hi[k] - lo[k] for k in range(3))
            lp = np.zeros(tuple(e + 2 for e in ext), bool)       # the box with one cell of neighbours round it
            src, dst = [], []
            for k in range(3):
                a0, a1 = lo[k] - 1, hi[k] + 1
                s0, s1 = max(a0, 0), min(a1, n[k])
                src.append(slice(s0, s1))
                dst.append(slice(s0 - a0, s1 - a0))
            lp[tuple(dst)] = self.alive[tuple(src)]
            au = self.alive[U]
            for f, (dx, dy, dz) in enumerate(_FACE_DIRS):
                nb = lp[1 + dx:1 + dx + ext[0], 1 + dy:1 + dy + ext[1], 1 + dz:1 + dz + ext[2]]
                self.expo[U + (f,)] = au & ~nb
            self.cell_mass[U] = np.where(au, _S_RHO[self.mat[U]] * self.cs ** 3, 0.0)
            if self._bricks is not None:                            # only the bricks this box touches need a new mesh
                B = MESH_BRICK
                for bx in range(lo[0] // B, (hi[0] - 1) // B + 1):
                    for by in range(lo[1] // B, (hi[1] - 1) // B + 1):
                        for bz in range(lo[2] // B, (hi[2] - 1) // B + 1):
                            self._brick_dirty.add((bx, by, bz))
        else:
            nx, ny, nz = n
            pad = np.pad(self.alive, 1)
            expo = np.zeros((nx, ny, nz, 6), bool)
            for f, (dx, dy, dz) in enumerate(_FACE_DIRS):
                nb = pad[1 + dx:1 + dx + nx, 1 + dy:1 + dy + ny, 1 + dz:1 + dz + nz]
                expo[..., f] = self.alive & ~nb
            self.expo = expo
            self.cell_mass = np.where(self.alive, _S_RHO[self.mat] * self.cs ** 3, 0.0)
            self._bricks = None                                     # everything changed: the mesh is rebuilt from scratch
            self._brick_dirty = set()
        al = self.alive
        if inc and getattr(self, 'cell_lo', None) is not None:
            # Cells were only removed, so the bounds can only shrink: step each face inwards while its layer is empty.
            lo_, hi_ = [int(v) for v in self.cell_lo], [int(v) for v in self.cell_hi]
            for ax in range(3):
                while lo_[ax] < hi_[ax] and not al[tuple(lo_[ax] if k == ax else slice(None) for k in range(3))].any():
                    lo_[ax] += 1
                while hi_[ax] > lo_[ax] and not al[tuple(hi_[ax] - 1 if k == ax else slice(None) for k in range(3))].any():
                    hi_[ax] -= 1
            if all(lo_[k] < hi_[k] for k in range(3)):
                self.cell_lo, self.cell_hi = np.array(lo_, np.int64), np.array(hi_, np.int64)
            else:
                self.cell_lo = self.cell_hi = np.zeros(3, np.int64)
        elif al.any():                                      # the live cells' bounds, from per-axis projections (no full-grid argwhere)
            lo_, hi_ = [], []
            for ax in range(3):
                nzv = np.nonzero(al.any(axis=tuple(a for a in range(3) if a != ax)))[0]
                lo_.append(int(nzv[0]))
                hi_.append(int(nzv[-1]) + 1)
            self.cell_lo, self.cell_hi = np.array(lo_, np.int64), np.array(hi_, np.int64)
        else:
            self.cell_lo = self.cell_hi = np.zeros(3, np.int64)
        self._surf = None                                   # the surface points are rebuilt on first use (see _build_surf)
        self.mesh_ver += 1
        self._mesh_cache = None
        self._aabb = None

    def _build_surf(self):
        """Surface sample points (cell corners and face centres), their normals and which are corners. Only loose
        bodies colliding with this object need them, so they are built when first asked for, not on every cut."""
        pts, nrm = [], []
        for f in range(6):
            idx = np.argwhere(self.expo[..., f])
            if not len(idx):
                continue
            ax, sg = f // 2, (1 if f % 2 else -1)
            u, v = (ax + 1) % 3, (ax + 2) % 3
            base = idx * 2 + 1
            base[:, ax] = idx[:, ax] * 2 + (2 if sg > 0 else 0)
            for du, dv in ((0, 0), (-1, -1), (-1, 1), (1, -1), (1, 1)):
                p = base.copy()
                p[:, u] += du
                p[:, v] += dv
                pts.append(p)
                n = np.zeros((len(p), 3))
                n[:, ax] = sg
                nrm.append(n)
        if pts:
            P = np.concatenate(pts)
            N = np.concatenate(nrm)
            M = 1 << 14                                       # pack each point into one integer: a 1-D unique is far
            key = (P[:, 0] * M + P[:, 1]) * M + P[:, 2]        # faster than unique(axis=0) on a big grid
            ukey, inv = np.unique(key, return_inverse=True)
            inv = inv.reshape(-1)
            uniq = np.stack([ukey // (M * M), (ukey // M) % M, ukey % M], axis=1)
            sumn = np.stack([np.bincount(inv, weights=N[:, k], minlength=len(uniq)) for k in range(3)], axis=1)
            ln = np.linalg.norm(sumn, axis=1, keepdims=True)
            g = uniq / 2.0                          # grid units
            n_ = np.where(ln > 1e-9, sumn / np.maximum(ln, 1e-9), 0.0)
            c_ = (uniq % 2 == 0).all(axis=1)    # cell corners; the rest are face centres
            self._surf = (g, n_, c_)
        else:
            self._surf = (np.zeros((0, 3)), np.zeros((0, 3)), np.zeros(0, bool))

    @property
    def live_count(self):
        """Number of live cells, kept up to date by _geometry (a full count of a big grid costs tens of milliseconds)."""
        return self._live


    @property
    def surf_g(self):
        if self._surf is None:
            self._build_surf()
        return self._surf[0]

    @property
    def surf_n(self):
        if self._surf is None:
            self._build_surf()
        return self._surf[1]

    @property
    def surf_corner(self):
        if self._surf is None:
            self._build_surf()
        return self._surf[2]

    @property
    def surf_loc(self):
        return self.surf_g * self.cs + self.corner

    def surface_world(self):
        return self.frame_pos + self.surf_loc @ self.R.T

    def surface_normals_world(self):
        return self.surf_n @ self.R.T

    def aabb(self):
        """World bounds (lo, hi) of the live cells. Cached until the cells or the pose change."""
        if self._aabb is not None:
            return self._aabb
        if not self.alive.any():
            self._aabb = (self.frame_pos.copy(), self.frame_pos.copy())
            return self._aabb
        c = np.array([[x, y, z] for x in (self.cell_lo[0], self.cell_hi[0])
                      for y in (self.cell_lo[1], self.cell_hi[1])
                      for z in (self.cell_lo[2], self.cell_hi[2])], np.float64)
        w = self.frame_pos + (c * self.cs + self.corner) @ self.R.T
        self._aabb = (w.min(0), w.max(0))
        return self._aabb

    def velocity_at(self, P):
        return np.zeros((len(P), 3))

    # ---- where is solid -----------------------------------------------------------------------------
    def probe(self, Pw):
        """World points -> (indices of points inside a live cell, depth to the nearest exposed face, outward
        normal of that face in world space)."""
        if NB.get('probe') is not None and len(Pw):
            sel, depth, k = NB['probe'](np.ascontiguousarray(Pw, np.float64), np.asarray(self.frame_pos, np.float64), self.R,
                                         np.asarray(self.corner, np.float64), float(self.cs), self.alive, self.expo)
            if not len(sel):
                return sel, None, None
            return sel, depth, _FACE_DIRS[k].astype(np.float64) @ self.R.T
        q = ((Pw - self.frame_pos) @ self.R - self.corner) / self.cs
        ij = np.floor(q).astype(np.int64)
        nx, ny, nz = self.alive.shape
        ok = (ij >= 0).all(axis=1) & (ij[:, 0] < nx) & (ij[:, 1] < ny) & (ij[:, 2] < nz)
        sel = np.nonzero(ok)[0]
        if not len(sel):
            return sel, None, None
        c = ij[sel]
        live = self.alive[c[:, 0], c[:, 1], c[:, 2]]
        sel, c = sel[live], c[live]
        if not len(sel):
            return sel, None, None
        f = q[sel] - c
        dist = np.stack([f[:, 0], 1 - f[:, 0], f[:, 1], 1 - f[:, 1], f[:, 2], 1 - f[:, 2]], axis=1)
        ex = self.expo[c[:, 0], c[:, 1], c[:, 2]]
        masked = np.where(ex, dist, np.inf)
        k = np.argmin(masked, axis=1)
        buried = ~np.isfinite(masked[np.arange(len(k)), k])           # no exposed face: use the nearest face
        if buried.any():
            k[buried] = np.argmin(dist[buried], axis=1)
        depth = dist[np.arange(len(k)), k] * self.cs
        normal = _FACE_DIRS[k].astype(np.float64) @ self.R.T
        return sel, depth, normal

    # ---- mesh ---------------------------------------------------------------------------------------
    def mesh(self, mode=None):
        """(n, 10) float32 vertices, 6 per exposed face: position in the frame, normal, colour, texture layer (-1 = none).
        A textured face carries its colour as a multiplier on the tile: 1.0 for sound cells, darker and greyer for cracked ones.
        The normal mesh is kept in bricks, so a cut rebuilds only the bricks it touched."""
        if mode is not None:
            return self._mesh_region((0, 0, 0), self.alive.shape, mode)
        if self._mesh_cache is not None:
            return self._mesh_cache
        B = MESH_BRICK
        shape = self.alive.shape
        nb = [-(-shape[k] // B) for k in range(3)]
        if self._bricks is None:
            self._bricks = {}
            keys = [(x, y, z) for x in range(nb[0]) for y in range(nb[1]) for z in range(nb[2])]
        else:
            keys = [k for k in self._brick_dirty if k[0] < nb[0] and k[1] < nb[1] and k[2] < nb[2]]
        self._brick_dirty = set()
        for key in keys:
            lo = [key[k] * B for k in range(3)]
            hi = [min(lo[k] + B, shape[k]) for k in range(3)]
            part = self._mesh_region(lo, hi)
            if len(part):
                self._bricks[key] = part
            else:
                self._bricks.pop(key, None)
        res = np.concatenate([self._bricks[k] for k in sorted(self._bricks)]) if self._bricks else np.zeros((0, 10), np.float32)
        self._mesh_cache = res
        return res

    def _mesh_region(self, lo, hi, mode=None):
        """Vertices for the exposed faces of the cells in [lo, hi)."""
        out = []
        cs = self.cs
        sl = tuple(slice(int(lo[k]), int(hi[k])) for k in range(3))
        off = np.array([int(v) for v in lo], np.int64)
        for f in range(6):
            idx = np.argwhere(self.expo[sl + (f,)])
            if not len(idx):
                continue
            idx = idx + off
            ax, sg = f // 2, (1.0 if f % 2 else -1.0)
            u, v = (ax + 1) % 3, (ax + 2) % 3
            base = idx.astype(np.float64)
            base[:, ax] += 1.0 if sg > 0 else 0.0
            corners = []
            for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)):
                p = base.copy()
                p[:, u] += du
                p[:, v] += dv
                corners.append(p)
            order = (0, 1, 2, 0, 2, 3) if sg > 0 else (0, 2, 1, 0, 3, 2)
            tri = np.stack([corners[o] for o in order], axis=1)          # (n, 6, 3)
            pos = tri * cs + self.corner
            ii = (idx[:, 0], idx[:, 1], idx[:, 2])
            mi = self.mat[ii]
            lay = _S_TEXLAYER[mi]
            dm = np.zeros((len(idx), 1), np.float32)      # cracks no longer darken the surface
            plain = _S_RGB[mi] * self.tint[ii][:, None] * (1.0 - 0.6 * dm) + np.array([0.20, 0.18, 0.17], np.float32) * (0.6 * dm)
            # Textured faces get a neutral darkening only: the tile already carries the colour, so damage no longer tints it.
            textured = self.tint[ii][:, None] * (1.0 - 0.6 * dm)
            col = np.where((lay >= 0)[:, None], textured, plain)
            if mode in ('integrity', 'stress', 'damage'):
                if mode == 'integrity':
                    col = self._integrity_rgb(ii)
                else:
                    load = np.clip(self.stress[ii] if mode == 'stress' else self.cdmg[ii] / 0.85, 0.0, 1.0)
                    cold = np.array([0.12, 0.45, 1.0] if mode == 'stress' else [0.05, 0.85, 0.85])
                    warm = np.array([1.0, 0.12, 0.15])
                    col = cold[None, :] * (1-load[:, None]) + warm[None, :] * load[:, None]
                lay = np.full(len(idx), -1.0, np.float32)
            nrm = np.zeros(3)
            nrm[ax] = sg
            v9 = np.empty((len(idx), 6, 10), np.float32)
            v9[:, :, 0:3] = pos
            v9[:, :, 3:6] = nrm
            v9[:, :, 6:9] = col[:, None, :]
            v9[:, :, 9] = lay[:, None]
            out.append(v9.reshape(-1, 10))
        return np.concatenate(out) if out else np.zeros((0, 10), np.float32)

    def load_of(self, ii):
        """How close each cell is to failing, 0..1: the worst of its stress and its cracks."""
        return np.clip(np.maximum(self.stress[ii], self.cdmg[ii] / 0.85), 0.0, 1.0)

    def _integrity_rgb(self, ii):
        """Green (safe) through yellow to red (about to fail)."""
        x = self.load_of(ii)
        return np.stack([np.interp(x, [0.0, 0.5, 1.0], [0.12, 0.95, 0.95]),
                         np.interp(x, [0.0, 0.5, 1.0], [0.75, 0.85, 0.12]),
                         np.interp(x, [0.0, 0.5, 1.0], [0.30, 0.12, 0.08])], axis=1).astype(np.float32)


class Structure(GridObject):
    """A fixed structure: cells, bonds between neighbours, and the cells that stand on the ground."""

    def __init__(self, mat, origin, cs, cdmg=None, tint=None):
        mat = np.asarray(mat)
        if cdmg is None:
            cdmg = np.zeros(mat.shape, np.float32)
        if tint is None:
            tint = np.ones(mat.shape, np.float32)     # uniform colour: no per-block variation, so no visible grid
        super().__init__(mat, cdmg, tint, cs)
        self.frame_pos[:] = origin
        self.bond = [self.alive[:-1] & self.alive[1:],
                     self.alive[:, :-1] & self.alive[:, 1:],
                     self.alive[:, :, :-1] & self.alive[:, :, 1:]]
        self.anch = np.zeros(self.alive.shape, bool)
        self.unanch = np.zeros(self.alive.shape, bool)   # feet that gave way: never ground again
        self.hot = np.asarray(origin, np.float64).copy()
        self.todo = []                    # (axis, plane) cuts still to be checked in this pass
        self.dirty_all = True             # the next support pass looks at the whole structure (new, or the ground changed)
        self.dirty_box = None             # otherwise just this box of cells, (lo, hi): where cuts have been made
        self.win = None                   # the box the pass in progress is checking (None = the whole structure)
        self.pass_broke = False
        self.stress_dirty = True          # a new structure is checked once before it is trusted
        self.detach_dirty = False
        self.wait = 0.0
        self.max_ratio = 0.0              # highest stress / strength seen in the last pass (1.0 = about to break)
        self.worst_load = 0.0             # highest stress in the area the last pass looked at (for the overlay)
        self.cdmg_peak = 0.0              # highest crack damage dealt so far
        self.stress_new = np.zeros(self.mat.shape, np.float32)   # stress being gathered by the pass that is running
        self._pass_open = False

    # ---- ground ---------------------------------------------------------------------------------------
    def refresh_anchors(self, world):
        """A cell with nothing under it is anchored when the terrain is solid just below its bottom face.
        Samples in chunks that are not loaded keep their old answer, so unloading never drops a structure."""
        below = np.zeros_like(self.alive)
        below[:, 1:, :] = self.alive[:, :-1, :]
        cand = self.alive & ~below
        idx = np.argwhere(cand)
        new = np.zeros_like(self.anch)
        if len(idx):
            P = self.frame_pos + (idx + np.array([0.5, 0.0, 0.5])) * self.cs - np.array([0.0, 0.03, 0.0])
            known = np.array([(int(math.floor(x / CHUNK_SIZE)), int(math.floor(z / CHUNK_SIZE))) in world.dens
                              for x, z in zip(P[:, 0].tolist(), P[:, 2].tolist())])
            solid = _density_many(world, P) > 0.0
            old = self.anch[idx[:, 0], idx[:, 1], idx[:, 2]]
            val = np.where(known, solid, old)
            new[idx[:, 0], idx[:, 1], idx[:, 2]] = val
        new &= ~self.unanch
        if not np.array_equal(new, self.anch):
            self.anch = new
            self.detach_dirty = True
            self.stress_dirty = True
            self.dirty_all = True

    # ---- damage ---------------------------------------------------------------------------------------
    def _note_dirty(self, lo, hi):
        """Cells in [lo, hi) changed: the next support pass checks that box widened by STRUCT_LOCAL_R."""
        r = int(math.ceil(STRUCT_LOCAL_R / self.cs))
        n = self.alive.shape
        self._union_box([max(int(lo[k]) - r, 0) for k in range(3)], [min(int(hi[k]) + r, n[k]) for k in range(3)])

    def _union_box(self, lo, hi):
        if self.dirty_box is None:
            self.dirty_box = (list(lo), list(hi))
        else:
            a, b = self.dirty_box
            self.dirty_box = ([min(a[k], lo[k]) for k in range(3)], [max(b[k], hi[k]) for k in range(3)])

    def _remove(self, kill, box=None, add=None, add_mat=0):
        """Take the cells in `kill` out of the structure. Without `box`, `kill` is a mask over the whole grid. With `box` = (lo, hi),
        `kill` is a mask over just that box of cells, and only the box (and its neighbours) is updated."""
        if box is None:
            if not kill.any():
                return
            lo, hi = [], []
            for ax in range(3):
                nzv = np.nonzero(kill.any(axis=tuple(k for k in range(3) if k != ax)))[0]
                lo.append(int(nzv[0]))
                hi.append(int(nzv[-1]) + 1)
        else:
            lo, hi = [int(x) for x in box[0]], [int(x) for x in box[1]]
        n = self.alive.shape
        Bx = tuple(slice(lo[k], hi[k]) for k in range(3))
        kb = kill[Bx] if box is None else kill
        self.mat[Bx][kb] = 0
        ch = kb
        if add is not None:                                          # cells filled in the same step (a dent's raised rim)
            self.mat[Bx][add] = add_mat
            ch = kb | add
        for arr in (self.cdmg, self.stress, self.stress_new, self.idmg):    # mostly zero: writing a zero over a zero would only touch fresh memory pages
            part = arr[Bx]
            if part[ch].any():
                part[ch] = 0
        R = tuple(slice(max(lo[k] - 1, 0), min(hi[k] + 1, n[k])) for k in range(3))
        a = self.mat[R] > 0
        off = [R[k].start for k in range(3)]
        if add is not None:
            addR = np.zeros(a.shape, bool)
            addR[tuple(slice(lo[k] - off[k], hi[k] - off[k]) for k in range(3))] = add
        for ax in range(3):
            lo_s = [slice(None)] * 3
            hi_s = [slice(None)] * 3
            lo_s[ax], hi_s[ax] = slice(0, -1), slice(1, None)
            pair = a[tuple(lo_s)] & a[tuple(hi_s)]                   # bonds inside the box and its margin
            bsl = tuple(slice(off[k], off[k] + pair.shape[k]) for k in range(3))
            self.bond[ax][bsl] &= pair
            if add is not None:
                self.bond[ax][bsl] |= pair & (addR[tuple(lo_s)] | addR[tuple(hi_s)])
        self.anch[R] &= a
        self.unanch[R] &= a
        self._geometry((lo, hi))
        self.detach_dirty = True
        self.stress_dirty = True
        self._note_dirty(lo, hi)

    DENT_RIM_FILL = 0.4       # share of the pressed-out cells that reappear as rim (the rest is squashed flat), one layer only
    DENT_RIM_PEAK = 1.2      # the rim's crest sits this many crater radii from the centre
    DENT_RIM_REACH = 1.6      # no rim cell further out than this many crater radii


    def blast(self, centre, radius, power, shatter=False):
        """Blast at a world point. Cells close enough are destroyed; cells further out are cracked, which
        weakens their bonds. Returns (centres, materials) of the destroyed cells. Only the cells in the blast's own
        box are looked at, not the whole structure."""
        none = (np.zeros((0, 3)), np.zeros(0, np.int64))
        resistance = blast_bond_scale()
        if not math.isfinite(resistance):
            return none
        centre = np.asarray(centre, np.float64)
        n = self.alive.shape
        g0 = (centre - self.frame_pos) / self.cs
        rr = radius / self.cs + 1.0
        lo = [max(int(math.floor(g0[k] - rr)), 0) for k in range(3)]
        hi = [min(int(math.ceil(g0[k] + rr)), n[k]) for k in range(3)]
        if any(hi[k] <= lo[k] for k in range(3)):
            return none
        idx = np.argwhere(self.alive[tuple(slice(lo[k], hi[k]) for k in range(3))])
        if not len(idx):
            return none
        idx = idx + np.array(lo, np.int64)
        cc = self.frame_pos + (idx + 0.5) * self.cs
        dist = np.linalg.norm(cc - centre, axis=1)
        near = dist < radius
        if not near.any():
            return none
        idx, cc, dist = idx[near], cc[near], dist[near]
        f = power * (1.0 - dist / radius) ** 2
        ii = (idx[:, 0], idx[:, 1], idx[:, 2])
        m = self.mat[ii]
        thr = _S_HARD[m] * STRUCT_SHATTER * resistance
        kill = f >= thr
        if shatter:
            kill = np.ones_like(kill)                   # every cell in range is destroyed, whatever its hardness
        hurt = ~kill
        if hurt.any():
            jj = (idx[hurt, 0], idx[hurt, 1], idx[hurt, 2])
            self.cdmg[jj] = np.minimum(0.85, self.cdmg[jj] + 0.7 * f[hurt] / thr[hurt])
            self.cdmg_peak = max(self.cdmg_peak, float(self.cdmg[jj].max()))
        killed_c, killed_m = cc[kill], m[kill]
        self.hot = centre.copy()
        if kill.any():
            ik = idx[kill]
            lo_k, hi_k = ik.min(0), ik.max(0) + 1
            loc = np.zeros(tuple(int(v) for v in hi_k - lo_k), bool)       # a mask over just the cells hit, not the whole grid
            loc[ik[:, 0] - lo_k[0], ik[:, 1] - lo_k[1], ik[:, 2] - lo_k[2]] = True
            self._remove(loc, (lo_k, hi_k))
        else:
            self.mesh_ver += 1                          # only cracks changed: the integrity overlay redraws, the mesh is as it was
            self._note_dirty(idx.min(0), idx.max(0) + 1)
        self.stress_dirty = True
        return killed_c, killed_m

    # ---- does it still stand? -------------------------------------------------------------------------
    def _queue_planes(self):
        """Every cut plane between two layers of cells in the area to check, nearest the last blast first. The area is the box
        round the cuts made since the last pass, or the whole structure when it is new or the ground changed."""
        n = self.alive.shape
        if self.dirty_all or self.dirty_box is None:
            lo, hi = [0, 0, 0], list(n)
            self.win = None
        else:
            lo, hi = list(self.dirty_box[0]), list(self.dirty_box[1])
            self.win = (lo, hi)
        self.dirty_all = False
        self.dirty_box = None
        planes = []
        for a in range(3):
            for p in range(lo[a], hi[a] - 1):
                sl = tuple(p if k == a else slice(lo[k], hi[k]) for k in range(3))
                if self.bond[a][sl].any():
                    mid = self.frame_pos[a] + (p + 1) * self.cs + (self.corner[a])
                    planes.append((abs(mid - self.hot[a]), a, p))
        planes.sort()
        self.todo = [(a, p) for _, a, p in planes]
        self.pass_broke = False
        if self.win is None:
            self.stress_new = np.zeros(self.mat.shape, np.float32)
        else:
            self.stress_new = self.stress                            # a windowed pass rewrites its own area in place; outside it the last answer stands
            self.stress_new[tuple(slice(lo[k], hi[k]) for k in range(3))] = 0.0
        self._pass_open = True

    def _check_plane_win(self, a, p):
        """check_plane on the pass's area only. The area is cut out as a small structure that shares the big one's arrays
        (so every change lands in the real structure), with the cells on its outer faces treated as held, since they join the
        rest of the structure, which this pass is not looking at."""
        if self.win is None:
            return self.check_plane(a, p)
        lo, hi = self.win
        n = self.alive.shape
        W = tuple(slice(lo[k], hi[k]) for k in range(3))
        sub = object.__new__(Structure)
        sub.cs = self.cs
        sub.mat, sub.cdmg, sub.alive = self.mat[W], self.cdmg[W], self.alive[W]
        sub.cell_mass, sub.unanch, sub.stress_new = self.cell_mass[W], self.unanch[W], self.stress_new[W]
        anch = self.anch[W].copy()
        for k in range(3):
            if lo[k] > 0:
                anch[tuple(0 if j == k else slice(None) for j in range(3))] = True
            if hi[k] < n[k]:
                anch[tuple(-1 if j == k else slice(None) for j in range(3))] = True
        sub.anch = anch
        sub.bond = [self.bond[ax][tuple(slice(lo[k], hi[k] - 1 if k == ax else hi[k]) for k in range(3))] for ax in range(3)]
        sub.max_ratio = self.max_ratio
        sub.detach_dirty = False
        broke = sub.check_plane(a, p - lo[a])
        if broke:
            self.cdmg_peak = max(self.cdmg_peak, 0.9)
        self.max_ratio = max(self.max_ratio, sub.max_ratio)
        if sub.detach_dirty:
            self.detach_dirty = True
        self.anch[W] &= ~self.unanch[W]                              # feet that gave way are no longer ground
        return broke

    def check_plane(self, a, p):
        """Cut the structure along one plane and look at what the cut separates from the ground. The part
        with no ground of its own hangs on the bonds that cross the plane. Its weight acts at its centre of
        mass; the bonds share it like a bolted joint: a uniform push or pull plus a linear change across the
        plane that balances the turning moment. A bond pulled apart beyond its tensile strength or crushed
        beyond its compressive strength breaks (the worst one first), and a moment the bonds cannot balance
        at all, because they all lie on one line, breaks the section. Returns True if a bond broke."""
        sl = tuple(p if k == a else slice(None) for k in range(3))
        cross = self.bond[a][sl]
        if not cross.any():
            return False
        lab = _label_cells(self.alive, self.bond, cut=(a, p))
        anchored = np.unique(lab[self.anch & self.alive])
        ij = np.argwhere(cross)
        lo = np.insert(ij, a, p, axis=1)
        hi = np.insert(ij, a, p + 1, axis=1)
        l_lo = lab[lo[:, 0], lo[:, 1], lo[:, 2]]
        l_hi = lab[hi[:, 0], hi[:, 1], hi[:, 2]]
        a_lo, a_hi = np.isin(l_lo, anchored), np.isin(l_hi, anchored)
        broke = False
        if a != 1:
            broke = self._check_thrust(a, p, lab, lo, hi, l_lo, l_hi, a_lo, a_hi)
        for L in np.unique(np.concatenate([l_lo[~a_lo], l_hi[~a_hi]])):
            # the loaded group L must hang only on anchored ground
            if np.any(((l_lo == L) & ~a_hi & (l_hi != L)) | ((l_hi == L) & ~a_lo & (l_lo != L))):
                continue
            use = ((l_lo == L) & a_hi) | ((l_hi == L) & a_lo)
            if not use.any():
                continue
            sgn = -1.0 if np.any((l_lo == L) & use) else 1.0        # support-to-load direction along axis a
            n = np.zeros(3)
            n[a] = sgn
            lo_u, hi_u = lo[use], hi[use]
            cm = self.cell_mass
            mass, com = _group_mass_com(cm, lab == L, self.cs)
            if mass <= 0:
                continue
            fg = np.array([0.0, -mass * STRUCT_GRAVITY, 0.0])
            pos = (lo_u + hi_u + 1) * 0.5 * self.cs                 # centres of the bonds' shared faces
            A = np.full(len(pos), self.cs * self.cs)
            Asum = A.sum()
            c = (A[:, None] * pos).sum(0) / Asum
            rho = pos - c
            sig0 = -float(fg @ n) / Asum
            mg = np.cross(com - c, fg)
            mg = mg - (mg @ n) * n                                   # turning about the plane's normal is carried by shear
            u, v = [k for k in range(3) if k != a]
            cols = []
            for k in (u, v):
                cols.append(((A * rho[:, k])[:, None] * np.cross(rho, n)).sum(0))
            Mm = np.stack(cols, axis=1)                              # (3, 2)
            g, *_ = np.linalg.lstsq(Mm, -mg, rcond=None)
            resid = float(np.linalg.norm(Mm @ g + mg))
            s = sig0 + g[0] * rho[:, u] + g[1] * rho[:, v]           # stress on each bond, push positive
            ml = self.mat[lo_u[:, 0], lo_u[:, 1], lo_u[:, 2]]
            mh = self.mat[hi_u[:, 0], hi_u[:, 1], hi_u[:, 2]]
            fac = 1.0 - np.maximum(self.cdmg[lo_u[:, 0], lo_u[:, 1], lo_u[:, 2]],
                                   self.cdmg[hi_u[:, 0], hi_u[:, 1], hi_u[:, 2]])
            fac = np.maximum(fac, 0.02)
            sk = STRENGTH['k']
            comp = np.minimum(_S_COMP[ml], _S_COMP[mh]) * fac * sk
            tens = np.minimum(_S_TENS[ml], _S_TENS[mh]) * fac * sk
            shear = np.minimum(_S_SHEAR[ml], _S_SHEAR[mh]) * fac * sk
            vt = fg - (fg @ n) * n
            tau = float(np.linalg.norm(vt)) / Asum
            ratio = np.maximum(np.maximum(s / comp, -s / tens), tau / shear)
            if resid > 0.02 * (float(np.linalg.norm(mg)) + 1e-9) and resid > 1.0:
                ratio = np.maximum(ratio, 2.0)                       # one line of bonds cannot hold a turning load
            r_c = np.minimum(ratio, 1.5).astype(np.float32)
            np.maximum.at(self.stress_new, (lo_u[:, 0], lo_u[:, 1], lo_u[:, 2]), r_c)
            np.maximum.at(self.stress_new, (hi_u[:, 0], hi_u[:, 1], hi_u[:, 2]), r_c)
            self.max_ratio = max(self.max_ratio, float(ratio.max()))
            for w in np.nonzero(ratio > 1.0)[0]:
                a_i, b_i = tuple(lo_u[w]), tuple(hi_u[w])
                self.bond[a][a_i] = False                 # the bond is indexed by the lower of its two cells
                self.cdmg[a_i] = min(0.9, float(self.cdmg[a_i]) + 0.12)
                self.cdmg[b_i] = min(0.9, float(self.cdmg[b_i]) + 0.12)
                broke = True
        return broke

    def _check_thrust(self, a, p, lab, lo, hi, l_lo, l_hi, a_lo, a_hi):
        """Arches. A piece that stands on the ground at one end and meets another grounded piece at this cut (the
        two halves of an arch at the crown) leans on its neighbour. Turning about the inner edge of its foot, its
        weight W at horizontal distance e from that edge is balanced by a sideways thrust H = W e / h pushed in at
        the top of the joint, h above the foot. The joint must take H in compression, and the foot must not slide:
        H <= friction x W. Where the joint is a loose slab (a lintel) it can instead carry W as shear; the piece
        stands if either way works. A piece that fails loses its ground for good and falls."""
        pair = a_lo & a_hi & (l_lo != l_hi)
        if not pair.any():
            return False
        broke = False
        opened = False                                            # a half has already failed at this joint
        g = STRUCT_GRAVITY
        sk = STRENGTH['k']
        for side, labs in ((0, l_lo), (1, l_hi)):
            for L in np.unique(labs[pair]):
                sel = pair & (labs == L)
                layer = p if side == 0 else p + 1
                lsl = tuple(layer if k == a else slice(None) for k in range(3))
                if np.any(self.anch[lsl] & (lab[lsl] == L)):
                    continue                                          # it stands on the ground right at the cut
                grp = lab == L
                foot = grp & self.anch & ~self.unanch
                if not foot.any():
                    continue
                mass, com = _group_mass_com(self.cell_mass, grp, self.cs)
                if mass <= 0:
                    continue
                fi = np.argwhere(foot)
                s_ = 1.0 if side == 0 else -1.0
                x_in = ((fi[:, a].max() + 1) if side == 0 else fi[:, a].min()) * self.cs
                e = s_ * (com[a] - x_in)
                if e <= 0.0:
                    continue
                W = mass * g
                y_foot = fi[:, 1].min() * self.cs
                cells = (lo if side == 0 else hi)[sel]
                y_top = (cells[:, 1].max() + 1) * self.cs
                h = max(y_top - y_foot, self.cs)
                H = W * e / h
                m_j = self.mat[cells[:, 0], cells[:, 1], cells[:, 2]]
                fac = max(0.02, 1.0 - float(self.cdmg[cells[:, 0], cells[:, 1], cells[:, 2]].max()))
                area = len(cells) * self.cs * self.cs
                comp = float(_S_COMP[m_j].min()) * fac * sk
                r_comp = (H / (area * ARCH_CONTACT)) / comp
                mu = float(_S_MU[self.mat[fi[:, 0], fi[:, 1], fi[:, 2]]].min())
                r_fric = H / (mu * W)
                r_thrust = max(r_comp, r_fric)
                shear = float(_S_SHEAR[m_j].min()) * fac * sk * ARCH_JOINT_SHEAR
                r_beam = (W / area) / shear
                ratio = min(r_thrust, r_beam)
                if opened:
                    ratio = max(ratio, 2.0)                           # the other half lost its prop, so it tips too
                r_c = np.float32(min(ratio, 1.5))
                np.maximum.at(self.stress_new, (cells[:, 0], cells[:, 1], cells[:, 2]), r_c)
                self.max_ratio = max(self.max_ratio, float(ratio))
                if ratio > 1.0:
                    self.unanch |= foot                               # the feet give way
                    self.anch &= ~self.unanch
                    ai = tuple(slice(None) if k != a else p for k in range(3))
                    self.bond[a][ai][...] = False                     # and the joint opens
                    self.cdmg[cells[:, 0], cells[:, 1], cells[:, 2]] = np.minimum(0.9, self.cdmg[cells[:, 0], cells[:, 1], cells[:, 2]] + 0.12)
                    self.detach_dirty = True
                    broke = True
                    opened = True
        return broke

    def update(self, world, dt, budget=STRUCT_BUDGET_S):
        """Run support checks within a time budget and return batches of detached cells."""
        detached = []
        if (self.stress_dirty or self.todo) and int(self.alive.sum()) > STRUCT_UNBREAKABLE_CELLS:
            self.stress_dirty = False                       # too big to crack under load: no stress checks. A cut all the way
            self.todo = []                                  # through still sends the cut-off part away (the detach step below)
            self._pass_open = False
        if self.detach_dirty:
            with Timed('structs.detach', gpu=False):
                detached.extend(self._detach())
        self.wait = max(0.0, self.wait - dt)
        if not self.todo and self.stress_dirty and self.wait <= 0.0:
            self._queue_planes()
            self.stress_dirty = False
        if self.todo:
            # One plane check labels the whole grid and can cost far more than the budget on a fine grid, and the
            # loop below cannot stop one halfway. So each check's cost goes on a debt that is paid down at the
            # budget's share of real time; no new check starts until the debt is clear. Average cost ~ budget.
            self._chk_debt = max(0.0, getattr(self, '_chk_debt', 0.0) - dt * budget * 60.0)
            t0 = time.perf_counter()
            with Timed('structs.check', gpu=False):
              while self.todo and self._chk_debt <= 0.0 and time.perf_counter() - t0 < budget:
                a, p = self.todo.pop(0)
                t_c = time.perf_counter()
                broke_c = self._check_plane_win(a, p)
                self._chk_debt += time.perf_counter() - t_c
                if broke_c:
                    SFX.crack(self.frame_pos + 0.5 * np.array(self.alive.shape) * self.cs)
                    self.pass_broke = True
                    self.detach_dirty = True
                    self._mesh_cache = None
                    self.mesh_ver += 1
            if not self.todo and self._pass_open:
                self._pass_open = False
                self.stress = self.stress_new
                self.worst_load = float(self.stress[tuple(slice(self.win[0][k], self.win[1][k]) for k in range(3))].max()
                                        if self.win is not None else self.stress.max())
                self.stress_ver += 1                  # the integrity overlay redraws from this
            if not self.todo and self.pass_broke:
                self.stress_dirty = True              # something broke, so look at the same area again
                if self.win is None:
                    self.dirty_all = True
                else:
                    self._union_box(*self.win)
                self.wait = STRUCT_CRACK_STEP
                self.pass_broke = False
            if self.detach_dirty:
                with Timed('structs.detach', gpu=False):
                    detached.extend(self._detach())
        return detached

    def _cut_body(self, grp):
        """A loose rigid body made of the cells in the mask `grp`, in the pose of this structure, keeping their bonds, damage and colours."""
        idx = np.argwhere(grp)
        lo, hi = idx.min(0), idx.max(0) + 1
        sl = tuple(slice(int(lo[k]), int(hi[k])) for k in range(3))
        g = grp[sl]
        body = RigidBody(np.where(g, self.mat[sl], 0).astype(np.int16), np.where(g, self.cdmg[sl], 0).astype(np.float32),
                         self.tint[sl].copy(), self.cs, np.zeros(3))
        pr = [g[:-1] & g[1:], g[:, :-1] & g[:, 1:], g[:, :, :-1] & g[:, :, 1:]]
        body.bond = []
        for a in range(3):
            bsl = tuple(slice(int(lo[k]), int(hi[k]) - 1 if k == a else int(hi[k])) for k in range(3))
            body.bond.append(self.bond[a][bsl] & pr[a])
        body.idmg = np.where(g, self.idmg[sl], 0).astype(np.float32)
        body.corner = np.asarray(self.corner, np.float64) + lo * self.cs
        body.frame_pos = np.array(self.frame_pos, np.float64)
        body._sync()
        body.recentre()
        hot = getattr(self, 'hot', None)                            # let go, it leans away from the last blast (as a cut-off slab of ground does), so a piece left
        if hot is not None:                                         # balanced on a stub still tips off it and falls
            d = body.frame_pos - np.asarray(hot, np.float64)
            d[1] = 0.0
            nd = float(np.linalg.norm(d))
            d = d / nd if nd > 1e-6 else np.array([1.0, 0.0, 0.0])
            size = max(1.0, float(body.mass) ** (1.0 / 3.0))
            body.v = body.v + d * 0.8
            body.w = body.w + np.cross(np.array([0.0, 1.0, 0.0]), d) * (0.9 / size ** 0.5)
        body.wake()
        return body

    def _detach(self):
        """Remove cells with no chain of bonds to an anchor and return their debris data."""
        self.detach_dirty = False
        lab = _label_cells(self.alive, self.bond)
        ground = np.unique(lab[self.anch & self.alive])
        free = self.alive & ~np.isin(lab, ground)
        if not free.any():
            return []
        if STRUCT_FALL_AS_BODY:
            took = np.zeros_like(free)
            for L in np.unique(lab[free]):
                grp = (lab == L) & free
                if STRUCT_MIN_BODY_CELLS <= int(grp.sum()) <= STRUCT_BODY_MAX_CELLS:
                    STRUCTS.bodies.append(self._cut_body(grp))          # it falls as one piece
                    took |= grp
            if took.any():
                self._remove(took)
                free &= ~took
                if not free.any():
                    return []
        pos = self.frame_pos + (np.argwhere(free) + 0.5) * self.cs
        mats = self.mat[free]
        tint = self.tint[free]
        self._remove(free)
        return [(pos, mats, tint)]


class RigidBody(GridObject):
    """A solid chunk with a centre of mass, an orientation, velocity and spin."""

    def __init__(self, mat, cdmg, tint, cs, com_local):
        super().__init__(mat, cdmg, tint, cs)
        al = self.alive
        self.bond = [al[:-1] & al[1:], al[:, :-1] & al[:, 1:], al[:, :, :-1] & al[:, :, 1:]]   # bonds between neighbouring cells, indexed by the lower cell
        self.grace = BOND_GRACE          # seconds left in which impacts are ignored
        self.frac_cd = 0.0               # seconds until this body may fracture again
        self.unbreakable = False         # True: impacts never damage this body (the cannon block)
        self.gscale = 1.0                # share of gravity this body feels (the bench's ram is driven, so it feels none)
        self.drive = None                # optional motor: drive(body, h, 'pre' | 'post') is called every sub-step (the bench's ram)
        self.impacts = []                # hard contacts noted by step(), used by StructureManager._apply_impacts
        self._obs = []
        self.corner = -np.asarray(com_local, np.float64)
        self.q = np.array([1.0, 0.0, 0.0, 0.0])
        self.v = np.zeros(3)
        self.w = np.zeros(3)
        self.asleep = False
        self.still = 0.0
        self._top = float(TERRAIN_MAX_H)
        self.last_contacts = 0
        self.supported = False
        self._mass_props()
        self._sync()

    def _mass_props(self):
        cells = np.argwhere(self.alive)
        m = self.cell_mass[self.alive]
        self.mass = float(m.sum())
        self.invm = 1.0 / max(self.mass, 1e-9)
        r = (cells + 0.5) * self.cs + self.corner
        r2 = np.einsum('ij,ij->i', r, r)
        I = np.eye(3) * float((m * r2).sum()) - np.einsum('i,ij,ik->jk', m, r, r)
        I += np.eye(3) * float((m * self.cs ** 2 / 6.0).sum())
        self.Ib_inv = np.linalg.inv(I)

    def _sync(self):
        self.R = _q_mat(self.q)
        self.Iinv = self.R @ self.Ib_inv @ self.R.T

    def velocity_at(self, P):
        return self.v + _cross(self.w, P - self.frame_pos)

    def wake(self):
        self.asleep = False
        self.still = 0.0

    def topple(self, centre):
        """Start a loose piece leaning away from the point it came off (the last blast): a push away from that point
        and a spin about the horizontal axis that turns its top away, so it tips over instead of dropping straight down."""
        up = np.array([0.0, 1.0, 0.0])
        d = np.asarray(self.frame_pos, np.float64) - np.asarray(centre, np.float64)
        d[1] = 0.0
        n = np.linalg.norm(d)
        d = d / n if n > 1e-6 else np.array([1.0, 0.0, 0.0])
        self.wake()                                  # split-off pieces keep the parent's velocity and spin; nothing is added

    # ---- blast --------------------------------------------------------------------------------------
    def blast(self, centre, radius, power):
        """Push on the surface that faces the blast. Each surface point takes a pressure that falls off with
        distance, so the impulse acts away from the centre of mass and the body spins as well as moves."""
        P = self.surface_world()
        N = self.surface_normals_world()
        d = P - centre
        dist = np.linalg.norm(d, axis=1)
        ok = (dist < radius) & (dist > 1e-6) & (np.linalg.norm(N, axis=1) > 0.5)
        if not ok.any():
            return
        P, N, d, dist = P[ok], N[ok], d[ok], dist[ok]
        facing = -np.einsum('ij,ij->i', N, d / dist[:, None])
        ok = facing > 0.05
        if not ok.any():
            return
        P, N, dist, facing = P[ok], N[ok], dist[ok], facing[ok]
        pressure = power * (1.0 - dist / radius) ** 2 * facing * (0.5 * self.cs * self.cs)
        J = -N * (pressure * STRUCT_BLAST_IMPULSE)[:, None]
        self.v = self.v + J.sum(0) * self.invm
        self.w = self.w + self.Iinv @ np.cross(P - self.frame_pos, J).sum(0)
        self.wake()

    # ---- contacts -----------------------------------------------------------------------------------
    def _contacts(self, world, obstacles):
        """Points where this body touches or is about to touch something. Returns arrays of the contact
        point, the normal that pushes the body out, the depth (negative: a small gap), and the velocity
        of whatever it touches."""
        Pw = self.surface_world()
        pts, nrm, dep, vob, own = [], [], [], [], []
        # terrain: the density field, with its gradient giving the surface normal
        Pc = Pw[self.surf_corner]
        if len(Pc):
            Pc = Pc[Pc[:, 1] < self._top + 0.4]            # only points low enough to reach the ground
        if len(Pc):
            cdep, cn, okc = _cell_contact(world, Pc)
            if okc.any():
                pts.append(Pc[okc])
                nrm.append(cn[okc])
                dep.append(cdep[okc])
                vob.append(np.zeros((int(okc.sum()), 3)))
                own.append(np.full(int(okc.sum()), -1))
        lo, hi = Pw.min(0) - 0.05, Pw.max(0) + 0.05
        for oi, O in enumerate(obstacles):
            olo, ohi = O.aabb()
            if (olo > hi).any() or (ohi < lo).any():
                continue
            # our points inside the other object
            m = ((Pw >= olo - 0.05) & (Pw <= ohi + 0.05)).all(axis=1)
            if m.any():
                ids = np.nonzero(m)[0]
                sel, depth, normal = O.probe(Pw[ids])
                if len(sel):
                    P = Pw[ids[sel]]
                    pts.append(P)
                    nrm.append(normal)
                    dep.append(depth)
                    vob.append(O.velocity_at(P))
                    own.append(np.full(len(P), oi))
            # its points inside us
            Ow = O.surface_world()
            m = ((Ow >= lo) & (Ow <= hi)).all(axis=1)
            if m.any():
                ids = np.nonzero(m)[0]
                sel, depth, normal = self.probe(Ow[ids])
                if len(sel):
                    P = Ow[ids[sel]]
                    pts.append(P)
                    nrm.append(-normal)
                    dep.append(depth)
                    vob.append(O.velocity_at(P))
                    own.append(np.full(len(P), oi))
        if not pts:
            return None
        out = (np.concatenate(pts), np.concatenate(nrm), np.concatenate(dep), np.concatenate(vob), np.concatenate(own))
        fam = getattr(self, 'family', None)
        if fam is not None:                                        # siblings meet exactly on the crack: a point on a ragged crack can read as half a cell deep
            deep = np.zeros(len(out[2]), bool)
            for oi in np.unique(out[4][out[4] >= 0]):
                if getattr(obstacles[int(oi)], 'family', None) is fam:
                    deep |= (out[4] == oi) & (out[2] > FRACTURE_SIBLING_DEEP * self.cs)
            if deep.any():
                keep = ~deep
                if not keep.any():
                    return None
                out = tuple(a[keep] for a in out)
        return out

    def _note_impacts(self, pts, nrm, force, own, v_pre):
        """Remember the contacts hard enough to matter to a bond: (point, normal, force, the other object or None for the
        ground, this body's velocity at the point before the solver). StructureManager._apply_impacts turns them into damage."""
        T = bond_threshold()
        if not (0.0 < T < math.inf):
            return
        big = np.nonzero(force >= BOND_MIN_R * 0.3 * T)[0]        # 0.3: the softest material holds 0.3 x the reference force
        for i in big:
            o = int(own[i])
            O = self._obs[o] if o >= 0 else None
            # The cells are found now, while both bodies are where the contact happened: the step moves them afterwards.
            c_self = _cell_near(self, pts[i], nrm[i])
            c_other = None if O is None else _cell_near(O, pts[i], -nrm[i], getattr(self, 'is_tool', False))
            self.impacts.append((pts[i].copy(), float(force[i]), O, c_self, c_other, v_pre[i].copy(), nrm[i].copy()))

    def _ground_top(self, world):
        """Highest the ground can be under this body. The ground is never above the flat top (dug cubes only ever lower it), so
        points above that skip the terrain test."""
        return float(TERRAIN_MAX_H)

    def _reduce(self, pts, nrm, dep, vob, own):
        """Keep the deepest contacts, spread out, so the solver has a few well-placed points instead of dozens."""
        n = len(pts)
        if n <= STRUCT_MAX_CONTACTS:
            return pts, nrm, dep, vob, own
        band = dep >= dep.max() - 0.12
        ids = np.nonzero(band)[0]
        if len(ids) <= STRUCT_MAX_CONTACTS:
            rest = np.setdiff1d(np.arange(n), ids)
            extra = rest[np.argsort(-dep[rest])][:STRUCT_MAX_CONTACTS - len(ids)]
            ids = np.concatenate([ids, extra])
        elif NB.get('spread') is not None:
            ids = ids[NB['spread'](np.ascontiguousarray(pts[ids], np.float64), np.ascontiguousarray(dep[ids], np.float64), int(STRUCT_MAX_CONTACTS))]
        else:
            chosen = [int(ids[np.argmax(dep[ids])])]
            mind = np.linalg.norm(pts[ids] - pts[chosen[0]], axis=1)
            while len(chosen) < STRUCT_MAX_CONTACTS:
                k = int(np.argmax(mind))
                chosen.append(int(ids[k]))
                mind = np.minimum(mind, np.linalg.norm(pts[ids] - pts[ids[k]], axis=1))
            ids = np.array(chosen)
        return pts[ids], nrm[ids], dep[ids], vob[ids], own[ids]

    def _pair_partners(self, own, pts, D, vn0, m):
        """The other loose bodies this one touches, as (body, rows of D that touch it, that body's angular terms). They are solved
        as true two-body contacts: their mass and inertia enter the effective mass and they take the equal and opposite impulse.
        Terrain, fixed structures and bodies that are asleep and only touched gently stay fixed obstacles."""
        out = []
        if own is None:
            return out
        for oi in np.unique(own[own >= 0]):
            O = self._obs[int(oi)]
            if O is self or not isinstance(O, RigidBody) or not O.alive.any():
                continue
            sel = np.nonzero(own == oi)[0]
            if O.asleep and float(vn0[sel].min()) > -0.75:       # a sleeper is woken only by a real impact (same 0.75 as the debris)
                continue
            rows = np.concatenate([sel, m + sel, 2 * m + sel])
            ro = pts[sel] - O.frame_pos
            out.append((O, rows, _cross(np.concatenate([ro, ro, ro]), D[rows])))
        return out

    def _solve(self, pts, nrm, dep, vob, h, own=None):
        """Sequential impulses on the contacts: a push along each normal that never pulls, and friction along
        two tangents limited by the push. Gives the body its new velocity and spin. Where the other object is a loose
        body, it receives the equal and opposite impulse (self._undo remembers its old state so a redone solve can restore it)."""
        self._undo = []
        m = len(pts)
        r = pts - self.frame_pos
        ref = np.where(np.abs(nrm[:, :1]) < 0.9, np.array([[1.0, 0, 0]]), np.array([[0, 1.0, 0]]))
        t1 = _cross(nrm, ref)
        t1 /= np.linalg.norm(t1, axis=1, keepdims=True)
        t2 = _cross(nrm, t1)
        D = np.concatenate([nrm, t1, t2])                          # (3m, 3) directions
        Ang = _cross(np.concatenate([r, r, r]), D)
        K = self.invm * (D @ D.T) + Ang @ self.Iinv @ Ang.T
        jv = D @ self.v + Ang @ self.w - np.einsum('ij,ij->i', D, np.concatenate([vob, vob, vob]))
        vn0 = jv[:m].copy()
        partners = self._pair_partners(own, pts, D, vn0, m)
        for O, rows, Ang_o in partners:                            # the other body resists too: its mass and inertia join the contact
            Dp = D[rows]
            K[np.ix_(rows, rows)] += O.invm * (Dp @ Dp.T) + Ang_o @ O.Iinv @ Ang_o.T
        diag = np.diag(K).copy()
        diag = np.maximum(diag, 1e-9)
        c = (dep - STRUCT_SLOP) / h
        c = np.where(c > 0, 0.0, c)                  # no velocity bias for overlaps (was adding outward speed); gaps still allow approach
        bounce = vn0 < -1.5
        c = np.where(bounce, np.maximum(c, -STRUCT_RESTITUTION * vn0), c)
        if NB.get('solve') is not None:
            lam = NB['solve'](np.ascontiguousarray(K.T), np.ascontiguousarray(jv, np.float64), diag, np.ascontiguousarray(c, np.float64),
                              m, float(WOBBLE['friction']), int(WOBBLE['iters']))
        else:
            lam = [0.0] * (3 * m)
            cl = c.tolist()
            dg = diag.tolist()
            for _ in range(WOBBLE['iters']):
                moved = 0.0
                for i in range(m):
                    new = max(0.0, lam[i] - (jv[i] - cl[i]) / dg[i])
                    dl = new - lam[i]
                    if dl:
                        lam[i] = new
                        jv += K[:, i] * dl
                        moved += abs(dl)
                    lim = WOBBLE['friction'] * lam[i]
                    for row in (m + i, 2 * m + i):
                        new = min(max(lam[row] - jv[row] / dg[row], -lim), lim)
                        dl = new - lam[row]
                        if dl:
                            lam[row] = new
                            jv += K[:, row] * dl
                            moved += abs(dl)
                if moved < 1e-5:
                    break
            lam = np.array(lam)
        self.v = self.v + self.invm * (D.T @ lam)
        self.w = self.w + self.Iinv @ (Ang.T @ lam)
        for O, rows, Ang_o in partners:                            # equal and opposite impulse on the other body (a sleeper is woken)
            lp = np.asarray(lam)[rows]
            self._undo.append((O, O.v.copy(), O.w.copy(), O.asleep, O.still))
            O.v = O.v - O.invm * (D[rows].T @ lp)
            O.w = O.w - O.Iinv @ (Ang_o.T @ lp)
            if O.asleep:
                O.wake()
        return lam[:m]                                           # the push along each contact normal (impulse), for the impact bonds

    def step(self, world, dt, obstacles):
        if self.asleep:
            return
        nsub = max(1, min(STRUCT_SUBSTEPS, getattr(self, 'nsub', STRUCT_SUBSTEPS)))
        h = dt / nsub
        self.grace = max(0.0, self.grace - dt)
        self.frac_cd = max(0.0, self.frac_cd - dt)
        self._obs = obstacles
        fall_v = -float(self.v[1])                           # downward speed at the start of the step, for the landing sound
        self._top = self._ground_top(world) + 0.5 * float(np.linalg.norm(self.v)) * dt
        contact_steps = 0
        support = False
        for _ in range(nsub):
            if not self.alive.any():
                break
            self.v[1] -= STRUCT_GRAVITY * self.gscale * h
            if self.drive is not None:
                self.drive(self, h, 'pre')
            self.w *= math.exp(-WOBBLE['ang_damp'] * h)
            if WOBBLE['lin_damp']:
                kd = math.exp(-WOBBLE['lin_damp'] * h)
                self.v[0] *= kd                                  # sideways only: a fall is not slowed
                self.v[2] *= kd
            for _try in range(3):
                con = self._contacts(world, obstacles)
                if con is None:
                    break
                pts, nrm, dep, vob, own = self._reduce(*con)
                v_pre = self.v + _cross(self.w, pts - self.frame_pos)       # velocity at each contact before the solver changes it
                v0, w0 = self.v.copy(), self.w.copy()
                lam_n = self._solve(pts, nrm, dep, vob, h, own)
                if self.grace > 0.0 or BOND['strength'] <= 0:
                    break
                self._note_impacts(pts, nrm, lam_n / h, own, v_pre)
                if not self.impacts:
                    break
                n_broke, dp = STRUCTS._apply_impacts(world, self)
                if n_broke == 0 or not self.alive.any():
                    break
                for O, v_o, w_o, asleep_o, still_o in self._undo:      # the redone solve pushes the other loose bodies again: restore them first
                    O.v, O.w, O.asleep, O.still = v_o, w_o, asleep_o, still_o
                self.v = v0 - dp * self.invm      # cells let go: take back this solve (it hit material that was still joined) and redo it
                self.w = w0                       # (dp: the momentum the released cells took with them)
            if con is not None and self.alive.any():
                # Position fix: the impulses only stop the approach, so an overlap that already exists is never
                # pushed out and lasts for good. Move the body out along its deepest contact, a little each substep.
                over = dep - STRUCT_SLOP
                if len(over) and float(over.max()) > 0.0:
                    i = int(np.argmax(over))
                    self.frame_pos = self.frame_pos + nrm[i] * min(float(over[i]), 0.05) * 0.6
                contact_steps += 1
                self.last_contacts = len(pts)
                cp = pts - pts.mean(0)
                support = len(pts) >= 3 and np.linalg.svd(cp, compute_uv=False)[1] > 0.12
            self.frame_pos = self.frame_pos + self.v * h
            wq = np.array([0.0, *(self.w * h * 0.5)])
            self.q = self.q + _q_mul(wq, self.q)
            self.q /= np.linalg.norm(self.q)
            self._sync()
            if self.drive is not None:
                self.drive(self, h, 'post')
        self.supported = support
        self._aabb = None
        if contact_steps and not getattr(self, '_touching', False) and fall_v > 2.5:
            SFX.body_land(self.frame_pos, fall_v, float(self.alive.sum()) * self.cs ** 3)
        self._touching = bool(contact_steps)
        k = WOBBLE['sleep_k']
        slow = np.linalg.norm(self.v) < STRUCT_SLEEP_LIN * k and np.linalg.norm(self.w) < STRUCT_SLEEP_ANG * k
        if slow and support and self.drive is None:
            self.still += dt
            if self.still >= STRUCT_SLEEP_TIME / k:
                self.asleep = True
                self.v[:] = 0.0
                self.w[:] = 0.0
        else:
            self.still = 0.0


MAX_LOOSE_BODIES = 10      # more loose pieces than this and the smallest become debris, to keep the physics cost bounded


def _chop_object(o, centre, d, half_w, depth, power, hot):
    """An axe cut into one structure or loose body: the cells in a slot along the swing direction `d` (half_w either side,
    `depth` deep from the hit point) are cut away if the blade can (hardness at most `power`) and only cracked if not.
    Returns (centres, materials) of the cells cut away and whether the slot touched the object at all."""
    none = (np.zeros((0, 3)), np.zeros(0, np.int64), False)
    cs = o.cs
    reach = max(half_w, depth) + 2.0 * cs
    if isinstance(o, Structure):
        n = o.alive.shape
        g0 = (centre - o.frame_pos) / cs
        rr = reach / cs + 1.0
        lo = [max(int(math.floor(g0[k] - rr)), 0) for k in range(3)]
        hi = [min(int(math.ceil(g0[k] + rr)), n[k]) for k in range(3)]
        if any(hi[k] <= lo[k] for k in range(3)):
            return none
        idx = np.argwhere(o.alive[tuple(slice(lo[k], hi[k]) for k in range(3))])
        if not len(idx):
            return none
        idx = idx + np.array(lo, np.int64)
        cc = o.frame_pos + (idx + 0.5) * cs
    else:
        idx = np.argwhere(o.alive)
        if not len(idx):
            return none
        cc = o.frame_pos + ((idx + 0.5) * cs + o.corner) @ o.R.T
    rel = cc - centre
    along = rel @ d
    lat = np.linalg.norm(rel - along[:, None] * d, axis=1)
    cut = (along >= -0.75 * cs) & (along <= depth) & (lat <= half_w)
    if not cut.any():
        return none
    idx, cc, lat = idx[cut], cc[cut], lat[cut]
    ii = (idx[:, 0], idx[:, 1], idx[:, 2])
    m = o.mat[ii]
    thr = _S_HARD[m] * STRUCT_SHATTER
    blunt = lat <= AXE_BLUNT_FRAC * half_w                  # the blunt middle of the axe: it never cuts a cube out, it only cracks
    kill = (thr <= power) & ~blunt                          # the sharp edges cut out whatever the blade can cut
    hurt = ~kill
    if hurt.any():
        jj = (idx[hurt, 0], idx[hurt, 1], idx[hurt, 2])
        add = np.full(int(hurt.sum()), AXE_BLUNT_CRACK)
        edge_hard = ~blunt[hurt]                            # an edge on something too hard to cut cracks it the old way
        add[edge_hard] = 0.7 * power / thr[hurt][edge_hard]
        o.cdmg[jj] = np.minimum(0.85, o.cdmg[jj] + add)
        if isinstance(o, Structure):
            o.cdmg_peak = max(o.cdmg_peak, float(o.cdmg[jj].max()))
    if isinstance(o, Structure):
        o.hot = np.asarray(hot, np.float64).copy()
        if kill.any():
            ik = idx[kill]
            lo_k, hi_k = ik.min(0), ik.max(0) + 1
            loc = np.zeros(tuple(int(v) for v in hi_k - lo_k), bool)
            loc[ik[:, 0] - lo_k[0], ik[:, 1] - lo_k[1], ik[:, 2] - lo_k[2]] = True
            o._remove(loc, (lo_k, hi_k))
        else:
            o.mesh_ver += 1
            o._note_dirty(idx.min(0), idx.max(0) + 1)
        o.stress_dirty = True
    elif kill.any():
        mask = np.zeros(o.alive.shape, bool)
        mask[idx[kill, 0], idx[kill, 1], idx[kill, 2]] = True
        o._remove(mask)
    return cc[kill], m[kill], True


def _bond_at(o, c, ax, sg):
    """Index into o.bond[ax] of the bond between cell c and its neighbour along axis ax (sg = +1 or -1), or None off the grid."""
    lo = list(c)
    if sg < 0:
        lo[ax] -= 1
    if lo[ax] < 0 or lo[ax] >= o.alive.shape[ax] - 1:
        return None
    return tuple(lo)


def _has_bond(o, c):
    for ax in range(3):
        for sg in (-1, 1):
            i = _bond_at(o, c, ax, sg)
            if i is not None and o.bond[ax][i]:
                return True
    return False


def _cell_near(o, P, toward, nearest=False):
    """The live cell of o that a contact at world point P presses on. `toward` points from P into o's material.
    nearest=True (used for the bench's ram and drop weight): when the four probes miss, as happens where a block presses on the rim of a hole it
    has just cut, take the live cell nearest the contact within one cell, so a sustained push still damages something instead of locking up."""
    cs = o.cs
    for k in (0.25, 0.0, -0.25, 0.6):
        q = ((P + toward * (k * cs) - o.frame_pos) @ o.R - o.corner) / cs
        ij = np.floor(q).astype(np.int64)
        if (ij >= 0).all() and (ij < np.array(o.alive.shape)).all() and o.alive[ij[0], ij[1], ij[2]]:
            return (int(ij[0]), int(ij[1]), int(ij[2]))
    if nearest:
        q = ((P + toward * (0.25 * cs) - o.frame_pos) @ o.R - o.corner) / cs
        base = np.floor(q).astype(np.int64)
        shape = np.array(o.alive.shape)
        best, bd = None, 1e9
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    ij = base + (dx, dy, dz)
                    if (ij >= 0).all() and (ij < shape).all() and o.alive[ij[0], ij[1], ij[2]]:
                        d = float(np.sum((ij + 0.5 - q) ** 2))
                        if d < bd:
                            best, bd = (int(ij[0]), int(ij[1]), int(ij[2])), d
        return best
    return None


class StructureManager:
    """Every structure and loose body in the world."""

    def __init__(self):
        self.structs = []
        self.bodies = []

    def clear(self):
        self.structs = []
        self.bodies = []
        self.extra_dirt = 0

    # ---- building -----------------------------------------------------------------------------------
    def ground_y(self, world, x, z):
        """Height of the top of the highest ground cube at column (x, z), or None if there is none (or it is not loaded)."""
        ix, iz = math.floor(x / CELL), math.floor(z / CELL)
        d = world.dens.get((ix // NC, iz // NC))
        if d is None:
            return None
        n = int(d.tops()[ix - (ix // NC) * NC, iz - (iz // NC) * NC])
        return float(n * CELL) if n > 0 else None

    def add(self, world, mat, x0, z0, cs=0.5):
        """Put a grid of materials (0 = empty) on the ground with its lowest corner at (x0, z0)."""
        nx, ny, nz = mat.shape
        y = self.ground_y(world, x0 + nx * cs * 0.5, z0 + nz * cs * 0.5)
        if y is None:
            return None
        st = Structure(np.asarray(mat, np.int16), np.array([x0, y, z0]), cs)
        st.refresh_anchors(world)
        self.structs.append(st)
        return st


    # ---- events -------------------------------------------------------------------------------------
    def wake_all(self):
        for b in self.bodies:
            b.wake()

    def _wake_bodies_near(self, centre, radius):
        """Wake only the loose bodies whose box comes within radius of centre."""
        c = np.asarray(centre, np.float64)
        for b in self.bodies:
            if b.asleep:
                lo, hi = b.aabb()
                if np.linalg.norm(np.clip(c, lo, hi) - c) <= radius:
                    b.wake()

    def _wake_region(self, centre, radius, column_up=0.0):
        """Wake the loose bodies and the debris cubes near one spot. Nothing outside the region is touched."""
        self._wake_bodies_near(centre, radius)
        BODIES.wake_sphere(centre, radius, column_up)


    def blast(self, world, centre, radius, power=1.0, shatter=False, throw=True, debris_normal=None):
        """Damage structures, push bodies, throw chunks. The caller draws the fireball. throw=False: what is destroyed is
        vaporised (the melting laser), so no chunks are thrown."""
        centre = np.asarray(centre, np.float64)
        self._wake_region(centre, radius * 2.0, column_up=radius * 3.0)
        broken = []
        for s in self.structs:
            lo, hi = s.aabb()
            if (centre < lo - radius).any() or (centre > hi + radius).any():
                continue
            kc, km = s.blast(centre, radius, power, shatter)
            for c, m in zip(kc, km):
                d = c - centre
                broken.append((1.0, c[0] - 0.5, c[1] - 0.5, c[2] - 0.5, int(m), d[0], d[1], d[2]))
            if len(kc) and throw:
                self._throw_chunks(kc, km, centre, radius, world=world, cs=s.cs, launch_normal=debris_normal)
        for b in self.bodies:
            b.blast(centre, radius, power)
            if np.linalg.norm(b.frame_pos - centre) < radius * 3:
                b.wake()
        centre = np.asarray(centre, np.float64)
        for b in list(self.bodies):                       # loose pieces take damage too, then split apart
            lo, hi = b.aabb()
            if (centre < lo - radius).any() or (centre > hi + radius).any():
                continue
            if b in self.bodies:                          # the cap may have turned it into debris already
                self._break_loose(world, b, centre, radius, power, shatter, debris_normal=debris_normal)
        return broken


    def _chips(self, world, pos, mats, centre, d):
        """Cubes cut out by the axe: each is pushed sideways out of the cut and a little along the swing, gently, then falls."""
        if not STRUCT_SHARDS:
            return
        pos, mats = np.asarray(pos), np.asarray(mats)
        if len(pos) > 80:
            sel = _rng.choice(len(pos), 80, replace=False)
            pos, mats = pos[sel], mats[sel]
        n = len(pos)
        rel = pos - centre
        along = rel @ d
        lat = rel - along[:, None] * d
        ln = np.maximum(np.linalg.norm(lat, axis=1, keepdims=True), 1e-6)
        t = np.clip(along / AXE_CUT_DEPTH, 0.0, 1.0)[:, None]      # 0 at the surface, 1 at the bottom of the cut
        # Momentum goes along the swing, so cubes near the surface leave that way. Deeper ones have uncut wood behind them, so
        # (as with a wedge-shaped blade) they are shoved out sideways instead of being driven into it. About 0.5 to 1.5 blocks/s.
        V = d * _rng.uniform(0.5, 1.5, (n, 1)) * (1.0 - t) + lat / ln * _rng.uniform(0.3, 0.8, (n, 1)) * (0.2 + 0.8 * t)
        V[:, 1] = np.minimum(V[:, 1], 0.0)                      # never upward: they fall
        col = _S_RGB[mats] * _rng.uniform(0.8, 1.1, (n, 1)).astype(np.float32)
        BODIES.spawn_chunks(pos, V, debris_cell_size(), col, world, material=mats)

    def _break_loose(self, world, body, centre, radius, power, shatter=False, debris_normal=None):
        """A blast or drill hit on a loose body: cells near the centre crack or are destroyed, then whatever is no
        longer connected breaks away."""
        kc, km = body.damage_at(centre, radius, power, shatter)
        self._finish_body(world, body, kc, km, centre, radius, debris_normal=debris_normal)

    def _finish_body(self, world, body, kc, km, centre, radius, debris_normal=None):
        """Throw out destroyed cells, split off pieces that are no longer connected, and keep the body count under
        the cap. Pieces split off a body topple away from the hit, like detached structure."""
        if len(kc):
            self._throw_chunks(kc, km, centre, radius, world=world, cs=body.cs, launch_normal=debris_normal)
        new, debris = _split_body(body)
        for child in new:
            child.topple(centre)
        for pos, mats in debris:
            self._throw_chunks(pos, mats, pos.mean(0), 1.5, slow=True, world=world, cs=body.cs)
        if not body.alive.any() and body in self.bodies:      # every cell was destroyed: the body is gone
            self.bodies.remove(body)
        self.bodies.extend(new)
        self._cap_bodies(world)

    def _cut_section(self, o, ax, k):
        """Break the bonds of cross-section k of body o along axis ax. With FRACTURE_JAGGED > 0 the crack does not stay in one flat
        layer: every column of cells is cut at its own height (k plus a smooth wandering offset), and the sideways bonds the crack steps over
        are cut too, so the two halves are still fully separated. The offsets come from a seed built from the body, so the same
        body breaks the same way every time."""
        ua, va = [a for a in range(3) if a != ax]
        perm = (ax, ua, va)
        M = o.bond[ax].transpose(perm)
        nl, nu, nv = M.shape
        amp = min(int(round(FRACTURE_JAGGED * (nl + 1))), FRACTURE_JAGGED_MAX)
        if amp < 1 or nu * nv < 4:
            M[k] = False
            return
        seed = (ax * 7919 + k * 104729 + int(o.alive.sum()) * 31 + nu * 1009 + nv) & 0x7fffffff
        rng = np.random.default_rng(seed)
        S = max(2, FRACTURE_PATCH)                                      # smooth wandering offset: random values on a coarse grid, blended
        coarse = rng.uniform(-amp, amp, size=(nu // S + 2, nv // S + 2))
        fu = np.arange(nu) / S
        fv = np.arange(nv) / S
        u0, v0 = np.floor(fu).astype(int), np.floor(fv).astype(int)
        tu = (fu - u0)[:, None]
        tv = (fv - v0)[None, :]
        tu = tu * tu * (3 - 2 * tu)
        tv = tv * tv * (3 - 2 * tv)
        c00, c10, c01, c11 = coarse[u0][:, v0], coarse[u0 + 1][:, v0], coarse[u0][:, v0 + 1], coarse[u0 + 1][:, v0 + 1]
        d = np.clip(np.rint((c00 * (1 - tu) + c10 * tu) * (1 - tv) + (c01 * (1 - tu) + c11 * tu) * tv), -amp, amp).astype(int)
        U, V = np.indices((nu, nv))
        p = np.clip(k + d, 0, nl - 1)
        p = np.where(M[p, U, V], p, k)                                  # no bond at the shifted height: cut where the plane is
        M[p, U, V] = False
        L = np.arange(nl + 1)[:, None, None]
        RU = o.bond[ua].transpose(perm)                                 # sideways bonds the crack steps over
        RU[(L >= (np.minimum(p[:-1], p[1:]) + 1)[None]) & (L <= np.maximum(p[:-1], p[1:])[None])] = False
        RV = o.bond[va].transpose(perm)
        RV[(L >= (np.minimum(p[:, :-1], p[:, 1:]) + 1)[None]) & (L <= np.maximum(p[:, :-1], p[:, 1:])[None])] = False

    def _stress_fracture(self, o, loads, scale):
        """Break a loose solid where the physics says it is overloaded. The contact forces (loads: point, force vector,
        cell) decelerate the body, so every cell needs an inertial force m*a (a = F/M plus the spin from the torque); the
        bonds across any cross-section have to carry the sum of those forces on one side of it. A section whose load per
        bond is past what the bonds hold lets go along its whole cross-section. Thin necks and weak glue go first; a
        stronger bond or a gentler landing breaks nothing. Nothing here is random."""
        T = bond_threshold()
        al = o.alive
        cells = np.argwhere(al)
        if len(cells) < 2 or not (0.0 < T < math.inf):
            return 0
        com = np.asarray(o.frame_pos, np.float64)
        Fext = np.zeros(3)
        tau = np.zeros(3)
        ext = np.zeros(al.shape + (3,))
        for P, Fv, c in loads:
            Fv = Fv * scale
            Fext += Fv
            tau += np.cross(P - com, Fv)
            ext[c] += Fv
        M = max(o.mass, 1e-9)
        a_lin = Fext / M
        alpha = o.Iinv @ tau
        r = o.R @ ((cells + 0.5) * o.cs + o.corner).T                # cell offsets from the centre of mass, in the world frame
        r = r.T
        m = o.cell_mass[al]
        acc = a_lin + np.cross(alpha, r)
        N = -ext
        N[al] += m[:, None] * acc                                     # what each cell needs, minus what the contact already supplies it
        k_mean = float(_S_BONDK[o.mat[al]].mean())
        cap = BOND_STRENGTH_K * T * k_mean * max(0.05, (o.cs / 0.5) ** 2)       # force one bond holds, in the same units as the contact force
        found = []
        for ax in range(3):
            if al.shape[ax] < 2:
                continue
            others = tuple(i for i in range(3) if i != ax)
            plane = np.cumsum(N.sum(axis=others), axis=0)[:-1]          # force across each cross-section, as a vector
            load = np.linalg.norm(plane, axis=1)
            nb = o.bond[ax].sum(axis=others)
            ok = nb > 0
            rho = np.where(ok, load / np.maximum(nb * cap, 1e-9), 0.0)
            for k in np.nonzero(rho >= 1.0)[0]:
                found.append((float(rho[k]), ax, int(k)))
        if not found:
            return 0
        found.sort(reverse=True)
        taken, cut = [], 0
        for rho, ax, k in found:
            if any(ax == ax2 and abs(k - k2) <= 1 for ax2, k2 in taken):
                continue                                                # neighbouring layers are the same crack
            self._cut_section(o, ax, k)
            taken.append((ax, k))
            cut += 1
            if cut >= FRACTURE_MAX_CUTS:
                break
        return cut

    def _apply_impacts(self, world, b):
        """Turn the hard contacts body b had this step into bond damage, the way the brick cannon does. Each contact presses on one
        cell of b and one cell of whatever it hit. R = force / (bond threshold x the material's factor). A cell takes
        BOND_DMG_PER_R x R damage; one with R >= 1 or full damage lets go (all its bonds break, its neighbours are cracked). In a loose
        body the freed cells are then split off by _split_body and fly on with the body's speed; in a fixed structure the cell is
        cut out, and the usual support check drops whatever it was holding up."""
        ev, b.impacts = b.impacts, []
        T = bond_threshold()
        if not ev or not (0.0 < T < math.inf):
            return 0, np.zeros(3)
        hits = {}
        for P, F, O, c_self, c_other, v, n_out in ev:
            for obj, cell in ((b, c_self), (O, c_other)):
                if obj is None or cell is None or getattr(obj, 'unbreakable', False) or (isinstance(obj, RigidBody) and obj.grace > 0.0):
                    continue
                if not obj.alive[cell]:                            # already gone (an earlier hit this pass, or it moved to another piece)
                    continue
                R = F / (T * float(_S_BONDK[obj.mat[cell]]) * max(0.05, (obj.cs / 0.5) ** 2))      # bonds hold in proportion to the face area of a brick
                if R < BOND_MIN_R:
                    continue
                h = hits.get((id(obj), cell))
                if h is None:
                    h = hits[(id(obj), cell)] = dict(obj=obj, cell=cell, rmax=0.0, rsum=0.0, P=P, v=v)
                h['rmax'] = max(h['rmax'], R)
                h['rsum'] += R
        if not hits:
            return 0, np.zeros(3)
        for e in hits.values():                                    # damage first
            o, c = e['obj'], e['cell']
            o.idmg[c] = min(1.2, float(o.idmg[c]) + BOND_DMG_PER_R * e['rsum'])
            o.cdmg[c] = max(float(o.cdmg[c]), min(0.85, 0.85 * float(o.idmg[c])))
            if isinstance(o, Structure):
                o.cdmg_peak = max(o.cdmg_peak, float(o.cdmg[c]))
        pos_l, mat_l, tint_l, vel_l, cs_l = [], [], [], [], []
        touched = {}
        broke = 0
        loads = {}
        nsub = max(1, int(getattr(b, 'nsub', STRUCT_SUBSTEPS)))
        for P, F, O, c_self, c_other, v, n_out in ev:                  # the contact forces on each loose solid, from this step
            for obj, cell, sgn in ((b, c_self, 1.0), (O, c_other, -1.0)):
                if isinstance(obj, RigidBody) and cell is not None and obj.grace <= 0.0 and not getattr(obj, 'unbreakable', False) and obj.alive[cell]:
                    loads.setdefault(id(obj), (obj, []))[1].append((np.asarray(P, np.float64), sgn * F * np.asarray(n_out, np.float64), cell))
        stress_hit = []
        for obj, items in loads.values():
            if int(obj.alive.sum()) >= FRACTURE_MIN_CELLS and obj.frac_cd <= 0.0 and len(self.bodies) < MAX_LOOSE_BODIES:
                if self._stress_fracture(obj, items, 1.0 / nsub):
                    obj.frac_cd = FRACTURE_COOLDOWN
                    touched[id(obj)] = obj
                    obj.wake()
                    broke += 1
        dp = np.zeros(3)                                           # momentum taken away by the cells let go from fixed structures
        for e in sorted(hits.values(), key=lambda q: -q['rmax']):
            if broke >= BOND_PER_STEP:
                break
            o, c = e['obj'], e['cell']
            if not o.alive[c] or not (e['rmax'] >= 1.0 or o.idmg[c] >= 1.0) or not _has_bond(o, c):
                continue
            if isinstance(o, RigidBody) and int(o.alive.sum()) >= FRACTURE_MIN_CELLS:
                continue                                           # a solid piece breaks by section stress (below), never by shedding cubes at the contact
            broke += 1
            nb_dmg = min(BOND_NEIGHBOUR_MAX, BOND_NEIGHBOUR_DMG * e['rmax'])
            for ax in range(3):
                for sg in (-1, 1):
                    i = _bond_at(o, c, ax, sg)
                    if i is None or not o.bond[ax][i]:
                        continue
                    q = list(c)
                    q[ax] += sg
                    q = tuple(q)
                    o.idmg[q] = min(0.9, float(o.idmg[q]) + nb_dmg)
                    o.cdmg[q] = max(float(o.cdmg[q]), min(0.85, 0.85 * float(o.idmg[q])))
                    if isinstance(o, RigidBody):
                        o.bond[ax][i] = False                      # a loose body keeps the cell until _split_body lets it go
            if isinstance(o, RigidBody):
                touched[id(o)] = o
                o.wake()
            else:
                pos = o.frame_pos + (np.array(c) + 0.5) * o.cs
                pos_l.append(pos)
                mat_l.append(int(o.mat[c]))
                tint_l.append(float(o.tint[c]))
                vel_l.append(np.asarray(e['v'], np.float64) * 0.6)
                dp += float(o.cell_mass[c]) * vel_l[-1]
                cs_l.append(o.cs)
                o.hot = np.asarray(e['P'], np.float64).copy()
                o._remove(np.ones((1, 1, 1), bool), (list(c), [c[0] + 1, c[1] + 1, c[2] + 1]))
        if not broke:
            return 0, dp
        if pos_l:
            self._release(world, np.array(pos_l), np.array(mat_l, np.int64), np.array(vel_l), np.array(tint_l))
        for o in touched.values():
            new, debris = _split_body(o, 30)                   # keep even small lumps as solid pieces; only crumbs become cubes
            for pos, mats in debris:
                self._release(world, pos, mats, o.velocity_at(pos))
            if not o.alive.any() and o in self.bodies:
                self.bodies.remove(o)
            for child in new:
                child.wake()
                child.frac_cd = FRACTURE_COOLDOWN
                d = np.asarray(child.frame_pos, np.float64) - np.asarray(o.frame_pos, np.float64)
                n = float(np.linalg.norm(d))
                if n > 1e-6 and child.mass >= 0.0:
                    u = d / n
                    tot = child.mass + o.mass
                    child.v = child.v + u * FRACTURE_PUSH * (o.mass / tot)
                    o.v = o.v - u * FRACTURE_PUSH * (child.mass / tot)
            self.bodies.extend(new)
        P0 = np.asarray(ev[0][0], np.float64)
        self._wake_region(P0, 1.5)
        SFX.crack(P0)
        self._cap_bodies(world)
        return broke, dp

    def _release(self, world, pos, mats, vel, tint=None):
        """Cells let go by an impact become loose cubes that carry on with the speed they had (plus a little scatter)."""
        if not STRUCT_SHARDS:
            return
        pos, mats, vel = np.asarray(pos, np.float64).reshape(-1, 3), np.asarray(mats), np.asarray(vel, np.float64).reshape(-1, 3)
        if len(pos) > 300:
            sel = _rng.choice(len(pos), 300, replace=False)
            pos, mats, vel = pos[sel], mats[sel], vel[sel]
            tint = None if tint is None else np.asarray(tint)[sel]
        col = _S_RGB[mats] * (1.0 if tint is None else np.asarray(tint, np.float32)[:, None])
        V = vel + _rng.normal(0.0, 0.8, vel.shape)
        BODIES.spawn_chunks(pos, V, debris_cell_size(), col, world, material=mats)

    def _cap_bodies(self, world):
        """Too many loose pieces: the smallest become debris, so the physics cost stays bounded."""
        while True:
            pool = [b for b in self.bodies if not getattr(b, 'is_tool', False)]
            if len(pool) <= MAX_LOOSE_BODIES:
                break
            small = min(pool, key=lambda b: int(b.alive.sum()))
            self.bodies.remove(small)
            pos, mats = _cells_to_debris(small, small.alive)
            if len(pos):
                self._throw_chunks(pos, mats, pos.mean(0), 1.5, slow=True, world=world, cs=small.cs)

    def _throw_chunks(self, pos, mats, centre, radius, slow=False, world=None, cs=0.5, launch_normal=None):
        if not STRUCT_SHARDS:
            return                                                # no cloud of loose cubes (see STRUCT_SHARDS)
        # A big hit at a high cube detail can break thousands of small cells at once; spawning a piece for each
        # of them bogs the frame down. Keep a random sample of them as debris and let the rest vanish.
        MAX_CHUNK_CELLS = 300
        pos, mats = np.asarray(pos), np.asarray(mats)
        count = MAX_CHUNK_CELLS if launch_normal is None else (2000 if STRUCT_DEBRIS_SPLIT <= 1 else MAX_CHUNK_CELLS // 8)
        if STRUCT_KEEP_ALL:
            count = len(pos)                                          # 'Delete cubes' is OFF: every destroyed cell becomes a cube
        if launch_normal is not None and BLAST_KEEP < 1.0:
            count = min(count, int(round(len(pos) * BLAST_KEEP)))           # incinerate the rest
            if count <= 0:
                return
        if len(pos) > count:
            sel = _rng.choice(len(pos), count, replace=False)
            pos, mats = pos[sel], mats[sel]
        if launch_normal is None:
            P = pos + _rng.uniform(-0.05, 0.05, pos.shape) * cs
        elif STRUCT_DEBRIS_SPLIT > 1:                         # old behaviour: every destroyed cell is thrown as eight half-size cubes
            offsets = (_CUBE_UNIT - 0.5) * (cs * 0.5)
            P = (pos[:, None, :] + offsets).reshape(-1, 3)
            mats = np.repeat(mats, len(offsets))
        else:
            P = pos + _rng.uniform(-BLAST_LATTICE_JITTER, BLAST_LATTICE_JITTER, pos.shape) * cs    # off the cell lattice: a perfect grid of cubes lands as a perfect grid of towers
        size = debris_cell_size()
        if launch_normal is not None and STRUCT_DEBRIS_SPLIT > 1:
            size *= 0.5
        d = P - centre
        dist = np.maximum(np.linalg.norm(d, axis=1, keepdims=True), 0.2)
        if launch_normal is None:
            speed = _rng.uniform(0.5, 2.0, (len(P), 1)) if slow else _rng.uniform(4.0, 12.0, (len(P), 1))
            V = d / dist * speed * (1.2 - 0.5 * np.minimum(dist / radius, 1.0))
            V[:, 1] = np.minimum(V[:, 1], 1.0)
        else:
            ln = np.asarray(launch_normal, np.float64)
            ln = ln / max(float(np.linalg.norm(ln)), 1e-9)
            speed = _rng.uniform(BLAST_SPEED[0], BLAST_SPEED[1], (len(P), 1))
            scatter = _rng.uniform(-1.0, 1.0, P.shape) * (BLAST_SPREAD * BLAST_SPRAY)
            scatter[:, 1] += BLAST_LIFT
            scatter -= (scatter @ ln)[:, None] * ln                  # sideways only: nothing along the normal
            side = d - (d @ ln)[:, None] * ln                          # offset from the blast centre across the wall face
            # Aim each cube along a DOME, not straight out of the surface. The further across the face a cell starts the more its
            # launch leans outward (BLAST_DOME, widened by the spread setting), and every cube gets a random lean of its own
            # (BLAST_JITTER). Without this the launch is within a few degrees of the surface normal, so a blast on flat ground
            # throws every cube straight up and each one falls back into the lattice column it was cut from: a field of towers.
            lateral = np.linalg.norm(side, axis=1, keepdims=True)
            outward = side / np.maximum(lateral, 1e-9)
            lean = outward * np.minimum(lateral / max(radius, 1e-6), 1.0) * (BLAST_DOME + BLAST_CONE * BLAST_SPRAY)
            wobble = _rng.normal(0.0, BLAST_JITTER, P.shape)
            wobble -= (wobble @ ln)[:, None] * ln                      # sideways only: the speed along the normal is left alone
            aim = ln + lean + wobble
            aim /= np.maximum(np.linalg.norm(aim, axis=1, keepdims=True), 1e-9)
            V = (speed * aim + scatter) * (1.0 - 0.25 * np.minimum(dist / radius, 1.0))
        col = _S_RGB[mats]
        if launch_normal is None:
            col = col * _rng.uniform(0.8, 1.1, (len(P), 1)).astype(np.float32)
        if launch_normal is not None and abs(launch_normal[1]) < 0.7:
            # Start wall fragments past the struck face. A launch from inside the
            # cavity can hit the intact rim immediately and lose its outward kick.
            # Preserve the spacing of the original depth layers so they can separate.
            normal_depth = (P - centre) @ launch_normal
            clearance = size * 0.5 * np.abs(launch_normal).sum() + 0.02
            out_depth = clearance + 1.10 * np.abs(normal_depth)
            P = P + (out_depth - normal_depth)[:, None] * launch_normal
            if BLAST_SQUEEZE != 1.0:
                # SQUEEZE: scale the pile towards (or away from) the blast axis and the struck face. Packed cubes overlap each other
                # and the solver then pushes them apart: that is the compress, decompress, blast-out.
                rel = P - centre
                dn = rel @ launch_normal
                lat = rel - dn[:, None] * launch_normal
                P = centre + lat * BLAST_SQUEEZE + (clearance + (dn - clearance) * BLAST_SQUEEZE)[:, None] * launch_normal
        BODIES.spawn_chunks(P, V, size, col, world, escape_normal=launch_normal, material=mats)

    def update(self, world, dt):
        dt = min(dt, 0.05)
        for s in list(self.structs):
            for pos, mats, tint in s.update(world, dt):
                centre = (pos.min(axis=0) + pos.max(axis=0)) * 0.5
                radius = float(np.linalg.norm(pos.max(axis=0) - centre)) + s.cs
                self._wake_region(centre, radius, column_up=1.0)
                SFX.collapse(centre, len(pos) * s.cs ** 3)
                if STRUCT_SHARDS:
                    velocity = _rng.uniform(-0.65, 0.65, pos.shape)
                    velocity[:, 1] = _rng.uniform(-0.6, 0.0, len(pos))
                    colour = _S_RGB[mats] * tint[:, None]
                    BODIES.spawn_chunks(pos, velocity, 0.95 * debris_cell_size(), colour, world, material=mats)
            if not s.alive.any():
                self.structs.remove(s)
        awake = [b for b in self.bodies if not b.asleep]
        nsub = max(1, STRUCT_SUBSTEPS - (len(awake) - 1) // 3)         # many moving pieces: fewer physics steps each, so the frame rate holds
        with Timed('structs.bodies', gpu=False):
            for b in awake:
                b.nsub = nsub
                if not b.alive.any():                       # emptied by an impact earlier in this pass
                    continue
                others = self.structs + [o for o in self.bodies if o is not b]
                b.step(world, dt, others)
        self.bodies = [b for b in self.bodies if b.frame_pos[1] > -30.0 and b.alive.any()]

    # ---- queries --------------------------------------------------------------------------------------
    def objects(self):
        return self.structs + self.bodies


    def hits_box(self, x, y, z, r, h):
        """True if the player's box at feet position (x, y, z) is inside a structure or a body."""
        if not (self.structs or self.bodies):
            return False
        lo_b = np.array([x - r, y, z - r])
        hi_b = np.array([x + r, y + h, z + r])
        P = None
        for o in self.objects():
            lo, hi = o.aabb()
            if (lo > hi_b).any() or (hi < lo_b).any():
                continue
            if P is None:
                P = np.array([[x + dx, ys, z + dz] for ys in (y + 0.05, y + 0.5 * h, y + h - 0.05)
                              for dx in (-r, 0.0, r) for dz in (-r, 0.0, r)])
            if len(o.probe(P)[0]):
                return True
        return False

    def raycast(self, origin, direction, reach, step=0.05):
        """First point along a ray that is inside a structure or body, or None. Returns (t, last point outside, object hit)."""
        best = None
        t = np.arange(0.0, reach, step)
        P = np.asarray(origin, np.float64) + np.outer(t, np.asarray(direction, np.float64))
        for o in self.objects():
            sel = o.probe(P)[0]
            if len(sel):
                k = int(sel.min())
                if best is None or k < best[0]:
                    best = (k, o)
        if best is None:
            return None
        k = best[0]
        return float(t[k]), P[max(k - 1, 0)], best[1]


STRUCTS = StructureManager()


def fire_cannon(world, origin, direction, n=CANNON_CELLS, speed=CANNON_SPEED, cs=0.5):
    """Fire a solid steel cube (n x n x n cells) from `origin` along `direction`. It is an ordinary loose body, so what it hits
    takes the impact: bonds that cannot hold the force let go (see StructureManager._apply_impacts)."""
    d = np.asarray(direction, np.float64)
    d = d / max(float(np.linalg.norm(d)), 1e-9)
    mat = np.full((n, n, n), STEEL, np.int16)
    body = RigidBody(mat, np.zeros(mat.shape, np.float32), np.ones(mat.shape, np.float32), cs, np.full(3, n * cs * 0.5))
    body.frame_pos = np.asarray(origin, np.float64) + d * (1.0 + n * cs)
    body.v = d * float(speed)
    body.w = _rng.normal(0.0, 0.4, 3)
    body.grace = 0.0
    body.unbreakable = True
    body.wake()
    STRUCTS.bodies.append(body)
    STRUCTS._cap_bodies(world)
    return body



# ---- trees ----------------------------------------------------------------------------------------------------














# ---- gameplay notifications -----------------------------------------------------------------------------------



























def _body_remove(self, kill):
    """A loose body loses cells. It is re-centred on its new centre of mass so its spin and inertia stay consistent,
    and it wakes up."""
    self.mat[kill] = 0
    self.cdmg[kill] = 0
    self.idmg[kill] = 0
    self._geometry()
    a = self.alive
    self.bond = [self.bond[0] & (a[:-1] & a[1:]), self.bond[1] & (a[:, :-1] & a[:, 1:]), self.bond[2] & (a[:, :, :-1] & a[:, :, 1:])]
    if self.alive.any():
        self.recentre()
        self.wake()


def _recentre(self):
    """Move the body's origin to its centre of mass without moving any cell in the world. The origin's velocity is
    adjusted to match, so the body's motion does not change."""
    idx = np.argwhere(self.alive)
    m = self.cell_mass[self.alive]
    local = (idx + 0.5) * self.cs + self.corner
    com = (m[:, None] * local).sum(0) / m.sum()
    shift = com @ self.R.T
    self.frame_pos = self.frame_pos + shift
    self.v = self.v + np.cross(self.w, shift)
    self.corner = self.corner - com
    self._aabb = None
    self._mass_props()
    self._sync()


def _body_damage(self, centre, radius, power, shatter=False):
    """A blast or drill hit on this loose body. Cells near the centre crack or are destroyed, using the same falloff
    and hardness rule as fixed structures. Returns (centres, materials) of the cells destroyed."""
    none = (np.zeros((0, 3)), np.zeros(0, np.int64))
    resistance = blast_bond_scale()
    if not math.isfinite(resistance) or getattr(self, 'unbreakable', False):
        return none
    idx = np.argwhere(self.alive)
    if not len(idx):
        return none
    local = (idx + 0.5) * self.cs + self.corner
    cc = self.frame_pos + local @ self.R.T
    dist = np.linalg.norm(cc - centre, axis=1)
    near = dist < radius
    if not near.any():
        return none
    idx, cc, dist = idx[near], cc[near], dist[near]
    self.wake()
    f = power * (1.0 - dist / radius) ** 2
    ii = (idx[:, 0], idx[:, 1], idx[:, 2])
    m = self.mat[ii]
    thr = _S_HARD[m] * STRUCT_SHATTER * resistance
    kill = f >= thr
    if shatter:
        kill = np.ones_like(kill)
    hurt = ~kill
    if hurt.any():
        jj = (idx[hurt, 0], idx[hurt, 1], idx[hurt, 2])
        self.cdmg[jj] = np.minimum(0.85, self.cdmg[jj] + 0.7 * f[hurt] / thr[hurt])
    killed_c, killed_m = cc[kill], m[kill]
    if kill.any():
        mask = np.zeros(self.alive.shape, bool)
        mask[idx[kill, 0], idx[kill, 1], idx[kill, 2]] = True
        self._remove(mask)
    return killed_c, killed_m


def _cells_to_debris(body, mask):
    """World positions and materials of the cells in mask, for throwing out as loose chunks."""
    idx = np.argwhere(mask)
    if not len(idx):
        return np.zeros((0, 3)), np.zeros(0, np.int64)
    local = (idx + 0.5) * body.cs + body.corner
    return body.frame_pos + local @ body.R.T, body.mat[mask].copy()


def _piece_of(body, piece):
    """A new rigid body made of the cells in piece, keeping the parent's pose and velocity."""
    child = RigidBody(np.where(piece, body.mat, 0), np.where(piece, body.cdmg, 0),
                      body.tint.copy(), body.cs, np.zeros(3))
    pr = [piece[:-1] & piece[1:], piece[:, :-1] & piece[:, 1:], piece[:, :, :-1] & piece[:, :, 1:]]
    child.bond = [bb & p for bb, p in zip(body.bond, pr)]       # the piece keeps exactly the bonds it had
    if getattr(body, 'family', None) is None:
        body.family = object()                                 # pieces broken off one body share a family
    child.family = body.family
    child.idmg = np.where(piece, body.idmg, 0).astype(np.float32)
    child.corner = body.corner.copy()
    child.frame_pos = body.frame_pos.copy()
    child.q = body.q.copy()
    child.v = body.v.copy()
    child.w = body.w.copy()
    child._sync()                      # R must follow q before recentre() uses it
    child.recentre()
    return child


def _split_body(body, min_cells=None):
    """Cells removed from a loose body can leave several pieces that no longer touch. The largest stays as `body`;
    each other piece becomes its own body, or debris if it is tiny. Returns (new bodies, debris), where debris is a
    list of (positions, materials) pairs."""
    alive = body.alive
    if not alive.any():
        return [], []
    pairs = [alive[:-1] & alive[1:], alive[:, :-1] & alive[:, 1:], alive[:, :, :-1] & alive[:, :, 1:]]
    bonds = [bb & p for bb, p in zip(body.bond, pairs)]          # cells are joined only where the body's bonds still stand
    lab = _label_cells(alive, bonds)
    labels = [int(L) for L in np.unique(lab[alive])]
    if len(labels) <= 1:
        return [], []
    sizes = {L: int((lab == L).sum()) for L in labels}
    main = max(labels, key=lambda L: sizes[L])
    if min_cells is None:
        min_cells = max(6, int(round(STRUCT_MIN_BODY_CELLS * (0.5 / body.cs) ** 3)))
    new_bodies, debris = [], []
    for L in labels:
        if L == main:
            continue
        piece = (lab == L) & alive
        if sizes[L] < min_cells:
            debris.append(_cells_to_debris(body, piece))
        else:
            new_bodies.append(_piece_of(body, piece))
    body._remove(alive & (lab != main))     # the pieces split off are now gone from the parent
    return new_bodies, debris


RigidBody._remove = _body_remove
RigidBody.recentre = _recentre
RigidBody.damage_at = _body_damage








_POST_VERT = """
#version 330 core
out vec2 vUV;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));   // one triangle that covers the screen
    vUV = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

_POST_DOWN = """
#version 330 core
in vec2 vUV;
out vec4 fragColor;
uniform sampler2D uTex;
uniform vec2 uTexel;      // one texel of the source
uniform float uThresh;    // brightness below which nothing glows (a very low value just copies and shrinks)
vec3 tap(vec2 uv) {
    vec3 c = texture(uTex, uv).rgb;
    float l = max(c.r, c.g * 0.9);                  // red/yellow weighted: fire, sparks and flashes glow, the blue sky and the grass do not
    return c * smoothstep(uThresh, uThresh + 0.18, l);
}
void main() {
    vec3 c = tap(vUV + uTexel * vec2(-0.5, -0.5)) + tap(vUV + uTexel * vec2(0.5, -0.5))
           + tap(vUV + uTexel * vec2(-0.5, 0.5)) + tap(vUV + uTexel * vec2(0.5, 0.5));
    fragColor = vec4(c * 0.25, 1.0);
}
"""

_POST_BLUR = """
#version 330 core
in vec2 vUV;
out vec4 fragColor;
uniform sampler2D uTex;
uniform vec2 uDir;        // one texel along the blur direction
void main() {
    vec3 c = texture(uTex, vUV).rgb * 0.227027027;
    c += texture(uTex, vUV + uDir * 1.3846153846).rgb * 0.3162162162;
    c += texture(uTex, vUV - uDir * 1.3846153846).rgb * 0.3162162162;
    c += texture(uTex, vUV + uDir * 3.2307692308).rgb * 0.0702702703;
    c += texture(uTex, vUV - uDir * 3.2307692308).rgb * 0.0702702703;
    fragColor = vec4(c, 1.0);
}
"""










# ═══════════════════════════════════════════════
#  PERFORMANCE HUD: frame and stage timing
# ═══════════════════════════════════════════════
DEBUG_ENABLED = False
DEBUG_STATS = {}

PROF_WINDOW = 240              # frames kept for every graph and average (4 s at 60 fps)

# CPU stages, in the order a frame runs them. PROF_TOP stages do not overlap and add up to the work time.
# PROF_SUB stages are parts of 'terrain' and are listed indented under it.
PROF_TOP = ['input', 'chunks', 'player', 'debris', 'structs', 'weapon', 'eject', 'terrain',
            'shadow', 'struct_draw', 'debris_draw', 'overlay', 'monitor', 'record', 'present', 'unload']
PROF_SUB = ['terrain.mesh', 'terrain.upload', 'terrain.list', 'terrain.collect', 'terrain.call']
# Parts of the debris stage ('debris'), timed inside BODIES.update(). They overlap each other, so they are not summed.
DEBRIS_SUB = ['debris.struct_push', 'debris.terrain_push', 'debris.move', 'debris.move.terrain',
             'debris.move.struct', 'debris.support', 'debris.separate', 'debris.terrain_fix']
STRUCTS_SUB = ['structs.check', 'structs.detach', 'structs.bodies']   # parts of the structs stage, timed inside STRUCTS.update()
PROF_FLIP = 'flip'


class Timed:
    """Times one stage of the frame. Always on the CPU; on the GPU too when gpu is True, with a timer query.
    GL runs one timer query at a time, so GPU stages must never nest."""
    __slots__ = ('name', 'gpu', 't0')

    def __init__(self, name, gpu=True):
        self.name = name
        self.gpu = gpu
        self.t0 = 0.0

    def __enter__(self):
        if self.gpu:
            GT.begin(self.name)
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        PROF.add(self.name, (time.perf_counter() - self.t0) * 1000.0)
        if self.gpu:
            GT.end()
        return False


class Profiler:
    """CPU milliseconds per stage for every frame, over the last PROF_WINDOW frames.
    A stage that did not run in a frame counts as zero, so averages stay honest."""

    def __init__(self):
        self.cur = {}
        self.hist = {name: collections.deque(maxlen=PROF_WINDOW) for name in PROF_TOP + PROF_SUB + DEBRIS_SUB + STRUCTS_SUB + [PROF_FLIP]}
        self.frame_ms = collections.deque(maxlen=PROF_WINDOW)
        self.work_ms = collections.deque(maxlen=PROF_WINDOW)

    def add(self, name, ms):
        self.cur[name] = self.cur.get(name, 0.0) + ms

    def push(self, frame_ms, work_ms):
        for name in self.cur:
            if name not in self.hist:
                self.hist[name] = collections.deque(maxlen=PROF_WINDOW)
        for name, dq in self.hist.items():
            dq.append(self.cur.get(name, 0.0))
        self.frame_ms.append(frame_ms)
        self.work_ms.append(work_ms)
        self.cur = {}


def _new_query():
    q = gl.glGenQueries(1)
    return int(q[0]) if hasattr(q, '__len__') else int(q)


def _query_elapsed_ms(q):
    # Explicit storage avoids PyOpenGL_accelerate's uint64 auto-allocation bug.
    from OpenGL.raw.GL.VERSION.GL_3_3 import glGetQueryObjectui64v
    value = ctypes.c_uint64()
    glGetQueryObjectui64v(q, gl.GL_QUERY_RESULT, ctypes.byref(value))
    return value.value / 1e6


class GpuTimers:
    """GPU milliseconds per stage, from GL_TIME_ELAPSED queries. Results arrive a frame or two late and are
    read only once available, so reading them never stalls the pipeline."""

    def __init__(self):
        self.enabled = False
        self.sample_this_frame = False
        self.next_sample = 0.0
        self.failed = False
        self.open_name = self.open_q = None
        self.frame = []
        self.pending = collections.deque()
        self.free = []
        self.frame_ms = collections.deque(maxlen=PROF_WINDOW)
        self.latest = {}
        self.latest_at = 0.0

    def begin(self, name):
        if not self.enabled or not self.sample_this_frame or self.failed or len(self.pending) >= 12 or self.open_q is not None:
            return
        try:
            q = self.free.pop() if self.free else _new_query()
            gl.glBeginQuery(gl.GL_TIME_ELAPSED, q)
            self.open_name, self.open_q = name, q
        except (GLError, NullFunctionError):
            self.failed = True

    def end(self):
        if self.open_q is None:
            return
        gl.glEndQuery(gl.GL_TIME_ELAPSED)
        self.frame.append((self.open_name, self.open_q))
        self.open_name = self.open_q = None










PROF = Profiler()
GT = GpuTimers()








_CUBE_UNIT = np.array([[(i >> 2) & 1, (i >> 1) & 1, i & 1] for i in range(8)], np.float64)














'''


if __name__ == '__main__':
    main()
